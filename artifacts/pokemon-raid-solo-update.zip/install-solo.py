from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, urllib.request
from datetime import datetime

root = Path(__file__).resolve().parent
app = Path('/opt/games-pokemon')
envfile = Path('/etc/games-party.env')
node = '/opt/node22/bin/node'
service = 'games-pokemon.service'
manifest = json.loads((root / 'solo-install-manifest.json').read_text())
for name, hashes in manifest.items():
    dest = app / name
    if not dest.is_file() or hashlib.sha256(dest.read_bytes()).hexdigest() not in hashes:
        raise SystemExit('停止：配置済みファイルに別の変更があります：' + name)
subprocess.run([node, str(root / 'tests/raid.test.cjs')], check=True)
for name in ['raid.cjs', 'server.cjs']:
    subprocess.run([node, '--check', str(root / 'connect-party/pokemon' / name)], check=True)
backup = Path('/root/games-pokemon-solo-backup-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
backup.mkdir(mode=0o700)
for name in manifest:
    target = backup / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(app / name, target)
had_env = envfile.exists()
if had_env:
    shutil.copy2(envfile, backup / 'games-party.env')
old_env = envfile.read_text() if had_env else ''
new_env = '\n'.join(line for line in old_env.splitlines() if not line.startswith('POKEMON_RAID_TEST_SOLO='))
new_env = new_env.rstrip('\n') + '\nPOKEMON_RAID_TEST_SOLO=1\n'
subprocess.run(['systemctl', 'stop', service], check=True)
try:
    for name in manifest:
        shutil.copyfile(root / 'connect-party/pokemon' / name, app / name)
    envfile.write_text(new_env)
    if not had_env:
        envfile.chmod(0o600)
    subprocess.run(['systemctl', 'start', service], check=True)
    settings = {}
    for path in [Path('/etc/games-hub.env'), envfile]:
        if path.exists():
            for line in path.read_text().splitlines():
                if '=' in line:
                    k, v = line.split('=', 1)
                    settings[k] = v.strip()
    port = int(settings.get('POKEMON_PORT') or 8501)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for attempt in range(15):
        try:
            with opener.open(f'http://127.0.0.1:{port}/api/health', timeout=2) as response:
                if json.load(response).get('ok'):
                    break
        except Exception:
            pass
        time.sleep(1)
    else:
        raise RuntimeError('起動確認が通りませんでした')
except Exception:
    subprocess.run(['systemctl', 'stop', service], check=False)
    for name in manifest:
        shutil.copy2(backup / name, app / name)
    if had_env:
        shutil.copy2(backup / 'games-party.env', envfile)
    else:
        envfile.unlink(missing_ok=True)
    subprocess.run(['systemctl', 'start', service], check=False)
    raise SystemExit('失敗したため元のファイルと設定に戻しました。バックアップ：' + str(backup))
print('ソロテスト設定を有効にしました。管理者限定は維持しています。')
print('バックアップ：' + str(backup))
print('Discordを開き直して、新しいレイドを募集してください。既存の部屋は3人設定のままです。')
