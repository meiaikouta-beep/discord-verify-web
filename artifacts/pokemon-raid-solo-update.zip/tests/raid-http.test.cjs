'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'raid-http-')),file=path.join(dir,'fixture.sqlite');
const db=new DatabaseSync(file,{enableForeignKeyConstraints:false});
db.exec(fs.readFileSync(path.join(__dirname,'bot-schema.sql'),'utf8'));
db.exec(`CREATE TABLE IF NOT EXISTS bot_settings(key TEXT PRIMARY KEY,value TEXT);
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate) VALUES ('S:3',3,3,'フシギバナ','grass',80,80,80,80,80,80,'final',255);
 INSERT INTO pokemon_evolution_rules(from_pokemon_key,to_pokemon_key) VALUES ('S:1','S:2'),('S:2','S:3');
 INSERT INTO pokemon_moves_master(move_id,name_en,name_ja,type,power,accuracy,pp,damage_class) VALUES (1,'tackle','たいあたり','normal',40,100,35,'physical');
 INSERT INTO pokemon_learnset(pokemon_key,move_id,learn_method,learn_level) VALUES ('S:3',1,'level-up',1);`);
for(let i=1;i<=3;i++) db.exec(`INSERT INTO users(guild_id,user_id) VALUES(1,${i}); INSERT INTO pokemon_user_groups(group_id,guild_id,user_id,group_name) VALUES(${i},1,${i},'チーム${i}'); INSERT INTO user_pokemon_owned(owned_id,guild_id,user_id,pokemon_key,species_id,level,max_hp,hp,attack,defense,sp_attack,sp_defense,speed) VALUES(${i},1,${i},'S:3',3,100,9999,9999,999,999,999,999,100); INSERT INTO pokemon_user_group_members(group_id,owned_id,slot) VALUES(${i},${i},1); INSERT INTO owned_pokemon_moves VALUES(${i},1,1);`);
db.close();
// テスト内だけ設定ファイルを注入する。実際の設定・資格情報は読み書きしない。
const original=fs.readFileSync,interval=global.setInterval;
fs.readFileSync=function(f,...args){if(f==='/etc/games-hub.env')return `DISCORD_CLIENT_ID=test\nDISCORD_BOT_TOKEN=test\nADMIN_USER_IDS=1,2,3\nPOKEMON_DB=${file}\nPOKEMON_RAID_TEST_SOLO=${process.env.RAID_SOLO_TEST==='1'?'1':'0'}\n`;if(f==='/etc/games-party.env')return '';return original.call(this,f,...args)};
global.setInterval=(...a)=>interval(...a).unref();
let S;try{S=require('../connect-party/pokemon/server.cjs')}finally{fs.readFileSync=original;global.setInterval=interval}
for(let i=1;i<=3;i++)S.sessions.set('test'+i,{uid:String(i),g:'1',name:'参加者'+i,exp:Date.now()+600000});
async function main(){
 await new Promise(resolve=>S.server.listen(0,'127.0.0.1',resolve));const port=S.server.address().port;
 const post=async(user,route,b={})=>{const r=await fetch(`http://127.0.0.1:${port}/api/${route}`,{method:'POST',headers:{'content-type':'application/json','x-session':'test'+user},body:JSON.stringify(b)});return {status:r.status,data:await r.json()}};
 assert.equal((await post(9,'raid')).status,401);
 let q=await post(1,'raid/create',{rank:1});assert.equal(q.status,200);let room=q.data.room;
 const act=async(u,type,more={})=>{const q=await post(u,'raid/action',{id:room.id,version:room.version,turn:room.turn,type,...more});assert.equal(q.status,200,JSON.stringify(q.data));room=q.data.room;};
 if(process.env.RAID_SOLO_TEST==='1') {
  assert.equal(room.requiredPlayers,1);await act(1,'party',{groupId:1});await act(1,'start');await act(1,'move',{idx:0});assert.equal(room.turn,2);
  console.log('PASS HTTP: configured solo mode, team load, start and one-player turn');return;
 }
 for(const u of [2,3])await act(u,'join');for(const u of [1,2,3])await act(u,'party',{groupId:u});
 assert.equal((await post(1,'team/delete',{groupId:1})).status,409);
 await act(1,'start');for(const u of [1,2,3])await act(u,'move',{idx:0});assert.equal(room.turn,2);
 if(process.env.RAID_BROWSER==='1') {
  const {chromium}=require('playwright');const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:420,height:860}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  // 実際のHTMLを読み、Discordログインだけを既存のテストセッションで置き換える。
  await page.route('**/api/login',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({session:'test1',me:{id:'1',name:'参加者1'},groups:[{id:1,name:'チーム1',members:[]}],regions:[],balls:{},money:0,gyms:[],rocket:[],badgeCount:0,trainerRegions:[],trainers:[]})}));
  await page.route(`http://127.0.0.1:${port}/`,route=>route.fulfill({status:200,contentType:'text/html',body:fs.readFileSync(path.join(__dirname,'../connect-party/pokemon/public/index.html'),'utf8').replace('login();\n})();', `window.__raidTest=()=>{sess='test1';H={groups:[{id:1,name:'チーム1',members:[]}],regions:[],balls:{},money:0};return raidOpen()};\n})();`)}));
  await page.goto(`http://127.0.0.1:${port}/`);
  await page.evaluate(()=>window.__raidTest());
  await page.waitForSelector('#raidView');await page.getByRole('button',{name:'たいあたり',exact:false}).waitFor();
  assert.equal(await page.locator('#raidView').count(),1);assert.equal(await page.locator('#raidView').evaluate(el=>el.scrollWidth<=el.clientWidth),true);
  await page.screenshot({path:path.join(dir,'raid-mobile.png'),fullPage:true});
  await page.getByRole('button',{name:'たいあたり',exact:false}).click();
  await page.waitForFunction(()=>document.querySelector('#raidView')?.textContent.includes('✅ 選択済'));
  room=(await post(1,'raid/action',{id:room.id,type:'status'})).data.room;
  for(const u of [2,3])await act(u,'move',{idx:0});
  await page.waitForFunction(()=>document.querySelector('#raidView')?.textContent.includes('ターン 3'));
  console.log('PASS browser move submission and polling synchronization');
  assert.deepEqual(errors,[]);await browser.close();console.log('PASS browser raid screen, move controls, mobile layout; screenshot '+path.join(dir,'raid-mobile.png'));
 }
 console.log('PASS HTTP: auth, 3 players, real bot schema, party load, mutation guard, synchronized turn');
}
main().then(()=>{S.server.close();S.db.close();}).catch(e=>{console.error(e);S.server.close();S.db.close();process.exit(1)});
