'use strict';
const test=require('node:test'), assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite');
const E=require('../connect-party/pokemon/engine.cjs'), {create}=require('../connect-party/pokemon/raid.cjs');
function fixture(){
 const db=new DatabaseSync(':memory:');
 db.exec(`CREATE TABLE bot_settings(key TEXT PRIMARY KEY,value TEXT);
 CREATE TABLE pokemon_master(pokemon_key TEXT PRIMARY KEY,species_id INT,display_name_ja TEXT,name_ja TEXT,type1 TEXT,type2 TEXT,base_hp INT,base_attack INT,base_defense INT,base_sp_attack INT,base_sp_defense INT,base_speed INT,is_mythical INT,is_legendary INT,is_mega INT,is_gmax INT,is_ultra_beast INT,evolution_stage TEXT,form_key TEXT,capture_rate INT,image_url TEXT,gender_rate INT,gender_lock TEXT,ability1_en TEXT,ability1_ja TEXT,ability2_en TEXT,ability2_ja TEXT,hidden_ability_en TEXT,hidden_ability_ja TEXT);
 CREATE TABLE pokemon_evolution_rules(from_pokemon_key TEXT,to_pokemon_key TEXT);
 CREATE TABLE pokemon_moves_master(move_id INT,name_en TEXT,name_ja TEXT,damage_class TEXT,power INT,type TEXT,accuracy INT,pp INT);
 CREATE TABLE pokemon_learnset(pokemon_key TEXT,move_id INT);
 CREATE TABLE user_pokemon_owned(owned_id INTEGER PRIMARY KEY,guild_id INT,user_id INT,pokemon_key TEXT,species_id INT,level INT,exp INT,gender TEXT,is_shiny INT,hp INT,max_hp INT,attack INT,defense INT,sp_attack INT,sp_defense INT,speed INT,iv_hp INT,iv_attack INT,iv_defense INT,iv_sp_attack INT,iv_sp_defense INT,iv_speed INT,image_url TEXT,obtained_type TEXT,caught_at INT,ability_en TEXT,ability_ja TEXT);
 CREATE TABLE user_pokemon_farm_deposits(owned_id INT);
 CREATE TABLE owned_pokemon_moves(owned_id INT,slot INT,move_id INT);
 CREATE TABLE user_pokedex(guild_id INT,user_id INT,pokemon_key TEXT,species_id INT,seen_count INT DEFAULT 0,caught_count INT DEFAULT 0,normal_caught INT DEFAULT 0,shiny_caught INT DEFAULT 0,first_seen_at INT,first_caught_at INT,PRIMARY KEY(guild_id,user_id,pokemon_key));
 INSERT INTO pokemon_master(pokemon_key,species_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,is_mythical,is_legendary,is_mega,is_gmax,is_ultra_beast,evolution_stage,capture_rate,gender_rate) VALUES ('S:3',3,'ボス','normal',80,80,80,80,80,80,0,0,0,0,0,'final',255,4);
 INSERT INTO pokemon_evolution_rules VALUES ('S:1','S:2'),('S:2','S:3');
 INSERT INTO pokemon_moves_master VALUES (1,'tackle','たいあたり','physical',40,'normal',100,35);
 INSERT INTO pokemon_learnset VALUES ('S:3',1);`);
 const all=(sql,...a)=>db.prepare(sql).all(...a),one=(sql,...a)=>db.prepare(sql).get(...a),run=(sql,...a)=>db.prepare(sql).run(...a);
 const tx=fn=>{db.exec('BEGIN');try{const r=fn();db.exec('COMMIT');return r;}catch(e){db.exec('ROLLBACK');throw e;}};
 const mkMove=m=>({id:m.move_id,en:m.name_en,name:m.name_ja,power:m.power,cls:m.damage_class,type:m.type,accuracy:m.accuracy,pp:m.pp,maxpp:m.pp,rules:[]});
 const wildMoves=()=>[mkMove(one('SELECT * FROM pokemon_moves_master'))];
 const users=['9007199254740993','9007199254740994','9007199254740995'];
 users.forEach((u,i)=>run('INSERT INTO user_pokemon_owned(owned_id,guild_id,user_id) VALUES (?,?,?)',i+1,1n,BigInt(u)));
 let now=1000000,randomValue=0;
 const ctx={all,one,run,tx,E,mkMove,wildMoves,monImg:()=>null,hasActiveBattle:()=>false,clock:()=>now,random:()=>randomValue,
 loadParty:(g,u,id)=>id===1?{party:[E.makeBattler({id:users.indexOf(String(u))+1,key:'S:3',name:'味方',type1:'normal',level:100,hp:9999,maxHp:9999,attack:100,defense:999,sp_attack:100,sp_defense:999,speed:100,moves:wildMoves()})]}:{error:'チームが見つかりません'}};
 let R=create(ctx);
 function call(room,u,type,extra={}){return R.action('1',u,u,{id:room.id,version:room.version,turn:room.turn,type,...extra});}
 function lobby(){let r=R.createRoom('1',users[0],'主',1).room;assert.ok(r);for(const u of users.slice(1)){const x=call(r,u,'join');assert.ifError(x.error);r=x.room;}for(const u of users){const x=call(r,u,'party',{groupId:1});assert.ifError(x.error);r=x.room;}return r;}
 return {db,ctx,users,one,all,run,call,lobby,get R(){return R},restart(){R=create(ctx)},advance(n){now+=n},random(n){randomValue=n}};
}
test('3人・権限・準備・同期・ボス2回行動・再起動',()=>{
 const f=fixture(),u=f.users;let r=f.lobby();assert.equal(r.players.length,3);
 assert.ok(f.call(r,'4','join').error);
 assert.ok(f.R.action('2',u[0],'主',{id:r.id,type:'status'}).error);
 assert.ok(f.call(r,u[1],'start').error);
 r=f.call(r,u[0],'start').room;assert.equal(r.phase,'battle');
 const first=r; r=f.call(r,u[0],'move',{idx:0}).room;assert.equal(r.turn,1);assert.ok(f.call(first,u[0],'move',{idx:0}).error);
 assert.ok(f.call(r,u[0],'move',{idx:0}).error);
 r=f.call(r,u[1],'move',{idx:0}).room;assert.equal(r.turn,1);
 r=f.call(r,u[2],'move',{idx:0}).room;assert.equal(r.turn,2);
 assert.equal(r.logs.filter(e=>e.t==='move'&&e.side==='e').length,2);
 assert.equal(r.players.filter(p=>p.chosen).length,0);
 f.restart();assert.equal(f.R.list('1',u[0]).room.turn,2);assert.equal(f.R.busy(u[0]),true);
 f.advance(120001);assert.equal(f.R.list('1',u[0]).room,null);assert.equal(f.R.busy(u[0]),false);f.db.close();
});
test('撃破→捕獲・保存・再送防止・再起動・図鑑',()=>{
 const f=fixture(),u=f.users;let r=f.lobby();r=f.call(r,u[0],'start').room;
 const raw=JSON.parse(f.one('SELECT state_json FROM web_raid_sessions WHERE id=?',r.id).state_json);raw.boss.hp=1;
 f.run('UPDATE web_raid_sessions SET state_json=? WHERE id=?',JSON.stringify(raw),r.id);f.restart();
 for(const uid of u){r=f.call(r,uid,'move',{idx:0}).room;}
 assert.equal(r.phase,'capture');assert.equal(r.players[0].balls,1);
 const stale=r,ret=f.call(r,u[0],'capture');assert.ifError(ret.error);assert.equal(ret.capture.success,true);r=ret.room;
 assert.ok(f.call(stale,u[0],'capture').error);
 assert.equal(f.one("SELECT COUNT(*) n FROM user_pokemon_owned WHERE obtained_type='raid_capture'").n,1);
 assert.equal(f.one('SELECT caught_count FROM user_pokedex').caught_count,1);
 f.restart();r=f.R.action('1',u[0],'主',{id:r.id,type:'status'}).room;assert.equal(r.players[0].caught,1);
 assert.ok(f.call(r,u[0],'capture').error);
 for(const uid of u.slice(1)){r=f.call(r,uid,'leave').room;}
 assert.equal(r.phase,'finished');assert.equal(f.R.busy(u[0]),false);f.db.close();
});
test('捕獲トランザクション失敗時はボールも個体も巻き戻す',()=>{
 const f=fixture(),u=f.users;let r=f.lobby();r=f.call(r,u[0],'start').room;
 const raw=JSON.parse(f.one('SELECT state_json FROM web_raid_sessions WHERE id=?',r.id).state_json);raw.phase='capture';raw.players.forEach(p=>p.balls=1);
 f.run('UPDATE web_raid_sessions SET state_json=? WHERE id=?',JSON.stringify(raw),r.id);f.restart();
 f.db.exec("CREATE TRIGGER fail_dex BEFORE INSERT ON user_pokedex BEGIN SELECT RAISE(ABORT,'test rollback'); END");
 assert.ok(f.call(r,u[0],'capture').error);
 assert.equal(f.one("SELECT COUNT(*) n FROM user_pokemon_owned WHERE obtained_type='raid_capture'").n,0);
 assert.equal(f.R.list('1',u[0]).room.players[0].balls,1);f.db.close();
});
test('募集期限・ランク無効・チーム未選択・離脱',()=>{
 const f=fixture(),u=f.users;
 f.run("INSERT INTO bot_settings VALUES ('raid_rank_disabled','1,6')");assert.ok(f.R.createRoom('1',u[0],'主',1).error);
 f.run('DELETE FROM bot_settings');let r=f.R.createRoom('1',u[0],'主',1).room;
 assert.ok(f.call(r,u[0],'start').error);assert.ok(f.R.createRoom('1',u[0],'主',1).error);
 r=f.call(r,u[1],'join').room;r=f.call(r,u[1],'leave').room;assert.equal(r.players.length,1);
 f.advance(600001);assert.equal(f.R.list('1',u[0]).room,null);f.db.close();
});
test('レイドボスの一撃必殺無効・継続ダメージ1/3',()=>{
 const f=fixture();let r=f.lobby();r=f.call(r,f.users[0],'start').room;
 const raw=JSON.parse(f.one('SELECT state_json FROM web_raid_sessions').state_json);
 const p=raw.players[0],b=p.party[0],events=[];const S={party:p.party,active:0,enemy:raw.boss,fld:raw.fld,sd:{p:p.sd,e:raw.bossSd}};
 const hp=raw.boss.hp;
 E.raidInternals.useMove(b,raw.boss,{name:'じわれ',pp:5,rules:[{effect_type:'ohko'}]},'p',events,S);assert.equal(raw.boss.hp,hp);
 raw.boss.status='poison';raw.boss.raidEndTurn=true;
 E.raidInternals.endTurn(raw.boss,'e',events,S,b);
 assert.equal(hp-raw.boss.hp,Math.max(1,Math.floor(Math.floor(raw.boss.maxHp/8)/3)));f.db.close();
});
test('戦闘離脱で全滅・捕獲失敗で消費・期限切れ復旧',()=>{
 const f=fixture(),u=f.users;let r=f.lobby();r=f.call(r,u[0],'start').room;
 for(const uid of u)r=f.call(r,uid,'leave').room;
 assert.equal(r.phase,'lost');assert.equal(f.R.busy(u[0]),false);
 r=f.lobby();r=f.call(r,u[0],'start').room;
 const raw=JSON.parse(f.one('SELECT state_json FROM web_raid_sessions WHERE id=?',r.id).state_json);raw.phase='capture';raw.master.capture_rate=1;raw.players.forEach(p=>p.balls=1);
 f.run('UPDATE web_raid_sessions SET state_json=? WHERE id=?',JSON.stringify(raw),r.id);f.restart();f.random(0.99);
 const ret=f.call(r,u[0],'capture');assert.ifError(ret.error);assert.equal(ret.capture.success,false);assert.equal(ret.room.players[0].balls,0);
 assert.equal(f.one("SELECT COUNT(*) n FROM user_pokemon_owned WHERE obtained_type='raid_capture'").n,0);
 f.advance(180001);f.restart();assert.equal(f.R.busy(u[1]),false);f.db.close();
});
test('明示設定時だけ1人で開始・行動・捕獲できる',()=>{
 const f=fixture(),u=f.users[0];let R=create({...f.ctx,soloTest:true});
 assert.equal(R.list('1',u).requiredPlayers,1);
 let r=R.createRoom('1',u,'主',1).room;assert.equal(r.requiredPlayers,1);
 const act=(type,extra={})=>{const ret=R.action('1',u,'主',{id:r.id,version:r.version,turn:r.turn,type,...extra});assert.ifError(ret.error);r=ret.room;return ret;};
 act('party',{groupId:1});act('start');assert.equal(r.phase,'battle');act('move',{idx:0});assert.equal(r.turn,2);
 const raw=JSON.parse(f.one('SELECT state_json FROM web_raid_sessions WHERE id=?',r.id).state_json);raw.boss.hp=1;
 f.run('UPDATE web_raid_sessions SET state_json=? WHERE id=?',JSON.stringify(raw),r.id);R=create({...f.ctx,soloTest:true});
 act('move',{idx:0});assert.equal(r.phase,'capture');act('capture');assert.equal(r.phase,'finished');assert.equal(r.players[0].caught,1);f.db.close();
});
test('ソロ設定をリクエストから指定しても通常設定は3人・旧部屋も3人',()=>{
 const f=fixture(),u=f.users[0];let r=f.R.createRoom('1',u,'主',1).room;
 assert.equal(r.requiredPlayers,3);r=f.call(r,u,'party',{groupId:1}).room;
 assert.ok(f.call(r,u,'start',{requiredPlayers:1,soloTest:true}).error);
 const raw=JSON.parse(f.one('SELECT state_json FROM web_raid_sessions WHERE id=?',r.id).state_json);delete raw.requiredPlayers;
 f.run('UPDATE web_raid_sessions SET state_json=? WHERE id=?',JSON.stringify(raw),r.id);
 const R=create({...f.ctx,soloTest:true});assert.equal(R.list('1',u).room.requiredPlayers,3);
 assert.ok(R.action('1',u,'主',{id:r.id,version:r.version,type:'start'}).error);f.db.close();
});
