#!/usr/bin/env python3
from __future__ import annotations

import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "games-casino"))

from server import baccarat, boatrace_purchase_idempotency, medal_bank, points, roulette, slot_authority  # noqa: E402


OWNER = "123456789:987654321"


class CasinoPointsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.points_path = base / "points.sqlite"
        pc = sqlite3.connect(self.points_path)
        pc.execute("CREATE TABLE points(server_id TEXT NOT NULL,user_id TEXT NOT NULL,points INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(server_id,user_id))")
        pc.execute("INSERT INTO points VALUES (?,?,?)", ("123456789", "987654321", 10_000))
        pc.commit(); pc.close()
        self.c = sqlite3.connect(base / "state.sqlite", isolation_level=None)
        self.c.row_factory = sqlite3.Row
        self.c.execute("ATTACH DATABASE ? AS pointsdb", (str(self.points_path),))
        self.c.execute("CREATE TABLE users(id TEXT PRIMARY KEY,name TEXT NOT NULL,slot_setting INTEGER,slot_day TEXT)")
        self.c.execute("CREATE TABLE inventory(owner TEXT NOT NULL,item TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(owner,item))")
        self.c.execute("INSERT INTO users(id,name) VALUES (?,?)", (OWNER, "Tester"))
        roulette.ensure_tables(self.c)
        baccarat.ensure_tables(self.c)
        medal_bank.migrate(self.c)
        slot_authority.migrate(self.c)

    def tearDown(self):
        self.c.close()
        self.tmp.cleanup()

    def balance(self):
        return points.balance(self.c, OWNER)

    def test_points_debit_is_atomic_and_scoped_to_guild(self):
        self.c.execute("BEGIN IMMEDIATE")
        self.assertTrue(points.debit(self.c, OWNER, 2_500))
        self.assertFalse(points.debit(self.c, OWNER, 8_000))
        self.c.commit()
        self.assertEqual(self.balance(), 7_500)
        with self.assertRaises(ValueError):
            points.debit(self.c, "bad-owner", 1)

    def test_roulette_duplicate_operation_and_server_payout(self):
        now = 1_000.0
        self.c.execute("BEGIN IMMEDIATE")
        roulette.place_bet(self.c, OWNER, None, [7], 100, "roulette-op-0001", now)
        roulette.place_bet(self.c, OWNER, None, [7], 100, "roulette-op-0001", now)
        rid = roulette.open_round(self.c)[0]
        self.assertEqual(self.balance(), 9_900)
        out = roulette.settle(self.c, rid, 7)
        self.c.commit()
        self.assertEqual(out["owners"][OWNER]["payout"], 3_600)
        self.assertEqual(self.balance(), 13_500)

    def test_baccarat_uses_points_and_pays_stake_plus_win(self):
        now = 2_000.0
        self.c.execute("BEGIN IMMEDIATE")
        baccarat.place_bet(self.c, OWNER, "player", 500, "baccarat-op-01", now)
        rid = baccarat.open_round(self.c)[0]
        out = baccarat.settle(self.c, rid, {"w": "P", "pp": False, "bp": False})
        self.c.commit()
        self.assertEqual(out["owners"][OWNER]["payout"], 1_000)
        self.assertEqual(self.balance(), 10_500)

    def test_slot_sand_roundtrip_and_authoritative_round(self):
        self.c.execute("BEGIN IMMEDIATE")
        slot_authority.runtime(self.c, OWNER)
        medal_bank.change(self.c, OWNER, "deposit_cash", 2_000, "deposit-op-001")
        medal_bank.change(self.c, OWNER, "lend", 1_000, "lend-op-000001")
        begin = slot_authority.begin(self.c, OWNER, "miss")
        self.assertEqual(begin["credit"], 43)
        result = slot_authority.settle(self.c, OWNER, begin["round_id"], [0, 0, 0], [])
        self.c.commit()
        self.assertFalse(result["won"])
        self.assertEqual(self.balance(), 8_000)
        self.assertIsNone(self.c.execute("SELECT 1 FROM pachi_rounds WHERE owner=?", (OWNER,)).fetchone())

    def test_member_card_exchange_returns_points(self):
        self.c.execute("BEGIN IMMEDIATE")
        slot_authority.runtime(self.c, OWNER)
        medal_bank.change(self.c, OWNER, "deposit_cash", 2_000, "deposit-op-002")
        medal_bank.change(self.c, OWNER, "lend", 1_000, "lend-op-000002")
        medal_bank.change(self.c, OWNER, "lend", 1_000, "lend-op-000003")
        medal_bank.change(self.c, OWNER, "insert_card", 0, "insert-op-0001")
        medal_bank.change(self.c, OWNER, "save", 50, "save-op-000001")
        medal_bank.change(self.c, OWNER, "eject_card", 0, "eject-op-0001")
        medal_bank.change(self.c, OWNER, "bank_exchange", 50, "exchange-op-01")
        self.c.commit()
        self.assertEqual(self.balance(), 9_000)

    def test_boat_purchase_request_is_idempotent(self):
        self.c.execute("CREATE TABLE fake_tickets(owner TEXT,amount INTEGER)")

        class League:
            @staticmethod
            def place_bets(c, owner, venue, date, race, items):
                amount = sum(x["amount"] for x in items)
                if not points.debit(c, owner, amount):
                    raise ValueError("ポイントが足りません")
                c.execute("INSERT INTO fake_tickets VALUES (?,?)", (owner, amount))
                return amount

        args = (self.c, League, OWNER, 1, "2026-11-04", 1, [{"kind": "tan1", "combo": "1", "amount": 100}], "boat-request-0001")
        first = boatrace_purchase_idempotency.purchase_once(*args)
        second = boatrace_purchase_idempotency.purchase_once(*args)
        self.assertFalse(first["replayed"])
        self.assertTrue(second["replayed"])
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM fake_tickets").fetchone()[0], 1)
        self.assertEqual(self.balance(), 9_900)
        self.assertEqual(boatrace_purchase_idempotency.purchase_status(self.c, OWNER, "boat-request-0001")["status"], "confirmed")


class IntegrationSourceTests(unittest.TestCase):
    def test_party_poker_is_casino_only(self):
        js = (ROOT / "party-public/party.js").read_text()
        html = (ROOT / "party-public/index.html").read_text()
        self.assertIn("CASINO_POKER", js)
        self.assertIn("k !== 'poker'", js)
        self.assertLess(html.index('src="poker-ui.js'), html.index('src="party.js'))

    def test_browser_currency_labels_are_points(self):
        for name in ("roulette_ui.js", "baccarat_ui.js", "boatrace_ui.js"):
            text = (ROOT / "games-casino/public" / name).read_text()
            self.assertNotIn("textContent = 'G'", text)
            self.assertNotIn("所持ゴールド", text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
