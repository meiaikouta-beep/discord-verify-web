// ============================================================
// Party Game（画面）：🎯 全員一致ゲーム / 🐺 ワードウルフ / 🎵 イントロドン
// ============================================================
(() => {
  'use strict';
  const BASE = location.pathname.replace(/\/[^/]*$/, '');   // 入口の中では '/party'
  const CASINO_POKER = new URLSearchParams(location.search).get('casino') === 'poker';
  if (CASINO_POKER) { document.title = 'TalkSurvivor Casino - Poker'; document.body.classList.add('casino-poker'); }
  const returnToCasino = () => {
    const q = new URLSearchParams(location.search); q.delete('casino');
    location.href = '/casino/' + (q.toString() ? '?' + q.toString() : '');
  };
  const $app = document.getElementById('app');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ALL_GAMES = {
    unanimous: { name: '全員一致ゲーム', img: 'unanimous.webp', desc: 'みんなの答えをそろえよう！', min: 2, steps: ['参加受付', 'お題えらび', '回答', '結果'] },
    wordwolf: { name: 'ワードウルフ', img: 'wordwolf.webp', desc: 'ひとりだけ違うお題の人を探せ', min: 3, steps: ['参加受付', 'お題確認', '話し合い', '投票', '結果'] },
    intro: { name: 'イントロドン', img: 'intro.webp', desc: '曲を聴いて曲名を当てよう', min: 1, steps: ['参加受付', '出題', '回答', '採点'] },
    poker: { name: 'ポーカー', img: 'poker.webp', desc: 'テキサスホールデム（2〜6人・ランク戦）', min: 2, steps: ['参加受付', '対戦', '精算'] },
  };
  const GAMES = Object.fromEntries(Object.entries(ALL_GAMES).filter(([k]) => CASINO_POKER ? k === 'poker' : k !== 'poker'));
  let st = null, me = null, view = CASINO_POKER ? 'poker' : 'title', ws = null, offset = 0, toastT = 0, aiOn = true, lastKey = '';
  const now = () => Date.now() + offset;   // サーバーの時計
  const toast = t => { const e = document.getElementById('toast'); e.textContent = t; e.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('on'), 2800); };
  const av = (id, avatar, cls = '') => avatar ? `<img class="av ${cls}" src="https://cdn.discordapp.com/avatars/${id}/${avatar}.png?size=128" alt="" onerror="this.outerHTML='<span class=&quot;av ${cls}&quot;>👤</span>'">` : `<span class="av ${cls}">👤</span>`;
  const memberAv = id => { const m = st?.members?.find(x => x.id === id); return m?.avatar || null; };

  // ============================================================
  // 音
  // ============================================================
  const bgm = new Audio('opening.mp3'); bgm.loop = true;
  let vol = 50; try { const v = localStorage.getItem('tsPartyVol'); if (v !== null && Number.isFinite(+v)) vol = +v; } catch {}
  const applyVol = () => { bgm.volume = (vol / 100) * 0.55; };
  applyVol();
  // ゲームごとのBGM（ゲーム画面に入ったらループ。対戦の本番中だけ止めて、終わったら続きから）
  const GBGM = {}; for (const k of ['unanimous', 'wordwolf', 'intro', 'poker']) { const a = new Audio('bgm-' + k + '.mp3'); a.loop = true; a.preload = 'auto'; GBGM[k] = a; }
  let gvol = 35; try { const v = localStorage.getItem('tsPartyGVol'); if (v !== null && Number.isFinite(+v)) gvol = +v; } catch {}
  const applyGVol = () => { for (const a of Object.values(GBGM)) a.volume = (gvol / 100) * 0.4; };
  applyGVol();
  function gbgmHold() {   // 止めておく場面か
    const s = st?.games?.[view]; if (!s) return false;
    if (view === 'wordwolf') return s.phase === 'talk';
    if (view === 'intro') return !(s.phase === 'lobby' || s.phase === 'select') || (introAudio && !introAudio.paused);   // 曲選択の画面だけ流す
    return false;
  }
  function gbgmTick() {
    for (const [k, a] of Object.entries(GBGM)) {
      const want = view === k && gvol > 0 && !gbgmHold();
      if (want && a.paused) a.play().catch(() => {}); else if (!want && !a.paused) a.pause();
    }
  }
  setInterval(gbgmTick, 150);
  const bgmOn = () => { if (view === 'title' && vol > 0 && bgm.paused) bgm.play().catch(() => {}); gbgmTick(); };
  addEventListener('pointerdown', bgmOn, true); addEventListener('keydown', bgmOn, true);
  let ac = null;
  const ctx = () => { try { ac ||= new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume(); } catch {} return ac; };
  function tone(f, d = .12, type = 'triangle', v = .14, at = 0, f2) {
    const c = ctx(); if (!c) return;
    const t = c.currentTime + at, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v * (vol / 100 * .8 + .25), t + .01); g.gain.exponentialRampToValueAtTime(.0005, t + d);
    o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + d + .05);
  }
  function noise(d = .3, v = .12, at = 0, hp = 800) {
    const c = ctx(); if (!c) return;
    const b = c.createBuffer(1, c.sampleRate * d, c.sampleRate), a = b.getChannelData(0);
    for (let i = 0; i < a.length; i++) a[i] = (Math.random() * 2 - 1) * (1 - i / a.length);
    const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    f.type = 'highpass'; f.frequency.value = hp; g.gain.value = v * (vol / 100 * .8 + .25);
    s.buffer = b; s.connect(f); f.connect(g); g.connect(c.destination); s.start(c.currentTime + at);
  }
  const sfx = {
    tap: () => tone(1300, .05, 'sine', .08),
    sel: () => { tone(880, .07); tone(1320, .09, 'triangle', .1, .05); },
    ok: () => { tone(660, .1); tone(990, .18, 'triangle', .14, .09); },
    ng: () => { tone(220, .22, 'square', .07); tone(170, .3, 'square', .07, .16); },
    fanfare: () => [523, 659, 784, 1046, 784, 1046].forEach((f, i) => tone(f, i > 3 ? .5 : .16, 'triangle', .16, i * .12)),
    drum: (n = 14) => { for (let i = 0; i < n; i++) noise(.06, .08 + i * .006, i * .07, 300); },
    stamp: () => { noise(.25, .35, 0, 60); tone(90, .3, 'sine', .3, 0, 50); },
    tick: () => tone(1800, .03, 'square', .05),
    beep: hi => tone(hi ? 1320 : 880, hi ? .5 : .18, 'square', .1),
    howl: () => tone(420, 1.4, 'sawtooth', .06, 0, 900),
    flip: () => noise(.08, .1, 0, 2000),
  };

  // ============================================================
  // 紙吹雪
  // ============================================================
  const cv = document.getElementById('confetti'), cg = cv.getContext('2d'); let parts = [], confRAF = 0;
  function confetti(n = 160, colors = ['#ffc531', '#ff4d5e', '#3b8cff', '#2fc26a', '#a35cff', '#ffffff']) {
    cv.width = innerWidth * devicePixelRatio; cv.height = innerHeight * devicePixelRatio;
    for (let i = 0; i < n; i++) parts.push({ x: Math.random() * cv.width, y: -20 - Math.random() * cv.height * .4, vx: (Math.random() - .5) * 6, vy: 2 + Math.random() * 5, r: Math.random() * 6.28, vr: (Math.random() - .5) * .3, s: (6 + Math.random() * 8) * devicePixelRatio, c: colors[i % colors.length], life: 0 });
    if (!confRAF) confRAF = requestAnimationFrame(step);
  }
  function step() {
    cg.clearRect(0, 0, cv.width, cv.height);
    parts = parts.filter(p => p.y < cv.height + 40 && p.life < 600);
    for (const p of parts) { p.x += p.vx; p.y += p.vy * devicePixelRatio; p.vy += .03; p.r += p.vr; p.life++; cg.save(); cg.translate(p.x, p.y); cg.rotate(p.r); cg.fillStyle = p.c; cg.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); cg.restore(); }
    confRAF = parts.length ? requestAnimationFrame(step) : 0;
  }

  // ============================================================
  // ログイン・通信
  // ============================================================
  async function login() {
    let hub = null; try { hub = JSON.parse(sessionStorage.getItem('tsHub') || 'null'); } catch {}
    if (!hub?.access_token) { $app.innerHTML = `<div class="stage"><div class="panel center"><h2>Talk Survivor online から開いてください</h2><button class="w" id="login-back">メニューへ</button></div></div>`; document.getElementById('login-back').onclick = () => CASINO_POKER ? returnToCasino() : location.href = '/' + location.search; return; }
    const inst = new URLSearchParams(location.search).get('instance_id') || hub.instanceId;
    try {
      const r = await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ access_token: hub.access_token, instanceId: inst }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'ログインできませんでした');
      me = j.me; aiOn = j.ai; connect(j.session);
    } catch (e) { $app.innerHTML = `<div class="stage"><div class="panel center"><h2>❌ ${esc(e.message)}</h2><div class="row c"><button onclick="location.reload()">もう一度</button><button class="w" id="login-back">メニューへ戻る</button></div></div></div>`; document.getElementById('login-back').onclick = () => CASINO_POKER ? returnToCasino() : location.href = '/' + location.search; }
  }
  let retry = 0;
  function connect(sess) {
    ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + BASE + '/ws?s=' + encodeURIComponent(sess));
    ws.onopen = () => { retry = 0; ping(); setTimeout(ping, 400); setTimeout(ping, 1200); };
    ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch { return; } onMsg(m); };
    ws.onclose = () => setTimeout(() => connect(sess), Math.min(8000, 600 * ++retry));
  }
  const sendG = (k, a, extra = {}) => { if (ws?.readyState === 1) ws.send(JSON.stringify({ t: 'g', k, a, ...extra })); };
  let bestRtt = 1e9;
  function ping() { if (ws?.readyState === 1) ws.send(JSON.stringify({ t: 'ping', c: Date.now() })); }
  setInterval(ping, 8000);
  function onMsg(m) {
    if (m.t === 'pong') { const rtt = Date.now() - m.c; if (rtt <= bestRtt * 1.5) { bestRtt = Math.min(bestRtt, rtt); offset = m.s - (m.c + rtt / 2); } return; }
    if (m.t === 'state') {
      const prev = st; st = m; aiOn = m.ai;
      if (view !== 'title') effects(prev?.games?.[view], st.games[view]);
      render();
    }
  }

  // ============================================================
  // 画面
  // ============================================================
  function goView(v) {
    if (v !== view) { introAudio?.pause(); clearTimeout(introStartT); clearTimeout(introStop); scheduled = ''; }   // 画面が変わったら曲を止める
    view = v; document.body.className = 't-' + v; lastKey = '';
    if (v === 'title') bgmOn(); else bgm.pause();
    gbgmTick();
    if (v === 'intro' && st?.games?.intro) { scheduleIntro(st.games.intro); if (st.games.intro.phase === 'judge') setTimeout(playAnswer, 300); }
    render(); $app.scrollTop = 0;
  }
  function render() {
    // 入力中の文字と、どこに入力していたかを残したまま描き直す
    const act = document.activeElement, actId = act?.id, sel = act && 'selectionStart' in act ? [act.selectionStart, act.selectionEnd] : null;
    const vals = {}; $app.querySelectorAll('input[id]').forEach(i => { vals[i.id] = i.value; });
    const s = view !== 'title' ? phaseOf(view) : null;
    const key = s ? `${view}|${s.phase}|${s.round || 0}|${s.busy ? 1 : 0}` : 'title';
    const fresh = key !== lastKey; lastKey = key;
    $app.innerHTML = view === 'title' ? titleHtml() : gameHtml(view, fresh);
    for (const [id, v] of Object.entries(vals)) { const i = document.getElementById(id); if (i) i.value = v; }
    if (actId) { const i = document.getElementById(actId); if (i) { i.focus(); try { if (sel) i.setSelectionRange(sel[0], sel[1]); } catch {} } }
    bind(); updRing();
    if (view === 'intro') setupViz();
  }
  const phaseOf = k => st?.games?.[k] || { phase: 'lobby', entrants: [] };
  const isHost = s => s.host === me?.id;
  const hostName = s => s.entrants?.find(e => e.id === s.host)?.name || '';
  const chip = (e, extra = '', cls = '') => `<span class="chip ${cls}">${av(e.id, e.avatar)}${esc(e.name)}${extra}</span>`;

  function titleHtml() {
    const people = (st?.members || []).map(m => `<span class="pill">${av(m.id, m.avatar)}${esc(m.name)}</span>`).join('');
    return `<div class="bar"><button class="ghost" data-act="hub">🏠 メニューへ戻る</button><span class="sp"></span><span class="pill" style="padding:8px 14px">🎵 <input id="vol" type="range" min="0" max="100" value="${vol}"></span></div>
      <img class="logo" src="logo.webp" alt="Party Game">
      <div class="games">${Object.entries(GAMES).map(([k, g]) => { const s = st?.games?.[k]; const n = (s?.entrants || []).filter(e => e.online).length;
        const badge = !s || !n ? '' : s.phase === 'lobby' ? `<span class="badge wait">👥 ${n}人 参加受付中</span>` : s.phase === 'final' ? '<span class="badge wait">🏁 結果発表中</span>' : `<span class="badge">● ${n}人 プレイ中</span>`;
        return `<div class="gcard" data-go="${k}">${badge}<img src="${g.img}" alt=""><div class="lab"><b>${g.name}</b><small>${g.desc}</small></div></div>`; }).join('')}</div>
      <div class="here">この部屋にいる人</div><div class="people">${people}</div>
      ${aiOn ? '' : '<div class="people"><span class="pill" style="padding:8px 14px">⚠️ AI のキーがまだ登録されていないので、お題は用意してあるものから出ます</span></div>'}`;
  }
  function gameHtml(k, fresh) {
    const s = phaseOf(k), g = GAMES[k];
    const inGame = s.entrants?.some(e => e.id === me?.id);
    const stepIdx = { unanimous: { lobby: 0, pick: 1, answer: 2, judging: 3, reveal: 3 }, wordwolf: { lobby: 0, prep: 1, check: 1, talk: 2, vote: 3, decide: 4, final: 4 }, intro: { lobby: 0, select: 1, answer: 2, judge: 3, reveal: 3, final: 3 }, poker: { lobby: 0, hand: 1, result: 1, final: 2 } }[k][s.phase] ?? 0;
    if (k === 'poker' && s.phase !== 'lobby') return `<div class="bar pk-bar"><button class="ghost" data-act="back">◀ ${CASINO_POKER ? 'カジノへ' : 'ゲーム選択へ'}</button><span class="sp"></span><span class="pill" style="padding:8px 14px">🎵 <input id="gvol" type="range" min="0" max="100" value="${gvol}"></span>${s.phase === 'final' && isHost(s) ? '<button class="ghost" data-act="reset">⏹ 参加受付に戻す</button>' : ''}</div>` + window.PokerUI.html(s, !inGame, fresh);
    let body;
    if (s.busy) body = `<div class="busy"><div class="spin"></div>${esc(s.busy)}</div>`;
    else if (s.phase === 'lobby') body = lobbyHtml(k, s);
    else if (k === 'poker') body = '';
    else body = (!inGame ? '<div class="msg">いまゲーム中です。次の参加受付から加われます（観戦中）</div>' : '') + ({ unanimous: unHtml, wordwolf: wwHtml, intro: inHtml }[k])(s, !inGame);
    return `<div class="bar"><button class="ghost" data-act="back">◀ ${CASINO_POKER ? 'カジノへ' : 'ゲーム選択へ'}</button><span class="sp"></span><span class="pill" style="padding:8px 14px">🎵 <input id="gvol" type="range" min="0" max="100" value="${gvol}"></span>${s.phase !== 'lobby' && isHost(s) ? '<button class="ghost" data-act="reset">⏹ 参加受付に戻す</button>' : ''}</div>
      <div class="ghead"><img src="${g.img}" alt=""><div><h1>${g.name}</h1><div class="steps">${g.steps.map((t, i) => `<span class="${i === stepIdx ? 'on' : ''}">${i + 1}. ${t}</span>`).join('')}</div></div></div>
      <div class="stage">${s.deadline ? '<div class="ring" id="ring"><svg viewBox="0 0 100 100"><circle class="bg" cx="50" cy="50" r="42"/><circle class="fg" cx="50" cy="50" r="42"/></svg><b></b></div>' : ''}
        <div class="panel ${fresh ? 'anim' : ''}">${s.msg ? `<div class="msg">${esc(s.msg)}</div>` : ''}${body}</div></div>`;
  }
  // 残り時間の円（描き直さずに毎回の表示だけ更新）
  let ringTotal = {}, lastTick = 0;
  function updRing() {
    const el = document.getElementById('ring'); if (!el || view === 'title') return;
    const s = phaseOf(view); if (!s.deadline) return;
    const key = view + s.phase + s.deadline;
    ringTotal[key] ||= Math.max(1, (s.deadline - now()) / 1000);
    const left = Math.max(0, (s.deadline - now()) / 1000), C = 2 * Math.PI * 42;
    const fg = el.querySelector('.fg'); fg.style.strokeDasharray = C; fg.style.strokeDashoffset = C * (1 - left / ringTotal[key]);
    const sec = Math.ceil(left);
    el.querySelector('b').textContent = sec >= 60 ? `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}` : sec;
    el.classList.toggle('warn', sec <= 15 && sec > 5); el.classList.toggle('danger', sec <= 5);
    if (sec <= 5 && sec > 0 && sec !== lastTick) { lastTick = sec; sfx.tick(); }
  }
  setInterval(updRing, 250);

  // ---------- 参加受付（3つ共通） ----------
  const pickVal = {};   // 設定の選択（ホストの画面）
  const seg = (id, opts, def) => { pickVal[id] ??= def; return `<div class="seg">${opts.map(([v, l]) => `<button data-seg="${id}" data-v="${v}" class="${String(pickVal[id]) === String(v) ? 'on' : ''}">${l}</button>`).join('')}</div>`; };
  function lobbyHtml(k, s) {
    const joined = s.entrants.some(e => e.id === me?.id), g = GAMES[k];
    const rules = {
      unanimous: '① GM（順番に交代）が、AI の考えた4つのお題から1つ選びます<br>② 全員が答えを入力。<b>全員の答えがそろえば成功！</b>（ひらがな・漢字の違いや、同じものを指す言い方は AI がそろえて判定します）<br>③ 何回連続でそろえられるか挑戦しよう',
      wordwolf: '① 一人ひとりにお題が配られます。<b>少数派（ワードウルフ）だけ少し違うお題</b>です<br>② お題をそのまま言わずに VC で話し合い<br>③ 時間が来たら怪しい人に投票。<b>いちばん票を集めた人は脱落</b>して、お題が公開されます<br>④ 少数派を全員見つければ市民の勝ち。逃げられたら延長戦か終了を選べます',
      intro: '① GM（順番に交代）が年代とジャンルを選んで出題。<b>3・2・1 のあと全員の画面で同時に曲が流れます</b><br>② 曲名を入力して「ドン！」<br>③ 最初に正解した人 <b>2点</b>、ほかの正解者 <b>1点</b>、正解者が1人だけなら <b>3点</b><br>④ 目標点に先に届いた人の優勝',
      poker: '① 2〜6人で遊ぶ <b>ノーリミット テキサスホールデム</b>。全員同じチップから始めます（コインは使いません）<br>② 手札2枚＋場の5枚で、いちばん強い5枚の役を作った人がポットを獲得<br>③ フォールド／チェック／コール／レイズ／オールインで勝負。持ち時間を過ぎると自動でチェック（できなければフォールド）<br>④ 最後の1人になるか、ホストが精算すると終了。<b>順位でランクポイントが増減</b>し、ランクとバッジが上がります（5ハンド未満の精算は練習扱い）',
    }[k];
    const settings = !isHost(s) ? `<p class="muted center">👑 ホスト（${esc(hostName(s)) || '最初に参加した人'}）が開始するのを待っています…</p>` : `<div class="stack">${({
      unanimous: `<div class="row"><span class="lbl">回答の時間</span>${seg('un-sec', [[30, '30秒'], [60, '60秒'], [90, '90秒'], [0, 'なし']], 60)}</div>`,
      wordwolf: `<div class="row"><span class="lbl">少数派の人数</span>${seg('ww-wolves', [[1, '1人'], [2, '2人'], [3, '3人']], 1)}</div><div class="row"><span class="lbl">話し合い</span>${seg('ww-min', [[3, '3分'], [4, '4分'], [5, '5分'], [6, '6分'], [10, '10分']], 3)}</div>`,
      intro: `<div class="row"><span class="lbl">目標点</span>${seg('in-target', [[10, '10点'], [20, '20点'], [30, '30点'], [50, '50点']], 10)}</div>`,
      poker: `<div class="row"><span class="lbl">初期チップ</span>${seg('pk-stack', [[2000, '2,000'], [3000, '3,000'], [5000, '5,000'], [10000, '10,000']], s.stack || 3000)}</div><div class="row"><span class="lbl">ブラインド</span>${seg('pk-bb', [[50, '25/50'], [100, '50/100'], [200, '100/200']], s.bb0 || 100)}</div><div class="row"><span class="lbl">ブラインド上昇</span>${seg('pk-up', [[0, 'なし'], [3, '3ハンドごと'], [5, '5ハンドごと'], [10, '10ハンドごと']], s.up ?? 5)}</div><div class="row"><span class="lbl">持ち時間</span>${seg('pk-sec', [[20, '20秒'], [30, '30秒'], [45, '45秒'], [60, '60秒']], s.sec || 30)}</div>`,
    }[k])}<div class="row c"><button class="y big" data-g="start" ${s.entrants.length < g.min ? 'disabled' : ''}>▶ ゲーム開始（${s.entrants.length}人）</button></div>${s.entrants.length < g.min ? `<p class="muted center">${g.min}人以上で始められます</p>` : ''}</div>`;
    return `<div class="row" style="justify-content:space-between"><h2>👥 参加受付 <small class="muted">${s.entrants.length}/${s.max || 8}人</small></h2>${joined ? '<button class="w" data-g="leave">参加をやめる</button>' : ''}</div>
      <div class="chips" style="margin-bottom:16px">${s.entrants.map(e => chip(e, e.id === s.host ? ' <span class="crown">👑</span>' : '')).join('') || '<span class="muted">まだだれもいません。最初に参加した人がホストになります</span>'}</div>
      ${joined ? settings : `<div class="row c"><button class="g big" data-g="join" ${s.entrants.length >= (s.max || 8) ? 'disabled' : ''}>🙋 参加する</button></div>`}
      ${k === 'poker' ? window.PokerUI.lobbyExtra(s) : ''}
      <div class="rules" style="margin-top:20px"><b>📗 あそびかた</b><br>${rules}</div>`;
  }

  // ============================================================
  // 🎯 全員一致ゲーム
  // ============================================================
  function unHtml(s, watch) {
    const gm = s.entrants.find(e => e.id === s.gm) || {};
    const stats = `<div class="stats"><span class="stat">第 <b>${s.round}</b> 問</span><span class="stat">🎩 GM ${esc(gm.name || '')}</span><span class="stat">🔥 連続 <b>${s.streak}</b></span><span class="stat">🏆 最高 <b>${s.best}</b></span><span class="stat">✅ ${s.success}/${s.total}</span></div>`;
    if (s.phase === 'pick') {
      if (s.gm === me?.id && !watch) return `${stats}<h2 class="center">お題を1つえらんでください</h2>
        <div class="topics">${s.topics.map((t, i) => `<button class="topic" data-g="pick" data-i="${i}">${esc(t)}</button>`).join('')}</div>
        <div class="row" style="margin-top:16px"><input type="text" id="un-custom" placeholder="自分でお題を書く（例：夏の食べ物といえば？）" maxlength="60" style="flex:1;min-width:220px;font-size:17px"><button class="w" data-g="pickCustom">これにする</button><button class="ghost" data-g="reroll">🔄 作り直す</button></div>`;
      return `${stats}<div class="busy"><div class="spin"></div>🎩 ${esc(gm.name || '')} さんがお題をえらんでいます…</div>`;
    }
    if (s.phase === 'answer') {
      return `${stats}<div class="scroll"><div class="lab">お　題</div><div class="q">${esc(s.topic)}</div></div>
        ${watch ? '' : `<div class="tanzaku"><input type="text" id="un-ans" maxlength="40" placeholder="みんなと同じになりそうな答え"><button class="r" data-g="answer">${s.mine != null ? '書き直す' : '送信'}</button></div>
        ${s.mine != null ? `<p class="muted center">送信した答え：<b>${esc(s.mine)}</b>（締め切りまで書き直せます）</p>` : '<p class="muted center">ひらがな・漢字の違いは気にしなくて大丈夫！</p>'}`}
        <div class="chips c" style="margin-top:14px">${s.entrants.map(e => chip(e, s.answered.includes(e.id) ? ' ✅' : ' ✍️', s.answered.includes(e.id) ? 'ok' : '')).join('')}</div>
        <p class="muted center">${s.answered.length}/${s.entrants.length}人が回答</p>
        ${s.gm === me?.id ? '<div class="row c"><button class="ghost" data-g="openNow">締め切って結果発表</button></div>' : ''}`;
    }
    if (s.phase === 'judging') return `${stats}<div class="scroll"><div class="lab">お　題</div><div class="q">${esc(s.topic)}</div></div><div class="busy"><div class="spin"></div>🥁 答えを照らし合わせています…</div>`;
    if (s.phase === 'reveal' && s.result) {
      const r = s.result, many = r.groups.length > 1;
      return `${stats}<div class="scroll" style="padding:14px 20px"><div class="q" style="font-size:clamp(20px,3.6vw,30px)">${esc(s.topic)}</div></div>
        <div class="answers" id="un-cards">${r.groups.map((g, i) => `<div class="acard ${many && i > 0 ? 'odd' : ''}" style="animation-delay:${i * .35}s"><b>${esc(g.text)}</b>${g.texts && g.texts.length > 1 ? `<div class="alt">（${g.texts.map(esc).join('・')}）</div>` : ''}<small>${g.names.map(esc).join('、')}</small></div>`).join('')}</div>
        <div id="un-stamp" style="opacity:0">${r.all ? `<div class="hanko">全員一致</div>${r.forced ? '<p class="muted center">GM の判断で一致にしました</p>' : ''}` : `<div class="hanko ng">${r.lone ? `${esc(r.lone)} さんだけ違った！` : '不一致…'}</div>`}</div>
        ${r.ai ? '<p class="muted center">🤖 ひらがな・漢字の違いや、同じものを指す答えは AI がまとめて判定しました</p>' : ''}
        <div class="row c" style="margin-top:12px">${!r.all && s.gm === me?.id ? '<button class="w" data-g="forceMatch">🙆 これは一致にする</button>' : ''}${(s.gm === me?.id || isHost(s)) && !watch ? '<button class="y big" data-g="next">▶ 次のお題へ</button>' : '<span class="muted">GM が次のお題へ進めます</span>'}</div>`;
    }
    return '';
  }

  // ============================================================
  // 🐺 ワードウルフ
  // ============================================================
  let cardOpen = false; const votePick = new Set();
  function wwHtml(s, watch) {
    const out = new Set(s.out || []), alive = s.entrants.filter(e => !out.has(e.id)), amOut = out.has(me?.id);
    const head = `<div class="chips c" style="margin-bottom:10px"><span class="chip plain">🐺 少数派 ${s.wolves}人</span><span class="chip plain">⏱ ${s.minutes}分</span><span class="chip plain">👥 残り ${alive.length}人</span>${(s.round || 1) > 1 ? `<span class="chip plain" style="background:#ff3448;color:#fff">🔥 延長戦 ${s.round - 1}</span>` : ''}</div>`;
    const card = !watch && s.myWord ? `<div class="wcard ${cardOpen ? 'open' : ''}" data-act="card"><div class="in"><div class="f">🌕<span>タップしてお題を見る</span></div><div class="b"><small>あなたのお題</small><b>${esc(s.myWord)}</b><small>タップでかくす</small></div></div></div>` : '';
    if (s.phase === 'check') return `${head}<h2 class="center">🎴 お題が配られました</h2>${card}
      <p class="muted center">自分のお題を確認してください。<b>自分が少数派かどうかは分かりません。</b><br>話し合いでは、お題そのものを言わないように！</p>
      ${isHost(s) ? '<div class="row c"><button class="y big" data-g="talk">▶ 話し合いスタート</button></div>' : '<p class="muted center">ホストが話し合いを始めるのを待っています…</p>'}`;
    if (s.phase === 'talk') return `${head}<div class="moon">💬</div><h2 class="center" style="margin-top:14px">${(s.round || 1) > 1 ? '延長戦！ もう一度話し合おう' : 'VC で話し合い中'}</h2>
      ${amOut ? '<p class="muted center">あなたは脱落しました。話し合いを見守ってください</p>' : card}
      <div class="chips c">${s.entrants.map(e => chip(e, '', out.has(e.id) ? 'out' : '')).join('')}</div>
      ${isHost(s) ? '<div class="row c" style="margin-top:14px"><button class="ghost" data-g="toVote">投票へ進む</button></div>' : ''}`;
    if (s.phase === 'vote') {
      const done = s.voted.includes(me?.id), need = s.need || s.wolves;
      return `${head}<h2 class="center">🗳️ 怪しいと思う人を <span style="color:#ff6b7a">${need}人</span> えらぼう</h2>
        ${watch || amOut ? '<p class="muted center">投票を見守っています…</p>' : done ? '<p class="muted center">投票しました。みんなを待っています…</p>' : `<div class="people-grid">${alive.filter(e => e.id !== me?.id).map((e, i) => `<button class="pcard ${votePick.has(e.id) ? 'sel' : ''}" data-act="vpick" data-id="${e.id}" style="animation-delay:${i * .05}s">${av(e.id, e.avatar, 'lg')}<b>${esc(e.name)}</b></button>`).join('')}</div>
        <div class="row c"><button class="r big" data-act="vsend" ${votePick.size !== need ? 'disabled' : ''}>🐺 この人に投票</button></div>`}
        <div class="chips c" style="margin-top:14px">${alive.map(e => chip(e, s.voted.includes(e.id) ? ' ✅' : ' 🤔', s.voted.includes(e.id) ? 'ok' : '')).join('')}</div>
        ${isHost(s) ? '<div class="row c" style="margin-top:12px"><button class="ghost" data-g="openNow">締め切って開票</button></div>' : ''}`;
    }
    if (s.phase === 'decide' && s.result) {
      const r = s.result;
      return `${head}<h2 class="center">📢 開票結果：脱落したのは…</h2>
        <div class="reveal-cards">${r.outNow.map((x, i) => `<div class="rcard ${x.wolf ? 'wolf' : ''}" style="animation-delay:${.6 + i * .5}s">${av(x.id, x.avatar, 'lg')}<b>${esc(x.name)}</b><small>お題：${esc(x.word)}</small><div style="margin-top:6px;font-weight:900">${x.wolf ? '🐺 ワードウルフだった！' : '🏙️ 市民だった…'}</div><small>${x.votes}票</small></div>`).join('') || '<p class="muted center">だれにも票が入りませんでした</p>'}</div>
        <p class="center" style="font-weight:900;font-size:20px">少数派はまだ <span style="color:#ff6b7a">${r.wolvesLeft}人</span> 残っています</p>
        ${isHost(s) ? '<div class="row c"><button class="y big" data-g="extend">🔥 延長戦（もう一度話し合い）</button><button class="ghost" data-g="end">終了する（少数派の勝ち）</button></div>' : '<p class="muted center">ホストが「延長戦」か「終了」を選んでいます…</p>'}`;
    }
    if (s.phase === 'final' && s.result) {
      const r = s.result;
      return `<div class="win-banner ${r.citizensWin ? 'city' : 'wolf'}">${r.citizensWin ? '🏙️ 市民の勝利！' : '🐺 ワードウルフの勝利！'}</div>
        <p class="center" style="font-weight:900;margin:0">${esc(r.reason || '')}</p>
        <div class="words"><div><small>多数派のお題</small><b>${esc(r.words.majority)}</b></div><div style="background:#ff344833"><small>少数派のお題</small><b style="color:#ff9aa5">${esc(r.words.minority)}</b></div></div>
        <div class="reveal-cards">${r.list.map((x, i) => `<div class="rcard ${x.wolf ? 'wolf' : ''}" style="animation-delay:${.4 + i * .25}s">${av(x.id, x.avatar, 'lg')}<b>${esc(x.name)}</b><small>${x.wolf ? '🐺 少数派' : '🏙️ 市民'}${x.out ? '（脱落）' : ''}</small><div style="font-weight:900;margin-top:4px">「${esc(x.word)}」</div></div>`).join('')}</div>
        <div class="row c">${isHost(s) && !watch ? '<button class="y big" data-g="start">🔁 もう一度遊ぶ</button>' : ''}<button class="ghost" data-act="back">◀ ゲーム選択に戻る</button></div>
        ${!isHost(s) ? '<p class="muted center">ホストが「もう一度遊ぶ」を押すと、同じメンバーで次のゲームが始まります</p>' : ''}`;
    }
    return '';
  }

  // ============================================================
  // 🎵 イントロドン
  // ============================================================
  const DECADES = ['ミックス', '1980年代', '1990年代', '2000年代', '2010年代', '2020年代'], GENRES = ['J-POP', 'アニメソング', 'ボカロ', 'ロック', 'アイドル', '洋楽', 'ミックス'];
  function board(s) {
    const max = Math.max(s.target, ...Object.values(s.scores || {}));
    return `<div class="board">${[...s.entrants].sort((a, b) => (s.scores[b.id] || 0) - (s.scores[a.id] || 0)).map(e => `<div class="brow"><span style="display:flex;gap:8px;align-items:center">${av(e.id, e.avatar)}${esc(e.name)}</span><div class="track"><div class="fill" style="width:${((s.scores[e.id] || 0) / max) * 100}%"></div><div class="goal" style="left:${(s.target / max) * 100}%"></div></div><span style="text-align:right">${s.scores[e.id] || 0} pt</span></div>`).join('')}</div>`;
  }
  function inHtml(s, watch) {
    const gm = s.entrants.find(e => e.id === s.gm) || {};
    const head = `<div class="chips c" style="margin-bottom:10px"><span class="chip plain">第${s.round}問</span><span class="chip plain">🎩 GM ${esc(gm.name || '')}</span><span class="chip plain">🎯 目標 ${s.target}pt</span><span class="chip plain">💿 ${esc(s.decade)}・${esc(s.genre)}</span></div>`;
    if (s.phase === 'select') {
      if (s.gm === me?.id && !watch) { pickVal['in-dec'] ??= s.decade; pickVal['in-gen'] ??= s.genre;
        return `${head}<h2 class="center neon" style="font-size:28px">出題する曲をえらぼう</h2>
        <div class="pick-grid"><div class="row"><span class="lbl">年代</span>${seg('in-dec', DECADES.map(d => [d, d]), s.decade)}</div><div class="row"><span class="lbl">ジャンル</span>${seg('in-gen', GENRES.map(d => [d, d]), s.genre)}</div></div>
        <div class="row c" style="margin:20px 0"><button class="don" data-g="play">出題</button></div>${board(s)}
        ${isHost(s) ? '<div class="row" style="justify-content:flex-end;margin-top:12px"><button class="ghost" data-g="finish">ここで終了して結果発表</button></div>' : ''}`; }
      return `${head}<div class="busy"><div class="spin"></div>🎩 ${esc(gm.name || '')} さんが出題の準備をしています…</div>${board(s)}`;
    }
    if (s.phase === 'answer') {
      return `${head}<div id="in-stage" style="min-height:230px;display:flex;flex-direction:column;align-items:center;justify-content:center">${introStageHtml(s)}</div>
        ${watch ? '' : s.mine != null ? `<p class="center" style="font-weight:900;font-size:20px">あなたの回答：「${esc(s.mine)}」</p>` : `<div class="ansbox"><input type="text" id="in-ans" maxlength="60" placeholder="曲名を入力"><button class="don" data-g="answer" style="width:110px;height:110px;font-size:28px">ドン!</button></div>`}
        <div class="chips c" style="margin-top:14px">${s.entrants.map(e => { const o = s.answered.indexOf(e.id); return chip(e, o >= 0 ? ` <span class="order">${o + 1}</span>` : ' 🎧', o >= 0 ? 'ok' : ''); }).join('')}</div>
        ${s.gm === me?.id ? `<div class="row c" style="margin-top:12px">${s.play && !s.play.replayed ? '<button class="ghost" data-g="replay">🔁 もう一度流す（1回）</button>' : ''}<button class="ghost" data-g="close">締め切る</button></div>` : ''}`;
    }
    if ((s.phase === 'judge' || s.phase === 'reveal') && s.song) {
      const song = `<div class="vinyl"><div class="disc"></div>${s.song.art ? `<img src="${esc(s.song.art)}" alt="" onerror="this.outerHTML='<div class=&quot;noart&quot;>🎵</div>'">` : '<div class="noart">🎵</div>'}</div>
        <div class="songinfo"><span>正解は…</span><b class="neon">${esc(s.song.title)}</b><span>${esc(s.song.artist)}${s.song.year ? `（${esc(s.song.year)}）` : ''}</span><div style="margin-top:10px"><button class="ghost" data-act="listen">▶ 曲を聴く</button></div></div>`;
      if (s.phase === 'judge') return `${head}${song}<h2>📝 回答 ${s.gm === me?.id ? '<small class="muted">（⭕❌ を押して直せます）</small>' : '<small class="muted">（GM が採点しています）</small>'}</h2>
        <div class="jl">${s.answers.map((a, i) => `<div class="jrow" style="animation-delay:${i * .08}s"><span class="n">${a.order ? `<span class="order">${a.order}</span>` : '　'}${av(a.uid, memberAv(a.uid))}<span class="nm" title="${esc(a.name)}">${esc(a.name)}</span></span><span class="t">${a.none ? '<span class="muted">（未回答）</span>' : esc(a.text)}</span>${s.gm === me?.id ? `<button class="${a.ok ? 'g' : 'w'}" data-g="toggle" data-uid="${a.uid}">${a.ok ? '⭕' : '❌'}</button>` : `<span style="font-size:24px">${a.ok ? '⭕' : '❌'}</span>`}</div>`).join('')}</div>
        ${s.gm === me?.id ? '<div class="row c" style="margin-top:16px"><button class="y big" data-g="score">✅ 採点する</button></div>' : ''}`;
      return `${head}${song}<div class="gain">${s.result?.gained?.length ? s.result.gained.map(x => `${esc(x.name)} +${x.p}`).join('　') : '正解者なし…'}</div>${board(s)}
        ${(s.gm === me?.id || isHost(s)) && !watch ? '<div class="row c" style="margin-top:16px"><button class="y big" data-g="next">▶ 次の問題へ</button></div>' : ''}`;
    }
    if (s.phase === 'final' && s.result?.final) {
      const f = s.result.final, ent = id => s.entrants.find(e => e.name === id) || {};
      return `<div class="win-banner city neon">🏆 ${esc(f[0]?.name || '')} の優勝！</div>
        <div class="podium">${[1, 0, 2].map(i => f[i] ? `<div class="p${i + 1}">${['🥇', '🥈', '🥉'][i]}<br>${esc(f[i].name)}<br>${f[i].p} pt</div>` : '').join('')}</div>
        ${f.length > 3 ? `<div class="board">${f.slice(3).map((x, i) => `<div class="brow"><span>${i + 4}. ${esc(x.name)}</span><span></span><span style="text-align:right">${x.p} pt</span></div>`).join('')}</div>` : ''}
        <div class="row c" style="margin-top:16px">${isHost(s) ? '<button class="y big" data-act="reset">🔁 参加受付に戻る</button>' : ''}<button class="ghost" data-act="back">◀ ゲーム選択に戻る</button></div>`;
    }
    return '';
  }
  // 出題中の真ん中（カウントダウン → 再生中 → 回答タイム）
  function introStageHtml(s) {
    const p = s.play; if (!p) return '';
    const t = p.at - now();
    if (t > 0) { const n = Math.ceil(t / 1000); return `<div class="neon cd" id="cd">${n > 3 ? 'READY' : n}</div><div class="muted">まもなく曲が流れます</div>`; }
    if (-t < p.dur * 1000) return `<canvas id="viz"></canvas><div class="neon" style="font-size:clamp(26px,5vw,42px)">🔊 イントロ再生中！</div>`;
    return `<canvas id="viz"></canvas><div class="neon" style="font-size:clamp(26px,5vw,42px)">✍️ 曲名を答えよう！</div>`;
  }

  // ---------- 曲を流す（サーバーの時計に合わせて、全員同じ瞬間に） ----------
  let introAudio = null, introStop = 0, introStartT = 0, scheduled = '', analyser = null, vizRAF = 0, cdShown = 0, stagePhase = '';
  function audioFor(url) {
    if (introAudio && introAudio.dataset.url === url) return introAudio;
    introAudio?.pause();
    const a = new Audio(BASE + '/' + url); a.dataset.url = url; a.preload = 'auto'; a.load();
    analyser = null;
    try { const c = ctx(); const src = c.createMediaElementSource(a); analyser = c.createAnalyser(); analyser.fftSize = 128; src.connect(analyser); analyser.connect(c.destination); } catch {}
    introAudio = a; return a;
  }
  function scheduleIntro(s) {
    const p = s.play;
    if (s.phase !== 'answer' || !p) return;
    const key = p.url + '@' + p.at;
    if (scheduled === key) return; scheduled = key;
    const a = audioFor(p.url); a.volume = Math.max(.2, vol / 100);
    clearTimeout(introStartT); clearTimeout(introStop);
    const wait = p.at - now();
    if (wait < -p.dur * 1000) return;
    introStartT = setTimeout(() => {
      const late = Math.max(0, (now() - p.at) / 1000);
      try { a.currentTime = (p.offset || 0) + late; } catch {}
      a.play().catch(() => toast('音を出せませんでした。画面を一度タップしてください'));
      introStop = setTimeout(() => a.pause(), Math.max(0, p.dur * 1000 - late * 1000));
    }, Math.max(0, wait));
  }
  // カウントダウンと画面の切りかえは、1フレームずつ正確に（「1」のときに鳴らないように）
  (function introLoop() {
    requestAnimationFrame(introLoop);
    if (view !== 'intro' || !st) return;
    const s = st.games.intro; if (!s || s.phase !== 'answer' || !s.play) { stagePhase = ''; return; }
    const t = s.play.at - now(), ph = t > 0 ? 'cd' : -t < s.play.dur * 1000 ? 'play' : 'ans';
    if (ph !== stagePhase) { stagePhase = ph; const el = document.getElementById('in-stage'); if (el) { el.innerHTML = introStageHtml(s); setupViz(); } if (ph === 'play') sfx.beep(true); }
    if (ph === 'cd') {
      const n = Math.ceil(t / 1000);
      if (n !== cdShown && n <= 3) { cdShown = n; const el = document.getElementById('cd'); if (el) { el.textContent = n; el.style.animation = 'none'; void el.offsetWidth; el.style.animation = ''; } sfx.beep(false); }
    } else cdShown = 0;
  })();
  function setupViz() {
    const c = document.getElementById('viz'); if (!c) return;
    cancelAnimationFrame(vizRAF);
    const g = c.getContext('2d'), data = new Uint8Array(64);
    const draw = () => {
      if (!c.isConnected) return;
      c.width = c.clientWidth * devicePixelRatio; c.height = c.clientHeight * devicePixelRatio;
      g.clearRect(0, 0, c.width, c.height);
      const playing = introAudio && !introAudio.paused;
      if (analyser && playing) analyser.getByteFrequencyData(data); else data.fill(0);
      const n = 32, w = c.width / n;
      for (let i = 0; i < n; i++) {
        const v = playing ? Math.max(data[i + 2] / 255, .06) : .04 + Math.abs(Math.sin(Date.now() / 600 + i)) * .03;
        const h = v * c.height * .95, grd = g.createLinearGradient(0, c.height - h, 0, c.height);
        grd.addColorStop(0, '#ff4de0'); grd.addColorStop(1, '#7b4dff');
        g.fillStyle = grd; g.shadowColor = '#ff4de0'; g.shadowBlur = 12 * devicePixelRatio;
        g.fillRect(i * w + w * .18, c.height - h, w * .64, h);
      }
      vizRAF = requestAnimationFrame(draw);
    };
    draw();
  }

  // ============================================================
  // 状態が変わったときの演出・音
  // ============================================================
  function effects(a, b) {
    if (!b) return;
    if (b.kind === 'poker') return window.PokerUI.effects(a, b);
    const changed = a?.phase !== b.phase;
    if (b.kind === 'unanimous' && changed) {
      if (b.phase === 'judging') sfx.drum(18);
      if (b.phase === 'reveal' && b.result) {
        const n = b.result.groups.length;
        for (let i = 0; i < n; i++) setTimeout(sfx.flip, i * 350);
        setTimeout(() => { const st2 = document.getElementById('un-stamp'); if (st2) st2.style.opacity = 1; sfx.stamp(); if (b.result.all) { setTimeout(sfx.fanfare, 250); confetti(220); } else { setTimeout(sfx.ng, 200); document.getElementById('un-cards')?.classList.add('shake'); } }, n * 350 + 400);
      }
      if (b.phase === 'pick') sfx.sel();
    }
    if (b.kind === 'unanimous' && b.phase === 'reveal' && b.result?.forced && !a?.result?.forced) { sfx.fanfare(); confetti(200); }
    if (b.kind === 'wordwolf' && changed) {
      if (b.phase === 'check') { cardOpen = false; sfx.sel(); }
      if (b.phase === 'talk') sfx.ok();
      if (b.phase === 'vote') { votePick.clear(); sfx.beep(true); }
      if (b.phase === 'decide') { sfx.drum(12); setTimeout(() => b.result?.outNow?.some(x => x.wolf) ? sfx.howl() : sfx.ng(), 900); }
      if (b.phase === 'final') { sfx.drum(10); setTimeout(() => { if (b.result?.citizensWin) { sfx.fanfare(); confetti(240); } else { sfx.howl(); confetti(140, ['#ff3448', '#ffe58a', '#7b4dff']); } }, 800); }
    }
    if (b.kind === 'intro') {
      if (changed && b.phase === 'judge') sfx.drum(10);
      if (changed && b.phase === 'reveal') { if (b.result?.gained?.length) { sfx.fanfare(); confetti(120, ['#ff4de0', '#7b4dff', '#ffc531', '#fff']); } else sfx.ng(); }
      if (changed && b.phase === 'final') { sfx.fanfare(); confetti(300); }
      if (changed && b.phase !== 'answer') { introAudio?.pause(); }
      if (changed && b.phase === 'judge') setTimeout(playAnswer, 900);   // 正解発表：その曲を自動で流す（採点ボタンで止まる）
      scheduleIntro(b);
    }
  }

  // ============================================================
  // ボタン
  // ============================================================
  function bind() {
    $app.querySelectorAll('[data-go]').forEach(b => b.onclick = () => { sfx.ok(); goView(b.dataset.go); });
    $app.querySelectorAll('[data-act]').forEach(b => b.onclick = e => act(b.dataset.act, b, e));
    $app.querySelectorAll('[data-g]').forEach(b => b.onclick = () => gAct(b.dataset.g, b));
    $app.querySelectorAll('[data-seg]').forEach(b => b.onclick = () => { pickVal[b.dataset.seg] = b.dataset.v; sfx.tap(); render(); });
    const v = document.getElementById('vol');
    const gv = document.getElementById('gvol');
    if (gv) gv.oninput = () => { gvol = +gv.value; try { localStorage.setItem('tsPartyGVol', gvol); } catch {} applyGVol(); gbgmTick(); };
    if (v) v.oninput = () => { vol = +v.value; try { localStorage.setItem('tsPartyVol', vol); } catch {} applyVol(); if (vol === 0) bgm.pause(); else bgmOn(); };
    if (view === 'poker') window.PokerUI.bind($app);
    for (const [id, a] of [['un-ans', 'answer'], ['in-ans', 'answer'], ['un-custom', 'pickCustom']]) { const i = document.getElementById(id); if (i) i.onkeydown = e => { if (e.key === 'Enter' && !e.isComposing) gAct(a); }; }
  }
  // 戻るときは参加受付を自動で取り消す（受付中・結果発表のあと。ゲームの途中は残す）
  function leaveOne(k) { const s = st?.games?.[k]; if (s && (s.phase === 'lobby' || s.phase === 'final') && s.entrants.some(e => e.id === me?.id)) sendG(k, 'leave'); }
  function leaveAll() { for (const k of Object.keys(GAMES)) leaveOne(k); }
  addEventListener('pagehide', leaveAll);
  function playAnswer() {
    const s = st?.games?.intro; if (view !== 'intro' || !s?.song || (s.phase !== 'judge' && s.phase !== 'reveal')) return;
    const au = audioFor('api/audio/' + s.song.id + '.m4a'); au.volume = Math.max(.2, vol / 100); clearTimeout(introStop);
    try { au.currentTime = 0; } catch {} au.play().catch(() => {});
  }
  function act(a, el) {
    if (a === 'hub') { leaveAll(); bgm.pause(); for (const a of Object.values(GBGM)) a.pause(); try { sessionStorage.setItem('tsSkipIntro', '1'); } catch {} setTimeout(() => { if (CASINO_POKER) returnToCasino(); else location.href = '/' + location.search; }, 200); }
    if (a === 'back') { sfx.tap(); leaveOne(view); if (CASINO_POKER) { bgm.pause(); for (const a of Object.values(GBGM)) a.pause(); setTimeout(returnToCasino, 120); } else goView('title'); }
    if (a === 'reset') { sendG(view, 'reset'); sfx.tap(); }
    if (a === 'card') { cardOpen = !cardOpen; sfx.flip(); el.classList.toggle('open', cardOpen); }
    if (a === 'vpick') { const id = el.dataset.id, need = st.games.wordwolf.need || st.games.wordwolf.wolves; if (votePick.has(id)) votePick.delete(id); else { if (votePick.size >= need) votePick.delete([...votePick][0]); votePick.add(id); } sfx.sel(); render(); }
    if (a === 'vsend') { sendG('wordwolf', 'vote', { ids: [...votePick] }); sfx.ok(); }
    if (a === 'listen') playAnswer();
  }
  function gAct(a, el) {
    const k = view, val = id => document.getElementById(id)?.value;
    sfx.tap();
    if (a === 'start') {
      if (k === 'unanimous') sendG(k, 'start', { sec: +(pickVal['un-sec'] ?? 60) });
      if (k === 'wordwolf') sendG(k, 'start', { wolves: +(pickVal['ww-wolves'] ?? 1), minutes: +(pickVal['ww-min'] ?? 3) });
      if (k === 'intro') sendG(k, 'start', { target: +(pickVal['in-target'] ?? 10) });
      if (k === 'poker') { const s = phaseOf('poker'); sendG(k, 'start', { stack: +(pickVal['pk-stack'] ?? s.stack ?? 3000), bb: +(pickVal['pk-bb'] ?? s.bb0 ?? 100), up: +(pickVal['pk-up'] ?? s.up ?? 5), sec: +(pickVal['pk-sec'] ?? s.sec ?? 30) }); }
      return;
    }
    if (a === 'pick') { sfx.ok(); return sendG(k, 'pick', { i: +el.dataset.i }); }
    if (a === 'pickCustom') { const t = val('un-custom'); if (t?.trim()) sendG(k, 'pick', { custom: t }); else toast('お題を入力してください'); return; }
    if (a === 'answer') {
      const i = document.getElementById(k === 'intro' ? 'in-ans' : 'un-ans'); const t = i?.value.trim();
      if (!t) { toast('答えを入力してください'); sfx.ng(); return; }
      sendG(k, 'answer', { text: t }); k === 'intro' ? (sfx.stamp(), sfx.ok()) : sfx.ok(); i.value = ''; i.blur(); return;
    }
    if (a === 'play') return sendG(k, 'play', { decade: pickVal['in-dec'], genre: pickVal['in-gen'] });
    if (a === 'toggle') return sendG(k, 'toggle', { uid: el.dataset.uid });
    sendG(k, a);
  }

  window.PartyAPI = { sendG, sfx, tone, noise, confetti, av, esc, toast, now, me: () => me, st: () => st, view: () => view, render, isHost: s => isHost(s), vol: () => vol };
  login();
  render();
})();
