#!/usr/bin/env python3
"""Install TalkSurvivor Casino/Boat Race with backups and automatic rollback."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE_APP = ROOT / "games-casino"
APP = Path("/opt/games-casino")
PARTY = Path("/opt/games-party/public")
HUB = Path("/var/www/games")
CHIBI = Path("/opt/talksurvivor/chibi_lobby")
POINTS_DB = Path("/opt/talkbots/home/dngr.sqlite")
SERVICE = Path("/etc/systemd/system/games-casino.service")
ENV_FILE = Path("/etc/games-casino.env")
SNIPPET = Path("/etc/nginx/snippets/games-casino.conf")
STAMP = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
BACKUP = Path(f"/root/talksurvivor-casino-backup-{STAMP}")
STAGE = Path(f"/opt/.games-casino-new-{STAMP}")

SLOT_ASSETS = [
    "pachi_cabinet_v8.png", "butterfly_top_v8.png", "butterfly_mid_v8.png", "butterfly_bottom_v8.png",
    "seven_aim.jpg", *(f"cd_{i}.png" for i in range(7)),
    "bgm_kokoro.mp3", "bgm_banchou.mp3", "bgm_yossha.mp3", "bgm_miko.mp3", "bgm_nana.mp3",
    "bgm_refrain.mp3", "bgm_ai.mp3", "pachi_freeze_v54.mp3", "pachi_zeb_v54.mp3",
    "pachi_freeze_end_v54.mp3", "se_robot_chance.mp3", "se_shakin.mp3",
    "ts_gauge_recover1.mp3", "ts_kakakakaan.mp3", "ts_super_mimo.mp3",
    "ts_v20_at_end.mp3", "ts_v20_at_last7.mp3",
]
BOAT_AUDIO = [
    "br_race_loop.wav", "br_bgm_final.mp3", "br_bgm_yosen.mp3",
    *(f"br_in_{grade}_{kind}.mp3" for grade in ("sg", "g1", "ippan") for kind in ("final", "yosen")),
]


def run(args, *, check=True, capture=False):
    print("+", " ".join(map(str, args)), flush=True)
    return subprocess.run([str(x) for x in args], check=check, text=True,
                          stdout=subprocess.PIPE if capture else None,
                          stderr=subprocess.STDOUT if capture else None)


def verify_package():
    manifest = ROOT / "MANIFEST.sha256"
    if not manifest.is_file():
        raise RuntimeError("MANIFEST.sha256 がありません")
    for line in manifest.read_text().splitlines():
        digest, rel = line.split("  ", 1)
        path = ROOT / rel
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError(f"配布ファイルが破損しています: {rel}")


def service_active(name):
    return subprocess.run(["systemctl", "is-active", "--quiet", name]).returncode == 0


def find_python():
    candidates = [
        CHIBI / ".venv/bin/python", CHIBI / "venv/bin/python",
        Path("/opt/talksurvivor/.venv/bin/python"), Path("/opt/talksurvivor/venv/bin/python"),
        Path("/usr/bin/python3"),
    ]
    candidates += list(Path("/opt").glob("*/.venv/bin/python"))
    for p in candidates:
        if p.is_file() and subprocess.run([p, "-c", "import fastapi,uvicorn,httpx"],
                                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            return p
    raise RuntimeError("FastAPI / uvicorn / httpx が入ったPython環境を検出できません")


def nginx_server_blocks(text):
    blocks = []
    for match in re.finditer(r"\bserver\s*\{", text):
        depth = 0
        for i in range(match.end() - 1, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    blocks.append((match.start(), i, text[match.start():i + 1]))
                    break
    return blocks


def nginx_block_score(block):
    return (100 if re.search(r"\blisten\b[^;]*\b443\b", block) else 0) + (20 if "ssl" in block else 0) + block.count("proxy_pass")


def find_nginx_site():
    found = []
    for pattern in ("/etc/nginx/sites-enabled/*", "/etc/nginx/conf.d/*.conf"):
        for p in map(Path, sorted(Path("/").glob(pattern.lstrip("/")))):
            try:
                text = p.resolve().read_text()
            except (OSError, UnicodeError):
                continue
            targets = [b for _, _, b in nginx_server_blocks(text)
                       if re.search(r"\bserver_name\b[^;]*\bgames\.talksurvivor\.online\b", b)]
            if targets:
                found.append((max(map(nginx_block_score, targets)), p.resolve()))
    if found:
        return max(found, key=lambda x: x[0])[1]
    raise RuntimeError("games.talksurvivor.online のnginx設定を検出できません")


def insert_nginx_include(text):
    if str(SNIPPET) in text:
        return text
    targets = [(nginx_block_score(block), start, end, block) for start, end, block in nginx_server_blocks(text)
               if re.search(r"\bserver_name\b[^;]*\bgames\.talksurvivor\.online\b", block)]
    if targets:
        _, start, end, block = max(targets, key=lambda x: x[0])
        # An existing direct route is kept; this also makes reruns safe after a manual route was added.
        if re.search(r"\blocation\s+(?:=\s*)?/casino(?:/|\s|\{)", block):
            return text
        indent = re.search(r"\n([ \t]*)[^\s]", block)
        pad = (indent.group(1) if indent else "    ")
        return text[:end] + f"\n{pad}include {SNIPPET};\n" + text[end:]
    raise RuntimeError("nginxの対象serverブロックを解析できません")


def check_points():
    if not POINTS_DB.is_file():
        raise RuntimeError(f"atto1 points DB がありません: {POINTS_DB}")
    c = sqlite3.connect(f"file:{POINTS_DB}?mode=ro", uri=True)
    try:
        cols = {r[1] for r in c.execute("PRAGMA table_info(points)")}
    finally:
        c.close()
    need = {"server_id", "user_id", "points"}
    if not need <= cols:
        raise RuntimeError(f"pointsテーブルの列が不足しています: {sorted(need - cols)}")


def backup_file(path, registry):
    existed = path.exists() or path.is_symlink()
    registry[path] = existed
    if existed:
        dest = BACKUP / "files" / path.relative_to("/")
        dest.parent.mkdir(parents=True, exist_ok=True)
        if path.is_symlink():
            dest.symlink_to(os.readlink(path))
        else:
            shutil.copy2(path, dest)


def restore_file(path, existed):
    if path.exists() or path.is_symlink():
        path.unlink()
    if existed:
        src = BACKUP / "files" / path.relative_to("/")
        path.parent.mkdir(parents=True, exist_ok=True)
        if src.is_symlink():
            path.symlink_to(os.readlink(src))
        else:
            shutil.copy2(src, path)


def merge_env(path):
    lines = path.read_text().splitlines() if path.exists() else []
    wanted = {"CASINO_DATA": "/opt/games-casino/data/casino.sqlite", "COIN_DB": str(POINTS_DB)}
    seen = set()
    out = []
    for line in lines:
        key = line.split("=", 1)[0].strip() if "=" in line and not line.lstrip().startswith("#") else ""
        if key in wanted:
            out.append(f"{key}={wanted[key]}")
            seen.add(key)
        else:
            out.append(line)
    out += [f"{k}={v}" for k, v in wanted.items() if k not in seen]
    path.write_text("\n".join(out).rstrip() + "\n")
    path.chmod(0o640)


def update_games_json():
    path = HUB / "games.json"
    games = json.loads(path.read_text())
    if not isinstance(games, list):
        raise RuntimeError("games.json が配列ではありません")
    games = [g for g in games if g.get("id") not in {"casino", "boat"}]
    additions = [
        {"id": "casino", "name": "カジノ", "desc": "ルーレット・バカラ・南国育ち・ポーカー",
         "image": "/card-casino.svg?v=20261104", "color": "#d79a28", "path": "/casino/"},
        {"id": "boat", "name": "ボートレース", "desc": "全国24場・オッズ・3Dレース",
         "image": "/card-boat.svg?v=20261104", "color": "#2488d8", "path": "/casino/?view=boat"},
    ]
    pos = next((i for i, g in enumerate(games) if g.get("adminOnly")), len(games))
    games[pos:pos] = additions
    path.write_text(json.dumps(games, ensure_ascii=False, indent=2) + "\n")


def wait_health():
    last = ""
    for _ in range(40):
        try:
            with urllib.request.urlopen("http://127.0.0.1:8600/api/health", timeout=2) as r:
                data = json.loads(r.read())
            if data.get("ok") is True:
                return data
            last = repr(data)
        except Exception as exc:
            last = str(exc)
        time.sleep(.5)
    raise RuntimeError("Casino health check failed: " + last)


def main():
    if os.geteuid() != 0:
        raise RuntimeError("rootで実行してください")
    verify_package()
    required_package = [SOURCE_APP / "app.py", ROOT / "party-public/party.js", ROOT / "party-public/index.html",
                        ROOT / "hub/card-casino.svg", ROOT / "hub/card-boat.svg"]
    required_server = [PARTY / "poker-ui.js", PARTY / "party.css", HUB / "games.json",
                       Path("/etc/games-hub.env"), CHIBI / "server/fan2604.txt"]
    required_server += [CHIBI / "client/assets" / x for x in SLOT_ASSETS]
    required_server += [CHIBI / "client" / x for x in BOAT_AUDIO]
    missing = [str(p) for p in required_package + required_server if not p.is_file()]
    if missing:
        raise RuntimeError("必要なファイルがありません:\n" + "\n".join(missing))
    check_points()
    python = find_python()
    node = next((p for p in (Path("/opt/node22/bin/node"), Path("/usr/bin/node")) if p.is_file()), None)
    nginx_site = find_nginx_site()
    print(f"Python: {python}\nnginx: {nginx_site}\nbackup: {BACKUP}", flush=True)

    # Build a complete staging tree before touching the running application.
    if STAGE.exists():
        shutil.rmtree(STAGE)
    shutil.copytree(SOURCE_APP, STAGE)
    (STAGE / "public/assets").mkdir(parents=True, exist_ok=True)
    for name in SLOT_ASSETS:
        shutil.copy2(CHIBI / "client/assets" / name, STAGE / "public/assets" / name)
    for name in BOAT_AUDIO:
        shutil.copy2(CHIBI / "client" / name, STAGE / "public" / name)
    shutil.copy2(CHIBI / "server/fan2604.txt", STAGE / "server/fan2604.txt")
    if APP.is_dir() and (APP / "data").is_dir():
        shutil.copytree(APP / "data", STAGE / "data", dirs_exist_ok=True)
    if APP.is_dir() and (APP / "server/.br_secret").is_file():
        shutil.copy2(APP / "server/.br_secret", STAGE / "server/.br_secret")
    run([python, "-m", "compileall", "-q", STAGE])
    if node:
        for js in (STAGE / "public/casino.js", STAGE / "public/slot-machine.js", ROOT / "party-public/party.js"):
            run([node, "--check", js])

    prior = {"casino": service_active("games-casino.service"), "party": service_active("games-party.service")}
    registry = {}
    BACKUP.mkdir(parents=True)
    for p in [PARTY / "party.js", PARTY / "index.html", HUB / "games.json", HUB / "card-casino.svg",
              HUB / "card-boat.svg", CHIBI / "client/index.html", ENV_FILE, SERVICE, SNIPPET, nginx_site]:
        backup_file(p, registry)
    (BACKUP / "install-state.json").write_text(json.dumps({str(k): v for k, v in registry.items()}, indent=2))

    app_moved = False
    try:
        run(["systemctl", "stop", "games-casino.service"], check=False)
        if APP.exists():
            shutil.move(APP, BACKUP / "app")
            app_moved = True
        os.replace(STAGE, APP)

        shutil.copy2(ROOT / "party-public/party.js", PARTY / "party.js")
        party_index = PARTY / "index.html"
        party_html = party_index.read_text()
        party_html = re.sub(r'<script\b[^>]*\bsrc=["\'][^"\']*(?:party|poker-ui)\.js[^"\']*["\'][^>]*>\s*</script>\s*', '', party_html)
        party_scripts = ('<script src="poker-ui.js?v=casino1"></script>\n'
                         '<script src="party.js?v=casino1"></script>\n')
        if "</body>" not in party_html:
            raise RuntimeError("Party index.html のbodyを確認できません")
        party_index.write_text(party_html.replace("</body>", party_scripts + "</body>", 1))
        shutil.copy2(ROOT / "hub/card-casino.svg", HUB / "card-casino.svg")
        shutil.copy2(ROOT / "hub/card-boat.svg", HUB / "card-boat.svg")
        update_games_json()

        # Hide the old title-screen entrances in Chiikawa; existing furniture and data remain untouched.
        chibi_index = CHIBI / "client/index.html"
        chibi_text = chibi_index.read_text()
        marker = "ts-casino-moved-to-hub"
        if marker not in chibi_text:
            style = (f'<style id="{marker}">#ts-pachi-settings-v10,#ts-boatrace-test,'
                     '#ts-roulette-open,#ts-baccarat-open{display:none!important}</style>\n')
            if "</head>" not in chibi_text:
                raise RuntimeError("ちいかわ index.html のheadを確認できません")
            chibi_index.write_text(chibi_text.replace("</head>", style + "</head>", 1))

        merge_env(ENV_FILE)
        SERVICE.write_text(
            "[Unit]\nDescription=TalkSurvivor Casino and Boat Race\nAfter=network.target\n\n"
            "[Service]\nType=simple\nUser=root\nWorkingDirectory=/opt/games-casino\n"
            "EnvironmentFile=-/etc/games-casino.env\n"
            f"ExecStart={python} -m uvicorn app:app --host 127.0.0.1 --port 8600 --no-access-log\n"
            "Restart=always\nRestartSec=2\nTimeoutStopSec=15\n\n[Install]\nWantedBy=multi-user.target\n"
        )
        SNIPPET.parent.mkdir(parents=True, exist_ok=True)
        SNIPPET.write_text(
            "location = /casino { return 302 /casino/; }\n"
            "location /casino/ {\n"
            "    proxy_pass http://127.0.0.1:8600/;\n"
            "    proxy_http_version 1.1;\n"
            "    proxy_set_header Upgrade $http_upgrade;\n"
            "    proxy_set_header Connection \"upgrade\";\n"
            "    proxy_set_header Host $host;\n"
            "    proxy_set_header X-Forwarded-Proto $scheme;\n"
            "    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n"
            "    proxy_read_timeout 3600s;\n"
            "}\n"
        )
        nginx_text = nginx_site.read_text()
        nginx_site.write_text(insert_nginx_include(nginx_text))
        run(["nginx", "-t"])
        run(["systemctl", "daemon-reload"])
        run(["systemctl", "enable", "--now", "games-casino.service"])
        if prior["party"]:
            run(["systemctl", "restart", "games-party.service"])
        run(["systemctl", "reload", "nginx"])
        health = wait_health()
        run(["systemctl", "is-active", "--quiet", "games-casino.service"])
        print("\n配置完了", json.dumps(health, ensure_ascii=False), flush=True)
        print("バックアップ:", BACKUP, flush=True)
    except Exception:
        print("\n失敗したため元の配置へ戻します", file=sys.stderr, flush=True)
        run(["systemctl", "stop", "games-casino.service"], check=False)
        if APP.exists():
            shutil.rmtree(APP)
        if app_moved and (BACKUP / "app").exists():
            shutil.move(BACKUP / "app", APP)
        for path, existed in reversed(list(registry.items())):
            restore_file(path, existed)
        run(["systemctl", "daemon-reload"], check=False)
        if prior["casino"]:
            run(["systemctl", "start", "games-casino.service"], check=False)
        else:
            run(["systemctl", "disable", "games-casino.service"], check=False)
        if prior["party"]:
            run(["systemctl", "restart", "games-party.service"], check=False)
        if subprocess.run(["nginx", "-t"]).returncode == 0:
            run(["systemctl", "reload", "nginx"], check=False)
        raise
    finally:
        if STAGE.exists():
            shutil.rmtree(STAGE)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
