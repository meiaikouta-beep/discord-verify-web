# TalkSurvivor Casino integration

This package adds the public Casino and Boat Race entries, reuses the current
Party Poker backend through a dedicated Casino entrance, and settles every
casino game against the existing `atto1` `points` table.

Production installation is performed by `install-integrated.py`. The installer
creates timestamped backups, validates Python and JavaScript syntax, tests the
nginx configuration before reload, and restores the previous deployment if a
service or health check fails.

The large slot and boat audio/image files are copied on the server from the
current `/opt/talksurvivor/chibi_lobby` deployment. They are deliberately not
duplicated inside the ZIP. The installer checks every required source asset
before changing any live file.

FastAPI, Uvicorn, HTTPX and WebSocket runtime dependencies are bundled under
`games-casino/vendor` for Ubuntu 24.04's CPython 3.12 x86_64. Installation does
not use the server's global Python packages and does not run pip or apt.

The uploaded Boat Race track loops on the venue, betting and purchase-history
screens. Opening the 3D race pauses it and switches to the existing race intro,
BGM and ambience. One Boat volume setting controls both. Casino and Boat cards
set `allowText`, so the hub accepts launches from either voice or text channels;
the VC restriction for every other content entry stays unchanged.
