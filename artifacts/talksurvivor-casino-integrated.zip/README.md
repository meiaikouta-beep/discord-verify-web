# TalkSurvivor Casino integration

This package adds the public Casino and Boat Race entries, reuses the current
Party Poker backend through a dedicated Casino entrance, and settles every
casino game against the existing `atto1` `points` table.

Production installation is performed by `install-integrated.py`. The installer
creates timestamped backups, validates Python and JavaScript syntax, tests the
nginx configuration before reload, and restores the previous deployment if a
service or health check fails.

The large slot and boat audio/image files are copied on the server from the
current `/opt/talksurvivor/chibi_lobby` deployment. They are deliberately not
duplicated inside the ZIP. The installer checks every required source asset
before changing any live file.
