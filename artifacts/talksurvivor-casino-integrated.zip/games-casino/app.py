from __future__ import annotations

import asyncio
import json
import os
import secrets
import sqlite3
import time
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from server import baccarat, boatrace_league as boat, boatrace_purchase_idempotency as boat_purchase, medal_bank, points, roulette, slot_authority


ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "public"


def read_env(*paths):
    out = dict(os.environ)
    for raw in paths:
        try:
            lines = Path(raw).read_text().splitlines()
        except OSError:
            continue
        for line in lines:
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                out.setdefault(k.strip(), v.strip())
    return out


ENV = read_env(os.getenv("HUB_ENV_FILE", "/etc/games-hub.env"), os.getenv("CASINO_ENV_FILE", "/etc/games-casino.env"))
CLIENT_ID = ENV.get("DISCORD_CLIENT_ID", "")
BOT_TOKEN = ENV.get("DISCORD_BOT_TOKEN", "")
API = ENV.get("DISCORD_API", "https://discord.com/api/v10").rstrip("/")
ALLOWED_GUILDS = {x.strip() for x in ENV.get("ALLOWED_GUILD_IDS", "").split(",") if x.strip()}
ADMIN_IDS = {x.strip() for x in ENV.get("ADMIN_USER_IDS", "").split(",") if x.strip()}
STATE_DB = Path(ENV.get("CASINO_DATA", "/opt/games-casino/data/casino.sqlite"))
POINTS_DB = Path(ENV.get("COIN_DB", "/opt/talkbots/home/dngr.sqlite"))
ALLOWED_ORIGINS = {
    "https://games.talksurvivor.online",
    f"https://{CLIENT_ID}.discordsays.com",
    *([ENV["EXTRA_ORIGIN"]] if ENV.get("EXTRA_ORIGIN") else []),
}
STATE_DB.parent.mkdir(parents=True, exist_ok=True)


def db():
    if not POINTS_DB.is_file():
        raise RuntimeError(f"points DB がありません: {POINTS_DB}")
    c = sqlite3.connect(STATE_DB, timeout=15, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("ATTACH DATABASE ? AS pointsdb", (str(POINTS_DB),))
    c.execute(
        "CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL, "
        "slot_setting INTEGER, slot_day TEXT)"
    )
    c.execute(
        "CREATE TABLE IF NOT EXISTS inventory (owner TEXT NOT NULL, item TEXT NOT NULL, "
        "quantity INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(owner,item))"
    )
    return c


def owner_of(sess):
    return f"{sess['guild']}:{sess['uid']}"


def point_balance(owner):
    c = db()
    try:
        return points.balance(c, owner)
    finally:
        c.close()


app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=PUBLIC), name="static")
sessions: dict[str, dict] = {}
connections: dict[str, set[WebSocket]] = {}
background_tasks: set[asyncio.Task] = set()
roulette_seats: dict[str, int] = {}
roulette_seen: dict[str, float] = {}
baccarat_seats: dict[str, int] = {}
baccarat_seen: dict[str, float] = {}
SEAT_IDLE = 90


def origin_ok(origin):
    return origin in ALLOWED_ORIGINS or (not origin and ENV.get("CASINO_TEST_NO_ORIGIN") == "1")


async def verify(access_token, instance_id):
    if not isinstance(access_token, str) or not 10 <= len(access_token) <= 200:
        raise HTTPException(400, "ログイン情報がありません")
    if not isinstance(instance_id, str) or not instance_id.startswith("i-") or len(instance_id) > 252:
        raise HTTPException(400, "アクティビティの情報がありません")
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            ur = await client.get(f"{API}/users/@me", headers={"Authorization": f"Bearer {access_token}"})
            if ur.status_code != 200:
                raise HTTPException(403, "ログインが切れています。アクティビティを開き直してください")
            user = ur.json()
            ir = await client.get(
                f"{API}/applications/{CLIENT_ID}/activity-instances/{instance_id}",
                headers={"Authorization": f"Bot {BOT_TOKEN}"},
            )
            if ir.status_code != 200:
                raise HTTPException(403, "アクティビティを確認できません")
            inst = ir.json()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(502, "Discordへ接続できません") from exc
    guild = str((inst.get("location") or {}).get("guild_id") or "")
    if (
        str(inst.get("application_id")) != CLIENT_ID
        or str(user.get("id")) not in {str(x) for x in inst.get("users", [])}
        or guild not in ALLOWED_GUILDS
    ):
        raise HTTPException(403, "このサーバーでは遊べません")
    return {
        "uid": str(user["id"]),
        "name": str(user.get("global_name") or user.get("username") or "プレイヤー")[:32],
        "avatar": user.get("avatar"),
        "guild": guild,
        "instance": instance_id,
    }


@app.get("/")
async def index():
    return FileResponse(PUBLIC / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/api/health")
async def health():
    return {"ok": True, "sessions": len(sessions), "connections": sum(map(len, connections.values()))}


@app.post("/api/login")
async def login(request: Request):
    if not origin_ok(request.headers.get("origin")):
        return JSONResponse({"error": "Origin not allowed"}, 403)
    try:
        body = await request.json()
    except Exception:
        body = {}
    sess = await verify(body.get("access_token"), body.get("instanceId"))
    sid = secrets.token_hex(24)
    sess["exp"] = time.time() + 12 * 3600
    sessions[sid] = sess
    if len(sessions) > 5000:
        sessions.pop(next(iter(sessions)))
    own = owner_of(sess)
    c = db()
    try:
        c.execute("BEGIN IMMEDIATE")
        c.execute(
            "INSERT INTO users(id,name) VALUES (?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name",
            (own, sess["name"]),
        )
        points.ensure(c, own)
        c.commit()
        balance = points.balance(c, own)
    finally:
        c.close()
    return {"session": sid, "me": {"id": sess["uid"], "name": sess["name"], "avatar": sess["avatar"]}, "points": balance}


async def send_owner(owner, payload):
    dead = []
    for ws in list(connections.get(owner, ())):
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        connections.get(owner, set()).discard(ws)


def display_name(owner):
    c = db()
    try:
        row = c.execute("SELECT name FROM users WHERE id=?", (owner,)).fetchone()
        return row[0] if row else "Player"
    finally:
        c.close()


def prune(seats, seen):
    now = time.time()
    gone = [o for o in seats if not connections.get(o) or now - seen.get(o, now) > SEAT_IDLE]
    for o in gone:
        seats.pop(o, None)
        seen.pop(o, None)
    return bool(gone)


def take_seat(owner, seats, maximum):
    if owner in seats:
        return seats[owner]
    used = set(seats.values())
    for i in range(maximum):
        if i not in used:
            seats[owner] = i
            return i
    return None


async def roulette_broadcast(only=None):
    if not roulette_seats:
        return
    c = db()
    try:
        snap = roulette.table_snapshot(c, time.time(), dict(roulette_seats), {o: display_name(o) for o in roulette_seats})
    finally:
        c.close()
    for owner, seat in list(roulette_seats.items()):
        if only is None or only == owner:
            await send_owner(owner, {"type": "roulette_state", **snap, "me": seat})


async def baccarat_broadcast(only=None):
    if not baccarat_seats:
        return
    c = db()
    try:
        baccarat.ensure_tables(c)
        snap = baccarat.table_snapshot(c, time.time(), dict(baccarat_seats), {o: display_name(o) for o in baccarat_seats})
    finally:
        c.close()
    for owner, seat in list(baccarat_seats.items()):
        if only is None or only == owner:
            await send_owner(owner, {"type": "baccarat_state", **snap, "me": seat})


async def roulette_message(owner, kind, data):
    if kind == "roulette_leave":
        roulette_seen.pop(owner, None)
        if roulette_seats.pop(owner, None) is not None:
            await roulette_broadcast()
        return
    prune(roulette_seats, roulette_seen)
    fresh = owner not in roulette_seats
    if fresh and take_seat(owner, roulette_seats, roulette.MAX_SEATS) is None:
        await send_owner(owner, {"type": "roulette_full", "message": "満席です"})
        return
    roulette_seen[owner] = time.time()
    c = db()
    try:
        c.execute("BEGIN IMMEDIATE")
        roulette.ensure_tables(c)
        roulette.ensure_open_round(c, time.time())
        if kind == "roulette_bet":
            roulette.place_bet(c, owner, data.get("t"), data.get("nums"), data.get("amount"), data.get("op_id"), time.time())
        elif kind == "roulette_clear":
            roulette.clear_bets(c, owner, time.time())
        elif kind == "roulette_undo":
            roulette.undo_bet(c, owner, time.time())
        c.commit()
    except (ValueError, sqlite3.Error) as exc:
        c.rollback()
        await send_owner(owner, {"type": "roulette_error", "message": str(exc), "op_id": data.get("op_id")})
    finally:
        c.close()
    await roulette_broadcast(None if fresh or kind != "roulette_state" else owner)


async def baccarat_message(owner, kind, data):
    if kind == "baccarat_leave":
        baccarat_seen.pop(owner, None)
        if baccarat_seats.pop(owner, None) is not None:
            await baccarat_broadcast()
        return
    prune(baccarat_seats, baccarat_seen)
    fresh = owner not in baccarat_seats
    if fresh and take_seat(owner, baccarat_seats, baccarat.MAX_SEATS) is None:
        await send_owner(owner, {"type": "baccarat_full", "message": "満席です"})
        return
    baccarat_seen[owner] = time.time()
    c = db()
    try:
        c.execute("BEGIN IMMEDIATE")
        baccarat.ensure_tables(c)
        baccarat.ensure_open_round(c, time.time())
        if kind == "baccarat_bet":
            baccarat.place_bet(c, owner, data.get("t"), data.get("amount"), data.get("op_id"), time.time())
        elif kind == "baccarat_clear":
            baccarat.clear_bets(c, owner, time.time())
        elif kind == "baccarat_undo":
            baccarat.undo_bet(c, owner, time.time())
        elif kind == "baccarat_reveal":
            baccarat.register_reveal(c, owner, dict(baccarat_seats), data.get("key"), time.time())
        c.commit()
    except (ValueError, sqlite3.Error) as exc:
        c.rollback()
        await send_owner(owner, {"type": "baccarat_error", "message": str(exc), "op_id": data.get("op_id")})
    finally:
        c.close()
    await baccarat_broadcast(None if fresh or kind != "baccarat_state" else owner)


async def medal_message(owner, kind, data):
    c = db()
    action = data.get("action")
    try:
        c.execute("BEGIN IMMEDIATE")
        slot_authority.runtime(c, owner)
        if kind == "pachi_medal_action":
            allowed = {"issue_card", "insert_card", "eject_card", "deposit_cash", "lend", "save", "replay", "bank_exchange", "sand_to_card", "card_cashout"}
            if action not in allowed:
                raise ValueError("この操作は準備中です")
            st = medal_bank.change(c, owner, action, data.get("amount"), data.get("op_id"))
        else:
            st = medal_bank.state(c, owner)
        c.commit()
        await send_owner(owner, {"type": "pachi_medal_state", **st, "points": points.balance(c, owner)})
        if kind == "pachi_medal_action":
            await send_owner(owner, {"type": "pachi_medal_result", "ok": True, "action": action, "op_id": data.get("op_id")})
    except (ValueError, sqlite3.Error) as exc:
        c.rollback()
        if kind == "pachi_medal_action":
            await send_owner(owner, {"type": "pachi_medal_result", "ok": False, "action": action, "op_id": data.get("op_id"), "message": str(exc)})
        await send_owner(owner, {"type": "notice", "message": str(exc)})
    finally:
        c.close()


async def slot_message(owner, kind, data, is_admin):
    if data.get("debug_force_role") is not None and not is_admin:
        data = dict(data)
        data["debug_force_role"] = None
    c = db()
    try:
        c.execute("BEGIN IMMEDIATE")
        if kind == "pachi_round_begin":
            result = slot_authority.begin(c, owner, data.get("debug_force_role"))
        elif kind == "pachi_round_settle":
            result = slot_authority.settle(c, owner, data.get("round_id"), data.get("positions"), data.get("stops"))
        elif kind == "pachi_round_abort":
            result = slot_authority.abort(c, owner, data.get("round_id"))
        elif kind == "pachi_at_resume_bet":
            slot_authority.runtime(c, owner)
            before = c.execute("SELECT * FROM pachi_runtime WHERE owner=?", (owner,)).fetchone()
            award = 0
            if not before["bonus_remaining"] and not before["bonus_pending"] and before["at_remaining"] > 0 and not before["at_hidden"]:
                award = before["at_bonus_pending"]
                if award:
                    c.execute("UPDATE pachi_runtime SET at_remaining=at_remaining+?,at_bonus_pending=0 WHERE owner=?", (award, owner))
            after = c.execute("SELECT at_remaining,at_rate,bonus_pending,bonus_remaining FROM pachi_runtime WHERE owner=?", (owner,)).fetchone()
            result = {"type": "pachi_at_resume_bet_result", "award": award, **dict(after)}
        else:
            raise ValueError("この操作は利用できません")
        c.commit()
        await send_owner(owner, result)
        await send_owner(owner, {"type": "pachi_medal_state", **medal_bank.state(c, owner), "points": points.balance(c, owner)})
    except (ValueError, sqlite3.Error) as exc:
        c.rollback()
        await send_owner(owner, {"type": "pachi_round_error", "message": str(exc)})
    finally:
        c.close()


async def boat_message(owner, kind, data):
    try:
        if kind == "br_list":
            out = boat.home()
        elif kind == "br_results":
            out = boat.results_today()
        elif kind == "br_racer":
            out = boat.racer_detail(int(data.get("no")))
        elif kind == "br_race":
            day = boat.parse_day(data.get("date"))
            out = boat.race_detail(int(data.get("venue")), day, int(data.get("no")))
            if out:
                c = db()
                try:
                    boat.ensure_tables(c)
                    out["bets"] = boat.race_bets(c, int(data.get("venue")), day, int(data.get("no")))
                finally:
                    c.close()
        elif kind == "br_bet_status":
            c = db()
            try:
                out = boat_purchase.purchase_status(c, owner, data.get("request_id"))
            finally:
                c.close()
        elif kind == "br_bet":
            c = db()
            try:
                boat.ensure_tables(c)
                day = boat.parse_day(data.get("date"))
                receipt = boat_purchase.purchase_once(
                    c, boat, owner, int(data.get("venue")), day, int(data.get("no")),
                    data.get("items"), data.get("request_id"),
                )
                out = {"ok": True, **receipt}
            except (ValueError, sqlite3.Error) as exc:
                out = {"ok": False, "error": str(exc)}
            finally:
                c.close()
        else:
            c = db()
            try:
                c.execute("BEGIN IMMEDIATE")
                boat.ensure_tables(c)
                boat.settle(c, owner)
                out = {"owner": owner, "bets": boat.my_bets(c, owner), "balance": points.balance(c, owner), "now_ms": int(time.time() * 1000)}
                c.commit()
            except ValueError as exc:
                c.rollback()
                out = {"ok": False, "error": str(exc)}
            finally:
                c.close()
        await send_owner(owner, {"type": kind, "data": out, "req": data.get("req")})
    except Exception as exc:
        await send_owner(owner, {"type": kind, "data": {"ok": False, "error": "ボートレースデータ取得失敗: " + str(exc)[:80]}, "req": data.get("req")})


async def on_message(sess, data):
    owner = owner_of(sess)
    kind = data.get("type")
    if kind and kind.startswith("roulette_"):
        return await roulette_message(owner, kind, data)
    if kind and kind.startswith("baccarat_"):
        return await baccarat_message(owner, kind, data)
    if kind in {"pachi_medal_state", "pachi_medal_action"}:
        return await medal_message(owner, kind, data)
    if kind in {"pachi_round_begin", "pachi_round_settle", "pachi_round_abort", "pachi_at_resume_bet"}:
        return await slot_message(owner, kind, data, sess["uid"] in ADMIN_IDS)
    if kind in {"br_list", "br_race", "br_racer", "br_bet", "br_bet_status", "br_my", "br_results"}:
        return await boat_message(owner, kind, data)


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    sid = ws.query_params.get("s", "")
    sess = sessions.get(sid)
    if not sess or sess["exp"] < time.time() or not origin_ok(ws.headers.get("origin")):
        await ws.close(code=1008)
        return
    await ws.accept()
    owner = owner_of(sess)
    connections.setdefault(owner, set()).add(ws)
    try:
        await ws.send_json({"type": "welcome", "id": sess["uid"], "name": sess["name"], "points": point_balance(owner), "slot_admin": sess["uid"] in ADMIN_IDS})
        while True:
            data = await ws.receive_json()
            if isinstance(data, dict):
                await on_message(sess, data)
    except WebSocketDisconnect:
        pass
    finally:
        connections.get(owner, set()).discard(ws)
        if not connections.get(owner):
            connections.pop(owner, None)


async def roulette_loop():
    while True:
        await asyncio.sleep(1)
        try:
            changed = prune(roulette_seats, roulette_seen)
            c = db()
            try:
                c.execute("BEGIN IMMEDIATE")
                roulette.ensure_tables(c)
                events = roulette.tick(c, time.time())
                c.commit()
            finally:
                c.close()
            for event in events:
                if event["kind"] == "result":
                    results = [{"seat": roulette_seats[o], "name": display_name(o), **v} for o, v in event["owners"].items() if o in roulette_seats]
                    for owner in roulette_seats:
                        await send_owner(owner, {"type": "roulette_result", "round_id": event["round_id"], "number": event["number"], "results": results})
            if events or changed or roulette_seats:
                await roulette_broadcast()
        except Exception as exc:
            print("roulette loop", repr(exc), flush=True)


async def baccarat_loop():
    while True:
        await asyncio.sleep(1)
        try:
            changed = prune(baccarat_seats, baccarat_seen)
            c = db()
            try:
                c.execute("BEGIN IMMEDIATE")
                baccarat.ensure_tables(c)
                events = baccarat.tick(c, time.time())
                c.commit()
                history = baccarat.history(c)
            finally:
                c.close()
            for event in events:
                if event["kind"] == "result":
                    results = [{"seat": baccarat_seats[o], "name": display_name(o), **v} for o, v in event["owners"].items() if o in baccarat_seats]
                    for owner in baccarat_seats:
                        await send_owner(owner, {"type": "baccarat_result", "round_id": event["round_id"], "hand": event["hand"], "history": history, "results": results})
            if events or changed or baccarat_seats:
                await baccarat_broadcast()
        except Exception as exc:
            print("baccarat loop", repr(exc), flush=True)


async def boat_settle_loop():
    while True:
        await asyncio.sleep(15)
        c = db()
        try:
            c.execute("BEGIN IMMEDIATE")
            boat.ensure_tables(c)
            boat.settle(c)
            c.commit()
        except Exception as exc:
            c.rollback()
            print("boat settle", repr(exc), flush=True)
        finally:
            c.close()


@app.on_event("startup")
async def startup():
    if not CLIENT_ID or not BOT_TOKEN:
        raise RuntimeError("/etc/games-hub.env が読めません")
    if len(boat.RACERS) < boat.ROSTER:
        raise RuntimeError(f"ボートレーサーデータを読み込めません: {len(boat.RACERS)}件")
    c = db()
    try:
        if not c.execute("SELECT 1 FROM pointsdb.sqlite_master WHERE type='table' AND name='points'").fetchone():
            raise RuntimeError(f"points テーブルがありません: {POINTS_DB}")
        c.execute("BEGIN IMMEDIATE")
        roulette.ensure_tables(c)
        baccarat.ensure_tables(c)
        boat.ensure_tables(c)
        boat_purchase.ensure_receipts(c)
        medal_bank.migrate(c)
        slot_authority.migrate(c)
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()
    for fn in (roulette_loop, baccarat_loop, boat_settle_loop):
        task = asyncio.create_task(fn())
        background_tasks.add(task)
        task.add_done_callback(background_tasks.discard)


@app.on_event("shutdown")
async def shutdown():
    tasks = list(background_tasks)
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    background_tasks.clear()
