"""Stage18: conservative, opt-in assignment migration for races with recorded bets.

No import-time writes. Existing races discovered from br_bets and br_result_v2
are always assigned legacy unless already consistently assigned. Never auto-assign v2.
"""
import datetime as dt
import sqlite3
from server.boatrace_engine_assignment import initialize, get, assign_once, AssignmentConflict, _key

class MigrationBlocked(RuntimeError): pass

def canonical_date(value):
    if not isinstance(value, str): raise ValueError('invalid date')
    base, sep, suffix = value.partition('@')
    if sep and suffix != '17': raise ValueError('unexpected race day suffix')
    return dt.date.fromisoformat(base).isoformat()

def has_bets(conn, venue, date, race):
    key = _key(venue, canonical_date(date), race)
    if not table_exists(conn, 'br_bets'): return False
    return conn.execute('SELECT 1 FROM br_bets WHERE venue=? AND date IN (?,?) AND race=? LIMIT 1',
                        (key[0], key[1], key[1]+'@17', key[2])).fetchone() is not None

def table_exists(conn, name):
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None

def discovered_races(conn):
    keys=set()
    if table_exists(conn,'br_bets'):
        for v,d,r in conn.execute('SELECT DISTINCT venue,date,race FROM br_bets'):
            keys.add(_key(v,canonical_date(d),r))
    if table_exists(conn,'br_result_v2'):
        for v,d,r in conn.execute('SELECT venue,date,race FROM br_result_v2'):
            keys.add(_key(v,canonical_date(d),r))
    return sorted(keys)

def audit(conn):
    """No writes. Returns a plan; fails on incompatible existing assignments/results."""
    keys=discovered_races(conn)
    plan=[]
    for key in keys:
        assigned = get(conn,*key) if table_exists(conn,'br_engine_assignment') else None
        frozen = None
        if table_exists(conn,'br_result_v2'):
            row=conn.execute('SELECT engine FROM br_result_v2 WHERE venue=? AND date=? AND race=?',key).fetchone()
            frozen=row[0] if row else None
        if assigned == 'v2' or frozen == 'v2':
            raise MigrationBlocked(f'existing race has v2 assignment/result: {key}')
        if assigned not in (None,'legacy') or frozen not in (None,'legacy'):
            raise MigrationBlocked(f'invalid existing engine: {key}')
        plan.append({'venue':key[0],'date':key[1],'race':key[2], 'action':'keep' if assigned else 'assign_legacy'})
    return plan

def apply_legacy(conn):
    """Caller must explicitly opt in; savepoint ensures atomicity, no commit."""
    conn.execute('SAVEPOINT br_migrate_legacy')
    try:
        plan=audit(conn)
        initialize(conn)
        for item in plan:
            assign_once(conn,item['venue'],item['date'],item['race'],'legacy')
        conn.execute('RELEASE SAVEPOINT br_migrate_legacy')
        return plan
    except BaseException:
        conn.execute('ROLLBACK TO SAVEPOINT br_migrate_legacy')
        conn.execute('RELEASE SAVEPOINT br_migrate_legacy')
        raise

def require_safe_future_v2(conn, venue, date, race, *, today, legacy_history_verified):
    """Blocks v2 if ANY bet exists (including settled/void), even before kickoff."""
    from server.boatrace_engine_assignment import assign_future_v2
    date=canonical_date(date)
    if has_bets(conn,venue,date,race):
        raise MigrationBlocked('cannot assign v2 to a race with existing bets')
    if table_exists(conn,'br_result_v2'):
        if conn.execute('SELECT 1 FROM br_result_v2 WHERE venue=? AND date=? AND race=?', (venue,date,race)).fetchone():
            raise MigrationBlocked('cannot assign v2 to a race with frozen result')
    return assign_future_v2(conn,venue,date,race,today=today,legacy_history_verified=legacy_history_verified)
