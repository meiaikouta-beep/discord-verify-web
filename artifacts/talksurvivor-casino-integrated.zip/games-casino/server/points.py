"""Atomic access to atto1's points table through an attached SQLite DB."""


def account(owner):
    try:
        server_id, user_id = str(owner).split(":", 1)
    except ValueError as exc:
        raise ValueError("アカウント情報が不正です") from exc
    if not server_id.isdigit() or not user_id.isdigit():
        raise ValueError("アカウント情報が不正です")
    return server_id, user_id


def ensure(c, owner):
    server_id, user_id = account(owner)
    c.execute(
        "INSERT OR IGNORE INTO pointsdb.points(server_id,user_id,points) VALUES (?,?,0)",
        (server_id, user_id),
    )
    return server_id, user_id


def balance(c, owner):
    server_id, user_id = account(owner)
    row = c.execute(
        "SELECT points FROM pointsdb.points WHERE server_id=? AND user_id=?",
        (server_id, user_id),
    ).fetchone()
    return int(row[0]) if row else 0


def debit(c, owner, amount):
    if type(amount) is not int or amount < 0:
        raise ValueError("数量が不正です")
    server_id, user_id = ensure(c, owner)
    return c.execute(
        "UPDATE pointsdb.points SET points=points-? "
        "WHERE server_id=? AND user_id=? AND points>=?",
        (amount, server_id, user_id, amount),
    ).rowcount == 1


def credit(c, owner, amount):
    if type(amount) is not int or amount < 0:
        raise ValueError("数量が不正です")
    server_id, user_id = ensure(c, owner)
    c.execute(
        "UPDATE pointsdb.points SET points=points+? WHERE server_id=? AND user_id=?",
        (amount, server_id, user_id),
    )
    return balance(c, owner)
