"""Opt-in durable idempotency for legacy boat-race purchases.

The receipt and points/ticket writes commit in the same SQLite transaction.
"""
import hashlib
import json
import re


_ID = re.compile(r'^[A-Za-z0-9_-]{12,100}$')


def ensure_receipts(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS br_purchase_receipts ('
                 'owner TEXT NOT NULL, request_id TEXT NOT NULL, fingerprint TEXT NOT NULL, '
                 'total INTEGER NOT NULL, PRIMARY KEY(owner,request_id))')


def purchase_once(conn, league, owner, venue, date, race, items, request_id):
    if not isinstance(request_id, str) or not _ID.fullmatch(request_id):
        raise ValueError('購入リクエストIDが不正です')
    if conn.in_transaction:
        raise ValueError('purchase requires a fresh transaction')
    try:
        payload = json.dumps([venue, str(date), race, items], ensure_ascii=False,
                             sort_keys=True, separators=(',', ':'), allow_nan=False)
    except (TypeError, ValueError):
        raise ValueError('投票内容が正しくありません') from None
    fingerprint = hashlib.sha256(payload.encode('utf-8')).hexdigest()
    conn.execute('BEGIN IMMEDIATE')
    try:
        ensure_receipts(conn)
        old = conn.execute('SELECT fingerprint,total FROM br_purchase_receipts '
                           'WHERE owner=? AND request_id=?', (owner, request_id)).fetchone()
        if old:
            if old[0] != fingerprint:
                raise ValueError('同じ購入IDに異なる投票内容は使用できません')
            conn.commit()
            return {'total': old[1], 'replayed': True}
        # legacy_purchase owns its own transaction; call the same checks and writes
        # under the lock already acquired here, without nesting transactions.
        day = date.split('@', 1)[0] if isinstance(date, str) else date.isoformat()
        present = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='br_engine_assignment'").fetchone()
        if present:
            assignment = conn.execute('SELECT engine FROM br_engine_assignment WHERE venue=? AND date=? AND race=?',
                                      (venue, day, race)).fetchone()
            if assignment and assignment[0] != 'legacy':
                raise ValueError('新方式のレースは舟券購入を準備中です')
        total = league.place_bets(conn, owner, venue, date, race, items)
        conn.execute('INSERT INTO br_purchase_receipts VALUES (?,?,?,?)',
                     (owner, request_id, fingerprint, total))
        conn.commit()
        return {'total': total, 'replayed': False}
    except BaseException:
        conn.rollback()
        raise


def purchase_status(conn, owner, request_id):
    """Read-only, owner-scoped receipt lookup. Missing receipt is not proof of failure."""
    if not isinstance(request_id, str) or not _ID.fullmatch(request_id):
        raise ValueError('購入リクエストIDが不正です')
    table = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='br_purchase_receipts'").fetchone()
    if not table:
        return {'status': 'not_found'}
    row = conn.execute('SELECT total FROM br_purchase_receipts WHERE owner=? AND request_id=?',
                       (owner, request_id)).fetchone()
    return {'status': 'confirmed', 'total': row[0]} if row else {'status': 'not_found'}
