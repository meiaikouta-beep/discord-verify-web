"""European (single-zero) roulette: server-authoritative rounds and bets.

All mutating functions must be called inside a SQLite BEGIN IMMEDIATE transaction
(same convention as medal_bank.py). Currency lives in atto1 points(server_id,user_id,points).
The client never decides amounts, winners, or results.
"""
import json
import secrets
from server import points

ROUND_SECONDS = 120                      # every round closes 2 minutes after it opens
CHIPS = (100, 500, 1000, 5000, 10000)    # 1 chip == this many gold
MAX_TOTAL_PER_ROUND = 1_000_000          # per player, per round
HISTORY_N = 15
MAX_SEATS = 4                            # players at the shared table

# Timeline after betting closes (seconds since closes_at). The client animation uses the same numbers.
SPIN_LAND = 15                           # ball is launched at 0 and drops into its pocket at 15
SPIN_STOP = 5                            # the wheel then takes 5 s to come to rest (ends at 20)
POPUP_DELAY = 2                          # result popup appears 2 s after the wheel stops (22)
POPUP_SHOW = 7                           # popup stays 7 s, then the next betting round opens (29)
REVEAL_AFTER = SPIN_LAND + SPIN_STOP + POPUP_DELAY
CYCLE_AFTER = REVEAL_AFTER + POPUP_SHOW

RED = frozenset({1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36})
_ALL = tuple(range(1, 37))

# Outside bets: id -> (numbers, payout multiplier "X to 1")
OUTSIDE = {
    'dozen1': (frozenset(range(1, 13)), 2),
    'dozen2': (frozenset(range(13, 25)), 2),
    'dozen3': (frozenset(range(25, 37)), 2),
    'col1': (frozenset(n for n in _ALL if n % 3 == 1), 2),
    'col2': (frozenset(n for n in _ALL if n % 3 == 2), 2),
    'col3': (frozenset(n for n in _ALL if n % 3 == 0), 2),
    'red': (frozenset(RED), 1),
    'black': (frozenset(n for n in _ALL if n not in RED), 1),
    'odd': (frozenset(n for n in _ALL if n % 2 == 1), 1),
    'even': (frozenset(n for n in _ALL if n % 2 == 0), 1),
    'low': (frozenset(range(1, 19)), 1),
    'high': (frozenset(range(19, 37)), 1),
}


def _street(k):
    return frozenset((3 * k + 1, 3 * k + 2, 3 * k + 3))


def _build_inside():
    """frozenset(numbers) -> (type, multiplier). Table columns are streets (1-2-3, 4-5-6 ...)."""
    d = {}
    for n in range(37):
        d[frozenset((n,))] = ('straight', 35)
    for n in range(1, 37):
        if n % 3:                       # neighbours inside the same column
            d[frozenset((n, n + 1))] = ('split', 17)
        if n <= 33:                     # neighbours across columns
            d[frozenset((n, n + 3))] = ('split', 17)
    for n in (1, 2, 3):
        d[frozenset((0, n))] = ('split', 17)
    for k in range(12):
        d[_street(k)] = ('street', 11)
    d[frozenset((0, 1, 2))] = ('trio', 11)
    d[frozenset((0, 2, 3))] = ('trio', 11)
    d[frozenset((0, 1, 2, 3))] = ('basket', 6)
    for n in range(1, 34):
        if n % 3:
            d[frozenset((n, n + 1, n + 3, n + 4))] = ('corner', 8)
    for k in range(11):
        d[_street(k) | _street(k + 1)] = ('sixline', 5)
    return d


INSIDE = _build_inside()


def resolve_bet(t, nums):
    """Validate a client bet description. Returns (bet_type, sorted_numbers, multiplier)."""
    if isinstance(t, str) and t in OUTSIDE:
        s, mult = OUTSIDE[t]
        return t, sorted(s), mult
    if not isinstance(nums, list) or not 1 <= len(nums) <= 6:
        raise ValueError('賭け位置が不正です')
    if any(type(n) is not int or not 0 <= n <= 36 for n in nums):
        raise ValueError('賭け位置が不正です')
    key = frozenset(nums)
    if len(key) != len(nums) or key not in INSIDE:
        raise ValueError('その場所にはベットできません')
    bt, mult = INSIDE[key]
    return bt, sorted(key), mult


def ensure_tables(c):
    c.execute('''CREATE TABLE IF NOT EXISTS roulette_rounds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        opened_at REAL NOT NULL, closes_at REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'open', result INTEGER)''')
    c.execute('''CREATE TABLE IF NOT EXISTS roulette_bets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        round_id INTEGER NOT NULL, owner TEXT NOT NULL, op_id TEXT NOT NULL,
        bet_type TEXT NOT NULL, nums TEXT NOT NULL,
        amount INTEGER NOT NULL CHECK(amount>0), mult INTEGER NOT NULL,
        created_at REAL NOT NULL, UNIQUE(owner, op_id))''')
    c.execute('CREATE INDEX IF NOT EXISTS roulette_bets_round ON roulette_bets(round_id, owner)')


def open_round(c):
    return c.execute(
        "SELECT id, opened_at, closes_at FROM roulette_rounds WHERE status='open' ORDER BY id DESC LIMIT 1"
    ).fetchone()


def latest_round(c):
    """Newest round in any state: (id, opened_at, closes_at, status, result)."""
    return c.execute(
        "SELECT id, opened_at, closes_at, status, result FROM roulette_rounds ORDER BY id DESC LIMIT 1"
    ).fetchone()


def ensure_open_round(c, now):
    """The open round, creating one if the table is idle. None while a spin / result is still being shown."""
    r = open_round(c)
    if r is None:
        last = latest_round(c)
        if last is not None and (last[3] == 'spinning' or now < last[2] + CYCLE_AFTER):
            return None
        c.execute('INSERT INTO roulette_rounds(opened_at, closes_at) VALUES (?,?)', (now, now + ROUND_SECONDS))
        r = open_round(c)
    return r


def _wallet(c, uid):
    return points.balance(c, uid)


def place_bet(c, uid, t, nums, amount, op_id, now):
    if not isinstance(op_id, str) or not 8 <= len(op_id) <= 100:
        raise ValueError('操作IDが不正です')
    if type(amount) is not int or amount not in CHIPS:
        raise ValueError('チップの額が不正です')
    r = ensure_open_round(c, now)
    if r is None or now >= r[2]:
        raise ValueError('ベットは締め切られました')
    bet_type, ns, mult = resolve_bet(t, nums)
    if c.execute('SELECT 1 FROM roulette_bets WHERE owner=? AND op_id=?', (uid, op_id)).fetchone():
        return                              # same operation sent twice: ignore
    total = c.execute('SELECT COALESCE(SUM(amount),0) FROM roulette_bets WHERE round_id=? AND owner=?',
                      (r[0], uid)).fetchone()[0]
    if total + amount > MAX_TOTAL_PER_ROUND:
        raise ValueError('1ラウンドのベット上限（%sポイント）を超えます' % format(MAX_TOTAL_PER_ROUND, ','))
    if not points.debit(c, uid, amount):
        raise ValueError('ポイントが足りません')
    c.execute('INSERT INTO roulette_bets(round_id,owner,op_id,bet_type,nums,amount,mult,created_at) '
              'VALUES (?,?,?,?,?,?,?,?)',
              (r[0], uid, op_id, bet_type, json.dumps(ns), amount, mult, now))


def _refund(c, uid, rows):
    total = sum(x[1] for x in rows)
    if total:
        points.credit(c, uid, total)
    for x in rows:
        c.execute('DELETE FROM roulette_bets WHERE id=?', (x[0],))
    return total


def _open_for_edit(c, now):
    r = ensure_open_round(c, now)
    if r is None or now >= r[2]:
        raise ValueError('ベットは締め切られました')
    return r


def clear_bets(c, uid, now):
    r = _open_for_edit(c, now)
    rows = c.execute('SELECT id, amount FROM roulette_bets WHERE round_id=? AND owner=?', (r[0], uid)).fetchall()
    return _refund(c, uid, rows)


def undo_bet(c, uid, now):
    r = _open_for_edit(c, now)
    rows = c.execute('SELECT id, amount FROM roulette_bets WHERE round_id=? AND owner=? ORDER BY id DESC LIMIT 1',
                     (r[0], uid)).fetchall()
    return _refund(c, uid, rows)


def history(c):
    rows = c.execute("SELECT result FROM roulette_rounds WHERE status='settled' AND result IS NOT NULL "
                     "ORDER BY id DESC LIMIT ?", (HISTORY_N,)).fetchall()
    return [x[0] for x in rows]


def state(c, uid, now):
    """Read-only snapshot for one player (no writes)."""
    r = open_round(c)
    bets = []
    total = 0
    if r is not None:
        rows = c.execute('SELECT bet_type, nums, SUM(amount) FROM roulette_bets '
                         'WHERE round_id=? AND owner=? GROUP BY bet_type, nums ORDER BY MIN(id)',
                         (r[0], uid)).fetchall()
        for x in rows:
            bets.append({'t': x[0], 'nums': json.loads(x[1]), 'amount': x[2]})
            total += x[2]
    return {
        'round': None if r is None else {'id': r[0], 'opened_at': r[1], 'closes_at': r[2]},
        'server_now': now,
        'bets': bets,
        'total_bet': total,
        'balance': _wallet(c, uid),
        'history': history(c),
        'chips': list(CHIPS),
        'round_seconds': ROUND_SECONDS,
    }


def settle(c, round_id, number):
    """Pay winners (stake + winnings) for the number that was drawn when the spin started."""
    c.execute("UPDATE roulette_rounds SET status='settled' WHERE id=?", (round_id,))
    owners = {}
    for owner, nums_json, amount, mult in c.execute(
            'SELECT owner, nums, amount, mult FROM roulette_bets WHERE round_id=?', (round_id,)).fetchall():
        o = owners.setdefault(owner, {'stake': 0, 'payout': 0})
        o['stake'] += amount
        if number in json.loads(nums_json):
            o['payout'] += amount * (mult + 1)
    for owner, o in owners.items():
        if o['payout']:
            points.credit(c, owner, o['payout'])
    return {'kind': 'result', 'round_id': round_id, 'number': number, 'owners': owners}


def tick(c, now):
    """Called once a second. One step of the round timeline per call:

    open --(closes_at)--> spinning (number drawn, bets locked, wheel animation runs on the clients)
         --(+REVEAL_AFTER)--> settled (payout + result popup)
         --(+CYCLE_AFTER)--> next round opens.
    """
    r = open_round(c)
    if r is not None:
        if now >= r[2]:
            number = secrets.randbelow(37)
            c.execute("UPDATE roulette_rounds SET status='spinning', result=? WHERE id=?", (number, r[0]))
            return [{'kind': 'spin', 'round_id': r[0], 'number': number}]
        return []
    last = latest_round(c)
    if last is not None and last[3] == 'spinning':
        if now >= last[2] + REVEAL_AFTER:
            return [settle(c, last[0], last[4])]
        return []
    if last is None or now >= last[2] + CYCLE_AFTER:
        c.execute('INSERT INTO roulette_rounds(opened_at, closes_at) VALUES (?,?)', (now, now + ROUND_SECONDS))
        return [{'kind': 'opened', 'round_id': open_round(c)[0]}]
    return []


def table_snapshot(c, now, seat_map, names):
    """Read-only snapshot of the shared table. seat_map: {uid: seat index}, names: {uid: display name}.

    Every seated player's balance and current-round bets are included so that everyone sees the same table.
    """
    r = latest_round(c)               # keeps showing the bets while the wheel spins and the result is shown
    owners = list(seat_map)
    bets = {u: [] for u in owners}
    totals = {u: 0 for u in owners}
    balances = {}
    if owners:
        q = ','.join('?' * len(owners))
        balances = {o: points.balance(c, o) for o in owners}
        if r is not None:
            rows = c.execute('SELECT owner, bet_type, nums, SUM(amount) FROM roulette_bets '
                             'WHERE round_id=? AND owner IN (%s) GROUP BY owner, bet_type, nums ORDER BY MIN(id)' % q,
                             [r[0]] + owners).fetchall()
            for o, t, nums, amt in rows:
                bets[o].append({'t': t, 'nums': json.loads(nums), 'amount': amt})
                totals[o] += amt
    players = []
    for u in sorted(owners, key=lambda x: seat_map[x]):
        players.append({
            'seat': seat_map[u],
            'name': names.get(u) or 'Player',
            'balance': balances.get(u, 0),
            'total_bet': totals[u],
            'bets': bets[u],
        })
    return {
        'round': None if r is None else {
            'id': r[0], 'opened_at': r[1], 'closes_at': r[2], 'status': r[3],
            'result': r[4] if r[3] in ('spinning', 'settled') else None,
        },
        'timeline': {'land': SPIN_LAND, 'stop': SPIN_STOP, 'popup_delay': POPUP_DELAY,
                     'popup_show': POPUP_SHOW, 'reveal': REVEAL_AFTER, 'cycle': CYCLE_AFTER},
        'server_now': now,
        'players': players,
        'history': history(c),
        'chips': list(CHIPS),
        'round_seconds': ROUND_SECONDS,
        'max_seats': MAX_SEATS,
    }
