"""Append-only race result store, independent of production routing.

Never imports or changes the legacy race engine. A result must be committed before
being served to payouts or 3D playback by a future integration.
"""
import hashlib
import json
import os
import sqlite3
from pathlib import Path

SCHEMA = '''CREATE TABLE IF NOT EXISTS br_result_v2 (
 venue INTEGER NOT NULL, date TEXT NOT NULL, race INTEGER NOT NULL,
 engine TEXT NOT NULL, result_json TEXT NOT NULL, digest TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(venue,date,race)
)'''


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def validate(result):
    if not isinstance(result, dict):
        raise ValueError('result must be object')
    order = result.get('order')
    if type(order) is not list or len(order) != 6 or any(type(x) is not int for x in order) or sorted(order) != list(range(1, 7)):
        raise ValueError('invalid finishing order')
    st = result.get('st')
    if type(st) is not list or len(st) != 6 or any(type(x) not in (int, float) or not 0 <= x <= 3 for x in st):
        raise ValueError('invalid start times')
    if not isinstance(result.get('kimarite'), str) or not result['kimarite']:
        raise ValueError('missing kimarite')
    pay = result.get('pay')
    if not isinstance(pay, dict) or any(not isinstance(v, dict) for v in pay.values()):
        raise ValueError('invalid payouts')
    for values in pay.values():
        for odds in values.values():
            if type(odds) not in (int, float) or not 0 < odds < 1_000_000:
                raise ValueError('invalid payout odds')
    canonical(result)


def initialize(conn):
    conn.execute(SCHEMA)


def put_once(conn, venue, date, race, engine, result):
    """Insert once; identical retries accepted, divergent retries rejected.

    Call inside the caller's transaction. No implicit commit.
    """
    if type(venue) is not int or venue < 1 or type(race) is not int or not 1 <= race <= 12:
        raise ValueError('invalid race key')
    if not isinstance(date, str) or not date or not isinstance(engine, str) or not engine:
        raise ValueError('invalid date or engine')
    validate(result)
    data = canonical(result)
    digest = hashlib.sha256(data.encode('utf-8')).hexdigest()
    conn.execute('INSERT OR IGNORE INTO br_result_v2(venue,date,race,engine,result_json,digest) VALUES(?,?,?,?,?,?)',
                 (venue, date, race, engine, data, digest))
    row = conn.execute('SELECT engine,result_json,digest FROM br_result_v2 WHERE venue=? AND date=? AND race=?',
                       (venue, date, race)).fetchone()
    if row is None or tuple(row) != (engine, data, digest):
        raise ValueError('race result already frozen with different content')
    return digest


def get(conn, venue, date, race):
    row = conn.execute('SELECT engine,result_json,digest FROM br_result_v2 WHERE venue=? AND date=? AND race=?',
                       (venue, date, race)).fetchone()
    if row is None:
        return None
    engine, data, digest = row
    if hashlib.sha256(data.encode('utf-8')).hexdigest() != digest:
        raise ValueError('frozen result checksum mismatch')
    result = json.loads(data)
    validate(result)
    return {'engine': engine, 'result': result, 'digest': digest}


def readonly_connect(path):
    """Inspect an existing database without creating or mutating it."""
    return sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)
