"""Immutable per-race engine assignment. Opt-in; no production writes by import.

The caller owns the SQLite transaction. Never automatically backfill existing races
with v2; use assign_legacy_for_existing to explicitly pin existing races first.
"""
import datetime as dt
import sqlite3

SCHEMA = '''CREATE TABLE IF NOT EXISTS br_engine_assignment (
 venue INTEGER NOT NULL, date TEXT NOT NULL, race INTEGER NOT NULL,
 engine TEXT NOT NULL CHECK(engine IN ('legacy','v2')),
 assigned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(venue,date,race)
)'''

class AssignmentConflict(ValueError):
    pass

class UnassignedRace(ValueError):
    pass

def initialize(conn):
    conn.execute(SCHEMA)

def _key(venue, date, race):
    if type(venue) is not int or venue < 1 or type(race) is not int or not 1 <= race <= 12:
        raise ValueError('invalid race key')
    if not isinstance(date, str) or dt.date.fromisoformat(date).isoformat() != date:
        raise ValueError('date must be YYYY-MM-DD')
    return venue, date, race

def get(conn, venue, date, race):
    key = _key(venue, date, race)
    row = conn.execute('SELECT engine FROM br_engine_assignment WHERE venue=? AND date=? AND race=?', key).fetchone()
    return row[0] if row else None

def assign_once(conn, venue, date, race, engine):
    key = _key(venue, date, race)
    if engine not in ('legacy', 'v2'):
        raise ValueError('invalid engine')
    # Protect against accidentally assigning an engine different from a frozen result.
    existing = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='br_result_v2'").fetchone()
    if existing:
        frozen = conn.execute('SELECT engine FROM br_result_v2 WHERE venue=? AND date=? AND race=?', key).fetchone()
        if frozen and frozen[0] != engine:
            raise AssignmentConflict('frozen result engine differs')
    conn.execute('INSERT OR IGNORE INTO br_engine_assignment(venue,date,race,engine) VALUES(?,?,?,?)', (*key, engine))
    actual = get(conn, *key)
    if actual != engine:
        raise AssignmentConflict('engine assignment is immutable')
    return actual

def require(conn, venue, date, race):
    value = get(conn, venue, date, race)
    if value is None:
        raise UnassignedRace('race engine is not assigned; do not infer from current settings')
    return value

def assignment_callback(conn):
    """Adapter for boatrace_result_router.resolve_result(engine_for_race=...)."""
    return lambda venue, date, race: require(conn, venue, date, race)

def assign_future_v2(conn, venue, date, race, *, today, legacy_history_verified=False):
    """Explicit guarded v2 assignment; never auto-switch on restart.

    `today` is the caller's local ISO date, captured once for the operation.
    A production rollout must separately ensure there are no open bets on this race.
    """
    _key(venue, date, race)
    if not legacy_history_verified:
        raise ValueError('legacy history verification required')
    if dt.date.fromisoformat(date) <= dt.date.fromisoformat(today):
        raise ValueError('v2 assignment must be for a future date')
    return assign_once(conn, venue, date, race, 'v2')
