"""V71 authoritative slot round, credit and payout validation.
Server determines all payable roles and validates the three stopped reel indexes.
"""
import secrets, json, time, datetime, os
from zoneinfo import ZoneInfo
from server import medal_bank

STRIPS=[
 ['flower','cherry','watermelon','bell','replay','red7','replay','blue7','bell','replay','flower','flower','watermelon','bell','replay','sp','cherry','watermelon','bell','replay'],
 ['cherry','flower','replay','bell','watermelon','cherry','red7','replay','bell','watermelon','cherry','blue7','replay','bell','watermelon','cherry','sp','replay','bell','watermelon'],
 ['watermelon','cherry','flower','bell','replay','sp','cherry','red7','bell','replay','watermelon','cherry','blue7','bell','replay','watermelon','cherry','flower','bell','replay']]
LINES=((0,0,0),(1,1,1),(2,2,2),(0,1,2),(2,1,0))
ROLES={'big':'red7','super':'blue7','freeze':'sp'}

def sym(i,p,row):return STRIPS[i][(p+row-1)%20]
def hits(pos):
    h=[]
    for line,rows in enumerate(LINES):
        for role in ('bell','watermelon','replay','red7','blue7','sp'):
            if all(sym(i,pos[i],rows[i])==role for i in range(3)):h.append((role,line))
    if sym(0,pos[0],0)=='cherry':h.append(('cherry',0))
    if sym(0,pos[0],2)=='cherry':h.append(('cherry',2))
    return h

def win(role,pos,nav=None,stops=None):
    if type(pos)!=list or len(pos)!=3 or any(type(n)!=int or not 0<=n<20 for n in pos):return False
    if nav is not None and stops!=nav:return False
    h=hits(pos)
    if role=='cherry':return any(x=='cherry' and y in (0,2) for x,y in h)
    if role=='freeze':return ('sp',3) in h and sym(0,pos[0],1)=='cherry'
    if role in ('big','super'):return (ROLES[role],1) in h
    if role=='miss':return False
    return any(x==role for x,_ in h)

def migrate(c):
    c.execute('''CREATE TABLE IF NOT EXISTS pachi_rounds (owner TEXT PRIMARY KEY, round_id TEXT NOT NULL, role TEXT NOT NULL, phase TEXT NOT NULL, nav TEXT, started_at INTEGER NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS pachi_runtime (owner TEXT PRIMARY KEY, bonus_pending TEXT, bonus_remaining INTEGER NOT NULL DEFAULT 0, bonus_kind TEXT, chain_bonus TEXT, replay_free INTEGER NOT NULL DEFAULT 0, at_remaining INTEGER NOT NULL DEFAULT 0, at_hidden INTEGER NOT NULL DEFAULT 0, mode TEXT NOT NULL DEFAULT 'A', at_rate REAL NOT NULL DEFAULT 0, at_bonus_pending INTEGER NOT NULL DEFAULT 0, day TEXT NOT NULL DEFAULT '')''')

# V21: keep setting 3 at the original standalone BIG/SUPER odds.
V21_SINGLE={1:(1/266,1/500),2:(1/257.7,1/484.5),3:(1/250,1/470),4:(1/242.7,1/456.3),5:(1/235.8,1/443.4),6:(1/229.4,1/431.2)}
V21_OVERLAP={1:(.07,.20,.70,.85),2:(.09,.215,.66,.82),3:(.11,.23,.62,.79),4:(.125,.245,.58,.76),5:(.14,.26,.54,.73),6:(.15,.28,.50,.70)}
V21_BELL=0.561
# 単独BIG/SUPERと小役(桜/西瓜)重複の当選確率を一括で倍率変更(元に戻すなら1.0)
V21_RATE_MULT=1/1.8   # 元の確率の1/1.8(=1.8倍重い)。1.0で元の確率
V21_SINGLE={k:(a*V21_RATE_MULT,b*V21_RATE_MULT) for k,(a,b) in V21_SINGLE.items()}
V21_OVERLAP={k:(min(1.0,a*V21_RATE_MULT),min(1.0,b*V21_RATE_MULT),c,d) for k,(a,b,c,d) in V21_OVERLAP.items()}

# AT上乗せ: 小役ごとのトリガー率と、上乗せゲーム数(値, 抽選比率)。AT中・ボーナス中の両方で使用
ADDON_CHANCE={'cherry':.18,'watermelon':.27,'replay':.005}
ADDON_VALS={'cherry':([20,30,50,70,100],[43,35,15,5,2]),'watermelon':([30,50,70,100,200],[47,30,15,7,1]),'replay':([100,200],[80,20])}

def randrole(phase,setting_num=3):
    weights=[('replay',1/7.3),('cherry',1/32),('watermelon',1/64)]
    if phase=='normal':weights=[('freeze',1/4096),('big',V21_SINGLE[setting_num][0]),('super',V21_SINGLE[setting_num][1])]+weights+[('bell',1/8)]
    elif phase=='at':weights=[('freeze',1/4096),('big',V21_SINGLE[setting_num][0]),('super',V21_SINGLE[setting_num][1])]+weights+[('bell',V21_BELL)]
    else:weights += [('bell',V21_BELL)]
    r=secrets.randbelow(10**9)/10**9
    for role,weight in weights:
        r-=weight
        if r<0:return role
    return 'miss'

V70_MODE={
 1:{'A':(.50,.35,.15),'B':(.70,.30),'C':(.70,.30),'atCherry':.15,'atWatermelon':.25},
 2:{'A':(.48,.35,.17),'B':(.68,.32),'C':(.68,.32),'atCherry':.17,'atWatermelon':.27},
 3:{'A':(.45,.35,.20),'B':(.65,.35),'C':(.65,.35),'atCherry':.19,'atWatermelon':.30},
 4:{'A':(.42,.35,.23),'B':(.62,.38),'C':(.62,.38),'atCherry':.22,'atWatermelon':.33},
 5:{'A':(.38,.35,.27),'B':(.58,.42),'C':(.55,.45),'atCherry':.25,'atWatermelon':.37},
 6:{'A':(.35,.35,.30),'B':(.55,.45),'C':(.50,.50),'atCherry':.30,'atWatermelon':.42},
}
def setting(c,uid):
 r=c.execute('SELECT slot_setting FROM users WHERE id=?',(uid,)).fetchone()
 n=int(r[0]) if r and r[0] else 1
 return n if 1<=n<=6 else 1

def ensure_at_columns(c):
    cols={r['name'] for r in c.execute('PRAGMA table_info(pachi_runtime)')}
    round_cols={r['name'] for r in c.execute('PRAGMA table_info(pachi_rounds)')}
    if 'at_first_hit' not in round_cols:c.execute('ALTER TABLE pachi_rounds ADD COLUMN at_first_hit INTEGER NOT NULL DEFAULT 0')
    for name,definition in [('at_continue','INTEGER NOT NULL DEFAULT -1'),('at_notice','INTEGER NOT NULL DEFAULT 0'),('overlap_delay','INTEGER NOT NULL DEFAULT 0'),('reset_id',"TEXT NOT NULL DEFAULT '0'")]:
        if name not in cols:c.execute(f'ALTER TABLE pachi_runtime ADD COLUMN {name} {definition}')

def prepare_at_continuation(c,uid,remaining,rate,force=False):
    # A continuation outcome is fixed at the beginning of each AT set.
    result=1 if force else int(secrets.randbelow(1000000)<rate*1000000)
    notice=secrets.randbelow(7)+1 if result else 0
    c.execute('UPDATE pachi_runtime SET at_continue=?,at_notice=? WHERE owner=?',(result,notice,uid))

def start_hidden_at(c,uid,mode):
    n=secrets.randbelow(100)
    initial=next(v for v,w in zip((30,50,75,100),(35,45,15,5)) if (n:=n-w)<0)
    n=secrets.randbelow(100)
    rate=next(v for v,w in zip((.79,.89),(50,50)) if (n:=n-w)<0) if mode=='D' else next(v for v,w in zip((.50,.67,.79,.89),(45,35,15,5)) if (n:=n-w)<0)
    c.execute('UPDATE pachi_runtime SET at_remaining=?,at_rate=?,at_hidden=0 WHERE owner=?',(initial,rate,uid))
    prepare_at_continuation(c,uid,initial,rate,force=(mode=='D'))

def force_settle(c,uid):
    a=c.execute('SELECT credit,sand_balance,card_inserted FROM pachi_medal_accounts WHERE owner=?',(uid,)).fetchone()
    if not a:return
    moved=a['credit']>0 or a['sand_balance']>0
    if moved and not c.execute("SELECT 1 FROM inventory WHERE owner=? AND item='pachi_member_card'",(uid,)).fetchone():
        c.execute("INSERT INTO inventory(owner,item,quantity) VALUES (?,'pachi_member_card',1)",(uid,))
    c.execute('UPDATE pachi_medal_accounts SET saved_medals=saved_medals+credit,credit=0,card_cash=card_cash+sand_balance,sand_balance=0,card_inserted=0 WHERE owner=?',(uid,))

def runtime(c,uid):
    c.execute('INSERT OR IGNORE INTO pachi_runtime(owner,mode) VALUES (?,?)',(uid,('A','B','C')[secrets.randbelow(3)]))
    ensure_at_columns(c)
    r=c.execute('SELECT * FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()
    day=datetime.datetime.now(ZoneInfo('Asia/Tokyo')).strftime('%Y-%m-%d')
    if r['day']!=day:
        user=c.execute('SELECT slot_day FROM users WHERE id=?',(uid,)).fetchone()
        if user and user['slot_day']!=day:
            c.execute('UPDATE users SET slot_setting=?,slot_day=? WHERE id=?',((lambda _n:next(_i+1 for _i,_t in enumerate((30,55,75,90,96,100)) if _n<_t))(secrets.randbelow(100)),day,uid))
        c.execute('DELETE FROM pachi_rounds WHERE owner=?',(uid,))
        force_settle(c,uid)
        c.execute('UPDATE pachi_runtime SET reset_id=? WHERE owner=?',(secrets.token_hex(4),uid))
        c.execute('UPDATE pachi_runtime SET bonus_pending=NULL,bonus_remaining=0,bonus_kind=NULL,chain_bonus=NULL,replay_free=0,at_remaining=0,at_hidden=0,at_rate=0,at_bonus_pending=0,at_continue=-1,at_notice=0,overlap_delay=0,mode=?,day=? WHERE owner=?',(('A','B','C')[secrets.randbelow(3)],day,uid))
        r=c.execute('SELECT * FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()
    return r

DEBUG_ROLES=frozenset(('bell','replay','watermelon','cherry','big','super','freeze','miss','chain','seven_fake','seven_real'))

def begin(c,uid,debug_force_role=None):
    if debug_force_role is not None:
        if os.environ.get('TS_PACHI_DEBUG_ENABLED','1') != '1':
            raise ValueError('テスト操作は無効です')
        if type(debug_force_role) is not str or debug_force_role not in DEBUG_ROLES:
            raise ValueError('不正な強制フラグです')
    a=medal_bank.state(c,uid)
    r=runtime(c,uid)
    existing=c.execute('SELECT started_at FROM pachi_rounds WHERE owner=?',(uid,)).fetchone()
    if existing and int(time.time())-existing['started_at']>3:
        c.execute('DELETE FROM pachi_rounds WHERE owner=?',(uid,))
        existing=None
    if existing:raise ValueError('前のゲームの停止操作が未完了です')
    if debug_force_role in ('big','super','freeze') and (r['bonus_pending'] or r['bonus_remaining']):
        raise ValueError('ボーナス中はボーナス図柄の強制指定はできません')
    if debug_force_role in ('seven_fake','seven_real') and (r['bonus_pending'] or not (r['bonus_remaining'] or r['at_remaining'])):
        raise ValueError('7を狙えの強制指定はボーナス・AT消化中のみ有効です')
    if debug_force_role=='chain':
        if not r['bonus_remaining']:raise ValueError('1G連予約はボーナス消化中のみ有効です')
        chain_kind=r['chain_bonus'] or ('big' if secrets.randbelow(10)<7 else 'super')
        c.execute('UPDATE pachi_runtime SET chain_bonus=? WHERE owner=?',(chain_kind,uid))
        r=runtime(c,uid)
        debug_force_role=None
    if not r['replay_free']:
        if not c.execute('UPDATE pachi_medal_accounts SET credit=credit-3 WHERE owner=? AND credit>=3',(uid,)).rowcount:raise ValueError('クレジットが3枚未満です')
    else:c.execute('UPDATE pachi_runtime SET replay_free=0 WHERE owner=?',(uid,))
    seven=None;seven_add=None
    seven_force=debug_force_role if debug_force_role in ('seven_fake','seven_real') else None
    if seven_force:debug_force_role='miss'
    overlap_hit=False
    if r['bonus_pending'] and r['overlap_delay']:
        role='miss';phase='overlap_notice'
        c.execute('UPDATE pachi_runtime SET overlap_delay=0 WHERE owner=?',(uid,))
    elif r['bonus_pending']:
        role=r['bonus_pending'];phase='bonus_draw'
        c.execute('UPDATE pachi_runtime SET bonus_pending=NULL WHERE owner=?',(uid,))
    else:
        phase='bonus' if r['bonus_remaining'] else 'at' if r['at_remaining'] else 'normal'
        role=debug_force_role if debug_force_role is not None else randrole(phase,setting(c,uid))
        # Overlap draws are conditional on the small role; the small role still pays.
        if phase in ('normal','at') and role in ('cherry','watermelon'):
            cherry_p,melon_p,cherry_big,melon_big=V21_OVERLAP[setting(c,uid)]
            if secrets.randbelow(1000000)<(cherry_p if role=='cherry' else melon_p)*1000000:
                big_share=cherry_big if role=='cherry' else melon_big
                overlap_kind='big' if secrets.randbelow(1000000)<big_share*1000000 else 'super'
                c.execute('UPDATE pachi_runtime SET bonus_pending=?,overlap_delay=1 WHERE owner=?',(overlap_kind,uid))
                overlap_hit=True
        if role in ('big','super'):
            c.execute('UPDATE pachi_runtime SET bonus_pending=? WHERE owner=?',(role,uid))
            role='miss';phase='establish'
    # Seven-aim is an independent presentation on a non-paying miss round.
    # Seven-aim rates on eligible miss rounds: real 1/120; fake 1/50 if not real.
    if phase in ('bonus','at') and role=='miss':
        if seven_force:
            seven='real' if seven_force=='seven_real' else 'fake'
        elif secrets.randbelow(120)==0:
            seven='real'
        elif secrets.randbelow(50)==0:
            seven='fake'
        if seven=='real':
            if phase=='bonus':
                seven_add='bonus'
                c.execute('UPDATE pachi_runtime SET at_bonus_pending=at_bonus_pending+50,at_hidden=CASE WHEN at_remaining>0 THEN at_hidden ELSE 1 END WHERE owner=?',(uid,))
            else:
                seven_add='at'
                c.execute('UPDATE pachi_runtime SET at_remaining=at_remaining+50 WHERE owner=?',(uid,))
    # Decide first AT win on the lever, so the client can announce at lever or stops.
    at_notice_step=-1
    if phase=='bonus' and role in ('cherry','watermelon') and not r['at_remaining'] and not r['at_hidden']:
        chance=V70_MODE[setting(c,uid)]['atCherry' if role=='cherry' else 'atWatermelon']
        if secrets.randbelow(1000000)<chance*1000000:
            c.execute('UPDATE pachi_runtime SET at_hidden=1 WHERE owner=?',(uid,))
            at_notice_step=secrets.randbelow(4)
    if phase=='at' and r['at_continue']<0:
        prepare_at_continuation(c,uid,r['at_remaining'],r['at_rate'])
        r=runtime(c,uid)
    at_add=0;at_add_step=-1
    if phase=='at' and not overlap_hit and role in ('cherry','watermelon','replay'):
        chance=ADDON_CHANCE[role]
        if secrets.randbelow(1000000)<chance*1000000:
            vals=ADDON_VALS[role]
            n=secrets.randbelow(sum(vals[1]));at_add=next(v for v,w in zip(vals[0],vals[1]) if (n:=n-w)<0)
            at_add_step=secrets.randbelow(4)
            c.execute('UPDATE pachi_runtime SET at_remaining=at_remaining+? WHERE owner=?',(at_add,uid))
    nav=None
    if role=='bell' and phase in ('bonus','at'):
        seq=[0,1,2]
        for i in (2,1):
            j=secrets.randbelow(i+1);seq[i],seq[j]=seq[j],seq[i]
        nav=seq
    pending_role = r['bonus_pending'] if phase in ('bonus_draw','overlap_notice') else (c.execute('SELECT bonus_pending FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()['bonus_pending'] if phase=='establish' else None)
    rid=secrets.token_hex(16)
    c.execute('INSERT INTO pachi_rounds(owner,round_id,role,phase,nav,started_at,at_first_hit) VALUES (?,?,?,?,?,?,?)',(uid,rid,role,phase,json.dumps(nav) if nav else None,int(time.time()),int(at_notice_step>=0)))
    return {'type':'pachi_round_begin_result','round_id':rid,'role':role,'phase':phase,'pending':pending_role,'nav':nav,'credit':a['credit']-(0 if r['replay_free'] else 3),'bonus_remaining':r['bonus_remaining'],'bonus_kind':r['bonus_kind'],'at_remaining':r['at_remaining'],'mode':r['mode'],'at_rate':r['at_rate'],'at_continue':r['at_continue']==1,'at_notice':r['at_notice'],'at_hidden':r['at_hidden'],'chain_bonus':c.execute('SELECT chain_bonus FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0], 'at_notice_step':at_notice_step,'at_add':at_add,'at_add_step':at_add_step, 'overlap_notice':phase=='overlap_notice','seven':seven,'seven_add':seven_add}

def settle(c,uid,rid,positions,stops):
    r=runtime(c,uid)
    row=c.execute('SELECT * FROM pachi_rounds WHERE owner=? AND round_id=?',(uid,rid)).fetchone()
    if not row:raise ValueError('未処理のゲームがありません')
    role=row['role'];phase=row['phase'];nav=json.loads(row['nav']) if row['nav'] else None
    won=win(role,positions,nav,stops)
    payout=(12 if phase in ('bonus','at') else 8) if role=='bell' else {'watermelon':10,'cherry':2}.get(role,0)
    if won and role in ('big','super','freeze'):payout=15
    if not won:payout=0
    if payout:c.execute('UPDATE pachi_medal_accounts SET credit=credit+? WHERE owner=?',(payout,uid))
    add_before=r['at_bonus_pending']
    if won and role=='replay':c.execute('UPDATE pachi_runtime SET replay_free=1 WHERE owner=?',(uid,))
    # AT small-role add-on draws are independent of eye-stop success.
    if phase=='bonus' and (r['at_remaining'] or r['at_hidden']) and not row['at_first_hit'] and role in ('cherry','watermelon','replay'):
        chance=ADDON_CHANCE[role]
        if secrets.randbelow(1000000)<chance*1000000:
            vals=ADDON_VALS[role]
            n=secrets.randbelow(sum(vals[1]));add=next(v for v,w in zip(vals[0],vals[1]) if (n:=n-w)<0)
            c.execute('UPDATE pachi_runtime SET '+('at_bonus_pending' if phase=='bonus' else 'at_remaining')+'='+('at_bonus_pending' if phase=='bonus' else 'at_remaining')+'+? WHERE owner=?',(add,uid))
    # First AT win was drawn at begin(); do not draw again at settle().
    # [super-promo] 赤7BIGが揃った時、20%でSUPER BIGへ昇格
    promoted=False;bonus_role=role
    if won and role=='big' and secrets.randbelow(100)<20:
        bonus_role='super';promoted=True
    if won and role in ('big','super','freeze'):
        length={'big':35,'super':60,'freeze':90}[bonus_role]
        chain_rate={'A':.15,'B':.30,'C':.65,'D':1.0}[r['mode']]
        chain=role=='freeze' or secrets.randbelow(1000000)<chain_rate*1000000
        chain_kind=('big' if secrets.randbelow(10)<7 else 'super') if chain else None
        c.execute('UPDATE pachi_runtime SET bonus_remaining=?,bonus_kind=?,chain_bonus=?,at_hidden=CASE WHEN ?="freeze" THEN 1 ELSE at_hidden END,mode=CASE WHEN ?="freeze" THEN "D" ELSE mode END WHERE owner=?',(length,bonus_role,chain_kind,role,role,uid))
        if r['at_remaining']:
            n=secrets.randbelow(100)
            add=next(v for v,w in zip((20,30,50,70,100),(40,35,15,7,3)) if (n:=n-w)<0)
            c.execute('UPDATE pachi_runtime SET at_bonus_pending=at_bonus_pending+? WHERE owner=?',(add,uid))
    elif phase=='bonus':
        remaining=max(0,r['bonus_remaining']-1)
        c.execute('UPDATE pachi_runtime SET bonus_remaining=? WHERE owner=?',(remaining,uid))
        if remaining==0:
            c.execute('UPDATE pachi_runtime SET bonus_kind=NULL,bonus_pending=chain_bonus,chain_bonus=NULL WHERE owner=?',(uid,))
            fresh=c.execute('SELECT * FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()
            if fresh['at_hidden'] and not fresh['at_remaining']:
                start_hidden_at(c,uid,fresh['mode'])
            elif fresh['at_hidden']:
                c.execute('UPDATE pachi_runtime SET at_hidden=0 WHERE owner=?',(uid,))
            # Mode transition at bonus completion, per setting 1 baseline.
            old=fresh['mode'];n=secrets.randbelow(1000000)/1000000;cfg=V70_MODE[setting(c,uid)]
            nxt= ('A' if n<cfg['A'][0] else 'B' if n<cfg['A'][0]+cfg['A'][1] else 'C') if old=='A' else ('B' if n<cfg['B'][0] else 'C') if old=='B' else ('A' if n<cfg['C'][0] else 'C') if old=='C' else ('A' if n<.20 else 'D')
            c.execute('UPDATE pachi_runtime SET mode=? WHERE owner=?',(nxt,uid))
    elif phase=='at':
        c.execute('UPDATE pachi_runtime SET at_remaining=MAX(0,at_remaining-1) WHERE owner=?',(uid,))
        fresh=c.execute('SELECT at_remaining,at_rate FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()
        if fresh['at_remaining']==0:
            if r['at_continue']==1:
                n=secrets.randbelow(100)
                initial=next(v for v,w in zip((30,50,75,100),(35,45,15,5)) if (n:=n-w)<0)
                c.execute('UPDATE pachi_runtime SET at_remaining=? WHERE owner=?',(initial,uid))
                prepare_at_continuation(c,uid,initial,fresh['at_rate'])
            else:
                c.execute('UPDATE pachi_runtime SET at_continue=-1,at_notice=0 WHERE owner=?',(uid,))
    c.execute('DELETE FROM pachi_rounds WHERE owner=?',(uid,))
    st=medal_bank.state(c,uid)
    return {'type':'pachi_round_settle_result','round_id':rid,'won':won,'payout':payout,'role':role,'credit':st['credit'],'bonus_remaining':c.execute('SELECT bonus_remaining FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0],'at_remaining':c.execute('SELECT at_remaining FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0],'at_continue':c.execute('SELECT at_continue FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0]==1,'at_notice':c.execute('SELECT at_notice FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0],'at_rate':c.execute('SELECT at_rate FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0],'bonus_pending':c.execute('SELECT bonus_pending FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0], 'at_hidden':c.execute('SELECT at_hidden FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0],'mode':c.execute('SELECT mode FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0], 'bonus_add':c.execute('SELECT at_bonus_pending FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()[0]-add_before,'promoted':promoted}

def abort(c,uid,rid):
    if rid:c.execute('DELETE FROM pachi_rounds WHERE owner=? AND round_id=?',(uid,rid))
    else:c.execute('DELETE FROM pachi_rounds WHERE owner=?',(uid,))
    return {'type':'pachi_round_abort_result'}
