"""Stage23 opt-in atomic result freeze; NOT wired into production settlement.

Requires an existing assignment, and a fresh connection to the same SQLite file
used for ticket purchases and engine assignment. Never calls legacy decide().
"""
from server.boatrace_engine_assignment import require
from server.boatrace_migration_guard import canonical_date, has_bets, table_exists
from server.boatrace_result_store import put_once, get, initialize


def freeze_assigned_result(conn, venue, date, race, engine, result):
    """Commit an immutable result under BEGIN IMMEDIATE; reject engine mismatch.

    For v2, any existing tickets are a hard failure, including settled tickets.
    Legacy tickets may coexist with a legacy result.
    """
    if conn.in_transaction:
        raise ValueError('result freeze requires a fresh transaction')
    conn.execute('BEGIN IMMEDIATE')
    try:
        day = canonical_date(date)
        if not table_exists(conn, 'br_engine_assignment'):
            raise ValueError('engine assignments not initialized')
        assigned = require(conn, venue, day, race)
        if engine != assigned:
            raise ValueError('result engine does not match fixed assignment')
        if engine == 'v2' and has_bets(conn, venue, day, race):
            raise ValueError('existing tickets prohibit v2 result')
        initialize(conn)
        digest = put_once(conn, venue, day, race, engine, result)
        conn.commit()
        return digest
    except BaseException:
        conn.rollback()
        raise


def read_assigned_result(conn, venue, date, race):
    """Read-only check: refuse results that differ from immutable assignment."""
    day = canonical_date(date)
    if not table_exists(conn, 'br_engine_assignment') or not table_exists(conn, 'br_result_v2'):
        return None
    assigned = require(conn, venue, day, race)
    record = get(conn, venue, day, race)
    if record and record['engine'] != assigned:
        raise ValueError('stored result and assignment disagree')
    return record
