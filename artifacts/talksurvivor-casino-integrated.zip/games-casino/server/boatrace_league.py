"""競艇リーグ: 開催スケジュール・出走表・オッズ・結果をサーバー側で決定する。

開催/出走表は日付から決定的に生成し、結果は秘密鍵つきHMACで決まるため
未来のレースの結果は外部から予測できず、過去の結果はDBなしで再現できる。
"""
import hashlib, hmac, math, os, random, re, secrets, unicodedata, datetime
from functools import lru_cache
from pathlib import Path
from zoneinfo import ZoneInfo
from server import points

JST = ZoneInfo('Asia/Tokyo')
HERE = Path(__file__).resolve().parent
FAN = HERE / 'fan2604.txt'
SECRET_FILE = HERE / '.br_secret'

VENUES = ['桐生', '戸田', '江戸川', '平和島', '多摩川', '浜名湖', '蒲郡', '常滑', '津', '三国', 'びわこ', '住之江',
          '尼崎', '鳴門', '丸亀', '児島', '宮島', '徳山', '下関', '若松', '芦屋', '福岡', '唐津', '大村']
NV = len(VENUES)
BLOCK = 7            # 全会場共通の開催ブロック(節の最大日数)
GAP = 30             # レース間隔(分)。第1レースは会場ごとに17:00〜22:00の間でずらす
FIRST_HOUR = 17      # 第1レース締切の時刻
DAY_CHANGE = 4       # 開催日の切り替わり時刻
START_DELAY = 120    # 締切からレース開始まで(秒)
DONE_DELAY = 300     # 締切から結果確定まで(秒) = 開始120 + ピット離れ70 + レース約90 + 余裕
PAYOUT = 0.75        # 払戻率
RACES = 12
PTS = [10, 8, 6, 4, 2, 1]   # 着順点
ROSTER = 48

TITLES = ['ちいかわ杯', 'もちもち記念', 'うさぎ賞争奪戦', '森の大感謝祭', 'ハチワレカップ', 'モモンガ記念競走',
          'くりまんじゅう杯', 'シーサー賞', 'ゴールドラッシュ杯', 'ひなたぼっこ杯', 'おむすびカップ', 'きのこ記念',
          'ぽかぽか競艇祭', 'ほっこりオープン', 'どんぐり争奪戦', 'こもれび賞']
GRADES = ['一般', 'G3', 'G2', 'G1', 'SG']
GRADE_W = [42, 22, 15, 12, 9]
COURSE_W = [1.0, 0.30, 0.22, 0.19, 0.09, 0.04]


def _secret():
    try:
        return SECRET_FILE.read_bytes()
    except OSError:
        k = secrets.token_bytes(32)
        SECRET_FILE.write_bytes(k)
        try:
            os.chmod(SECRET_FILE, 0o600)
        except OSError:
            pass
        return k


_SECRET = None


def _h(*parts):
    return int.from_bytes(hashlib.sha256('|'.join(map(str, parts)).encode()).digest()[:8], 'big')


def _rng(*parts):
    return random.Random(_h(*parts))


def _secret_rng(*parts):
    global _SECRET
    if _SECRET is None:
        _SECRET = _secret()
    d = hmac.new(_SECRET, '|'.join(map(str, parts)).encode(), hashlib.sha256).digest()
    return random.Random(int.from_bytes(d[:8], 'big'))


# ---------------------------------------------------------------- 選手データ
def _int(b, default=0):
    s = b.decode('ascii', 'ignore').strip()
    try:
        return int(s)
    except ValueError:
        return default


def _load():
    racers = {}
    if not FAN.exists():
        return racers
    for line in FAN.read_bytes().splitlines():
        if len(line) < 160:
            continue
        p = [0]

        def t(n):
            s = line[p[0]:p[0] + n]
            p[0] += n
            return s
        no = _int(t(4))
        name = t(16).decode('cp932', 'ignore')
        kana = unicodedata.normalize('NFKC', t(15).decode('cp932', 'ignore')).strip()
        branch = t(4).decode('cp932', 'ignore').strip('　 ')
        grade = t(2).decode('ascii', 'ignore').strip()
        era = t(1).decode('ascii', 'ignore')
        birth = t(6).decode('ascii', 'ignore')
        t(1)
        age = _int(t(2))
        height = _int(t(3))
        weight = _int(t(2))
        blood = t(2).decode('ascii', 'ignore').strip()
        win = _int(t(4)) / 100
        r2 = _int(t(4)) / 10
        w1 = _int(t(3))
        w2 = _int(t(3))
        starts = _int(t(3))
        fin = _int(t(2))
        champ = _int(t(2))
        avg_st = _int(t(3)) / 100
        courses = []
        for _ in range(6):
            n = _int(t(3))
            r3 = _int(t(4)) / 10
            st = _int(t(3)) / 100
            rk = _int(t(3)) / 100
            courses.append({'n': n, 'r3': r3, 'st': st, 'rank': rk})
        parts = [x for x in re.split('　{2,}', name.strip('　 ')) if x]
        if len(parts) >= 2:
            nm = parts[0].replace('　', '') + '　' + ''.join(parts[1:]).replace('　', '')
        else:
            nm = name.replace('　', '')
        base = {'S': 1925, 'H': 1988, 'R': 2018, 'T': 1911}.get(era, 1925)
        try:
            bd = '%04d/%s/%s' % (base + int(birth[:2]), birth[2:4], birth[4:6])
        except ValueError:
            bd = ''
        tot = sum(c['n'] for c in courses)
        r3 = sum(c['n'] * c['r3'] for c in courses) / tot if tot else 0
        racers[no] = {'no': no, 'name': nm, 'kana': kana, 'branch': branch, 'grade': grade, 'birth': bd, 'age': age,
                      'height': height, 'weight': weight, 'blood': blood, 'win': win, 'r2': r2, 'r3': round(r3, 2),
                      'w1': w1, 'w2': w2, 'starts': starts, 'fin': fin, 'champ': champ, 'st': avg_st, 'courses': courses}
    return racers


RACERS = _load()
RLIST = sorted(RACERS)
GRADE_RANK = {'A1': 0, 'A2': 1, 'B1': 2, 'B2': 3}


def _wr(r):
    return r['win'] if r['starts'] >= 10 and r['win'] > 0 else 3.8


# ---------------------------------------------------------------- 開催
_EPOCH = datetime.datetime(2000, 1, 1)


def _ord(d):
    """日時 -> 開催日インデックス。1開催日 = 17:00〜翌4:00。4:00に切り替わる。"""
    if not isinstance(d, datetime.datetime):
        d = datetime.datetime.combine(d, datetime.time(12))
    if d.tzinfo:
        d = d.astimezone(JST).replace(tzinfo=None)
    return int((d - _EPOCH - datetime.timedelta(hours=DAY_CHANGE)).total_seconds() // 86400)


def _date(o):
    """開催日 o の第1レース締切時刻(17:00)。"""
    return (_EPOCH + datetime.timedelta(days=o, hours=FIRST_HOUR)).replace(tzinfo=JST)


def dkey(o):
    return (_EPOCH + datetime.timedelta(days=o)).strftime('%Y-%m-%d') + '@17'


def parse_day(s):
    s = str(s)
    if '@' not in s:
        raise ValueError('bad date')
    return _date(_ord(datetime.datetime.fromisoformat(s.split('@')[0]) + datetime.timedelta(hours=12)))


def _label(o):
    return (_EPOCH + datetime.timedelta(days=o)).strftime('%m/%d')


@lru_cache(maxsize=64)
def _assign(block):
    """ブロックごとの 選手->会場。SG/G1/G2開催場には全国の上位選手を優先して集める。"""
    tier = {'SG': 0, 'G1': 1, 'G2': 2}
    gv = []
    for v in range(NV):
        g = _block_grade(v, block)
        if g in tier:
            gv.append((tier[g], v, g))
    gv.sort()
    m, taken = {}, set()
    ranked = sorted(RLIST, key=lambda n: (-_wr(RACERS[n]), _h('rk', n, block)))
    for _, v, g in gv:
        lim = {'SG': 0.12, 'G1': 0.30, 'G2': 0.55}[g]
        cand = [n for n in ranked[:int(len(ranked) * lim)] if n not in taken]
        cand.sort(key=lambda n: _h('pick', n, block, v))
        for n in cand[:ROSTER]:
            m[n] = v
            taken.add(n)
    for n in RLIST:
        if n not in m:
            v = _h('pool', n, block) % NV
            m[n] = v
    return m


def _pool_venue(no, block):
    return _assign(block)[no]


def _block_grade(venue, block):
    """そのブロックの節グレード(開催しなければNone)。series_infoと同じ抽選。"""
    rng = _rng('series', venue, block)
    if rng.random() > 0.88:
        return None
    length = rng.choice([4, 5, 6, 7, 6, 5])
    rng.randint(0, BLOCK - length)
    grade = rng.choices(GRADES, GRADE_W)[0]
    if grade in ('SG', 'G1', 'G2') and length < 5:
        grade = 'G3'
    if grade == 'SG' and length < 6:
        grade = 'G1'
    return grade


@lru_cache(maxsize=512)
def series_info(venue, o):
    """venue(0-23) が日付序数 o に開催していれば開催情報を返す。"""
    block, off = divmod(o, BLOCK)
    rng = _rng('series', venue, block)
    if rng.random() > 0.88:
        return None
    length = rng.choice([4, 5, 6, 7, 6, 5])
    start = rng.randint(0, BLOCK - length)
    if not start <= off < start + length:
        return None
    grade = rng.choices(GRADES, GRADE_W)[0]
    if grade in ('SG', 'G1', 'G2') and length < 5:
        grade = 'G3'
    if grade == 'SG' and length < 6:
        grade = 'G1'
    sh = _date(block * BLOCK + start).hour
    return {'venue': venue, 'block': block, 'days': length, 'day': off - start + 1, 'final': off - start + 1 == length,
            'start_ord': block * BLOCK + start, 'grade': grade, 'title': VENUES[venue] + rng.choice(TITLES),
            'sh': sh, 'night': sh >= 15, 'morning': sh < 10}


@lru_cache(maxsize=256)
def roster(venue, block, grade):
    pool = [n for n in RLIST if _pool_venue(n, block) == venue]
    pool.sort(key=lambda n: _h('ord', n, block, venue))
    if grade in ('SG', 'G1', 'G2'):
        pool.sort(key=lambda n: -_wr(RACERS[n]))
    elif grade == 'G3':
        top = sorted(pool, key=lambda n: -_wr(RACERS[n]))[:int(len(pool) * 0.75)]
        pool = top
    return tuple(sorted(pool[:ROSTER]))


def _motor(venue, block, kind, no):
    return round(20 + (_h(kind, venue, block, no) % 400) / 10, 1)


def _chunks(pool, count, rng):
    slots = count * 6
    for attempt in range(300):
        ent = pool + [rng.choice(pool) for _ in range(slots - len(pool))] if slots > len(pool) else rng.sample(pool, slots)
        keyed = sorted(ent, key=lambda n: _wr(RACERS[n]) + rng.gauss(0, 1.1 + attempt * 0.01))
        chunks = [keyed[i * 6:(i + 1) * 6] for i in range(count)]
        if all(len(set(c)) == 6 for c in chunks):
            return chunks
    for c in chunks:
        seen = set()
        for j, n in enumerate(c):
            if n in seen:
                c[j] = rng.choice([x for x in pool if x not in c])
            seen.add(c[j])
    return chunks


def _entry(venue, block, course, no):
    mo = _h('motor', venue, block, no) % 60 + 1
    bo = _h('boat', venue, block, no) % 60 + 1
    return {'course': course, 'no': no, 'motor': mo, 'motor_r2': _motor(venue, block, 'm', mo),
            'boat': bo, 'boat_r2': _motor(venue, block, 'b', bo)}


def stage_of(s, no):
    if s['day'] == s['days'] and no == RACES:
        return 'final'
    if s['day'] == s['days'] - 1 and no > RACES - 3:
        return 'semi'
    return 'prelim'


STAGE_NAMES = {'prelim': '予選', 'semi': '準優勝戦', 'final': '優勝戦'}


@lru_cache(maxsize=512)
def standings(venue, start_o, days, block, grade):
    """予選(初日〜準優前々日)終了時点の得点率順位。準優勝戦の出場者(上位18名)はこれで決まる。"""
    ros = roster(venue, block, grade)
    pts, runs = {n: 0 for n in ros}, {n: 0 for n in ros}
    for k in range(days - 2):
        o = start_o + k
        vd = venue_day(venue, o)
        for r in vd['races']:
            res = decide(venue, o, r['no'])
            for e in r['entries']:
                pts[e['no']] += PTS[res['order'].index(e['course'])]
                runs[e['no']] += 1
    rate = {n: pts[n] / runs[n] if runs[n] else 0 for n in ros}
    return tuple(sorted(ros, key=lambda n: (-rate[n], -_wr(RACERS[n]), n)))


def semi_lineup(top18):
    """予選順位 -> 準優(10R,11R,12R)の枠。1号艇は1位=12R,2位=11R,3位=10R。以降は蛇行で配分。"""
    nos = [RACES - 2, RACES - 1, RACES]
    line = {n: [None] * 6 for n in nos}
    for lane in range(6):
        grp = top18[lane * 3:lane * 3 + 3]
        order = [nos[2], nos[1], nos[0]] if lane % 2 == 0 else [nos[0], nos[1], nos[2]]
        for rk, rn in zip(grp, order):
            line[rn][lane] = rk
    return line


def final_lineup(venue, s):
    """準優の1着・2着で優勝戦の枠が決まる(12R1着=1号艇, 11R1着=2号艇, 10R1着=3号艇, 12R2着=4号艇 ...)。"""
    o = s['start_ord'] + s['days'] - 2
    vd = venue_day(venue, o)
    nos = [RACES, RACES - 1, RACES - 2]
    firsts, seconds = [], []
    for rn in nos:
        res = decide(venue, o, rn)
        ents = vd['races'][rn - 1]['entries']
        firsts.append(ents[res['order'][0] - 1]['no'])
        seconds.append(ents[res['order'][1] - 1]['no'])
    return firsts + seconds


@lru_cache(maxsize=2048)
def venue_day(venue, o):
    s = series_info(venue, o)
    if not s:
        return None
    ros = list(roster(venue, s['block'], s['grade']))
    if len(ros) < 12:
        return None
    rng = _rng('day', venue, o)
    day, days, block = s['day'], s['days'], s['block']
    special = {}
    pool, count = ros, RACES
    if day == days - 1:
        top = standings(venue, s['start_ord'], days, block, s['grade'])[:18]
        special = semi_lineup(list(top))
        pool, count = [n for n in ros if n not in top], RACES - 3
    elif day == days:
        fin = final_lineup(venue, s)
        special = {RACES: fin}
        pool, count = [n for n in ros if n not in fin], RACES - 1
    chunks = _chunks(pool, count, rng)
    base = _date(o) + datetime.timedelta(minutes=(venue * 53) % 301)
    races = []
    for i in range(RACES):
        no = i + 1
        if no in special:
            order = special[no]
        else:
            order = chunks[i][:]
            rng.shuffle(order)
        races.append({'no': no, 'deadline': base + datetime.timedelta(minutes=GAP * i), 'stage': stage_of(s, no),
                      'entries': [_entry(venue, block, k + 1, n) for k, n in enumerate(order)]})
    return {'series': s, 'races': races}


# ---------------------------------------------------------------- 確率・オッズ
# 着順モデルv3を使い始める開催日。これより前の開催日は従来モデルのまま(過去の結果・オッズ・精算を変えないため)
V3_FROM = _ord(datetime.datetime(2026, 10, 26, 12, 0))
# コース別の平均3連対率(%)。選手のコース別成績がこれより良い/悪いかで補正する
LANE_R3 = (66.0, 48.0, 45.0, 42.0, 33.0, 22.0)
# v3のコース別の重み(STの影響を入れたうえで、1コース約55%・2約14%・3約12%・4約10%・5約6%・6約3%の1着率になるよう調整)
COURSE_W3 = (1.0, 0.168, 0.142, 0.117, 0.066, 0.033)


def _is_v3(o):
    return o is not None and o >= V3_FROM


def _base_st(r, course):
    return r['courses'][course - 1]['st'] or r['st'] or 0.17


# v3: 成績データのない選手(出走10未満 or 勝率0)は低い固定勝率にし、他の補正は付けない
V3_ROOKIE_WR = 1.5


def _has_data(r):
    return r['starts'] >= 10 and r['win'] > 0


def _v3_log(e, r):
    """v3: 勝率・モーター・ボート・コース別成績・体重から、STを除いた強さ(対数)を求める。"""
    eq = 0.018 * (e['motor_r2'] - 40) + 0.008 * (e.get('boat_r2', 40) - 40)
    if not _has_data(r):
        return 0.55 * (V3_ROOKIE_WR - 5.5) + eq
    x = 0.55 * (_wr(r) - 5.5) + eq
    c = r['courses'][e['course'] - 1]
    if c['n'] >= 8 and r.get('r3'):
        dev = (c['r3'] - r['r3']) - (LANE_R3[e['course'] - 1] - sum(LANE_R3) / 6)
        x += max(-0.35, min(0.35, 0.012 * dev))
    if r.get('weight'):
        x += max(-0.15, min(0.15, 0.012 * (52 - r['weight'])))
    return x


def strengths(entries, o=None, sts=None):
    out = []
    if not _is_v3(o):
        for e in entries:
            r = RACERS[e['no']]
            out.append(COURSE_W[e['course'] - 1] * math.exp(0.5 * (_wr(r) - 5.5) + 0.02 * (e['motor_r2'] - 40)))
        return out
    # v3: STも強さに入れる。オッズ(sts=None)は選手の平均ST、結果は実際のSTを使う
    rs = [RACERS[e['no']] for e in entries]
    st = list(sts) if sts else [_base_st(r, e['course']) for r, e in zip(rs, entries)]
    mean = sum(st) / len(st)
    for i, (e, r) in enumerate(zip(entries, rs)):
        x = _v3_log(e, r) - (5.0 * (st[i] - mean) if _has_data(r) else 0.0)
        if sts and _has_data(r):
            inner = st[:i]
            if i == 0 and st[0] - min(st[1:]) > 0.08:
                x -= 0.35                      # 1号艇が出遅れ、外に先手を取られた
            if i >= 1 and st[i] <= min(inner) - 0.06:
                x += 0.30                      # 内の艇より明らかに速いスタート(まくれる)
            if i + 1 < len(st) and st[i] - st[i + 1] >= 0.06:
                x -= 0.15                      # すぐ外の艇に先手を取られた(壁にならない)
        out.append(COURSE_W3[e['course'] - 1] * math.exp(x))
    return out


def _p3(s, a, b, c):
    S = sum(s)
    return s[a] / S * s[b] / (S - s[a]) * s[c] / (S - s[a] - s[b])


def odds_table(entries, o=None):
    s = strengths(entries, o)
    idx = range(6)
    tan3, fuku3, tan2, fuku2, wide, tan1, fuku1 = {}, {}, {}, {}, {}, {}, {}
    S = sum(s)
    p3 = {}
    for a in idx:
        for b in idx:
            if b == a:
                continue
            for c in idx:
                if c in (a, b):
                    continue
                p3[(a, b, c)] = _p3(s, a, b, c)
    p2 = {}
    for a in idx:
        for b in idx:
            if a != b:
                p2[(a, b)] = s[a] / S * s[b] / (S - s[a])
    pr = {}
    for (a, b, c), p in p3.items():
        k = '%d-%d-%d' % (a + 1, b + 1, c + 1)
        pr.setdefault('tan3', {})[k] = p
        kk = '-'.join(map(str, sorted((a + 1, b + 1, c + 1))))
        pr.setdefault('fuku3', {})[kk] = pr.get('fuku3', {}).get(kk, 0) + p
        for x, y in ((a, b), (a, c), (b, c)):
            w = '-'.join(map(str, sorted((x + 1, y + 1))))
            pr.setdefault('wide', {})[w] = pr.get('wide', {}).get(w, 0) + p
    for (a, b), p in p2.items():
        pr.setdefault('tan2', {})['%d-%d' % (a + 1, b + 1)] = p
        kk = '-'.join(map(str, sorted((a + 1, b + 1))))
        pr.setdefault('fuku2', {})[kk] = pr.get('fuku2', {}).get(kk, 0) + p
    for a in idx:
        pr.setdefault('tan1', {})[str(a + 1)] = s[a] / S
        pr.setdefault('fuku1', {})[str(a + 1)] = sum(p for (x, y), p in p2.items() if a in (x, y))
    rate = {'tan1': 0.80, 'fuku1': 0.80}
    od = {}
    for kind, d in pr.items():
        r = rate.get(kind, PAYOUT)
        od[kind] = {k: max(1.0, min(9999.9, math.floor(r / p * 10) / 10)) if p > 0 else 9999.9 for k, p in d.items()}
    return od


# ---------------------------------------------------------------- 結果
@lru_cache(maxsize=8192)
def decide(venue, o, no):
    vd = venue_day(venue, o)
    race = vd['races'][no - 1]
    ents = race['entries']
    rng = _secret_rng('result', venue, o, no)
    if _is_v3(o):
        return _decide_v3(ents, o, rng)
    s = strengths(ents)
    left = list(range(6))
    order = []
    while left:
        tot = sum(s[i] for i in left)
        x = rng.random() * tot
        for i in left:
            x -= s[i]
            if x <= 0:
                break
        order.append(i)
        left.remove(i)
    sts = []
    for e in ents:
        r = RACERS[e['no']]
        base = r['courses'][e['course'] - 1]['st'] or r['st'] or 0.17
        sts.append(round(max(0.01, rng.gauss(base, 0.035)), 2))
    w = order[0] + 1
    if w == 1:
        kim = '逃げ'
    elif w == 2:
        kim = '差し'
    else:
        kim = rng.choice(['まくり', 'まくり', 'まくり差し'])
    if rng.random() < 0.06 and w != 1:
        kim = '抜き'
    res = [i + 1 for i in order]
    od = odds_table(ents)
    key3 = '%d-%d-%d' % tuple(res[:3])
    key2 = '%d-%d' % tuple(res[:2])
    pay = {
        'tan3': {key3: od['tan3'][key3]},
        'fuku3': {'-'.join(map(str, sorted(res[:3]))): od['fuku3']['-'.join(map(str, sorted(res[:3])))]},
        'tan2': {key2: od['tan2'][key2]},
        'fuku2': {'-'.join(map(str, sorted(res[:2]))): od['fuku2']['-'.join(map(str, sorted(res[:2])))]},
        'wide': {k: od['wide'][k] for k in ('-'.join(map(str, sorted(p))) for p in ((res[0], res[1]), (res[0], res[2]), (res[1], res[2])))},
        'tan1': {str(res[0]): od['tan1'][str(res[0])]},
        'fuku1': {str(res[0]): od['fuku1'][str(res[0])], str(res[1]): od['fuku1'][str(res[1])]},
    }
    return {'order': res, 'st': sts, 'kimarite': kim, 'pay': _pay(res, od)}


def _pay(res, od):
    key3 = '%d-%d-%d' % tuple(res[:3])
    key2 = '%d-%d' % tuple(res[:2])
    f3 = '-'.join(map(str, sorted(res[:3])))
    f2 = '-'.join(map(str, sorted(res[:2])))
    return {
        'tan3': {key3: od['tan3'][key3]},
        'fuku3': {f3: od['fuku3'][f3]},
        'tan2': {key2: od['tan2'][key2]},
        'fuku2': {f2: od['fuku2'][f2]},
        'wide': {k: od['wide'][k] for k in ('-'.join(map(str, sorted(p))) for p in ((res[0], res[1]), (res[0], res[2]), (res[1], res[2])))},
        'tan1': {str(res[0]): od['tan1'][str(res[0])]},
        'fuku1': {str(res[0]): od['fuku1'][str(res[0])], str(res[1]): od['fuku1'][str(res[1])]},
    }


def _decide_v3(ents, o, rng):
    """v3: 先にSTを決め、それを強さに反映して着順を引く。決まり手もSTと枠から決める。"""
    sts = []
    for e in ents:
        base = _base_st(RACERS[e['no']], e['course'])
        sts.append(round(max(0.01, rng.gauss(base, 0.035)), 2))
    s = strengths(ents, o, sts)
    left = list(range(6))
    order = []
    while left:
        tot = sum(s[i] for i in left)
        x = rng.random() * tot
        for i in left:
            x -= s[i]
            if x <= 0:
                break
        order.append(i)
        left.remove(i)
    res = [i + 1 for i in order]
    w = res[0]
    q = rng.random()
    if w == 1:
        kim = '逃げ'
    elif rng.random() < (0.08 if w <= 4 else 0.18):
        kim = '抜き'
    else:
        lead_st = sts[w - 1] <= min(sts[:w - 1]) - 0.03      # 内の艇より先にスタートを決めた
        if w == 2:
            kim = 'まくり' if lead_st and q < 0.6 else '差し'
        elif lead_st:
            kim = 'まくり' if q < 0.7 else 'まくり差し'
        else:
            kim = 'まくり差し' if q < 0.45 else '差し' if q < 0.75 and w <= 4 else 'まくり'
    od = odds_table(ents, o)
    return {'order': res, 'st': sts, 'kimarite': kim, 'pay': _pay(res, od)}


def race_status(deadline, now):
    if now < deadline:
        return 'open'
    if now < deadline + datetime.timedelta(seconds=START_DELAY):
        return 'closed'
    if now < deadline + datetime.timedelta(seconds=DONE_DELAY):
        return 'running'
    return 'done'

# ---------------------------------------------------------------- API用ビュー
def _hhmm(dt):
    return dt.strftime('%H:%M')


def _racer_brief(r):
    return {'no': r['no'], 'name': r['name'], 'grade': r['grade'], 'branch': r['branch'], 'age': r['age']}


def home(now=None, date=None):
    now = now or datetime.datetime.now(JST)
    o = _ord(date or now)
    d = _date(o)
    out = []
    for v in range(NV):
        vd = venue_day(v, o)
        if not vd:
            out.append({'venue': v + 1, 'name': VENUES[v], 'open': False})
            continue
        s = vd['series']
        nxt = None
        for r in vd['races']:
            if now < r['deadline']:
                nxt = r
                break
        item = {'venue': v + 1, 'name': VENUES[v], 'open': True, 'grade': s['grade'], 'title': s['title'],
                'day': s['day'], 'days': s['days'], 'final': s['final'], 'night': bool(nxt and 1 <= nxt['deadline'].hour < 4), 'morning': False,
                'from': _label(s['start_ord']), 'to': _label(s['start_ord'] + s['days'] - 1),
                'next_no': nxt['no'] if nxt else 0, 'next_deadline': _hhmm(nxt['deadline']) if nxt else '',
                'next_in': int((nxt['deadline'] - now).total_seconds()) if nxt else 0,
                'watch_no': next((r['no'] for r in vd['races'] if race_status(r['deadline'], now) in ('closed', 'running')), 0),
                'first': _hhmm(vd['races'][0]['deadline']), 'last': _hhmm(vd['races'][-1]['deadline'])}
        out.append(item)
    return {'date': dkey(o), 'label': _label(o), 'updated': now.strftime('%H:%M'), 'now': now.strftime('%Y-%m-%d %H:%M:%S'), 'venues': out}


def _entry_view(e):
    r = RACERS[e['no']]
    return {'course': e['course'], 'no': r['no'], 'name': r['name'], 'grade': r['grade'], 'branch': r['branch'],
            'age': r['age'], 'weight': r['weight'], 'win': r['win'], 'r2': r['r2'], 'r3': r['r3'], 'st': r['st'],
            'motor': e['motor'], 'motor_r2': e['motor_r2'], 'boat': e['boat'], 'boat_r2': e['boat_r2']}


def _racer_results(no, venue, s, now):
    """今節の成績: 日ごとの [(レース, 進入, 着順, ST)]。まだ始まっていない日は含めない。"""
    days = []
    cur = _ord(now)
    pts = runs = 0
    for k in range(s['days']):
        o = s['start_ord'] + k
        row = []
        vd = venue_day(venue, o) if o <= cur else None
        if vd:
            for r in vd['races']:
                for e in r['entries']:
                    if e['no'] == no:
                        item = {'race': r['no'], 'course': e['course'], 'rank': 0, 'st': 0, 'stage': r['stage']}
                        if race_status(r['deadline'], now) == 'done':
                            res = decide(venue, o, r['no'])
                            item['rank'] = res['order'].index(e['course']) + 1
                            item['st'] = res['st'][e['course'] - 1]
                            pts += PTS[item['rank'] - 1]
                            runs += 1
                        row.append(item)
        days.append(row)
    return {'days': days, 'pts': pts, 'runs': runs, 'rate': round(pts / runs, 2) if runs else 0}


def race_detail(venue_no, date, no, now=None):
    now = now or datetime.datetime.now(JST)
    v = venue_no - 1
    o = _ord(date)
    if o > _ord(now):
        return None
    vd = venue_day(v, o) if 0 <= v < NV else None
    if not vd or not 1 <= no <= RACES:
        return None
    s = vd['series']
    race = vd['races'][no - 1]
    st = race_status(race['deadline'], now)
    stage = race['stage']
    out = {'venue': venue_no, 'name': VENUES[v], 'date': dkey(o), 'label': _label(o), 'no': no, 'status': st, 'grade': s['grade'],
           'title': s['title'], 'day': s['day'], 'days': s['days'], 'final': s['final'], 'deadline': _hhmm(race['deadline']),
           'stage': stage, 'stage_name': STAGE_NAMES[stage],
           'remain': int((race['deadline'] - now).total_seconds()),
           'schedule': [{'no': r['no'], 'deadline': _hhmm(r['deadline']), 'status': race_status(r['deadline'], now), 'stage': r['stage']} for r in vd['races']],
           'days_list': [{'day': k + 1, 'date': _label(s['start_ord'] + k)} for k in range(s['days'])],
           'entries': [_entry_view(e) for e in race['entries']], 'odds': odds_table(race['entries'], o)}
    for ev, e in zip(out['entries'], race['entries']):
        ev['series'] = _racer_results(e['no'], v, s, now)
    out['start_ms'] = int((race['deadline'] + datetime.timedelta(seconds=START_DELAY)).timestamp() * 1000)
    out['server_ms'] = int(now.timestamp() * 1000)
    out['kind'] = 'final' if stage == 'final' else 'prelim'
    if st in ('closed', 'running', 'done'):
        res = decide(v, o, no)
        # st/kimarite は3D映像を結果に合わせるために渡す(着順と同じく締切後のみ)
        out['live'] = {'seed': _h('seed', v, o, no) & 0x7fffffff, 'order': res['order'], 'st': res['st'], 'kimarite': res['kimarite']}
        if st == 'done':
            out['result'] = res
    return out


def racer_detail(no, now=None):
    now = now or datetime.datetime.now(JST)
    r = RACERS.get(no)
    if not r:
        return None
    o0 = _ord(now)
    sched = []
    seen = set()
    for o in range(o0, o0 + 24):
        v = _pool_venue(no, o // BLOCK)
        s = series_info(v, o)
        if s and no in roster(v, s['block'], s['grade']) and (v, s['block']) not in seen:
            seen.add((v, s['block']))
            sched.append({'from': _label(s['start_ord']), 'to': _label(s['start_ord'] + s['days'] - 1),
                          'venue': VENUES[v], 'grade': s['grade'], 'title': s['title']})
    today = []
    v = _pool_venue(no, o0 // BLOCK)
    vd = venue_day(v, o0)
    if vd and no in roster(v, vd['series']['block'], vd['series']['grade']):
        for rc in vd['races']:
            for e in rc['entries']:
                if e['no'] == no:
                    today.append({'venue': VENUES[v], 'venue_no': v + 1, 'grade': vd['series']['grade'], 'title': vd['series']['title'],
                                  'races': [x['no'] for x in vd['races'] if any(y['no'] == no for y in x['entries'])]})
                    break
            else:
                continue
            break
    past = []
    b0 = o0 // BLOCK
    for b in range(b0, b0 - 10, -1):
        v = _pool_venue(no, b)
        for o in range(b * BLOCK, b * BLOCK + BLOCK):
            s = series_info(v, o)
            if not s or s['start_ord'] != o or o + s['days'] > o0 + 1 and False:
                continue
            if no not in roster(v, s['block'], s['grade']) or s['start_ord'] > o0:
                continue
            days = _racer_results(no, v, s, now)['days']
            line = ''.join(str(x['rank']) if x['rank'] else '' for row in days for x in row)
            if line:
                past.append({'from': _label(s['start_ord']), 'to': _label(s['start_ord'] + s['days'] - 1),
                             'venue': VENUES[v], 'grade': s['grade'], 'title': s['title'], 'line': line})
        if len(past) >= 3:
            break
    tot = sum(c['n'] for c in r['courses']) or 1
    return {'racer': r, 'today': today, 'schedule': sched, 'past': past[:3],
            'course': [{'course': i + 1, 'enter': round(c['n'] * 100 / tot, 1), 'n': c['n'], 'r3': c['r3'], 'st': c['st'],
                        'rank': c['rank']} for i, c in enumerate(r['courses'])]}


# ---------------------------------------------------------------- 投票・払戻
KIND_NAMES = {'tan3': '3連単', 'fuku3': '3連複', 'tan2': '2連単', 'fuku2': '2連複', 'wide': '拡連複', 'tan1': '単勝', 'fuku1': '複勝'}
MIN_BET, MAX_BET, MAX_ITEMS = 100, 100000, 120


def ensure_tables(c):
    c.execute('CREATE TABLE IF NOT EXISTS br_bets (id INTEGER PRIMARY KEY AUTOINCREMENT, owner TEXT NOT NULL, venue INTEGER NOT NULL,'
              ' date TEXT NOT NULL, race INTEGER NOT NULL, kind TEXT NOT NULL, combo TEXT NOT NULL, amount INTEGER NOT NULL,'
              ' odds REAL NOT NULL, status TEXT NOT NULL DEFAULT "open", payout INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL)')
    c.execute('CREATE INDEX IF NOT EXISTS br_bets_owner ON br_bets(owner, id)')
    c.execute('CREATE INDEX IF NOT EXISTS br_bets_open ON br_bets(status)')


def race_bets(c, venue_no, date, no):
    rows = c.execute('SELECT b.owner, b.kind, b.combo, b.amount, COALESCE(u.name, "ゲスト") AS name FROM br_bets b LEFT JOIN users u ON u.id=b.owner'
                     ' WHERE b.venue=? AND b.date=? AND b.race=? ORDER BY b.id', (venue_no, dkey(_ord(date)), no)).fetchall()
    by = {}
    for r in rows:
        u = by.setdefault(r['owner'], {'name': r['name'], 'total': 0, 'items': []})
        u['total'] += r['amount']
        u['items'].append({'kind': r['kind'], 'name': KIND_NAMES.get(r['kind'], r['kind']), 'combo': r['combo'], 'amount': r['amount']})
    return sorted(by.values(), key=lambda u: -u['total'])


def place_bets(c, owner, venue_no, date, no, items, now=None):
    now = now or datetime.datetime.now(JST)
    v = venue_no - 1
    o = _ord(date)
    vd = venue_day(v, o) if 0 <= v < NV and o <= _ord(now) else None
    if not vd or not 1 <= no <= RACES:
        raise ValueError('そのレースはありません')
    race = vd['races'][no - 1]
    if race_status(race['deadline'], now) != 'open':
        raise ValueError('このレースは締め切りました')
    if not isinstance(items, list) or not items or len(items) > MAX_ITEMS:
        raise ValueError('投票内容が正しくありません')
    od = odds_table(race['entries'], o)
    total, rows = 0, []
    for it in items:
        kind, combo, amt = it.get('kind'), str(it.get('combo')), it.get('amount')
        if kind not in od or combo not in od[kind] or not isinstance(amt, int) or isinstance(amt, bool):
            raise ValueError('投票内容が正しくありません')
        if amt < MIN_BET or amt > MAX_BET or amt % 100:
            raise ValueError('1点100ポイント〜の100ポイント単位で指定してください')
        total += amt
        rows.append((owner, venue_no, dkey(o), no, kind, combo, amt, od[kind][combo], int(now.timestamp())))
    if not points.debit(c, owner, total):
        raise ValueError('ポイントが足りません（合計 %s）' % format(total, ','))
    c.executemany('INSERT INTO br_bets(owner,venue,date,race,kind,combo,amount,odds,created) VALUES (?,?,?,?,?,?,?,?,?)', rows)
    return total


def settle(c, owner=None, now=None, *, frozen_only=False, assigned_results=False):
    """確定済みレースの未精算の票を精算して配当をポイントに反映する。精算した持ち主の集合を返す。"""
    now = now or datetime.datetime.now(JST)
    if assigned_results and frozen_only:
        raise ValueError("choose one settlement mode")
    if assigned_results and not c.in_transaction:
        raise ValueError("assigned settlement requires caller-owned transaction")
    if frozen_only:
        # Opt-in only. Caller must own a write transaction on the SAME database.
        # Never fall back to a freshly recomputed legacy result.
        if not c.in_transaction:
            raise ValueError('frozen settlement requires caller-owned transaction')
        from server.boatrace_atomic_result import read_assigned_result
    q = 'SELECT * FROM br_bets WHERE status="open"'  + (' AND owner=?' if owner else '')
    rows = c.execute(q, (owner,) if owner else ()).fetchall()
    cache, paid = {}, set()
    for b in rows:
        key = (b['venue'], b['date'], b['race'])
        if key not in cache:
            if '@' not in b['date']:
                cache[key] = 'void'
            else:
                o = _ord(parse_day(b['date']))
                vd = venue_day(b['venue'] - 1, o)
                rc = vd['races'][b['race'] - 1] if vd else None
                if rc and race_status(rc['deadline'], now) == 'done':
                    if frozen_only or assigned_results:
                        from server.boatrace_atomic_result import read_assigned_result
                        from server.boatrace_migration_guard import canonical_date, table_exists
                        from server.boatrace_engine_assignment import get as engine_get
                        assigned = (engine_get(c, b['venue'], canonical_date(b['date']), b['race'])
                                    if table_exists(c, 'br_engine_assignment') else None)
                        if assigned_results and assigned is None:
                            cache[key] = decide(b['venue'] - 1, o, b['race'])
                        else:
                            frozen = read_assigned_result(c, b['venue'], b['date'], b['race'])
                            if frozen is None:
                                raise ValueError('finished race has no frozen official result')
                            cache[key] = frozen['result']
                    else:
                        cache[key] = decide(b['venue'] - 1, o, b['race'])
                else:
                    cache[key] = None
        res = cache[key]
        if res is None:
            continue
        if res == 'void':
            updated = c.execute('UPDATE br_bets SET status="void" WHERE id=? AND status="open"', (b['id'],)).rowcount
            if updated != 1:
                raise ValueError('ticket state changed')
            points.credit(c, b['owner'], b['amount'])
            paid.add(b['owner'])
            continue
        od = res['pay'].get(b['kind'], {}).get(b['combo'])
        pay = int(b['amount'] * od) if od else 0
        updated = c.execute('UPDATE br_bets SET status=?, payout=? WHERE id=? AND status="open"', ('win' if pay else 'lose', pay, b['id'])).rowcount
        if updated != 1:
            raise ValueError('ticket state changed')
        if pay:
            points.credit(c, b['owner'], pay)
        paid.add(b['owner'])
    return paid


def my_bets(c, owner, limit=200):
    rows = c.execute('SELECT * FROM br_bets WHERE owner=? ORDER BY id DESC LIMIT ?', (owner, limit)).fetchall()
    out = [{'id': r['id'], 'venue': r['venue'], 'name': VENUES[r['venue'] - 1], 'date': r['date'], 'race': r['race'],
            'label': _label(_ord(parse_day(r['date']))) if '@' in r['date'] else r['date'][5:10],
            'kind': r['kind'], 'kind_name': KIND_NAMES.get(r['kind'], r['kind']), 'combo': r['combo'], 'amount': r['amount'],
            'odds': r['odds'], 'status': r['status'], 'payout': r['payout']} for r in rows]
    for b in out:
        b['deadline_ms'] = 0
        if b['status'] == 'open' and '@' in b['date']:
            try:
                vd = venue_day(b['venue'] - 1, _ord(parse_day(b['date'])))
                b['deadline_ms'] = int(vd['races'][b['race'] - 1]['deadline'].timestamp() * 1000) if vd else 0
            except Exception:
                pass
    return out

def results_today(now=None, limit=80):
    """直近3開催日(=3時間)のレース結果。"""
    now = now or datetime.datetime.now(JST)
    o1 = _ord(now)
    out = []
    for o in range(o1 - 1, o1 + 1):
        for v in range(NV):
            vd = venue_day(v, o)
            if not vd:
                continue
            for r in vd['races']:
                if race_status(r['deadline'], now) == 'done':
                    res = decide(v, o, r['no'])
                    k = '%d-%d-%d' % tuple(res['order'][:3])
                    out.append({'venue': v + 1, 'name': VENUES[v], 'date': dkey(o), 'no': r['no'], 'time': _hhmm(r['deadline']), 'order': res['order'],
                                'stage_name': STAGE_NAMES[r['stage']] if r['stage'] != 'prelim' else '',
                                'tan3': res['pay']['tan3'][k], 'ts': r['deadline'].timestamp()})
    out.sort(key=lambda x: -x['ts'])
    return {'date': dkey(o1), 'results': out[:limit]}
