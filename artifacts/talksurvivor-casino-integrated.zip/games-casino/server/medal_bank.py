"""V71: authenticated user's medal-sand and member-card balances.
All balance mutations must be invoked under a SQLite BEGIN IMMEDIATE transaction.
Slot winnings must only be credited by a server-validated reel result (not client input).
"""
from server import points

CARD='pachi_member_card'

def migrate(c):
    c.execute('''CREATE TABLE IF NOT EXISTS pachi_medal_accounts (
        owner TEXT PRIMARY KEY, sand_balance INTEGER NOT NULL DEFAULT 0 CHECK(sand_balance>=0),
        credit INTEGER NOT NULL DEFAULT 0 CHECK(credit>=0),
        saved_medals INTEGER NOT NULL DEFAULT 0 CHECK(saved_medals>=0),
        card_inserted INTEGER NOT NULL DEFAULT 0 CHECK(card_inserted IN (0,1)))''')
    cols={r[1] for r in c.execute('PRAGMA table_info(pachi_medal_accounts)')}
    if 'card_cash' not in cols:
        c.execute('ALTER TABLE pachi_medal_accounts ADD COLUMN card_cash INTEGER NOT NULL DEFAULT 0 CHECK(card_cash>=0)')
    c.execute('''CREATE TABLE IF NOT EXISTS pachi_medal_ops (
        owner TEXT NOT NULL, op_id TEXT NOT NULL, action TEXT NOT NULL,
        amount INTEGER NOT NULL, PRIMARY KEY(owner,op_id))''')

def state(c,uid):
    c.execute('INSERT OR IGNORE INTO inventory(owner,item,quantity) VALUES (?,?,1)',(uid,CARD))
    c.execute('INSERT OR IGNORE INTO pachi_medal_accounts(owner) VALUES (?)',(uid,))
    r=c.execute('SELECT * FROM pachi_medal_accounts WHERE owner=?',(uid,)).fetchone()
    out={k:r[k] for k in ('sand_balance','credit','saved_medals','card_inserted','card_cash')}
    try:
        rr=c.execute('SELECT reset_id FROM pachi_runtime WHERE owner=?',(uid,)).fetchone()
        out['stats_reset']=(rr[0] if rr else None) or '0'
    except Exception:
        out['stats_reset']='0'
    return out

def change(c,uid,action,amount,op_id):
    if not isinstance(op_id,str) or not 8<=len(op_id)<=100: raise ValueError('操作IDが不正です')
    if type(amount)!=int or amount<0 or amount>1000000: raise ValueError('数量が不正です')
    st=state(c,uid)
    old=c.execute('SELECT action,amount FROM pachi_medal_ops WHERE owner=? AND op_id=?',(uid,op_id)).fetchone()
    if old:
        if old['action']!=action or old['amount']!=amount: raise ValueError('操作IDの再利用は禁止です')
        return st
    if action=='insert_card':
        if amount: raise ValueError('数量は0にしてください')
        card=c.execute('SELECT quantity FROM inventory WHERE owner=? AND item=?',(uid,CARD)).fetchone()
        if not card or card['quantity']<1: raise ValueError('会員カードがありません')
        c.execute('UPDATE pachi_medal_accounts SET card_inserted=1 WHERE owner=?',(uid,))
    elif action=='eject_card':
        if amount: raise ValueError('数量は0にしてください')
        c.execute('UPDATE pachi_medal_accounts SET card_inserted=0 WHERE owner=?',(uid,))
    elif action=='issue_card':
        if amount: raise ValueError('数量は0にしてください')
        card=c.execute('SELECT quantity FROM inventory WHERE owner=? AND item=?',(uid,CARD)).fetchone()
        if not card:
            c.execute('INSERT INTO inventory(owner,item,quantity) VALUES (?,?,1)',(uid,CARD))
    elif action=='deposit_cash':
        if not 1000<=amount<=10000 or amount%1000: raise ValueError('入金は1,000〜10,000ポイント、1,000単位です')
        if not points.debit(c,uid,amount):
            raise ValueError('ポイントが不足しています')
        c.execute('UPDATE pachi_medal_accounts SET sand_balance=sand_balance+? WHERE owner=?',(amount,uid))
    elif action=='lend':
        if amount!=1000: raise ValueError('貸出は1,000ポイント単位です')
        if not c.execute('UPDATE pachi_medal_accounts SET sand_balance=sand_balance-1000,credit=credit+46 WHERE owner=? AND sand_balance>=1000',(uid,)).rowcount:
            raise ValueError('残金が不足しています')
    elif action=='save':
        if amount<1 or not st['card_inserted']: raise ValueError('カード挿入と枚数を確認してください')
        if not c.execute('UPDATE pachi_medal_accounts SET credit=credit-?,saved_medals=saved_medals+? WHERE owner=? AND credit>=?',(amount,amount,uid,amount)).rowcount:
            raise ValueError('クレジット不足です')
    elif action=='replay':
        if amount<1 or not st['card_inserted']: raise ValueError('カード挿入と枚数を確認してください')
        if not c.execute('UPDATE pachi_medal_accounts SET saved_medals=saved_medals-?,credit=credit+? WHERE owner=? AND saved_medals>=?',(amount,amount,uid,amount)).rowcount:
            raise ValueError('貯メダル不足です')
    elif action=='sand_to_card':
        if amount<1 or not st['card_inserted']: raise ValueError('会員カードを挿入してください')
        if not c.execute('UPDATE pachi_medal_accounts SET sand_balance=sand_balance-?,card_cash=card_cash+? WHERE owner=? AND sand_balance>=?',(amount,amount,uid,amount)).rowcount:
            raise ValueError('コインサンドの残金が不足しています')
    elif action=='card_cashout':
        if amount<1 or st['card_inserted']: raise ValueError('カードを返却して銀行で換金してください')
        card=c.execute('SELECT quantity FROM inventory WHERE owner=? AND item=?',(uid,CARD)).fetchone()
        if not card or card['quantity']<1: raise ValueError('会員カードがありません')
        if not c.execute('UPDATE pachi_medal_accounts SET card_cash=card_cash-? WHERE owner=? AND card_cash>=?',(amount,uid,amount)).rowcount:
            raise ValueError('カード残金が不足しています')
        points.credit(c,uid,amount)
    elif action=='bank_exchange':
        if amount<50 or amount%50 or not st['saved_medals']: raise ValueError('換金は50枚単位です')
        card=c.execute('SELECT quantity FROM inventory WHERE owner=? AND item=?',(uid,CARD)).fetchone()
        if not card or card['quantity']<1 or st['card_inserted']: raise ValueError('会員カードを返却して銀行で提示してください')
        if not c.execute('UPDATE pachi_medal_accounts SET saved_medals=saved_medals-? WHERE owner=? AND saved_medals>=?',(amount,uid,amount)).rowcount:
            raise ValueError('貯メダル不足です')
        points.credit(c,uid,amount//50*1000)
    else: raise ValueError('操作が不正です')
    c.execute('INSERT INTO pachi_medal_ops(owner,op_id,action,amount) VALUES (?,?,?,?)',(uid,op_id,action,amount))
    return state(c,uid)
