"""Punto banco baccarat: server-authoritative rounds and bets (8-deck shoe, up to 4 seats at one shared table).

Same conventions as roulette.py: every mutating function must be called inside a SQLite BEGIN IMMEDIATE
transaction, currency lives in atto1 points(server_id,user_id,points), and the client never decides cards, winners or amounts.

Cards are ints 0..51: rank = c % 13 (0=A, 1..8 = 2..9, 9=10, 10=J, 11=Q, 12=K), suit = c // 13 (0 spade, 1 heart,
2 diamond, 3 club). The client draws them from the same numbers (client/cards/<rank><suit>.png).
"""
import json
import secrets
from server import points

ROUND_SECONDS = 40                       # betting time
CHIPS = (100, 500, 1000, 5000, 10000)    # same chips as the roulette
MAX_TOTAL_PER_ROUND = 1_000_000          # per player, per round
MAX_SEATS = 4
HISTORY_N = 96                           # bead plate
DECKS = 8
RESHUFFLE_BELOW = 24                     # new shoe when fewer cards than this are left before a round

# Timeline after betting closes (seconds since closes_at). The client uses exactly the same numbers.
T_DEAL = 3.5                             # four cards slide out of the shoe, face down
SQ_PLAYER = 16                           # squeeze window for the Player's two cards
SQ_BANKER = 16                           # squeeze window for the Banker's two cards
SQ_THIRD = 10                            # squeeze window for each third card
POPUP_DELAY = 2.5                        # pause after the last card is shown, then the result popup
EARLY_GRACE = 2.0                        # a window ends this long after the squeezer turned the last card over
EARLY = {}                               # round_id -> {step key: early end, seconds after betting closed} (memory only)
POPUP_SHOW = 8                           # popup stays, then the next betting round opens

# bet type -> payout in hundredths of the stake (winnings only, stake comes back on top)
PAYOUT = {'player': 100, 'banker': 95, 'tie': 800, 'ppair': 1100, 'bpair': 1100}


# ---------------------------------------------------------------- rules
def rank_of(c):
    return c % 13


def value_of(c):
    r = c % 13
    return r + 1 if r < 9 else 0         # A=1, 2..9 face value, 10/J/Q/K = 0


def total(cards):
    return sum(value_of(c) for c in cards) % 10


def player_draws(p2):
    return p2 <= 5


def banker_draws(b2, p3):
    """b2: banker's two-card total; p3: player's third-card VALUE or None when the player stood."""
    if p3 is None:
        return b2 <= 5
    if b2 <= 2:
        return True
    if b2 == 3:
        return p3 != 8
    if b2 == 4:
        return 2 <= p3 <= 7
    if b2 == 5:
        return 4 <= p3 <= 7
    if b2 == 6:
        return 6 <= p3 <= 7
    return False


def play_hand(draw):
    """Deal one coup with draw() -> card. Order: P, B, P, B, then third cards by the tableau."""
    p = [draw()]
    b = [draw()]
    p.append(draw())
    b.append(draw())
    p2, b2 = total(p), total(b)
    if p2 < 8 and b2 < 8:                # no natural
        p3 = None
        if player_draws(p2):
            p.append(draw())
            p3 = value_of(p[2])
        if banker_draws(b2, p3):
            b.append(draw())
    ps, bs = total(p), total(b)
    return {
        'p': p, 'b': b, 'ps': ps, 'bs': bs,
        'w': 'P' if ps > bs else 'B' if bs > ps else 'T',
        'pp': rank_of(p[0]) == rank_of(p[1]),
        'bp': rank_of(b[0]) == rank_of(b[1]),
        'nat': max(p2, b2) >= 8,
    }


def schedule(hand, early=None):
    """Reveal windows, seconds since betting closed: [(side, [card indexes], start, end)], and reveal_after.
    early: {key: end} - a window whose cards were all turned over early ends there (keys p, b, p3, b3)."""
    early = early or {}
    steps = []
    t = T_DEAL

    def add(key, side, cards, dur):
        nonlocal t
        end = t + dur
        e = early.get(key)
        if e is not None:
            end = max(t + 0.5, min(end, e))
        steps.append((side, cards, t, end))
        t = end

    add('p', 'p', [0, 1], SQ_PLAYER)
    add('b', 'b', [0, 1], SQ_BANKER)
    if len(hand['p']) > 2:
        add('p3', 'p', [2], SQ_THIRD)
    if len(hand['b']) > 2:
        add('b3', 'b', [2], SQ_THIRD)
    return steps, t + POPUP_DELAY


def reveal_after(hand, early=None):
    return schedule(hand, early)[1]


def cycle_after(hand, early=None):
    return reveal_after(hand, early) + POPUP_SHOW


def register_reveal(c, uid, seat_map, key, now):
    """The squeezer says every card of the running window is face up -> end that window early. True if changed."""
    if key not in ('p', 'b', 'p3', 'b3'):
        return False
    r = latest_round(c)
    if r is None or r[3] != 'spinning' or not r[4]:
        return False
    hand = r[4]
    early = EARLY.setdefault(r[0], {})
    order = ['p', 'b'] + (['p3'] if len(hand['p']) > 2 else []) + (['b3'] if len(hand['b']) > 2 else [])
    if key in early or key not in order:
        return False
    side, _cards, start, end = schedule(hand, early)[0][order.index(key)]
    rel = now - r[2]
    if not (start + 0.8 <= rel < end):          # only the window that is running right now
        return False
    # same "who squeezes" rule as the client: seated player with the biggest bet on that side (lowest seat on ties)
    k = 'player' if side == 'p' else 'banker'
    stake = {}
    for o, a in c.execute('SELECT owner, SUM(amount) FROM baccarat_bets WHERE round_id=? AND bet_type=? GROUP BY owner',
                          (r[0], k)).fetchall():
        stake[o] = a
    best, amt = None, 0
    for o in sorted(seat_map, key=lambda x: seat_map[x]):
        if stake.get(o, 0) > amt:
            best, amt = o, stake[o]
    if best is not None and best != uid:
        return False
    if uid not in seat_map:
        return False
    new_end = rel + EARLY_GRACE
    if new_end >= end - 0.2:
        return False
    early[key] = new_end
    for rid in [x for x in EARLY if x < r[0] - 5]:
        EARLY.pop(rid, None)
    return True


def bet_result(bet_type, hand):
    """Total returned to the player for a bet of 1 unit-hundredth math: returns (returns_numerator, kind)."""
    w = hand['w']
    if bet_type == 'player':
        return (100 + PAYOUT['player'], 'win') if w == 'P' else (100, 'push') if w == 'T' else (0, 'lose')
    if bet_type == 'banker':
        return (100 + PAYOUT['banker'], 'win') if w == 'B' else (100, 'push') if w == 'T' else (0, 'lose')
    if bet_type == 'tie':
        return (100 + PAYOUT['tie'], 'win') if w == 'T' else (0, 'lose')
    if bet_type == 'ppair':
        return (100 + PAYOUT['ppair'], 'win') if hand['pp'] else (0, 'lose')
    if bet_type == 'bpair':
        return (100 + PAYOUT['bpair'], 'win') if hand['bp'] else (0, 'lose')
    return 0, 'lose'


def payout_for(bet_type, amount, hand):
    num, _ = bet_result(bet_type, hand)
    return amount * num // 100


# ---------------------------------------------------------------- storage
def ensure_tables(c):
    c.execute('''CREATE TABLE IF NOT EXISTS baccarat_rounds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        opened_at REAL NOT NULL, closes_at REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'open', hand TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS baccarat_bets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        round_id INTEGER NOT NULL, owner TEXT NOT NULL, op_id TEXT NOT NULL,
        bet_type TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0),
        created_at REAL NOT NULL, UNIQUE(owner, op_id))''')
    c.execute('CREATE INDEX IF NOT EXISTS baccarat_bets_round ON baccarat_bets(round_id, owner)')
    c.execute('CREATE TABLE IF NOT EXISTS baccarat_shoe (id INTEGER PRIMARY KEY CHECK(id=1), cards TEXT NOT NULL)')


def _new_shoe():
    cards = list(range(52)) * DECKS
    rnd = secrets.SystemRandom()
    rnd.shuffle(cards)
    return cards


def _load_shoe(c):
    row = c.execute('SELECT cards FROM baccarat_shoe WHERE id=1').fetchone()
    return json.loads(row[0]) if row else []


def _save_shoe(c, cards):
    c.execute('INSERT INTO baccarat_shoe(id,cards) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET cards=excluded.cards',
              (json.dumps(cards),))


def shoe_left(c):
    return len(_load_shoe(c))


def deal_from_shoe(c):
    """Draw one coup from the persistent shoe (reshuffles when it is running low). Returns (hand, reshuffled)."""
    shoe = _load_shoe(c)
    reshuffled = False
    if len(shoe) < RESHUFFLE_BELOW:
        shoe = _new_shoe()
        reshuffled = True
    hand = play_hand(lambda: shoe.pop())
    _save_shoe(c, shoe)
    hand['left'] = len(shoe)
    hand['shuffled'] = reshuffled
    return hand, reshuffled


def open_round(c):
    return c.execute(
        "SELECT id, opened_at, closes_at FROM baccarat_rounds WHERE status='open' ORDER BY id DESC LIMIT 1"
    ).fetchone()


def latest_round(c):
    """Newest round in any state: (id, opened_at, closes_at, status, hand_dict_or_None)."""
    r = c.execute('SELECT id, opened_at, closes_at, status, hand FROM baccarat_rounds ORDER BY id DESC LIMIT 1').fetchone()
    if r is None:
        return None
    return (r[0], r[1], r[2], r[3], json.loads(r[4]) if r[4] else None)


def _round_cycle_end(last):
    """When the table is idle again after this round (None if the round is still open)."""
    if last[4] is None:
        return last[2]
    return last[2] + cycle_after(last[4], EARLY.get(last[0]))


def ensure_open_round(c, now):
    r = open_round(c)
    if r is None:
        last = latest_round(c)
        if last is not None and (last[3] == 'spinning' or now < _round_cycle_end(last)):
            return None
        c.execute('INSERT INTO baccarat_rounds(opened_at, closes_at) VALUES (?,?)', (now, now + ROUND_SECONDS))
        r = open_round(c)
    return r


def _wallet(c, uid):
    return points.balance(c, uid)


def place_bet(c, uid, t, amount, op_id, now):
    if not isinstance(op_id, str) or not 8 <= len(op_id) <= 100:
        raise ValueError('操作IDが不正です')
    if type(amount) is not int or amount not in CHIPS:
        raise ValueError('チップの額が不正です')
    if t not in PAYOUT:
        raise ValueError('その場所にはベットできません')
    r = ensure_open_round(c, now)
    if r is None or now >= r[2]:
        raise ValueError('ベットは締め切られました')
    if c.execute('SELECT 1 FROM baccarat_bets WHERE owner=? AND op_id=?', (uid, op_id)).fetchone():
        return
    total = c.execute('SELECT COALESCE(SUM(amount),0) FROM baccarat_bets WHERE round_id=? AND owner=?',
                      (r[0], uid)).fetchone()[0]
    if total + amount > MAX_TOTAL_PER_ROUND:
        raise ValueError('1ラウンドのベット上限（%sポイント）を超えます' % format(MAX_TOTAL_PER_ROUND, ','))
    if not points.debit(c, uid, amount):
        raise ValueError('ポイントが足りません')
    c.execute('INSERT INTO baccarat_bets(round_id,owner,op_id,bet_type,amount,created_at) VALUES (?,?,?,?,?,?)',
              (r[0], uid, op_id, t, amount, now))


def _refund(c, uid, rows):
    total_ = sum(x[1] for x in rows)
    if total_:
        points.credit(c, uid, total_)
    for x in rows:
        c.execute('DELETE FROM baccarat_bets WHERE id=?', (x[0],))
    return total_


def _open_for_edit(c, now):
    r = ensure_open_round(c, now)
    if r is None or now >= r[2]:
        raise ValueError('ベットは締め切られました')
    return r


def clear_bets(c, uid, now):
    r = _open_for_edit(c, now)
    rows = c.execute('SELECT id, amount FROM baccarat_bets WHERE round_id=? AND owner=?', (r[0], uid)).fetchall()
    return _refund(c, uid, rows)


def undo_bet(c, uid, now):
    r = _open_for_edit(c, now)
    rows = c.execute('SELECT id, amount FROM baccarat_bets WHERE round_id=? AND owner=? ORDER BY id DESC LIMIT 1',
                     (r[0], uid)).fetchall()
    return _refund(c, uid, rows)


def history(c):
    out = []
    for (h,) in c.execute("SELECT hand FROM baccarat_rounds WHERE status='settled' AND hand IS NOT NULL "
                          "ORDER BY id DESC LIMIT ?", (HISTORY_N,)).fetchall():
        d = json.loads(h)
        out.append({'w': d['w'], 'pp': d['pp'], 'bp': d['bp'], 'ps': d['ps'], 'bs': d['bs']})
    return out                           # newest first


def state(c, uid, now):
    """Read-only snapshot for one player (no writes)."""
    r = open_round(c)
    bets, tot = [], 0
    if r is not None:
        for t, amt in c.execute('SELECT bet_type, SUM(amount) FROM baccarat_bets WHERE round_id=? AND owner=? '
                                'GROUP BY bet_type ORDER BY MIN(id)', (r[0], uid)).fetchall():
            bets.append({'t': t, 'amount': amt})
            tot += amt
    return {'round': None if r is None else {'id': r[0], 'opened_at': r[1], 'closes_at': r[2]},
            'server_now': now, 'bets': bets, 'total_bet': tot, 'balance': _wallet(c, uid),
            'history': history(c), 'chips': list(CHIPS), 'round_seconds': ROUND_SECONDS}


def settle(c, round_id, hand):
    """Pay everybody for the coup that was dealt when betting closed."""
    c.execute("UPDATE baccarat_rounds SET status='settled' WHERE id=?", (round_id,))
    owners = {}
    for owner, t, amount in c.execute('SELECT owner, bet_type, amount FROM baccarat_bets WHERE round_id=?',
                                      (round_id,)).fetchall():
        o = owners.setdefault(owner, {'stake': 0, 'payout': 0})
        o['stake'] += amount
        o['payout'] += payout_for(t, amount, hand)
    for owner, o in owners.items():
        if o['payout']:
            points.credit(c, owner, o['payout'])
    return {'kind': 'result', 'round_id': round_id, 'hand': hand, 'owners': owners}


def tick(c, now):
    """Called once a second. open -> (closes_at) dealing -> (+reveal_after) settled -> (+cycle_after) next round."""
    r = open_round(c)
    if r is not None:
        if now >= r[2]:
            hand, _ = deal_from_shoe(c)
            c.execute("UPDATE baccarat_rounds SET status='spinning', hand=? WHERE id=?", (json.dumps(hand), r[0]))
            return [{'kind': 'deal', 'round_id': r[0], 'hand': hand}]
        return []
    last = latest_round(c)
    if last is not None and last[3] == 'spinning':
        if now >= last[2] + reveal_after(last[4], EARLY.get(last[0])):
            return [settle(c, last[0], last[4])]
        return []
    if last is None or now >= _round_cycle_end(last):
        c.execute('INSERT INTO baccarat_rounds(opened_at, closes_at) VALUES (?,?)', (now, now + ROUND_SECONDS))
        return [{'kind': 'opened', 'round_id': open_round(c)[0]}]
    return []


def table_snapshot(c, now, seat_map, names):
    """Read-only snapshot of the shared table. seat_map: {uid: seat index}, names: {uid: display name}."""
    r = latest_round(c)
    owners = list(seat_map)
    bets = {u: [] for u in owners}
    totals = {u: 0 for u in owners}
    balances = {}
    if owners:
        q = ','.join('?' * len(owners))
        balances = {o: points.balance(c, o) for o in owners}
        if r is not None:
            for o, t, amt in c.execute('SELECT owner, bet_type, SUM(amount) FROM baccarat_bets WHERE round_id=? '
                                       'AND owner IN (%s) GROUP BY owner, bet_type ORDER BY MIN(id)' % q,
                                       [r[0]] + owners).fetchall():
                bets[o].append({'t': t, 'amount': amt})
                totals[o] += amt
    players = [{'seat': seat_map[u], 'name': names.get(u) or 'Player', 'balance': balances.get(u, 0),
                'total_bet': totals[u], 'bets': bets[u]} for u in sorted(owners, key=lambda x: seat_map[x])]
    rd = None
    if r is not None:
        dealt = r[3] in ('spinning', 'settled')
        rd = {'id': r[0], 'opened_at': r[1], 'closes_at': r[2], 'status': r[3],
              'hand': r[4] if dealt else None,
              'early': dict(EARLY.get(r[0], {})) if dealt else {}}
    return {'round': rd,
            'timeline': {'deal': T_DEAL, 'sq_player': SQ_PLAYER, 'sq_banker': SQ_BANKER, 'sq_third': SQ_THIRD,
                         'popup_delay': POPUP_DELAY, 'popup_show': POPUP_SHOW},
            'server_now': now, 'players': players, 'history': history(c), 'chips': list(CHIPS),
            'round_seconds': ROUND_SECONDS, 'max_seats': MAX_SEATS, 'shoe_left': shoe_left(c)}
