#!/usr/bin/python3
"""Run the bundled Casino service without server-side pip or apt installs."""

from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "vendor"))

import uvicorn  # noqa: E402


if __name__ == "__main__":
    uvicorn.run("app:app", host="127.0.0.1", port=8600, access_log=False)
