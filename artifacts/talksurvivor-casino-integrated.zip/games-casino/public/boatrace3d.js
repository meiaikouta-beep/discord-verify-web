// 競艇 3Dレース。全画面オーバーレイで動作し、閉じると全て破棄する。
import * as THREE from '/casino/static/vendor/three.module.js';
import {createRace,createRiggedRace,T0,pathPos,L,R0,PU,US,LAPS,COLORS,NAMES,RUN,PIT_X,pitZ,START_X,CENTER_X,CENTER_Z} from '/casino/static/boatrace_sim.js?v=br29turn';

const wh=(x,z,t)=>0.14*Math.sin(0.32*x+0.9*t)+0.1*Math.sin(0.55*z+1.2*t+1.0)+0.07*Math.sin(0.8*x+0.65*z+1.8*t);
const PX0=-300,PX1=175,PZ=42,SX=-30;
const LANE_HEX=COLORS.map(c=>'#'+c.toString(16).padStart(6,'0'));
const PLAYERS=['ちいかわ','ハチワレ','うさぎ','モモンガ','くりまんじゅう','シーサー'];
const darkText=ln=>ln===1||ln===5;

const WATER_VS=`uniform float uT;varying vec3 vW;varying vec3 vN;
float H(vec2 p){return 0.14*sin(0.32*p.x+0.9*uT)+0.1*sin(0.55*p.y+1.2*uT+1.0)+0.07*sin(0.8*p.x+0.65*p.y+1.8*uT);}
void main(){vec3 p=position;float h=H(p.xz);
float dx=0.14*0.32*cos(0.32*p.x+0.9*uT)+0.07*0.8*cos(0.8*p.x+0.65*p.z+1.8*uT);
float dz=0.1*0.55*cos(0.55*p.z+1.2*uT+1.0)+0.07*0.65*cos(0.8*p.x+0.65*p.z+1.8*uT);
vN=normalize(vec3(-dx,1.0,-dz));p.y=h;vW=p;gl_Position=projectionMatrix*viewMatrix*vec4(p,1.0);}`;
const WATER_FS=`uniform vec3 uCam;uniform vec3 uSun;uniform vec3 uH;uniform vec3 uTop;uniform vec3 uFog;uniform float uL;uniform float uSp;varying vec3 vW;varying vec3 vN;
void main(){vec3 V=normalize(uCam-vW);vec3 N=normalize(vN+0.025*vec3(sin(vW.x*1.7+vW.z*0.9),0.0,cos(vW.z*1.9+vW.x*0.7)));
vec3 R=reflect(-V,N);float fr=pow(1.0-max(dot(V,N),0.0),3.0);
vec3 deep=vec3(0.06,0.24,0.30)*uL,shallow=vec3(0.13,0.36,0.42)*uL;
vec3 sky=mix(uH,uTop,clamp(R.y*1.6,0.0,1.0));
vec3 c=mix(deep,shallow,0.5+0.5*N.x)+sky*(0.18+0.65*fr);
float sp=pow(max(dot(R,normalize(uSun)),0.0),180.0);c+=vec3(1.0,0.95,0.8)*sp*uSp;
float d=length(vW-uCam);c=mix(c,uFog,clamp((d-250.0)/500.0,0.0,0.55));
gl_FragColor=vec4(c,1.0);}`;

function canvasTex(w,h,draw){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=4;return t}
const lam=(c,o)=>new THREE.MeshLambertMaterial(Object.assign({color:c},o||{}));
function box(w,h,d,mat,x,y,z,parent){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);if(parent)parent.add(m);return m}

// 大時計(残り15秒の文字盤)。sec=残り秒
function drawDial(g,S,sec){
  const c=S/2;g.clearRect(0,0,S,S);
  const gr=g.createLinearGradient(0,0,S,S);gr.addColorStop(0,'#f4f4f4');gr.addColorStop(0.5,'#707070');gr.addColorStop(1,'#e8e8e8');
  g.fillStyle=gr;g.beginPath();g.arc(c,c,c-1,0,7);g.fill();
  g.fillStyle='#14181c';g.beginPath();g.arc(c,c,c*0.86,0,7);g.fill();
  g.strokeStyle='#e8e8e8';g.lineCap='round';
  for(let i=0;i<15;i++){const a=i/15*Math.PI*2-Math.PI/2,r1=c*0.82,r2=c*(i%5===0?0.68:0.75);g.lineWidth=S*(i%5===0?0.022:0.012);g.beginPath();g.moveTo(c+Math.cos(a)*r1,c+Math.sin(a)*r1);g.lineTo(c+Math.cos(a)*r2,c+Math.sin(a)*r2);g.stroke()}
  g.fillStyle='#fff';g.font=`bold ${S*0.17}px sans-serif`;g.textAlign='center';g.textBaseline='middle';
  for(const n of[5,10]){const a=(15-n)/15*Math.PI*2-Math.PI/2;g.fillText(String(n),c+Math.cos(a)*c*0.5,c+Math.sin(a)*c*0.5)}
  g.fillStyle='#ff4a2a';g.beginPath();g.moveTo(c,c*0.1);g.lineTo(c-S*0.03,c*0.02);g.lineTo(c+S*0.03,c*0.02);g.fill();
  const s=Math.max(0,Math.min(15,sec)),a=(15-s)/15*Math.PI*2-Math.PI/2;
  g.strokeStyle='#ff7a14';g.lineWidth=S*0.035;g.beginPath();g.moveTo(c-Math.cos(a)*c*0.18,c-Math.sin(a)*c*0.18);g.lineTo(c+Math.cos(a)*c*0.74,c+Math.sin(a)*c*0.74);g.stroke();
  g.fillStyle='#ff7a14';g.beginPath();g.arc(c,c,S*0.05,0,7);g.fill();
}
function drawNormalClock(g,S){
  const c=S/2;g.fillStyle='#f8f8f4';g.fillRect(0,0,S,S);g.strokeStyle='#223';g.lineWidth=S*0.03;g.beginPath();g.arc(c,c,c*0.86,0,7);g.stroke();
  g.fillStyle='#223';g.font=`bold ${S*0.11}px sans-serif`;g.textAlign='center';g.textBaseline='middle';
  for(let i=1;i<=12;i++){const a=i/12*Math.PI*2-Math.PI/2;g.fillText(String(i),c+Math.cos(a)*c*0.68,c+Math.sin(a)*c*0.68)}
  g.lineWidth=S*0.04;g.beginPath();g.moveTo(c,c);g.lineTo(c+Math.cos(-0.6)*c*0.42,c+Math.sin(-0.6)*c*0.42);g.stroke();
  g.lineWidth=S*0.025;g.beginPath();g.moveTo(c,c);g.lineTo(c+Math.cos(1.9)*c*0.62,c+Math.sin(1.9)*c*0.62);g.stroke();
}
function label(text,wm,hm,color,fpx,pw){
  const ph=Math.round(pw*hm/wm);
  const t=canvasTex(pw,ph,(g,w,h)=>{g.clearRect(0,0,w,h);g.fillStyle=color;g.font=`900 ${fpx}px sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillText(text,w/2,h/2+2)});
  const m=new THREE.Mesh(new THREE.PlaneGeometry(wm,hm),new THREE.MeshBasicMaterial({map:t,transparent:true,depthWrite:false,opacity:0.85,fog:false}));
  m.rotation.x=-Math.PI/2;const o=new THREE.Object3D();o.add(m);o.rotation.y=Math.PI/2;return o;
}

export async function openBoatRace(opts){
  opts=opts||{};if(opts.names)opts.names.forEach((n,i)=>{PLAYERS[i]=n});const hp=new URLSearchParams(location.hash.slice(1));
  let raceNo=opts.raceNo||hp.get('race')||'3',raceName=opts.raceName||hp.get('name')||'一般戦';
  if(document.getElementById('br-overlay'))return;
  const ov=document.createElement('div');ov.id='br-overlay';
  ov.style.cssText='position:fixed;inset:0;z-index:100000;background:#9cc3e6;touch-action:none;font-family:system-ui,sans-serif;color:#fff;user-select:none';
  ov.innerHTML=`<canvas id="br-cv" style="position:absolute;inset:0;width:100%;height:100%;display:block"></canvas>
<div id="br-top" style="position:absolute;left:0;right:0;top:0;display:flex;justify-content:space-between;align-items:center;padding:8px 10px;background:linear-gradient(#000a,#0000)"><b style="font-size:17px;text-shadow:0 1px 3px #000">🚤 ボートレース</b><span style="display:flex;align-items:center;gap:4px;margin-left:auto;margin-right:8px;opacity:.85;font-size:15px">🔊<input type="range" id="br-vol" min="0" max="1" step="0.05" style="width:80px"></span><button id="br-close" style="font-size:16px;padding:8px 14px;border:0;border-radius:10px;background:#c0392bd0;color:#fff">✕ 閉じる</button></div>
<div id="br-left" style="position:absolute;left:8px;top:52px;display:flex;flex-direction:column;gap:6px;align-items:flex-start;max-width:calc(100% - 130px)"><div id="br-info" style="background:#0009;border-radius:10px;padding:7px 10px;font-size:15px;line-height:1.55;min-width:140px"></div>
<div id="br-od" style="background:#000a;border-radius:10px;padding:6px 10px;font-size:14px;line-height:1.5;display:none"></div></div>
<div id="br-cm" style="position:absolute;left:8px;right:8px;top:48px;display:none;background:linear-gradient(90deg,#b71c1ce6,#e65100e6);border:2px solid #ffd54a;border-radius:10px;padding:6px 12px;font-size:22px;font-weight:800;line-height:1.3;text-shadow:0 1px 3px #000;text-align:center;pointer-events:none;z-index:6"></div>
<canvas id="br-clk" width="240" height="240" style="position:absolute;right:8px;top:52px;width:104px;height:104px;display:none;filter:drop-shadow(0 2px 5px #000a)"></canvas>
<div id="br-big" style="position:absolute;left:0;right:0;top:34%;text-align:center;font-size:44px;font-weight:900;text-shadow:0 2px 8px #000;pointer-events:none"></div>
<div id="br-res" style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);display:none;background:#000c;border-radius:14px;padding:14px 18px;min-width:230px;max-width:92vw;font-size:17px;line-height:1.7"></div>
<div id="br-ctl" style="position:absolute;left:0;right:0;bottom:0;padding:8px;background:linear-gradient(#0000,#000a);display:flex;flex-wrap:wrap;gap:6px;justify-content:center"></div>`;
  document.body.appendChild(ov);
  const cv=ov.querySelector('#br-cv'),info=ov.querySelector('#br-info'),big=ov.querySelector('#br-big'),res=ov.querySelector('#br-res'),ctl=ov.querySelector('#br-ctl');
  const clkC=ov.querySelector('#br-clk'),clkG=clkC.getContext('2d');
  const renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.75));
  const scene=new THREE.Scene();
  // 時間帯: 23時〜は夕方、1時〜はナイター(レース開始時刻のJST)
  const hr=new Date((opts.live?opts.live.startMs:Date.now())+9*3600e3).getUTCHours();
  const PH=(hr>=1&&hr<4)?2:(hr>=23||hr===0)?1:0;
  const SK=[{h:[0.82,0.9,0.96],t:[0.28,0.52,0.88],fog:0xcfe0ee,hemi:[0xdfeeff,0x6b7a62,0.95],dl:[0xfff2dd,1.0],cl:0xffffff,bg:'#9cc3e6',lv:1,sp:1.3},
    {h:[1.0,0.52,0.26],t:[0.2,0.16,0.4],fog:0x8a5a62,hemi:[0xffb78a,0x3a3a50,0.55],dl:[0xff9a55,0.55],cl:0xd98a7a,bg:'#6a4a6a',lv:0.5,sp:0.9},
    {h:[0.09,0.13,0.26],t:[0.03,0.06,0.16],fog:0x141c34,hemi:[0x8fa6dc,0x2a3050,0.95],dl:[0xa8bce8,0.55],cl:0x2a3350,bg:'#0b1226',lv:0.4,sp:0.2}][PH];
  scene.fog=new THREE.Fog(SK.fog,260,900);ov.style.background=SK.bg;
  const cam=new THREE.PerspectiveCamera(55,1,0.5,2500);
  const sunDir=new THREE.Vector3(-0.5,0.75,0.4).normalize();
  scene.add(new THREE.HemisphereLight(SK.hemi[0],SK.hemi[1],SK.hemi[2]));
  const dl=new THREE.DirectionalLight(SK.dl[0],SK.dl[1]);dl.position.copy(sunDir).multiplyScalar(200);scene.add(dl);

  const sky=new THREE.Mesh(new THREE.SphereGeometry(1500,24,12),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,
    uniforms:{uH:{value:new THREE.Vector3(...SK.h)},uTop:{value:new THREE.Vector3(...SK.t)}},
    vertexShader:'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
    fragmentShader:'uniform vec3 uH;uniform vec3 uTop;varying vec3 p;void main(){float h=clamp(normalize(p).y,0.0,1.0);gl_FragColor=vec4(mix(uH,uTop,pow(h,0.55)),1.0);}'}));
  scene.add(sky);
  if(PH===2){const n=260,pa=new Float32Array(n*3);for(let i=0;i<n;i++){const a=Math.random()*6.283,e=0.15+Math.random()*1.3,r=1400;pa[i*3]=Math.cos(a)*Math.cos(e)*r;pa[i*3+1]=Math.sin(e)*r;pa[i*3+2]=Math.sin(a)*Math.cos(e)*r}
    const sg=new THREE.BufferGeometry();sg.setAttribute('position',new THREE.BufferAttribute(pa,3));scene.add(new THREE.Points(sg,new THREE.PointsMaterial({color:0xffffff,size:3,sizeAttenuation:false,fog:false,depthWrite:false})))}
  const cmat=new THREE.MeshBasicMaterial({color:SK.cl,transparent:true,opacity:PH===2?0.35:0.85,fog:false});
  for(let i=0;i<14;i++){const c=new THREE.Mesh(new THREE.SphereGeometry(1,8,6),cmat);c.scale.set(60+Math.random()*60,12+Math.random()*8,25+Math.random()*20);c.position.set((Math.random()-0.5)*1800,260+Math.random()*120,(Math.random()-0.5)*1800);scene.add(c)}

  // 水面
  const wgeo=new THREE.PlaneGeometry(PX1-PX0,PZ*2,240,40);wgeo.rotateX(-Math.PI/2);wgeo.translate((PX0+PX1)/2,0,0);
  const wmat=new THREE.ShaderMaterial({uniforms:{uT:{value:0},uCam:{value:new THREE.Vector3()},uSun:{value:sunDir},uH:{value:new THREE.Vector3(...SK.h)},uTop:{value:new THREE.Vector3(...SK.t)},uFog:{value:new THREE.Color(SK.fog)},uL:{value:SK.lv},uSp:{value:SK.sp}},vertexShader:WATER_VS,fragmentShader:WATER_FS});
  scene.add(new THREE.Mesh(wgeo,wmat));

  // 地面・護岸
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(3000,3000),lam(0x5f8a52));ground.rotation.x=-Math.PI/2;ground.position.y=-0.4;scene.add(ground);
  const conc=lam(0xb9bdc2),concD=lam(0x8e949a);
  box(PX1-PX0+16,1.6,6,conc,(PX0+PX1)/2,0.3,PZ+3,scene);box(PX1-PX0+16,1.6,6,conc,(PX0+PX1)/2,0.3,-PZ-3,scene);
  box(6,1.6,PZ*2+12,conc,PX1+3,0.3,0,scene);box(6,1.6,PZ*2+12,conc,PX0-3,0.3,0,scene);
  box(PX1-PX0+60,0.1,50,concD,(PX0+PX1)/2,0.05,PZ+30,scene);
  box(PX1-PX0+60,0.1,24,concD,(PX0+PX1)/2,0.05,-PZ-18,scene);
  const rail=lam(0xe8ecef);
  box(PX1-PX0,0.08,0.1,rail,(PX0+PX1)/2,2.5,PZ+0.6,scene);box(PX1-PX0,0.08,0.1,rail,(PX0+PX1)/2,2.0,PZ+0.6,scene);

  // ===== スタンド(階段状の観客席 + 観客 + ガラス張りの建屋 + 屋根) =====
  const NT=9,TD=2.2,TH=1.1,TZ0=68,SW=220;
  const seatTex=canvasTex(128,32,(g,w,h)=>{g.fillStyle='#2c3f66';g.fillRect(0,0,w,h);for(let i=0;i<8;i++){g.fillStyle=i%2?'#3d5a94':'#36508a';g.fillRect(i*16+1,4,14,22)}});
  seatTex.wrapS=THREE.RepeatWrapping;seatTex.repeat.set(SW/2,1);
  const seatM=new THREE.MeshLambertMaterial({map:seatTex}),tierM=lam(0xaeb4bb);
  for(let k=0;k<NT;k++){const h=(k+1)*TH;box(SW,h,TD,[tierM,tierM,seatM,tierM,tierM,tierM],SX,h/2,TZ0+TD*k+TD/2,scene)}
  const crowdBody=new THREE.InstancedMesh(new THREE.BoxGeometry(0.55,0.95,0.38),lam(0xffffff),NT*210);
  const crowdHead=new THREE.InstancedMesh(new THREE.SphereGeometry(0.2,6,5),lam(0xe6b894),NT*210);
  {const o=new THREE.Object3D(),col=new THREE.Color();let n=0;
   for(let k=0;k<NT;k++){const y=(k+1)*TH;for(let x=SX-SW/2+2;x<SX+SW/2-2;x+=1.05){if(Math.random()<0.3)continue;
     const zz=TZ0+TD*k+TD*0.55+(Math.random()-0.5)*0.3;o.position.set(x+(Math.random()-0.5)*0.2,y+0.55,zz);o.updateMatrix();crowdBody.setMatrixAt(n,o.matrix);
     col.setHSL(Math.random(),0.45+Math.random()*0.4,0.3+Math.random()*0.35);crowdBody.setColorAt(n,col);
     o.position.y=y+1.22;o.updateMatrix();crowdHead.setMatrixAt(n,o.matrix);n++}}
   crowdBody.count=n;crowdHead.count=n;}
  scene.add(crowdBody,crowdHead);
  const zb=TZ0+TD*NT;
  const glassTex=canvasTex(1024,256,(g,w,h)=>{
    const gr=g.createLinearGradient(0,0,0,h);gr.addColorStop(0,'#5d7fa8');gr.addColorStop(1,'#2d4566');g.fillStyle=gr;g.fillRect(0,0,w,h);
    g.strokeStyle='#cfd8e2';g.lineWidth=3;for(let x=0;x<=w;x+=32){g.beginPath();g.moveTo(x,0);g.lineTo(x,h);g.stroke()}
    for(let y=0;y<=h;y+=64){g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke()}
    g.fillStyle='rgba(255,255,255,0.14)';for(let i=0;i<9;i++){g.beginPath();g.moveTo(i*130,0);g.lineTo(i*130+50,0);g.lineTo(i*130-60,h);g.lineTo(i*130-110,h);g.fill()}
    for(let i=0;i<70;i++){g.fillStyle=Math.random()<0.5?'rgba(255,230,150,0.55)':'rgba(20,30,50,0.35)';g.fillRect(Math.floor(Math.random()*32)*32+4,Math.floor(Math.random()*4)*64+6,24,52)}});
  glassTex.wrapS=THREE.RepeatWrapping;
  const wallM=lam(0xd8dde3);
  box(SW+4,34,26,[wallM,wallM,wallM,wallM,wallM,new THREE.MeshLambertMaterial({map:glassTex})],SX,17,zb+13,scene);
  const drawSign=(g,w,h)=>{g.fillStyle='#1d3a63';g.fillRect(0,0,w,h);g.fillStyle='#fff';g.font='bold 40px sans-serif';g.textBaseline='middle';g.fillText('BOAT RACE　ちいかわ水上競技場',30,34);
    g.fillStyle='#ffd23a';g.fillRect(w-190,10,160,44);g.fillStyle='#1d3a63';g.font='bold 30px sans-serif';g.fillText(raceNo+'R '+raceName,w-180,34)};
  const signTex=canvasTex(1024,64,drawSign);
  window.__brSetRace=(no,name)=>{raceNo=String(no);raceName=String(name);const c=signTex.image;drawSign(c.getContext('2d'),c.width,c.height);signTex.needsUpdate=true};
  const navy=lam(0x2a3b57);
  box(SW+10,1.4,44,navy,SX,21,TZ0+22,scene);
  box(SW+10,5,1,[navy,navy,navy,navy,navy,new THREE.MeshLambertMaterial({map:signTex})],SX,23.2,TZ0-0.6,scene);
  for(let x=SX-SW/2;x<=SX+SW/2;x+=22)box(0.9,21,0.9,lam(0xe3e6ea),x,10.5,TZ0+1.5,scene);
  // 国旗風の旗飾り
  for(let i=0;i<14;i++){const f=box(1.4,2.2,0.05,lam(new THREE.Color().setHSL(i/14,0.7,0.55)),SX-SW/2+8+i*15.5,17.8,TZ0-0.2,scene);f.rotation.z=(i%2?0.1:-0.1)}

  // 大時計の塔(カウントダウン表示)
  const towerC=document.createElement('canvas');towerC.width=towerC.height=256;const towerG=towerC.getContext('2d');
  const towerTex=new THREE.CanvasTexture(towerC);towerTex.colorSpace=THREE.SRGBColorSpace;drawDial(towerG,256,15);
  const tw=lam(0xdde1e6);
  box(2.4,36,2.4,tw,START_X,18,PZ+14,scene);
  const clkMat=new THREE.MeshBasicMaterial({map:towerTex});
  const tower=new THREE.Mesh(new THREE.BoxGeometry(15,15,1.6),[tw,tw,tw,tw,clkMat,clkMat]);
  tower.position.set(START_X,43.5,PZ+14);scene.add(tower);
  box(16.4,1.4,2.4,navy,START_X,51.7,PZ+14,scene);

  // 電光掲示板(対岸)
  const bc=document.createElement('canvas');bc.width=1024;bc.height=480;const bgx=bc.getContext('2d');
  const btex=new THREE.CanvasTexture(bc);btex.colorSpace=THREE.SRGBColorSpace;
  const BZ=-PZ-26;
  box(66,27,2.4,lam(0x15181d),-20,25,BZ,scene);
  for(const sx of[-28,28])box(3,17,3,lam(0x30343a),-20+sx,8,BZ-0.3,scene);
  const board=new THREE.Mesh(new THREE.PlaneGeometry(62,23),new THREE.MeshBasicMaterial({map:btex,fog:false}));board.position.set(-20,25,BZ+1.25);scene.add(board);
  box(66,1.2,3.4,lam(0x40454c),-20,38.9,BZ,scene);

  // 屋外大型照明塔(高所のナイター照明)。夕方・夜は点灯
  {const lit=PH>0,pole=lam(0x6b7078),lampOn=new THREE.MeshBasicMaterial({color:lit?0xfffbe8:0xc9ccd0,fog:false});
   const glowTex=canvasTex(64,64,(g,w,h)=>{const r=g.createRadialGradient(32,32,0,32,32,32);r.addColorStop(0,'rgba(255,248,215,0.95)');r.addColorStop(0.3,'rgba(255,238,180,0.4)');r.addColorStop(1,'rgba(255,230,150,0)');g.fillStyle=r;g.fillRect(0,0,w,h)});
   const glowM=new THREE.SpriteMaterial({map:glowTex,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,fog:false});
   const spots=[[-250,PZ+14],[-150,PZ+14],[-20,PZ+14],[110,PZ+14],[-250,-PZ-26],[-150,-PZ-26],[110,-PZ-26],[PX1+14,0],[PX0-14,0]];
   for(const [x,z] of spots){const H=52;
     box(1.6,H,1.6,pole,x,H/2,z,scene);
     const bank=new THREE.Group();bank.position.set(x,H+3,z);bank.rotation.y=z===0?(x>0?-Math.PI/2:Math.PI/2):(z>0?Math.PI:0);scene.add(bank);
     box(11,5.5,1,pole,0,0,0,bank);
     for(let i=0;i<4;i++)for(let j=0;j<2;j++)box(2.3,2,0.4,lampOn,-4.2+i*2.8,1.3-j*2.6,0.7,bank);
     if(lit){const sp=new THREE.Sprite(glowM);sp.scale.set(48,48,1);sp.position.set(x,H+3,z);scene.add(sp)}}
   if(lit){const pc=[[-200,24,0],[-80,24,0],[40,24,0],[130,24,0]];
     for(const p of pc){const L=new THREE.PointLight(0xfff0d0,PH===2?4.5:1.8,420,1.2);L.position.set(...p);scene.add(L)}}
  }

  // スタートライン周り
  for(const s of[1,-1]){box(0.5,9,0.5,lam(0xffffff),START_X,4.5,s*(PZ+0.2),scene);box(0.52,1.2,0.52,lam(0xd22),START_X,7.5,s*(PZ+0.2),scene);box(0.52,1.2,0.52,lam(0xd22),START_X,3.5,s*(PZ+0.2),scene)}
  const flyMat=new THREE.MeshBasicMaterial({color:0x5ec8ff,transparent:true,opacity:0.95,blending:THREE.AdditiveBlending,depthWrite:false,fog:false});
  const flyLine=new THREE.Mesh(new THREE.PlaneGeometry(0.8,PZ*2),flyMat);flyLine.rotation.x=-Math.PI/2;flyLine.position.set(START_X,0.38,0);scene.add(flyLine);
  const curtain=new THREE.Mesh(new THREE.PlaneGeometry(PZ*2,3.2),new THREE.MeshBasicMaterial({color:0x5ec8ff,transparent:true,opacity:0.16,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,fog:false}));
  curtain.rotation.y=Math.PI/2;curtain.position.set(START_X,1.9,0);scene.add(curtain);
  const stl=label('START',46,16,'#ffae1a',150,512);stl.position.set(START_X+30,0.36,-4);scene.add(stl);const startLabels=[stl];
  for(const d of[RUN[0]+3,RUN[3]+3]){        // スロー/ダッシュの待機ライン(文字は出さない)
    const lx=START_X-d;const ln=new THREE.Mesh(new THREE.PlaneGeometry(0.4,PZ*2),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:0.35,depthWrite:false,fog:false}));
    ln.rotation.x=-Math.PI/2;ln.position.set(lx,0.36,0);scene.add(ln);
  }
  // ===== ピット(白い2階建てピット棟 + 浮き桟橋 + 号艇色のゲートアーチ) =====
  {
    const PF=PIT_X-3.2;                  // 桟橋の前端(ボートの船尾がここに着く)
    const z0=pitZ(0)-4,z1=pitZ(5)+4,zc=(z0+z1)/2,zl=z1-z0;
    // ピット棟: 1階はガラス戸、2階は窓が並ぶ白い外壁
    const pitWallTex=canvasTex(1024,512,(g,w,h)=>{
      g.fillStyle='#eef0ee';g.fillRect(0,0,w,h);
      g.fillStyle='#d9ddda';for(let y=0;y<h;y+=32)g.fillRect(0,y,w,2);
      const win=(x,y,ww,hh)=>{g.fillStyle='#9aa3a8';g.fillRect(x-4,y-4,ww+8,hh+8);
        const gr=g.createLinearGradient(0,y,0,y+hh);gr.addColorStop(0,'#3d4b57');gr.addColorStop(1,'#1d2730');g.fillStyle=gr;g.fillRect(x,y,ww,hh);
        g.fillStyle='#b9c2c7';g.fillRect(x+ww/2-2,y,4,hh);g.fillRect(x,y+hh*0.45,ww,3);
        g.fillStyle='rgba(255,255,255,0.12)';g.beginPath();g.moveTo(x+6,y+hh);g.lineTo(x+ww*0.35,y);g.lineTo(x+ww*0.5,y);g.lineTo(x+ww*0.2,y+hh);g.fill()};
      for(let i=0;i<6;i++)win(26+i*168,44,120,120);      // 2階
      for(let i=0;i<8;i++)win(18+i*127,300,92,170);       // 1階
      g.fillStyle='#c8ccc9';g.fillRect(0,238,w,14);
    });
    const pwM=lam(0xeef0ee),pwF=new THREE.MeshLambertMaterial({map:pitWallTex});
    const BX=PX0-16;
    box(26,15,zl+16,[pwF,pwM,pwM,pwM,pwM,pwM],BX,7.5,zc,scene);
    box(28,0.8,zl+18,lam(0x9aa0a6),BX,15.4,zc,scene);                       // 屋上の縁
    box(3,0.35,zl+16,lam(0xd4d8dc),PX0-1.5,7.6,zc,scene);                    // 2階バルコニー
    const railM=lam(0xe6eaec);
    box(0.08,0.08,zl+16,railM,PX0-0.1,8.8,zc,scene);box(0.08,0.08,zl+16,railM,PX0-0.1,8.2,zc,scene);
    for(let z=z0-8;z<=z1+8;z+=1.6)box(0.07,1.2,0.07,railM,PX0-0.1,8.3,z,scene);
    // 護岸上の通路と桟橋への渡り
    box(3,0.25,zl+10,lam(0xb5b9bd),PX0-1.5,1.2,zc,scene);
    // 浮き桟橋(本体)と、艇ごとの仕切り
    const deckM=lam(0x4f8aa3),deckS=lam(0x2f5e74),fendM=lam(0x1d2228);
    const DX0=PX0+0.5,DX1=PF;
    box(DX1-DX0,0.55,zl,[deckS,deckS,deckM,deckS,deckS,deckS],(DX0+DX1)/2,0.18,zc,scene);
    box(0.35,0.4,zl,fendM,DX1+0.1,0.15,zc,scene);
    for(let i=0;i<=6;i++){const z=i<6?pitZ(i)-2.8:pitZ(5)+2.8;
      box(4.2,0.45,0.55,[deckS,deckS,deckM,deckS,deckS,deckS],PF+2.1,0.16,z,scene);
      box(0.35,1.2,0.35,lam(0xf2f2f2),PF+3.9,0.75,z,scene);}            // 仕切りの先端の白い柱
    // 桟橋上の小物(機器箱)
    box(1.2,1.4,1.2,lam(0xb83a3a),DX0+1.5,1.15,z1-1,scene);box(0.8,1.6,0.9,lam(0xdfe3e6),DX0+1.2,1.25,z0+1.5,scene);
    // 号艇色のゲートアーチ(白丸に艇番、下側は白地に号艇色の市松模様)
    const ARCH_NUM=['#111','#111','#e02020','#2050e0','#7a6400','#20a040'];
    const archTex=ln=>canvasTex(256,368,(g,w,h)=>{
      const col=LANE_HEX[ln-1],dot=ln===1?'#222':col,lw=34,top=150;
      const outer=()=>{g.beginPath();g.moveTo(4,h);g.lineTo(4,top);g.bezierCurveTo(4,-20,w-4,-20,w-4,top);g.lineTo(w-4,h);g.closePath()};
      const inner=()=>{g.beginPath();g.moveTo(4+lw,h+2);g.lineTo(4+lw,top+30);g.bezierCurveTo(4+lw,40,w-4-lw,40,w-4-lw,top+30);g.lineTo(w-4-lw,h+2);g.closePath()};
      g.clearRect(0,0,w,h);
      outer();g.fillStyle=col;g.fill();
      // 下半分: 白地+号艇色の市松(下に行くほど粗く)
      g.save();outer();g.clip();g.fillStyle='#fff';g.fillRect(0,top+40,w,h);
      for(let y=top+40,r=0;y<h;y+=10,r++){const s=Math.max(1.5,8-r*0.45);for(let x=(r%2)*10;x<w;x+=20){g.fillStyle=dot;g.fillRect(x+5-s/2,y+5-s/2,s,s)}}
      g.restore();
      g.globalCompositeOperation='destination-out';inner();g.fill();g.globalCompositeOperation='source-over';
      outer();g.lineWidth=5;g.strokeStyle=ln===1?'#9aa0a6':'#ffffff';g.stroke();
      inner();g.lineWidth=3;g.strokeStyle=ln===1?'#9aa0a6':'#ffffffaa';g.stroke();
      // 白丸と艇番
      g.fillStyle='#fff';g.beginPath();g.arc(w/2,64,48,0,7);g.fill();g.lineWidth=5;g.strokeStyle=ln===1||ln===2?'#111':col;g.stroke();
      g.fillStyle=ARCH_NUM[ln-1];g.font='900 68px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(String(ln),w/2,68);
    });
    const AW=4.8,AH=AW*368/256;
    for(let i=0;i<6;i++){
      const am=new THREE.MeshLambertMaterial({map:archTex(i+1),transparent:true,alphaTest:0.5,side:THREE.DoubleSide});
      const a=new THREE.Mesh(new THREE.PlaneGeometry(AW,AH),am);a.rotation.y=Math.PI/2;a.position.set(PF-0.6,0.45+AH/2,pitZ(i));scene.add(a);
      for(const s of[-1,1])box(0.18,0.5,0.18,lam(0x9aa0a6),PF-0.6,0.6,pitZ(i)+s*(AW/2-0.35),scene);   // 足元の固定金具
    }
  }
  // 進入用センターポール。第1/第2ターンマークとは別の固定目標物。
  // 2つのターンマークと同じ軌道(z=0)上、CENTER_X に配置する。
  {
    const cx=CENTER_X,cz=CENTER_Z;
    const pole=new THREE.Group();
    const shaft=new THREE.Mesh(new THREE.CylinderGeometry(0.32,0.38,8.4,12),lam(0xf5f5f0));
    shaft.position.y=4.2;pole.add(shaft);
    for(const y of [1.6,3.7,5.8,7.7]){
      const stripe=new THREE.Mesh(new THREE.CylinderGeometry(0.405,0.405,0.65,12),lam(0xe33227));
      stripe.position.y=y;pole.add(stripe);
    }
    const cap=new THREE.Mesh(new THREE.SphereGeometry(0.8,12,8),lam(0xffdf36));
    cap.position.y=8.8;pole.add(cap);
    const base=new THREE.Mesh(new THREE.CylinderGeometry(1.0,1.2,0.55,16),lam(0xf9a31b));
    base.position.y=0.35;pole.add(base);
    pole.position.set(cx,0,cz);scene.add(pole);
  }
  // ターンマーク
  const marks=[];
  for(const sx of[1,-1]){
    const m=new THREE.Group();
    m.add(new THREE.Mesh(new THREE.CylinderGeometry(1.5,1.7,3.2,14),lam(0xff7a12)));
    const band=new THREE.Mesh(new THREE.CylinderGeometry(1.56,1.66,0.7,14),lam(0xffffff));band.position.y=0.2;m.add(band);
    const top=new THREE.Mesh(new THREE.ConeGeometry(1.0,1.4,12),lam(0xff7a12));top.position.y=2.3;m.add(top);
    m.position.set(sx*L/2,1.0,0);scene.add(m);marks.push(m);
  }
  const tgeo=new THREE.ConeGeometry(5,16,7),tr=new THREE.InstancedMesh(tgeo,lam(0x2f6b3a),220),dm=new THREE.Object3D();
  for(let i=0;i<220;i++){const a=Math.random()*Math.PI*2,rr=330+Math.random()*420;let x=Math.cos(a)*rr-15,z=Math.sin(a)*rr;if(z>0&&Math.abs(x+30)<190&&z<150)z+=150;dm.position.set(x,6,z);const s=0.7+Math.random()*1.1;dm.scale.set(s,s,s);dm.updateMatrix();tr.setMatrixAt(i,dm.matrix)}
  scene.add(tr);
  const bm=lam(0xa9b4c2);for(let i=0;i<26;i++){const a=Math.random()*Math.PI*2,rr=800+Math.random()*300,h=40+Math.random()*120;box(40+Math.random()*50,h,40+Math.random()*50,bm,Math.cos(a)*rr,h/2,Math.sin(a)*rr,scene)}

  // ===== ボート・選手 =====
  const ST=[-2.3,-2.0,-1.3,-0.4,0.6,1.5,2.1,2.55,2.85];
  const BW=[0.56,0.62,0.66,0.66,0.63,0.52,0.36,0.17,0.02];
  const SY=[0.62,0.6,0.58,0.58,0.6,0.64,0.7,0.76,0.8];
  const CY=[0.22,0.2,0.18,0.18,0.2,0.26,0.38,0.5,0.6];
  const ring=k=>{const w=BW[k],s=SY[k],c=CY[k],m=s+(c-s)*0.45;return[[w,s],[w*0.97,m],[w*0.68,c],[-w*0.68,c],[-w*0.97,m],[-w,s]]};
  const bandCache={};
  function band(a,b){const key=a+'_'+b;if(bandCache[key])return bandCache[key];
    const pos=[],idx=[];for(let k=0;k<ST.length;k++){const r=ring(k);pos.push(r[a][0],r[a][1],ST[k],r[b][0],r[b][1],ST[k])}
    for(let k=0;k<ST.length-1;k++){const i=k*2;idx.push(i,i+2,i+1,i+1,i+2,i+3)}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setIndex(idx);g.computeVertexNormals();return bandCache[key]=g}
  const transom=(()=>{const r=ring(0),pos=[];r.forEach(p=>pos.push(p[0],p[1],ST[0]));const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setIndex([0,1,5,1,4,5,1,2,4,2,3,4]);g.computeVertexNormals();return g})();
  const DS=THREE.DoubleSide;
  const hullM=lam(0xf3f0e4,{side:DS}),deckM=lam(0xe4dfc9,{side:DS}),botM=lam(0x23303f,{side:DS}),blackM=lam(0x1b1d22),silM=lam(0xaeb6c0),cockM=lam(0x20242b),skinM=lam(0xe8b890),pantsM=lam(0x2c3446),wsM=lam(0xbfe3ff,{transparent:true,opacity:0.35,side:DS});
  const UC=new THREE.CylinderGeometry(1,1,1,8),SPH=new THREE.SphereGeometry(1,12,9),TORUS=new THREE.TorusGeometry(0.11,0.022,6,14);
  const UP=new THREE.Vector3(0,1,0);
  function limb(parent,mat,a,b,r){const m=new THREE.Mesh(UC,mat),d=new THREE.Vector3(b[0]-a[0],b[1]-a[1],b[2]-a[2]),len=d.length();
    m.position.set((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2);m.scale.set(r,len,r);m.quaternion.setFromUnitVectors(UP,d.normalize());parent.add(m);return m}
  function ball(parent,mat,p,r,sx,sy,sz){const m=new THREE.Mesh(SPH,mat);m.position.set(p[0],p[1],p[2]);m.scale.set(r*(sx||1),r*(sy||1),r*(sz||1));parent.add(m);return m}
  const numTexes=[];
  function numTex(ln){return numTexes[ln]||(numTexes[ln]=canvasTex(64,64,(g,w,h)=>{g.fillStyle=LANE_HEX[ln-1];g.fillRect(0,0,w,h);g.fillStyle=darkText(ln)?'#111':'#fff';g.font='bold 52px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(String(ln),32,36)}))}

  function makeBoat(lane){
    const col=COLORS[lane-1],g=new THREE.Group(),inner=new THREE.Group();inner.position.y=-0.32;g.add(inner);
    const sm=lam(col,{side:DS});
    [[0,1,sm],[1,2,hullM],[2,3,botM],[3,4,hullM],[4,5,sm],[5,0,deckM]].forEach(([a,b,m])=>inner.add(new THREE.Mesh(band(a,b),m)));
    inner.add(new THREE.Mesh(transom,hullM));
    // コクピット・ウインドシールド
    box(0.78,0.05,1.5,cockM,0,0.62,-0.55,inner);
    const ws=box(0.82,0.34,0.03,wsM,0,0.8,0.82,inner);ws.rotation.x=-0.62;
    box(0.9,0.04,0.05,silM,0,0.6,0.97,inner);
    // モーター(ステー/カウリング/ギアケース/プロペラ)
    box(0.62,0.5,0.14,blackM,0,0.78,-2.38,inner);
    const cow=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.3,0.55,12),lam(0x2e333b));cow.position.set(0,1.05,-2.6);inner.add(cow);
    const cb=new THREE.Mesh(new THREE.CylinderGeometry(0.205,0.215,0.1,12),sm);cb.position.set(0,1.16,-2.6);inner.add(cb);
    limb(inner,silM,[0,0.85,-2.62],[0,-0.08,-2.72],0.07);
    const gc=new THREE.Mesh(new THREE.CapsuleGeometry(0.1,0.34,4,8),silM);gc.rotation.x=Math.PI/2;gc.position.set(0,-0.12,-2.78);inner.add(gc);
    const prop=new THREE.Group();prop.position.set(0,-0.12,-3.02);inner.add(prop);
    for(let i=0;i<3;i++){const bl=box(0.46,0.09,0.02,silM,0,0,0);bl.rotation.z=i*Math.PI/3;prop.remove(bl);const bh=new THREE.Group();bh.add(bl);prop.add(bh)}
    // 艇旗(艇番)
    box(0.03,1.35,0.03,silM,0.42,1.25,-2.3,inner);
    const fl=new THREE.Mesh(new THREE.PlaneGeometry(0.5,0.34),new THREE.MeshBasicMaterial({map:numTex(lane),side:DS}));fl.position.set(0.42,1.78,-2.55);fl.rotation.y=Math.PI/2;inner.add(fl);
    // 選手(膝立ち姿勢でハンドルを握る)
    const rd=new THREE.Group();rd.position.set(0,0.62,-0.75);inner.add(rd);
    const suit=lam(col),vest=lam(col);
    const HC=[0xd8d8d8,0xff8a00,0x7a3fd0,0x18b8c8,0xff4f9a,0x9ccc20],hcol=HC[lane-1];
    const hip=[0,0.4,-0.42],sh=[0,0.6,0.34],hd=[0,0.68,0.64];
    for(const s of[-1,1]){
      limb(rd,pantsM,[s*0.12,0.4,-0.42],[s*0.2,0.13,0.12],0.1);
      limb(rd,pantsM,[s*0.2,0.13,0.12],[s*0.2,0.1,-0.72],0.085);
      box(0.15,0.1,0.34,blackM,s*0.2,0.08,-0.88,rd);
      limb(rd,suit,[s*0.24,0.6,0.34],[s*0.32,0.4,0.62],0.07);
      limb(rd,suit,[s*0.32,0.4,0.62],[s*0.14,0.34,0.88],0.06);
      ball(rd,lam(0x202428),[s*0.14,0.34,0.89],0.07);
    }
    limb(rd,vest,hip,sh,0.21);
    ball(rd,vest,[0,0.62,0.26],0.28,1.1,0.6,0.95);
    ball(rd,suit,[0,0.66,0.42],0.2,1.15,0.7,0.9);
    const bp=new THREE.Mesh(new THREE.PlaneGeometry(0.28,0.28),new THREE.MeshBasicMaterial({map:numTex(lane),side:DS}));bp.position.set(0,0.56,-0.1);bp.rotation.y=Math.PI;bp.rotation.x=-0.9;rd.add(bp);
    const helm=ball(rd,lam(hcol),hd,0.205,1,0.95,1.12);
    const visor=new THREE.Mesh(new THREE.SphereGeometry(0.21,10,6,Math.PI*0.25,Math.PI*0.5,Math.PI*0.3,Math.PI*0.22),lam(0x0c1118));visor.position.set(hd[0],hd[1]-0.02,hd[2]+0.03);rd.add(visor);
    const stripe=box(0.06,0.02,0.38,lam(lane===1||lane===5||lane===6?0x222222:0xffffff),0,hd[1]+0.2,hd[2]-0.02,rd);    const wheel=new THREE.Mesh(TORUS,blackM);wheel.position.set(0,0.4,0.9);wheel.rotation.x=Math.PI/2-0.5;rd.add(wheel);
    
    g.userData={inner,prop};
    return g;
  }
  const raceInfo=opts.live?{st:opts.live.st,kimarite:opts.live.kimarite}:{};
  let race=opts.live?createRiggedRace(opts.live.seed,opts.live.order,raceInfo):createRace();
  const boats=[];
  for(let i=1;i<=6;i++){const b=makeBoat(i);scene.add(b);boats.push(b)}

  // 航跡・水しぶき
  const NP=2200;const ppos=new Float32Array(NP*3),pvel=new Float32Array(NP*3),page=new Float32Array(NP).fill(99),psz=new Float32Array(NP);
  const pg=new THREE.BufferGeometry();pg.setAttribute('position',new THREE.BufferAttribute(ppos,3));pg.setAttribute('aAge',new THREE.BufferAttribute(page,1));pg.setAttribute('aSz',new THREE.BufferAttribute(psz,1));
  const pm=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uS:{value:1}},
    vertexShader:'attribute float aAge;attribute float aSz;varying float vA;uniform float uS;void main(){vA=clamp(1.0-aAge/2.6,0.0,1.0);vec4 mv=modelViewMatrix*vec4(position,1.0);gl_PointSize=aSz*uS*(260.0/-mv.z)*step(aAge,2.6);gl_Position=projectionMatrix*mv;}',
    fragmentShader:'varying float vA;void main(){vec2 c=gl_PointCoord-0.5;float d=length(c);if(d>0.5)discard;gl_FragColor=vec4(1.0,1.0,1.0,vA*0.75*(1.0-d*1.6));}'});
  const pts=new THREE.Points(pg,pm);pts.frustumCulled=false;scene.add(pts);
  let pi=0;
  function emit(x,y,z,vx,vy,vz,sz){const i=pi;pi=(pi+1)%NP;ppos[i*3]=x;ppos[i*3+1]=y;ppos[i*3+2]=z;pvel[i*3]=vx;pvel[i*3+1]=vy;pvel[i*3+2]=vz;page[i]=0;psz[i]=sz}

  {const st=document.createElement('style');st.textContent='@media (max-height:560px),(max-width:700px){#br-ov-bets,#br-ov-bets *{font-size:11px!important;line-height:1.35!important}#br-ov-bets{max-height:15vh!important;padding:3px 8px!important;opacity:.92}#br-ov-bets .card{margin:0!important;padding:2px 0!important;border:0!important;background:none!important}#br-ctl button{font-size:12px!important;padding:5px 9px!important;min-width:0!important}#br-ctl{padding:4px!important;gap:4px!important}#br-info{font-size:12px!important;padding:4px 8px!important;line-height:1.35!important}#br-od{font-size:11px!important;padding:3px 6px!important}#br-cm{font-size:14px!important;padding:3px 8px!important;top:40px!important}#br-big{font-size:28px!important}#br-top{padding:4px 8px!important}#br-top b{font-size:14px!important}#br-top button{font-size:13px!important;padding:5px 10px!important}#br-left{top:40px!important}}';ov.appendChild(st)}
  // HUD
  let camMode='auto',follow=0,speed=1;
  const mkBtn=(label,fn,extra)=>{const b=document.createElement('button');b.textContent=label;b.style.cssText='font-size:16px;padding:9px 12px;border:0;border-radius:9px;background:#fff3;color:#fff;backdrop-filter:blur(3px)'+(extra||'');b.addEventListener('click',fn);ctl.appendChild(b);return b};
  const camBtns={},camList=[['auto','オート'],['pit','ピット'],['stand','スタンド'],['turn1','1マーク'],['chase','追尾'],['bird','上空'],['onboard','艇上']];
  const hl=()=>{for(const k in camBtns)camBtns[k].style.background=k===camMode?'#3b82f6e0':'#fff3';folBtns.forEach((b,i)=>b.style.outline=i===follow?'2px solid #fff':'none')};
  for(const [k,l] of camList)camBtns[k]=mkBtn(l,()=>{camMode=k;hl()});
  const sep=document.createElement('div');sep.style.cssText='width:100%;height:0';ctl.appendChild(sep);
  const folBtns=[mkBtn('先頭',()=>{follow=0;hl()})];
  for(let i=1;i<=6;i++)folBtns.push(mkBtn(String(i),()=>{follow=i;hl()},`;background:${LANE_HEX[i-1]};color:${darkText(i)?'#000':'#fff'};min-width:40px;font-weight:700`));
  const sp=mkBtn('速度x1',()=>{speed=speed===1?2:speed===2?4:1;sp.textContent='速度x'+speed});
  mkBtn('🔄 もう一度',()=>restart());
  if(opts.live)for(const b of ov.querySelectorAll('button')){if(/\u901f\u5ea6x|\u3082\u3046\u4e00\u5ea6/.test(b.textContent))b.style.display='none'}
  hl();
  {const sk=/skip=(\d+)/.exec(location.hash),cm=/cam=(\w+)/.exec(location.hash);if(sk)for(let i=0;i<sk[1]*60;i++)race.step(1/60);if(cm){camMode=cm[1];hl()}}

  let alive=true;const aud=[],tms=[];
  const LOOP_VOL=0.4;   // ループ音は実況・レース曲より少し控えめ
  // ループ音: レース画面を開いた時点から結果表示まで、つなぎ目なしで鳴らし続ける(Web Audio)。
  // ピット離れのイントロ・レース曲はこれまでどおり、それぞれのタイミングで重ねて流す。
  let loopGain=null,loopStop=null;
  if(opts.live&&opts.live.sound&&opts.live.sound.loop){
    const url=opts.live.sound.loop,AC=window.AudioContext||window.webkitAudioContext;
    let ctx=null,src=null,fb=null;
    const fallback=()=>{if(fb||!alive||stopBgm.d)return;fb=new Audio(url);fb.loop=true;aud.push(fb);aud.loopEl=fb;applyVol();const p=fb.play();if(p)p.catch(()=>{})};
    loopStop=()=>{try{src&&src.stop()}catch(_){}try{ctx&&ctx.close()}catch(_){}src=null;ctx=null;if(fb){try{fb.pause()}catch(_){}}};
    (async()=>{
      await 0;   // applyVol などの定義が終わってから始める
      if(!AC)return fallback();
      try{
        ctx=new AC();loopGain=ctx.createGain();loopGain.connect(ctx.destination);applyVol();
        const ab=await ctx.decodeAudioData(await (await fetch(url)).arrayBuffer());
        if(!alive||stopBgm.d){loopStop();return}
        src=ctx.createBufferSource();src.buffer=ab;src.loop=true;src.connect(loopGain);src.start();
        if(ctx.state==='suspended')ctx.resume().catch(()=>{});
      }catch(e){console.warn('[boat race] loop audio',e);loopStop();loopGain=null;fallback()}
    })();
    for(const ev of ['pointerdown','touchend','click'])ov.addEventListener(ev,()=>{if(ctx&&ctx.state==='suspended')ctx.resume().catch(()=>{});if(fb&&fb.paused&&!stopBgm.d){const p=fb.play();if(p)p.catch(()=>{})}},{passive:true});
  }
  if(opts.live&&opts.live.sound&&(opts.live.sound.intro||opts.live.sound.bgm)){
    const L=opts.live,S=L.sound,nowS=()=>Date.now()+L.offset;
    const intro=S.intro?new Audio(S.intro):null,bgm=S.bgm?new Audio(S.bgm):null;
    let introDone=false;
    if(intro){intro.preload='auto';intro.loop=false;intro.addEventListener('ended',()=>{introDone=true});aud.push(intro)}
    if(bgm){bgm.preload='auto';bgm.loop=true;aud.push(bgm)}
    const pitMs=L.startMs;
    const startMs=L.startMs-T0*1000;
    let phase='none';
    // 音声の状態を画面左下に表示(原因調査用)。正常に再生できたら消える
    const note=document.createElement('div');note.style.cssText='position:absolute;left:8px;bottom:8px;z-index:30;padding:5px 9px;border-radius:8px;background:#000b;color:#ffd54a;font:12px sans-serif;display:none;pointer-events:none';ov.appendChild(note);
    const say=m=>{note.textContent=m||'';note.style.display=m?'block':'none'};
    for(const a of [intro,bgm])if(a)a.addEventListener('error',()=>say('音声読込エラー: '+decodeURIComponent(a.src.split('/').pop())+' (code '+(a.error&&a.error.code)+')'));
    function tryPlay(a){if(!a)return;
      let vol=NaN;try{vol=parseFloat(localStorage.getItem('brVol'))}catch(_){}
      const p=a.play();
      if(p)p.then(()=>say(vol===0?'🔇 音量が0です(音量スライダーを上げてください)':'')).catch(e=>{console.warn('[boat race] 音声再生が拒否されました。画面をタップしてください:',e);say('🔇 画面をタップすると音が出ます ('+(e&&e.name)+')')})}
    function syncSound(){
      if(!alive)return;
      const now=nowS();
      const next=now<pitMs?'none':now<startMs?'intro':'race';
      if(next===phase)return;
      phase=next;
      if(intro)intro.pause();if(bgm)bgm.pause();
      if(next==='intro'&&intro){
        // ピット離れの時点を音声0秒とする。再生済み部分は飛ばし、繰り返さない。
        const sec=Math.max(0,(now-pitMs)/1000);
        if(Number.isFinite(intro.duration)&&sec>=intro.duration)return;
        try{intro.currentTime=sec}catch(_){}
        tryPlay(intro);
      }else if(next==='race'&&bgm){
        const sec=Math.max(0,(now-startMs)/1000);
        try{bgm.currentTime=Number.isFinite(bgm.duration)&&bgm.duration>0?sec%bgm.duration:0}catch(_){}
        tryPlay(bgm);
      }
    }
    // 読み込みが間に合わなくても時刻に従って切り替える。
    syncSound();tms.push(setInterval(syncSound,100));
    for(const ev of ['pointerdown','touchend','click'])ov.addEventListener(ev,()=>{
      if(!alive)return;
      if(phase==='intro'&&intro&&intro.paused&&!introDone)tryPlay(intro);
      if(phase==='race'&&bgm&&bgm.paused)tryPlay(bgm);
    },{passive:true});
  }
  const getVol=()=>{const v=parseFloat(localStorage.getItem('brVol'));return isFinite(v)?Math.min(1,Math.max(0,v)):0.8};
  const applyVol=()=>{const v=getVol();aud.forEach(a=>{a.volume=a===aud.loopEl?v*LOOP_VOL:v});if(loopGain)loopGain.gain.value=v*LOOP_VOL;const s=ov.querySelector('#br-vol');if(s&&+s.value!==v)s.value=v};
  window.addEventListener('brvol',applyVol);applyVol();
  {const s=ov.querySelector('#br-vol');if(s)s.oninput=()=>{localStorage.setItem('brVol',s.value);window.dispatchEvent(new Event('brvol'))}}
  function stopBgm(){if(!stopBgm.d){stopBgm.d=1;if(loopStop)loopStop();aud.forEach(a=>{a.loop=false;try{a.pause()}catch(e){}})}}
  if(opts.live&&opts.live.bets){
    const bx=document.createElement('div');bx.id='br-ov-bets';bx.style.cssText='position:absolute;left:6px;right:6px;bottom:6px;max-height:24vh;overflow:auto;background:#000c;color:#fff;border-radius:10px;padding:6px 10px;font-size:14px;line-height:1.5;z-index:5;pointer-events:auto';
    bx.innerHTML='<b>\u307f\u3093\u306a\u306e\u6295\u7968</b> \u8aad\u307f\u8fbc\u307f\u4e2d...';ov.appendChild(bx);
    const ld=()=>{if(!bx.isConnected)return;Promise.resolve(opts.live.bets()).then(h=>{if(bx.isConnected&&h!=null)bx.innerHTML=h}).catch(()=>{})};
    const pos=()=>{bx.style.bottom=(ctl.offsetHeight+6)+'px'};pos();tms.push(setInterval(pos,500));window.addEventListener('resize',pos);ld();tms.push(setInterval(ld,10000));
  }
  function restart(){if(opts.live)return;race=createRace();res.style.display='none';big.textContent='';for(let p=0;p<NP;p++)page[p]=99;camPos.copy(PIT_CAM);camLook.copy(PIT_LOOK)}

  // カメラ制御
  // ピット正面(水面側)から6艇とゲートアーチを見る位置
  const PIT_CAM=new THREE.Vector3(PIT_X+22,6.5,(pitZ(0)+pitZ(5))/2+2),PIT_LOOK=new THREE.Vector3(PIT_X-9,3.6,(pitZ(0)+pitZ(5))/2);
  const camPos=PIT_CAM.clone(),camLook=PIT_LOOK.clone(),wantPos=new THREE.Vector3(),wantLook=new THREE.Vector3();
  const focusBoat=()=>race.boats[(follow||race.order[0])-1];
  function chooseAuto(fb){
    if(race.t<T0+7)return'pit';   // ピット離れの直後まではピット正面、その後はスタンド視点
    if(race.t<0)return'stand';
    if(race.done)return'stand';
    const a=(((fb.u)%PU)+PU)%PU,arc=Math.PI*R0;
    if(fb.u-US<0||a<L-70)return'stand';
    if(a<L+arc+30)return'turn1';
    if(a<2*L+arc-80)return'chase';
    if(fb.u-US>=(LAPS-1)*PU&&a>PU-60)return'stand';
    return'turn2';
  }
  function aim(mode,fb,dt){
    const bx=fb.x,bz=fb.z,hx=Math.sin(fb.hd),hz=Math.cos(fb.hd);
    switch(mode){
      case'pit':wantPos.copy(PIT_CAM);wantLook.copy(PIT_LOOK);break;
      case'formation':{
        const bs=race.boats, minX=Math.min(...bs.map(b=>b.x)),maxX=Math.max(...bs.map(b=>b.x));
        const minZ=Math.min(...bs.map(b=>b.z)),maxZ=Math.max(...bs.map(b=>b.z));
        const cx=(minX+maxX)/2,cz=(minZ+maxZ)/2;
        const span=Math.max(65,maxX-minX+42,(maxZ-minZ+20)*2.0);
        const height=Math.max(65,span/(2*Math.tan(cam.fov*Math.PI/360)*Math.max(.8,cam.aspect))*.8);
        wantPos.set(cx+6,height,cz+height*.23);wantLook.set(cx,.5,cz);break;}
      case'stand':{
        if(race.t<0){const bs=race.boats,gx=bs.reduce((a,b)=>a+b.x,0)/6,gz=bs.reduce((a,b)=>a+b.z,0)/6;wantPos.set(Math.max(-300,Math.min(80,gx-10)),10,66);wantLook.set(gx,1,gz)}
        else{const cx=Math.max(-120,Math.min(80,bx*0.75-8));wantPos.set(cx,9.5,66);wantLook.set(bx,1,bz)}
        break}
      case'turn1':wantPos.set(L/2+48,8,48);wantLook.set((bx+L/2)/2+4,1,bz*0.5);break;
      case'turn2':wantPos.set(-L/2-48,8,-PZ-8);wantLook.set((bx-L/2)/2-4,1,bz*0.5);break;
      case'chase':wantPos.set(bx-hx*9.5,3.6,bz-hz*9.5);wantLook.set(bx+hx*12,1,bz+hz*12);break;
      case'bird':{const d=Math.max(210,200/(Math.tan(cam.fov*Math.PI/360)*Math.max(cam.aspect,0.5)));wantPos.set(-15,d,34);wantLook.set(-15,0,0);break}
      case'onboard':wantPos.set(bx-hx*1.6,1.9,bz-hz*1.6);wantLook.set(bx+hx*14,1.0,bz+hz*14);break;
    }
    const k=mode==='onboard'?1:1-Math.exp(-dt*(mode==='chase'?5:3));
    camPos.lerp(wantPos,k);camLook.lerp(wantLook,mode==='onboard'?1:1-Math.exp(-dt*5));
  }

  function resize(){const w=window.innerWidth,h=window.innerHeight;renderer.setSize(w,h,false);cam.aspect=w/h;cam.fov=w/h<0.8?72:55;cam.updateProjectionMatrix()}
  resize();window.addEventListener('resize',resize);

  const fmt=t=>{const m=Math.floor(t/60),s=t-m*60;return String(m)+"'"+s.toFixed(1).padStart(4,'0')};
  const chip=ln=>`<span style="display:inline-block;width:18px;text-align:center;border-radius:4px;background:${LANE_HEX[ln-1]};color:${darkText(ln)?'#000':'#fff'};border:1px solid #fff8;font-weight:700">${ln}</span>`;
  function liveEnd(){stopBgm();const L2=opts.live;if(!res._req){res._req=1;L2.onDone&&L2.onDone()}big.textContent='';const h2=L2.html;if(h2){if(res.dataset.h!==h2){res.innerHTML=h2;res.dataset.h=h2}}else if(res.style.display==='none')res.innerHTML='\u7d50\u679c\u78ba\u5b9a\u4e2d...';res.style.display='grid';res.style.gridTemplateColumns='repeat(auto-fit,minmax(270px,1fr))';res.style.gap='4px 14px';res.style.alignItems='start';res.style.width='min(96vw,1020px)';res.style.maxHeight='78vh';res.style.overflow='auto';res.style.pointerEvents='auto'}
  const odEl=ov.querySelector('#br-od'),cmEl=ov.querySelector('#br-cm');
  if(opts.live&&opts.live.bets)cmEl.style.bottom='';
  function layoutCm(){const w=window.innerWidth>=760;
    if(w){cmEl.style.top='3px';cmEl.style.left='190px';cmEl.style.right='190px';cmEl.style.fontSize='22px';info.style.top='48px';odEl.style.top='48px'}
    else{cmEl.style.top='46px';cmEl.style.left='8px';cmEl.style.right='8px';cmEl.style.fontSize='17px';const t=opts.live?'104px':'48px';info.style.top=t;odEl.style.top=t}}
  layoutCm();window.addEventListener('resize',layoutCm);
  const cs={beat:{},q:[],last:{},pr:null,shownAt:0,lap:1,fin:0,t1:false,st:false,init:false};
  const nm=ln=>`${ln}号艇 ${PLAYERS[ln-1]}選手`;
  function say(k,text,gap){const n=race.t;if(cs.last[k]!==undefined&&n-cs.last[k]<gap)return;cs.last[k]=n;cs.q.push(text);if(cs.q.length>3)cs.q.shift()}
  // ピット離れ後の選手紹介。1〜6号艇を、待機位置への到着(-15秒)より前に紹介し終える
  const RAC=opts.racers||[],esc=x=>String(x==null?'':x).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const INTRO_OPEN=T0+4,INTRO_T=T0+10,INTRO_DT=6.5;   // -66秒: 導入、-60秒から6.5秒ずつ6人 → -21秒に終了
  function introLine(i){
    const r=RAC[i]||{},parts=[];
    if(r.branch)parts.push(esc(/支部$/.test(r.branch)?r.branch:r.branch+'支部'));
    if(r.grade)parts.push(esc(/級$/.test(r.grade)?r.grade:r.grade+'級'));
    parts.push(esc(r.name||PLAYERS[i])+'選手');
    return `${chip(i+1)} ${i+1}号艇　${parts.join('　')}${r.age?'、'+esc(r.age)+'歳':''}`;
  }
  function introComm(){
    const t=race.t;let h='';
    if(t>=INTRO_OPEN&&t<INTRO_T)h='各艇ピット離れ! 出走選手をご紹介します';
    else if(t>=INTRO_T&&t<INTRO_T+INTRO_DT*6)h=introLine(Math.floor((t-INTRO_T)/INTRO_DT));
    if(h){if(cmEl.dataset.h!==h){cmEl.innerHTML=h;cmEl.dataset.h=h}cmEl.style.display='block'}
    else if(cmEl.dataset.h){cmEl.dataset.h='';cmEl.style.display='none'}
  }
  function comm(){
    if(race.t<0){introComm();return}
    if(race.t<0.5||!race.crossedAll)return;
    const bs=race.boats,ord=race.order,lead=bs[ord[0]-1];
    if(!cs.init){cs.init=true;if(race.t>6){cs.st=true;cs.t1=!!race.t1;cs.lap=lead.lapNo;cs.fin=race.finishOrder.length}}
    if(!cs.st){cs.st=true;const d=bs.map(b=>b.delay),f=d.indexOf(Math.min(...d))+1,s=d.indexOf(Math.max(...d))+1;
      say('st',`スタート! ${nm(f)}、スタート踏み込んだ!${d[s-1]>0.3?` ${nm(s)}は出遅れ!`:` ${nm(s)}はやや遅れた!`}`,0)}
    if(race.t1&&!cs.t1){cs.t1=true;const w=ord[0],b=bs[w-1];
      const kind=({nige:'逃げた',sashi:'差した',makuri:'まくった',mzashi:'まくり差した'})[w===1?'nige':race.k1]||'先行した';
      say('t1',`第1ターンマーク! ${nm(w)}、${kind}! ${w===1?'1号艇が先頭で逃げ切り態勢!':'先頭に立った!'} 2番手は${ord[1]}号艇、3番手${ord[2]}号艇!`,0)}
    if(race.t1){
      if(cs.pr){
        for(let i=0;i<3;i++){const a=ord[i],pa=cs.pr[a];
          if(pa!==undefined&&pa>i+1){const x=ord[i+1];
            const tc=bs[a-1].tac,key='o'+a+'_'+x;
            const T={sashi:['内を鋭く差した!','差された'],mzashi:['間を割って、まくり差し!','差された'],makuri:['外から豪快にまくった!','まくられた'],tsuke:['つけまいで抜いた!','かわされた']}[tc];
            const bt=cs.beat[x+'>'+a],back=bt!=null&&race.t-bt>4;cs.beat[a+'>'+x]=race.t;delete cs.beat[x+'>'+a];   // 4秒以上前に抜かれた相手を抜いたら「抜き返し」
            if(back)say(key,`${nm(a)}、${T?T[0].replace(/!$/,'')+'で':''}抜き返した! ${i+1}番手を取り戻す!`,6);
            else if(T)say(key,`${nm(a)}、${T[0]} ${nm(x)}は${T[1]}! ${i+1}番手に浮上!`,6);
            else say(key,`${nm(a)}、直線で抜いた! ${nm(x)}は抜かれた! ${i+1}番手に上がる!`,6)}}
      }
      for(let i=0;i<3;i++){const u=bs[ord[i]-1].u-bs[ord[i+1]-1].u;
        if(u<5&&!bs[ord[i]-1].finished)say('d'+i,`${i+1}着争い! ${ord[i]}号艇と${ord[i+1]}号艇、並んでいる! 熱い戦い!`,14)}
    }
    if(lead.lapNo>cs.lap){cs.lap=lead.lapNo;say('lap',cs.lap>=3?`最終周回! 先頭は${nm(ord[0])}、後続が追う!`:`${cs.lap}周目に入る! 先頭は${nm(ord[0])}!`,0)}
    if(race.finishOrder.length>cs.fin){cs.fin=race.finishOrder.length;const w=race.finishOrder[cs.fin-1];
      say('f'+cs.fin,cs.fin===1?`ゴール! ${nm(w)}、1着! ${race.kimarite}で決めた!`:`${cs.fin}着は${nm(w)}!`,0)}
    cs.pr={};ord.forEach((ln,i)=>{cs.pr[ln]=i+1});
    const nowMs=performance.now();
    if(cs.q.length&&nowMs-cs.shownAt>2800){cmEl.textContent=cs.q.shift();cmEl.style.display='block';cs.shownAt=nowMs}
    else if(cmEl.style.display==='block'&&!cs.q.length&&nowMs-cs.shownAt>6500)cmEl.style.display='none';
  }
  function hud(){
    const bs=race.boats,ord=race.order;
    let h=race.t<0?`<b>スタートまで ${Math.ceil(-race.t)}</b>`:`<b>${fmt(Math.max(0,race.t))}</b>　周回 ${Math.min(LAPS,bs[ord[0]-1].lapNo)}/${LAPS}`;
    ord.forEach((ln,i)=>{const b=bs[ln-1];h+=`<div>${chip(ln)} ${i+1}位 ${b.finished?'🏁':Math.round(b.v*3.6)+'km/h'}</div>`});
    info.innerHTML=h;
    if(opts.live)comm();
    {const o=opts.live&&opts.live.odds,lp=bs[ord[0]-1].lapNo;
      if(o&&race.t>=0&&lp>=2&&!race.done){const k=ord[0]+'-'+ord[1]+'-'+ord[2];odEl.innerHTML=`<div style="opacity:.8">現在の予想(3連単)</div>${chip(ord[0])}-${chip(ord[1])}-${chip(ord[2])} <b style="color:#ffd54a;font-size:15px">${o[k]!=null?o[k].toFixed(1)+'倍':'--'}</b>`;odEl.style.display='block'}
      else odEl.style.display='none'}
    if(race.t<0&&race.t>-6)big.textContent=Math.ceil(-race.t);
    else if(race.t>=0&&race.t<1.8)big.textContent='スタート!';
    else if(!race.done)big.textContent='';
    if(opts.live&&race.done&&race.t>race.endT+3){liveEnd()}else if(race.done&&res.style.display==='none'&&race.t>race.endT+3){
      let r=`<b style="font-size:17px">🏁 結果　決まり手: ${race.kimarite}</b><br>`;
      race.finishOrder.forEach((ln,i)=>{r+=`${i+1}着 ${chip(ln)} ${PLAYERS[ln-1]}　${fmt(race.boats[ln-1].fin)}<br>`});
      res.innerHTML=r;res.style.display='block';big.textContent=''
    }
  }
  function drawBoard(){
    const g=bgx,W=1024;g.fillStyle='#040a16';g.fillRect(0,0,W,480);
    const hg=g.createLinearGradient(0,0,W,0);hg.addColorStop(0,'#0b4fb0');hg.addColorStop(1,'#1d8ae0');g.fillStyle=hg;g.fillRect(0,0,W,66);
    g.fillStyle='#fff';g.font='bold 38px sans-serif';g.textBaseline='middle';g.textAlign='left';g.fillText('ちいかわ水上競技場　'+raceNo+'R　'+raceName,22,36);
    g.textAlign='right';g.fillStyle='#ffe14a';
    g.fillText(race.t<0?(race.t>-15?`スタートまで ${Math.ceil(-race.t)}秒`:'出走準備中'):race.done?'結果確定':`${Math.min(LAPS,race.boats[race.order[0]-1].lapNo)}周目 / ${LAPS}周`,W-22,36);
    const list=race.t<0?[1,2,3,4,5,6]:race.done?race.finishOrder:race.order;
    g.textAlign='left';
    list.forEach((ln,i)=>{
      const y=80+i*58,b=race.boats[ln-1];
      g.fillStyle=i%2?'#0a1424':'#0e1b31';g.fillRect(14,y,W-28,52);
      g.fillStyle='#ffb21e';g.font='bold 34px sans-serif';g.fillText(race.t<0?`${i+1}枠`:`${i+1}位`,28,y+27);
      g.fillStyle=LANE_HEX[ln-1];g.fillRect(150,y+6,52,40);g.fillStyle=darkText(ln)?'#111':'#fff';g.font='bold 32px sans-serif';g.textAlign='center';g.fillText(String(ln),176,y+28);
      g.textAlign='left';g.fillStyle='#fff';g.font='bold 34px sans-serif';g.fillText(PLAYERS[ln-1],230,y+27);
      g.textAlign='right';g.fillStyle='#8fe3ff';g.font='bold 30px sans-serif';
      g.fillText(race.t<0?(ln>3?'ダッシュ':'スロー'):b.finished?fmt(b.fin):Math.round(b.v*3.6)+' km/h',W-28,y+27);g.textAlign='left';
    });
    if(race.done){g.fillStyle='#ffe14a';g.font='bold 36px sans-serif';g.fillText('決まり手　'+race.kimarite,28,448)}
    btex.needsUpdate=true;
  }

  let raf=0,last=performance.now(),acc=0,T=0,hudT=0,boardT=0,towerT=0;
  const SUBDT=1/60;
  function frame(now){
    if(!alive)return;raf=requestAnimationFrame(frame);
    const dt=Math.min(0.1,(now-last)/1000);last=now;T+=dt;
    let n=0;if(opts.live){const tg=T0+(Date.now()+opts.live.offset-opts.live.startMs)/1000;while(race.t<tg-1e-6&&n<1500&&!(race.done&&race.t>race.endT+6)){race.step(SUBDT);n++}}else{acc+=dt*speed;while(acc>=SUBDT&&n<12){race.step(SUBDT);acc-=SUBDT;n++}}
    wmat.uniforms.uT.value=T;
    for(let i=0;i<6;i++){
      const b=race.boats[i],m=boats[i];
      const y=wh(b.x,b.z,T);
      const fx=Math.sin(b.hd),fz=Math.cos(b.hd);
      const slope=(wh(b.x+fx*2,b.z+fz*2,T)-wh(b.x-fx*2,b.z-fz*2,T))/4;
      m.position.set(b.x,y*0.9+0.05,b.z);m.rotation.set(0,b.hd,0,'YXZ');
      const sf=Math.min(1,b.v/22);
      m.userData.inner.rotation.set(-0.1*sf-slope*1.2,0,b.bank+Math.sin(T*2.3+i)*0.015);
      m.userData.prop.rotation.z=T*(b.v>1?30:2);
      if(b.v>6){
        const sx=b.x-fx*2.7,sz=b.z-fz*2.7,k=Math.min(1,b.v/20);
        for(let j=0;j<3;j++){const sd=(Math.random()-0.5)*0.5;emit(sx+(Math.random()-0.5)*0.6,y+0.12,sz+(Math.random()-0.5)*0.6,-fz*sd*3-fx*1.5*k,0.4+Math.random()*2.6*k,fx*sd*3-fz*1.5*k,0.7+Math.random()*0.9)}
        const lx=-fz,lz=fx;
        for(const s of[-1,1])emit(b.x+fx*1.4+lx*s*0.7,y+0.1,b.z+fz*1.4+lz*s*0.7,lx*s*(1+k*1.3),0.6*k+Math.random()*0.5,lz*s*(1+k*1.3),0.6+Math.random()*0.5);
      }
    }
    for(let i=0;i<NP;i++){if(page[i]>=2.6)continue;page[i]+=dt;const o=i*3;
      pvel[o+1]-=9*dt*(pvel[o+1]>0||ppos[o+1]>0.15?1:0);ppos[o]+=pvel[o]*dt;ppos[o+1]=Math.max(0.12,ppos[o+1]+pvel[o+1]*dt);ppos[o+2]+=pvel[o+2]*dt;
      if(ppos[o+1]<=0.121){pvel[o]*=0.9;pvel[o+2]*=0.9;pvel[o+1]=0}}
    pg.attributes.position.needsUpdate=true;pg.attributes.aAge.needsUpdate=true;pg.attributes.aSz.needsUpdate=true;
    marks.forEach((m,i)=>{m.position.y=1.0+wh(m.position.x,0,T)*0.9;m.rotation.z=Math.sin(T*1.1+i)*0.04});
    flyMat.opacity=0.8+0.15*Math.sin(T*8);
    const fb=focusBoat();
    let mode=camMode==='auto'?chooseAuto(fb):camMode;
    aim(mode,fb,dt);
    cam.position.copy(camPos);cam.lookAt(camLook);
    if(mode==='onboard')cam.rotateZ(-fb.bank*0.6);
    wmat.uniforms.uCam.value.copy(cam.position);
    pm.uniforms.uS.value=cv.clientHeight/700;
    // スタートまでの残り時間(スタートラインを全艇が過ぎたら消す)
    const showClk=race.t>-15&&!race.crossedAll;
    if(race.crossedAll&&startLabels[0].visible)for(const l of startLabels)l.visible=false;else if(!race.crossedAll&&!startLabels[0].visible)for(const l of startLabels)l.visible=true;
    if(showClk){clkC.style.display='block';drawDial(clkG,240,-race.t)}else if(clkC.style.display!=='none')clkC.style.display='none';
    towerT+=dt;if(towerT>0.1){towerT=0;drawDial(towerG,256,showClk||race.t<0?-race.t:0);towerTex.needsUpdate=true}
    boardT+=dt;if(boardT>0.25){boardT=0;drawBoard()}
    hudT+=dt;if(hudT>0.12){hudT=0;hud()}
    renderer.render(scene,cam);
  }
  function close(){
    alive=false;if(loopStop)loopStop();cancelAnimationFrame(raf);tms.forEach(x=>{clearTimeout(x);clearInterval(x)});aud.forEach(a=>{a.loop=false;try{a.pause();a.removeAttribute('src');a.load()}catch(e){}});window.removeEventListener('resize',resize);window.removeEventListener('brvol',applyVol);
    scene.traverse(o=>{if(o.geometry)o.geometry.dispose();const m=o.material;if(m)(Array.isArray(m)?m:[m]).forEach(x=>{if(x.map)x.map.dispose();x.dispose()})});
    renderer.dispose();try{renderer.forceContextLoss()}catch(e){}
    ov.remove();
  }
  ov.querySelector('#br-close').addEventListener('click',close);
  drawBoard();
  raf=requestAnimationFrame(frame);
  return{close};
}
