const $ = s => document.querySelector(s);
const BASE = '/casino';
const BOAT_MODE = new URLSearchParams(location.search).get('view') === 'boat';
let socket = null, me = null, ready = false;

function status(message, error = false) {
  for (const id of ['#casino-status', '#boat-status']) { const el = $(id); if (el) { el.textContent = message || ''; el.style.color = error ? '#ff9ca9' : '#ffd783'; } }
}
function setPoints(n) {
  const text = Number(n || 0).toLocaleString() + ' pt';
  $('#casino-points').textContent = text; $('#boat-points').textContent = text;
}
function send(data) {
  if (!socket || socket.readyState !== WebSocket.OPEN) return false;
  socket.send(JSON.stringify(data)); return true;
}
window.__tsBrSend = send;

function connect(session) {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  socket = new WebSocket(`${proto}://${location.host}${BASE}/ws?s=${encodeURIComponent(session)}`);
  socket.onopen = () => { ready = true; status(''); };
  socket.onclose = () => { ready = false; status('接続が切れました。画面を開き直してください', true); };
  socket.onmessage = ev => {
    let m; try { m = JSON.parse(ev.data); } catch { return; }
    if (m.type === 'welcome') { setPoints(m.points); window.__tsSlotAdmin = !!m.slot_admin; document.documentElement.classList.toggle('ts-slot-admin', !!m.slot_admin); }
    if ((m.type === 'roulette_state' || m.type === 'baccarat_state') && Array.isArray(m.players)) {
      const mine = m.players.find(p => p.seat === m.me); if (mine) setPoints(mine.balance);
    }
    if (m.type === 'br_my' && m.data?.balance !== undefined) setPoints(m.data.balance);
    if (m.type?.startsWith('roulette_')) window.dispatchEvent(new CustomEvent('ts:roulette', { detail: m }));
    if (m.type?.startsWith('baccarat_')) window.dispatchEvent(new CustomEvent('ts:baccarat', { detail: m }));
    if (m.type?.startsWith('br_') || ['br_list','br_race','br_racer','br_bet','br_my','br_results'].includes(m.type)) window.dispatchEvent(new CustomEvent('ts:br', { detail: m }));
    if (m.type === 'pachi_medal_state') { window.dispatchEvent(new CustomEvent('pachi:medal-state', { detail: m })); if (m.points !== undefined) setPoints(m.points); }
    if (m.type === 'pachi_medal_result') window.dispatchEvent(new CustomEvent('pachi:medal-result', { detail: m }));
    if (m.type === 'pachi_round_begin_result') window.dispatchEvent(new CustomEvent('pachi:round-begin-result', { detail: m }));
    if (m.type === 'pachi_round_settle_result') window.dispatchEvent(new CustomEvent('pachi:round-settle-result', { detail: m }));
    if (m.type === 'pachi_at_resume_bet_result') window.dispatchEvent(new CustomEvent('pachi:at-resume-bet-result', { detail: m }));
    if (m.type === 'pachi_round_error') window.dispatchEvent(new CustomEvent('pachi:round-error', { detail: m }));
    if (m.type === 'notice') status(m.message, true);
  };
}

async function login() {
  let hub = null; try { hub = JSON.parse(sessionStorage.getItem('tsHub') || 'null'); } catch {}
  if (!hub?.access_token) { status('TalkSurvivor online のCONTENTSから開いてください', true); return; }
  const instanceId = new URLSearchParams(location.search).get('instance_id') || hub.instanceId;
  try {
    const r = await fetch(`${BASE}/api/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ access_token: hub.access_token, instanceId }) });
    const j = await r.json(); if (!r.ok) throw new Error(j.error || j.detail || 'ログインできませんでした');
    me = j.me; $('#casino-name').textContent = me.name; $('#boat-name').textContent = me.name; setPoints(j.points); connect(j.session);
  } catch (e) { status(e.message, true); }
}

for (const b of document.querySelectorAll('[data-back]')) b.onclick = () => { location.href = '/' + location.search.replace(/^\?/, '?'); };
document.querySelector('[data-game="roulette"]').onclick = async () => { if (!ready) return status('接続中です…'); const m = await import('/casino/static/roulette_ui.js?v=1'); m.openRoulette(); };
document.querySelector('[data-game="baccarat"]').onclick = async () => { if (!ready) return status('接続中です…'); const m = await import('/casino/static/baccarat_ui.js?v=1'); m.openBaccarat(); };
document.querySelector('[data-game="poker"]').onclick = () => {
  const q = new URLSearchParams(location.search); q.delete('view'); q.set('casino', 'poker');
  location.href = '/party/?' + q.toString();
};
$('#open-boat').onclick = async () => { if (!ready) return status('接続中です…'); const m = await import('/casino/static/boatrace_ui.js?v=1'); m.openBoatLeague(); };

window.addEventListener('pachi:medal-action', e => { const d = e.detail || {}; send({ type: 'pachi_medal_action', action: d.action, amount: d.amount, op_id: d.op_id || crypto.randomUUID() }); });
window.addEventListener('pachi:medal-refresh', () => send({ type: 'pachi_medal_state' }));
window.addEventListener('pachi:round-begin', e => send({ type: 'pachi_round_begin', debug_force_role: e.detail?.debug_force_role || null }));
window.addEventListener('pachi:round-settle', e => send({ type: 'pachi_round_settle', ...e.detail }));
window.addEventListener('pachi:round-abort', e => send({ type: 'pachi_round_abort', round_id: e.detail?.round_id || null }));
window.addEventListener('pachi:at-resume-bet', () => send({ type: 'pachi_at_resume_bet' }));

const bgm = $('#casino-bgm'), vol = $('#casino-volume'), out = document.querySelector('.volume output');
function applyVolume() { bgm.volume = Number(vol.value) / 100; out.value = vol.value + '%'; localStorage.setItem('casinoVolume', vol.value); }
vol.value = localStorage.getItem('casinoVolume') || '45'; applyVolume(); vol.oninput = applyVolume;
const unlock = () => { if (!BOAT_MODE) bgm.play().catch(() => {}); document.removeEventListener('pointerdown', unlock); document.removeEventListener('keydown', unlock); };
document.addEventListener('pointerdown', unlock); document.addEventListener('keydown', unlock);

// Imported games create a full-screen root of their own. Pause the lobby loop
// while one is open so it never doubles the table/slot music.
const gameAudioState = () => {
  const open = $('#rl-root') || $('#bc-root') || $('#brui') || !$('#ts-pachi-fullscreen-v10').hidden;
  if (open || BOAT_MODE) bgm.pause(); else if (document.hasFocus()) bgm.play().catch(() => {});
};
new MutationObserver(gameAudioState).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden'] });

if (BOAT_MODE) { $('#casino-app').hidden = true; $('#boat-home').hidden = false; document.title = 'TalkSurvivor Boat Race'; }
login();
