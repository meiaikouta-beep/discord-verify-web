// 競艇テスト用レースシミュレーション(単位: m, 秒)。描画に依存しない純粋ロジック。
export const L=240,R0=20,START_X=50,US=START_X+120,LAPS=3,T0=-70; // US=スタートラインの周回座標(START_X+L/2)
export const BOW=2.9;
export const PIT_X=-284,V0=8,VL=20.6,CENTER_X=-44,CENTER_Z=0;
export const RUN=[118,122,126,150,156,162]; // 待機位置からスタートラインまでの距離(1-3号艇=スロー, 4-6号艇=ダッシュ)
export const VMAX=21,VC_RATIO=0.25,T_WAIT_END=-10,V_WAIT=0.8,T_ARRIVE=-15; // -15秒に待機位置へ到着、-10秒まで約5秒待機、そこから10秒でスタートラインへ
export const PU=2*L+2*Math.PI*R0;
export const COLORS=[0xffffff,0x222222,0xe02020,0x2050e0,0xf0d020,0x20a040];
export const NAMES=['白','黒','赤','青','黄','緑'];
export const pitZ=i=>6+i*5.6, startZ=i=>14+3.6*i;
const sstep=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function mulberry(seed){let a=seed>>>0;return()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
function gauss(rnd){let u=0;for(let i=0;i<4;i++)u+=rnd();return(u-2)*1.73}

export function pathPos(u,r,out){
  const a=((u%PU)+PU)%PU,arc=Math.PI*R0;
  if(a<L){out.x=-L/2+a;out.z=r}
  else if(a<L+arc){const th=(a-L)/arc*Math.PI;out.x=L/2+r*Math.sin(th);out.z=r*Math.cos(th)}
  else if(a<2*L+arc){out.x=L/2-(a-L-arc);out.z=-r}
  else{const th=(a-2*L-arc)/arc*Math.PI;out.x=-L/2-r*Math.sin(th);out.z=-r*Math.cos(th)}
  return out;
}
// 旋回ブレンド。exitLenを長くすると旋回後の膨らみ(外側への移動)がゆるやかになる
function blend(u,exitLen){
  const a=((u%PU)+PU)%PU,arc=Math.PI*R0;
  const seg=(s,e)=>sstep((a-(s-40))/40)*(1-sstep((a-e)/exitLen));
  return Math.max(seg(L,L+arc),seg(2*L+arc,2*L+2*arc));
}
// ================= レース本体の演出(着順はサーバーが決定し、映像はその結果に合わせて組み立てる) =================
// 仕組み: 基準艇(ペース)の軌跡を全艇が「時間差τ」で追いかける。τの小さい艇ほど前。
// τを旋回の進入・頂点・出口でキーフレーム指定すると、順位の入れ替わり(抜き)がその区間で起こる。
// 旋回半径 rE(進入)/rA(頂点)/rX(出口) を艇ごとに変え、マーク際を回る艇・外を回る艇・流れる艇を作る。
// ================= レース本体の演出(着順はサーバーが決定し、映像はその結果に合わせて組み立てる) =================
// 仕組み: 基準艇(ペース: マーク際を回る理想の艇)の軌跡を、全艇が「時間差τ」で追いかける。τの小さい艇ほど前。
//  τ = 順位の段取り(キーフレーム) + その艇の航跡で自然に生じる遅れG。外を回る艇ほどGが増え、内を回る艇は詰める。
//  旋回半径 rE(進入)/rA(頂点)/rX(出口) を艇ごとに変え、マーク際ギリギリ・外を回る・流れる(マークを外す)を作る。
const ARC=Math.PI*R0,HALF=PU/2,NTURN=LAPS*2,VS=21.6,KP=3.2;
const RP=8,RMIN=6.2,VT0=14.2;               // RP=基準艇の旋回半径(マーク際), RMIN=これより内には入れない
const inArcA=a=>(a>=L&&a<L+ARC)||a>=2*L+ARC;
const tStart=k=>L+(k-1)*HALF;               // 第k旋回(1〜6)の円弧が始まる周回座標u
const turnOf=u=>Math.min(NTURN,Math.max(1,Math.floor((u-L+140)/HALF)+1));
const KF_E=-0.7,KF_M=0.45,KF_X=1.3;          // 旋回中のキーフレーム位置(円弧長に対する割合)
const UFIN=US+LAPS*PU;
const vTurn=r=>VT0+0.35*(r-RP);              // 旋回中の自然な速さ(外ほどわずかに速いが、距離が長いぶん遅れる)
function natRate(U,r,vs){const a=((U%PU)+PU)%PU,f=blend(U,25),v=(1-f)*(vs||VS)+f*vTurn(r);return v/(inArcA(a)?Math.max(r,RMIN)/R0:1)}
const PACE=(()=>{const dt=1/60,n=60*220,U=new Float64Array(n),V=new Float64Array(n);let u=US;
  for(let i=0;i<n;i++){const t=i*dt,rate=natRate(u,RP,VL+(VS-VL)*Math.min(1,t/3));U[i]=u;V[i]=rate;u+=rate*dt}
  return{U,V,dt,n}})();
function paceAt(t){
  if(t<=0)return[US+VL*t,VL];
  const x=t/PACE.dt;if(x>=PACE.n-1){const i=PACE.n-1;return[PACE.U[i]+PACE.V[i]*(t-i*PACE.dt),PACE.V[i]]}
  const i=Math.floor(x),q=x-i;return[PACE.U[i]+(PACE.U[i+1]-PACE.U[i])*q,PACE.V[i]+(PACE.V[i+1]-PACE.V[i])*q];
}
// 旋回計画TRに沿った、周回座標uでの目標旋回半径
function radiusAt(TR,lane,Sz,u){
  const k=turnOf(u),tr=TR[k][lane],tph=(u-tStart(k))/ARC,xa=tr.xA;
  const rp=tph<=0?tr.rE:tph<xa?tr.rE+(tr.rA-tr.rE)*sstep(tph/xa):tph<1?tr.rA+(tr.rX-tr.rA)*sstep((tph-xa)/(1-xa)):tr.rX;
  let c=0;for(let j=1;j<=NTURN;j++)if(u>tStart(j)+ARC)c=j;
  const rS=c?TR[c][lane].rS:Sz,fr=blend(u,100);
  return(1-fr)*rS+fr*rp;
}
const G0=US-20,GS=0.5,GN=Math.ceil((UFIN+200-G0)/GS);
// 出口速度の差(m/s)。外から入ってイン側に切れ込む(rE>rX)と速く、インから回って膨らむ(rX>rA)と遅い
const exitDv=tr=>Math.max(-2.4,Math.min(1.6,0.2*(tr.rE-tr.rX)-0.12*Math.max(0,tr.rX-tr.rA-2.5)));
function buildG(TR,lane,Sz){const g=new Float32Array(GN);let acc=0;
  for(let i=0;i<GN;i++){const U=G0+i*GS;g[i]=acc;if(U>=US){const r=radiusAt(TR,lane,Sz,U);
    let vs=VS,c=0;for(let j=1;j<=NTURN;j++)if(U>tStart(j)+ARC)c=j;
    if(c){const du=U-(tStart(c)+ARC);vs=VS+exitDv(TR[c][lane])*(1-sstep(du/120))}   // 出口速度の差は直線の約120mで消える
    acc+=GS*(1/natRate(U,r,vs)-1/natRate(U,RP))}}
  return g}
function gAt(g,U){const x=(U-G0)/GS;if(x<=0)return 0;const i=Math.min(GN-2,Math.floor(x)),q=Math.min(1,x-i);return g[i]+(g[i+1]-g[i])*q}
export const KIM_JP={nige:'逃げ',sashi:'差し',makuri:'まくり',mzashi:'まくり差し',nuki:'抜き'};
const KIM_EN={'逃げ':'nige','差し':'sashi','まくり':'makuri','まくり差し':'mzashi','抜き':'nuki','恵まれ':'nuki'};
// サーバーから決まり手が来ないとき(テスト等)の決まり手。1着艇の枠で確率を変える
function pickKim(w,q){
  if(w===1)return'nige';
  const T={2:[['sashi',.6],['makuri',.28],['nuki',.12]],3:[['makuri',.42],['mzashi',.38],['sashi',.12],['nuki',.08]],
    4:[['makuri',.44],['mzashi',.3],['sashi',.14],['nuki',.12]],5:[['mzashi',.42],['makuri',.34],['nuki',.24]],6:[['mzashi',.38],['makuri',.32],['nuki',.3]]}[w];
  let a=0;for(const [k,p] of T){a+=p;if(q<a)return k}return T[0][0];
}
const rankMap=arr=>{const m={};arr.forEach((l,i)=>m[l]=i);return m};
const moveTo=(arr,l,pos)=>{const a=arr.filter(x=>x!==l);a.splice(pos,0,l);return a};
function bubble(a,b){a=a.slice();const out=[],pos=l=>b.indexOf(l);
  for(let n=0;n<40;n++){let done=true;for(let i=0;i<5;i++)if(pos(a[i])>pos(a[i+1])){out.push(i);[a[i],a[i+1]]=[a[i+1],a[i]];done=false}if(done)break}
  return out}
// 予定の順位orderを守りつつ、自然な遅れnatにできるだけ近い時間差を作る。gap(前の艇,この艇)=[最小差,固定するか]
function chain(order,nat,gap,gmax){
  const T={};let prev=null;const lead=Math.min(...order.map(l=>nat[l]));
  for(const l of order){
    if(prev==null)T[l]=lead;
    else{const [gmin,fix]=gap(prev,l),lo=T[prev]+gmin;T[l]=fix===true?lo:Math.max(lo,Math.min(nat[l],T[prev]+(fix||gmax)))}
    prev=l}
  return T}

// ================= 線取りの個性化 =================
// 旧: 半径が「順位の入れ子」(例: 8.8+0.7*順位)で、全員がほぼ同じ弧・同じ直線を通っていた。
// 新: 抜き/抜かれに関わらない艇は、旋回ごとに次の型から選び、進入→頂点→出口を一続きの軌跡として決める。
//   HOLD   標準           IN_OUT インから回りすぎて膨らむ(距離は短いが出口が遅い)
//   OUT_IN 外から内へ切れ込む(距離が縮み出口が速い)   WIDE 大回り(距離が伸びる)
// 抜き/抜かれの艇(pairs)の半径は崩さず、艇どうしの最小間隔だけ外側へ押して確保する。
const RMAXL=24,GAPL=2.2,BIAS=1.3;
function spreadLines(TR,TURN,rnd,lanes){
  const jit=s=>(rnd()-0.5)*s,rg=(a,b)=>a+rnd()*(b-a);
  const STY={
    HOLD:  (re)=>({rE:rg(9.6,12.8),rA:rg(7.6,10.2),rX:rg(8.8,12.6)}),
    IN_OUT:()=>{const rA=rg(RMIN+0.2,RMIN+1.0);return{rE:rg(7.0,9.2),rA,rX:rA+rg(3.5,6.5)}},
    OUT_IN:()=>({rE:rg(12.5,16.5),rA:rg(RMIN+0.6,RMIN+2.0),rX:rg(7.2,9.0)}),
    WIDE:  ()=>{const rA=rg(10.5,14.5);return{rE:rg(10.5,15.0),rA,rX:rA+rg(0,3.0)}}
  };
  const pick=top=>{const v=rnd(),w=top?[.45,.35,.10,.10]:[.30,.15,.30,.25];
    return v<w[0]?'HOLD':v<w[0]+w[1]?'IN_OUT':v<w[0]+w[1]+w[2]?'OUT_IN':'WIDE'};
  // 近くを走る(順位が2つ以内)艇どうしの間隔を確保。anchor(抜き関係の艇・既に決めた艇)は動かさず、新しい艇を外側/内側へずらす
  const settle=(vals,order,movable,key,lo)=>{
    const rk=rankMap(order),placed=lanes.filter(l=>!movable[l]);
    const ok=(l,r)=>placed.every(m=>Math.abs(rk[m]-rk[l])>2||Math.abs(vals[m][key]-r)>=GAPL);
    for(const l of order.filter(x=>movable[x])){
      let r=Math.max(lo,Math.min(RMAXL,vals[l][key])),best=r,done=ok(l,r);
      for(let d=0.4;!done&&d<14;d+=0.4)for(const s of[1,-1]){const c=r+s*d;if(c<lo||c>RMAXL)continue;if(ok(l,c)){best=c;done=true;break}}
      vals[l][key]=best;placed.push(l)}
  };
  for(let k=1;k<=NTURN;k++){
    const S=TURN[k],T=TR[k];
    const inv={};lanes.forEach(l=>inv[l]=false);
    if(k===1){const e=rankMap(S.ent),m=rankMap(S.mid),x=rankMap(S.ex);lanes.forEach(l=>{inv[l]=e[l]!==m[l]||m[l]!==x[l]||T[l].tac!==''})}
    else S.pairs.forEach(p=>{inv[p.P]=true;inv[p.Q]=true});
    const mov={};lanes.forEach(l=>{mov[l]=!inv[l]});
    const xr=rankMap(S.ex);
    for(const l of lanes){if(inv[l])continue;
      const top=xr[l]===0,st=STY[pick(top)](),t=T[l];
      const bias=BIAS*xr[l];                                       // 前の艇は内、後ろの艇は外寄り(ただし型しだいで逆転する)
      if(k>1)t.rE=st.rE+bias+jit(0.8);                            // 第1ターンの進入は枠なりのまま
      t.rA=Math.max(RMIN+0.2,st.rA+bias*0.8+jit(0.6));t.rX=Math.max(RMIN+0.6,st.rX+bias+jit(0.8));
      if(k===1&&t.rA>t.rE)t.rA=Math.max(RMIN+0.2,t.rE-0.5)}
    settle(T,S.ent,mov,'rE',RMIN+0.8);settle(T,S.mid,mov,'rA',RMIN+0.2);settle(T,S.ex,mov,'rX',RMIN+0.6);
  }
  // 直線の横位置: 出口の線と次の進入の線の間(次に外から攻める艇・内を差す艇は早めに自分の進入線へ)
  for(let k=1;k<=NTURN;k++){
    const S=TURN[k],T=TR[k],N=k<NTURN?TR[k+1]:null,inv={};lanes.forEach(l=>inv[l]=false);
    const nxt=k<NTURN?TURN[k+1].pairs:[];nxt.forEach(p=>{inv[p.P]=true;inv[p.Q]=true});
    for(const l of lanes){
      if(!N){T[l].rS=T[l].rX+jit(3.0);continue}
      const a=inv[l]?0.8:rg(0.35,0.7);T[l].rS=T[l].rX*(1-a)+N[l].rE*a+jit(inv[l]?0.4:2.0)}
    const mov={};lanes.forEach(l=>mov[l]=!inv[l]);
    settle(T,S.ex,mov,'rS',RMIN+3.5)}
}
// 着順finに合わせて、6旋回ぶんの順位推移・旋回半径・時間差を組み立てる
function buildScenario(rnd,fin,tau0,kim,Sz){
  const lanes=[1,2,3,4,5,6],w=fin[0],jit=s=>(rnd()-0.5)*s;
  const TR=[null],TURN=[null];
  // ---------- 1) 各旋回の順位(進入/頂点/出口)と旋回半径 ----------
  const E=tau0.slice();
  if(kim==='makuri')E[w-1]-=0.12;                  // スタートから伸びて、マーク手前で外から並びかける
  if(kim==='mzashi')E[w-1]-=0.07;
  if(kim==='sashi')E[w-1]+=0.04;                   // 一歩引いて差しを狙う
  // 1マークへは内側の艇ほど先に回る。STの差が大きいと順番が入れ替わる(0.1秒差≒1コース分)
  const dmin=Math.min(...tau0),key={};lanes.forEach(l=>key[l]=l+9*(tau0[l-1]-dmin)+jit(0.3));
  const ent=lanes.slice().sort((a,b)=>key[a]-key[b]);
  let mid=ent.slice();
  if(kim==='nige'||kim==='sashi'||kim==='nuki')mid=moveTo(mid,1,0);
  if(kim==='makuri')mid=moveTo(mid,w,0);
  if(kim==='mzashi'){mid=moveTo(mid,1,0);mid=moveTo(mid,w,1)}
  const lead=kim==='nige'||kim==='nuki'?1:w;
  // 1マーク出口の2番手以下: 旋回の並び(mid)と最終着順の中間。残りの差は2周目以降の抜きで埋める
  const mR=rankMap(mid),fR=rankMap(fin),sc={};lanes.forEach(l=>sc[l]=0.6*mR[l]+0.4*fR[l]+jit(1.2));
  let rest=fin.filter(l=>l!==lead).sort((a,b)=>sc[a]-sc[b]);
  if(kim==='nuki'){rest=rest.filter(l=>l!==w);rest.splice(rnd()<0.65?0:1,0,w)}
  const t1=[lead,...rest];
  const rE_=rankMap(ent),rM=rankMap(mid),rX_=rankMap(t1);
  const passEM=(j,i)=>rE_[j]>rE_[i]&&rM[j]<rM[i], passMX=(j,i)=>rM[j]>rM[i]&&rX_[j]<rX_[i];
  const T1={};
  lanes.forEach(l=>{T1[l]={rE:9.2+1.7*(l-1)+jit(0.5),rA:7.6+1.25*rM[l]+jit(0.5),rX:8.6+1.3*rX_[l]+jit(0.8),rS:9.8+1.15*rX_[l],tac:'',xA:0.55}});
  for(let it=0;it<2;it++)for(const j of lanes)for(const i of lanes){
    if(i===j||!passEM(j,i))continue;
    if(j>i){T1[j].rA=Math.max(T1[j].rA,T1[i].rA+1.8);T1[j].rE=Math.max(T1[j].rE,T1[i].rE+1.6);if(!it)T1[i].rX+=2.5;T1[j].tac='makuri'}  // 外から被せる。被された艇は流れる
    else T1[j].rA=Math.min(T1[j].rA,Math.max(RMIN+0.6,T1[i].rA-1.5));
  }
  for(const j of lanes)for(const i of lanes){
    if(i===j||!passMX(j,i))continue;          // 頂点から出口で内側を抜ける(差し/まくり差し)
    if(T1[j].tac!=='makuri')T1[j].rA=Math.min(T1[j].rA,8.6);
    T1[j].rX=Math.min(T1[j].rX,7.4+0.45*rX_[j]);T1[i].rX=Math.max(T1[i].rX,T1[j].rX+4.5);T1[i].xA=0.35;T1[j].xA=0.72;
    T1[j].tac=T1[j].tac==='makuri'||T1[j].tac==='mzashi'?'mzashi':'sashi';
  }
  if(kim!=='nige'&&kim!=='nuki')T1[w].tac=kim;
  if(kim==='nige'||kim==='nuki'){T1[1].rA=Math.min(T1[1].rA,RMIN+0.6);T1[1].tac='nige'}   // 逃げはマーク際ギリギリ
  TR[1]=T1;TURN[1]={ent,mid,ex:t1,pairs:[]};
  // 第2〜第6ターン: 毎ターン「最終着順までに必要な入れ替わり」を割り振り、余裕があれば道中の競り合い(抜いて抜き返す)も入れる
  // pairs: {P:抜かれる艇, Q:抜く艇, kind, ph:'EM'(進入〜頂点で外から)|'MX'(頂点〜出口で内から)}
  let cur=t1.slice();
  const kindOf=()=>{const r=rnd();return r<0.42?'sashi':r<0.74?'tsuke':r<0.9?'makuri':'mzashi'};
  for(let k=2;k<=NTURN;k++){
    const need=bubble(cur,fin),tl=NTURN-k+1,used=[],pairs=[];
    const free=p=>!used.some(u=>Math.abs(u-p)<2);
    let q=Math.ceil(need.length/tl);if(need.length<tl&&rnd()<0.3)q=0;if(k===NTURN)q=need.length;
    for(let n=0;n<need.length&&q>0;n++){const p=need[n];
      // 同じ艇が2つ続けて順位を上げるときは、まくり差し(外から1艇を越え、さらに内から1艇を差す)にまとめる
      const p2=need[n+1];
      if(p2===p-1&&rnd()<0.55&&free(p)&&!used.some(u=>Math.abs(u-p2)<2&&u!==p)){
        const Q=cur[p+1];pairs.push({P:cur[p],Q,kind:'mzashi',ph:'EM'},{P:cur[p-1],Q,kind:'mzashi',ph:'MX'});used.push(p,p2);n++;q-=2;continue}
      if(!free(p))break;
      const kd=kindOf()==='mzashi'?'makuri':kindOf();
      pairs.push({P:cur[p],Q:cur[p+1],kind:kd,ph:kd==='sashi'?'MX':'EM'});used.push(p);q--;
    }
    // 道中の競り合い: 着順に関係ない入れ替わり(あとのターンで抜き返す)。残りのターンに余裕があるときだけ
    // BATTLE_P: 1組目の発生確率 / 2組目の発生確率(あとのターンで抜き返す前提。残りターンの余裕があるときだけ)
    const BATTLE_P=[0.75,0.35];
    for(let e=0;e<2;e++){
      if(!(k<NTURN&&need.length+2*(e+1)<=(tl-1)*2&&rnd()<BATTLE_P[e]))continue;
      const cand=[0,1,2,3,4].filter(p=>free(p)&&(p>0||rnd()<0.5));
      if(cand.length){const p=cand[Math.floor(rnd()*cand.length)],kd=kindOf()==='mzashi'?'sashi':kindOf();pairs.push({P:cur[p],Q:cur[p+1],kind:kd,ph:kd==='sashi'?'MX':'EM'});used.push(p)}
    }
    const swap=(o,x)=>{const i=o.indexOf(x.P),j=o.indexOf(x.Q);if(i>=0&&j>=0){o[i]=x.Q;o[j]=x.P}};
    const midO=cur.slice();for(const x of pairs)if(x.ph==='EM')swap(midO,x);
    const exO=midO.slice();for(const x of pairs)if(x.ph==='MX')swap(exO,x);
    const rE_k=rankMap(cur),rM_k=rankMap(midO),rX_k=rankMap(exO),Tk={};
    const inPair=l=>pairs.some(x=>x.P===l||x.Q===l);
    lanes.forEach(l=>{Tk[l]={rE:9.6+0.8*rE_k[l],rA:7.8+0.5*rM_k[l]+jit(0.4),rX:8.8+0.7*rX_k[l]+jit(0.6),rS:9.8+1.15*rX_k[l],tac:'',xA:0.55};
      if(!inPair(l)){const v=rnd();
        if(v<0.16)Tk[l].rX+=2.5+rnd()*3;                                   // 出口で流れる
        else if(v<0.30)Tk[l].rA=Math.max(RMIN+0.3,Tk[l].rA-1.2);           // マーク際ギリギリを攻める
        else if(v<0.36){Tk[l].rA+=3.5;Tk[l].rX+=3}}});                      // マークを外して大きく回る
    for(const {P,Q,kind,ph} of pairs){const p=Tk[P],q=Tk[Q];q.tac=kind;
      if(ph==='MX'){                                                        // 内から差す
        if(kind==='sashi'){q.rE=Math.max(RMIN+1,p.rE-1.8);p.rE=Math.max(p.rE,q.rE+1.8);q.rA=Math.max(RMIN+0.5,Math.min(7.6,p.rA-1));p.rA=Math.max(p.rA,q.rA+1.4)}
        q.rX=7.6;p.rX=Math.max(p.rX,13.5);p.xA=0.35;q.xA=0.7}
      else{const o=kind==='makuri'?[2.8,3,9.2,3]:[1.8,1.7,8.8,2.2];      // 外から被せる(つけまいは艇に密着、まくりは大きく)
        q.rE=Math.max(q.rE,p.rE+o[0]);q.rA=Math.max(q.rA,p.rA+o[1]);if(kind!=='mzashi')q.rX=o[2];p.rX+=o[3]}}
    TR[k]=Tk;TURN[k]={ent:cur.slice(),mid:midO,ex:exO,pairs};cur=exO;
  }
  spreadLines(TR,TURN,rnd,lanes);
  // 割り振れなかった入れ替わりは最終直線で抜く
  let finO=null;const left=bubble(cur,fin);
  if(left.length){finO=cur.slice();for(const p of left){const Q=finO[p+1],P=finO[p];TR[NTURN][Q].rS=TR[NTURN][P].rS+2.4;[finO[p],finO[p+1]]=[finO[p+1],finO[p]]}}
  // ---------- 2) 各艇の航跡による自然な遅れG ----------
  const G=lanes.map(l=>buildG(TR,l,Sz[l-1]));
  // ---------- 3) 時間差のキーフレーム(合計τ = KF + G) ----------
  const KF=lanes.map(l=>({U:[US],T:[tau0[l-1]]}));
  const add=(U,T)=>lanes.forEach(l=>{KF[l-1].U.push(U);KF[l-1].T.push(T[l]-gAt(G[l-1],U))});
  const adv=(T,U0,U1)=>{const n={};lanes.forEach(l=>n[l]=T[l]+gAt(G[l-1],U1)-gAt(G[l-1],U0));return n};
  let Uprev=tStart(1)+KF_E*ARC,Tcur={};lanes.forEach(l=>Tcur[l]=E[l-1]+gAt(G[l-1],Uprev));
  add(Uprev,Tcur);
  for(let k=1;k<=NTURN;k++){
    const S=TURN[k],Ue=tStart(k)+KF_E*ARC,Um=tStart(k)+KF_M*ARC,Ux=tStart(k)+KF_X*ARC;
    const pr=(a,b)=>S.pairs.find(x=>(x.P===a&&x.Q===b)||(x.P===b&&x.Q===a));
    if(k>1){Tcur=chain(S.ent,adv(Tcur,Uprev,Ue),(p,l)=>S.pairs.some(x=>x.Q===l&&x.P===p)?[0.07,0.45]:[0.16,false],1.5);add(Ue,Tcur)}   // 抜く艇は直線で詰めて真後ろにつける
    const isMX=l=>k===1&&lanes.some(i=>passMX(l,i));
    Tcur=chain(S.mid,adv(Tcur,Ue,Um),(p,l)=>{const x=pr(p,l);return x?[x.ph==='MX'?0.15:0.06,false]:[isMX(l)?0.42:0.11,false]},1.0);add(Um,Tcur);
    Tcur=chain(S.ex,adv(Tcur,Um,Ux),(p,l)=>[pr(p,l)?0.12:0.14,false],1.2);add(Ux,Tcur);
    Uprev=Ux;
    // 出口速度の差で直線上の順位が崩れないよう、直線の中間でも順位を確定する(近づいても最小間隔で後ろにつく)
    if(k<NTURN){const Us=(Ux+tStart(k+1)+KF_E*ARC)/2;Tcur=chain(S.ex,adv(Tcur,Uprev,Us),()=>[0.14,false],1.5);add(Us,Tcur);Uprev=Us}
  }
  {const U=UFIN-12;Tcur=chain(finO||cur,adv(Tcur,Uprev,U),()=>[0.16,false],1.5);add(U,Tcur);Uprev=U}
  add(UFIN+80,adv(Tcur,Uprev,UFIN+80));
  return{KF,TR,G,t1,k1:kim==='nuki'?'nige':kim};
}
// サーバーが決めた着順(order)・ST・決まり手で、全員が同じレースを再現する
export function createRiggedRace(seed,order,info){
  let r;
  for(let k=0;k<40;k++){
    r=createRace((seed+k*7919)>>>0,order,info);
    for(let i=0;i<30000&&!r.done;i++)r.step(1/60);
    if(!order||r.finishOrder.join('')===order.join(''))return createRace((seed+k*7919)>>>0,order,info);
  }
  return createRace(seed,order,info);
}
export function createRace(seed,order,info){
  info=info||{};
  seed=seed||((Math.random()*2**31)|0);const rnd=mulberry(seed);
  if(!order){const wt=[1,0.3,0.22,0.19,0.09,0.04],left=[1,2,3,4,5,6];order=[];
    while(left.length){const tot=left.reduce((s,l)=>s+wt[l-1],0);let x=rnd()*tot,i=0;for(;i<left.length-1;i++){x-=wt[left[i]-1];if(x<=0)break}order.push(left.splice(i,1)[0])}}
  const w=order[0];
  let kim=KIM_EN[info.kimarite]||pickKim(w,rnd());
  if(w===1)kim='nige';else if(kim==='nige')kim=pickKim(w,rnd());
  const boats=[];
  for(let i=0;i<6;i++){
    const st=info.st&&Number.isFinite(+info.st[i])?+info.st[i]:null;
    let delay=st!=null?Math.max(0.01,Math.min(0.45,st)):0.10+rnd()*0.17+(i>=3?0.02:0);
    if(st==null){if(i+1===w&&kim==='makuri')delay=0.05+rnd()*0.06;if(i+1===w&&kim==='mzashi')delay=0.07+rnd()*0.06;if(i===0&&kim==='nige')delay=Math.min(delay,0.16)}
    const run=RUN[i],T=2*run/(V0+VL);
    boats.push({lane:i+1,ph:rnd()*6.28,delay,run,T,acc:(VL-V0)/T,tAcc:delay-T,tOut:T0,
      Sx:START_X-BOW-run,Sz:startZ(i),Px:PIT_X,Pz:pitZ(i),
      u:0,v:0,r:startZ(i),x:0,z:0,hd:Math.PI/2,bank:0,prevHd:Math.PI/2,tau:0,tac:'',
      crossed:false,finished:false,fin:0,rank:i+1,lapNo:1,turn1Rank:0});
  }
  const tau0=boats.map(b=>b.delay+BOW/VL);
  const SC=buildScenario(rnd,order,tau0,kim,boats.map(b=>b.Sz));
  boats.forEach((b,i)=>{b.kf=SC.KF[i];b.g=SC.G[i];b.tau=tau0[i]});
  const R={t:T0,boats,order:[1,2,3,4,5,6],finishOrder:[],done:false,kimarite:'',k1:SC.k1,plannedT1:SC.t1,seed,t1:null,crossedAll:false,serverKim:info.kimarite||''};
  const tmp={x:0,z:0},tmp2={x:0,z:0};
  function ranks(){
    const arr=boats.slice().sort((a,b)=>a.finished&&b.finished?a.fin-b.fin:a.finished?-1:b.finished?1:b.u-a.u);
    arr.forEach((b,i)=>b.rank=i+1);R.order=arr.map(b=>b.lane);
  }
  // ピット→センターポール周回→ホーム側ターンマーク周回→待機位置→約5秒待機→10秒でスタートライン。
  // 経路は滑らかな曲線(距離で進む)。速度: ピットから最高速まで徐々に加速→ポールを回りながら1/4へ→待機位置で停止。
  const vOf=(s,P)=>{
    let v=s<P.sAcc?Math.sqrt(Math.max(0,2*P.a*s)):VMAX;
    if(s>P.Sb)v=VMAX+(P.Vc-VMAX)*sstep((s-P.Sb)/(P.Sc-P.Sb));
    if(s>P.Sc)v=P.Vc;
    const d0=P.Send-P.dDec;if(s>d0)v=v+(V_WAIT-v)*sstep((s-d0)/P.dDec);
    return Math.max(v,V_WAIT*0.6);
  };
  function crSpline(pts){
    const n=pts.length,Q=[[2*pts[0][0]-pts[1][0],2*pts[0][1]-pts[1][1]],...pts,[pts[n-1][0]+30,pts[n-1][1]]];
    const xs=[],zs=[],ss=[],node=[0];let acc=0;
    const dd=(a,b)=>Math.sqrt(Math.hypot(a[0]-b[0],a[1]-b[1]))||1e-4;
    const lp=(a,b,q)=>[a[0]+(b[0]-a[0])*q,a[1]+(b[1]-a[1])*q];
    for(let j=1;j<n;j++){
      const p0=Q[j-1],p1=Q[j],p2=Q[j+1],p3=Q[j+2];
      const t0=0,t1=t0+dd(p0,p1),t2=t1+dd(p1,p2),t3=t2+dd(p2,p3);
      const m=Math.max(4,Math.ceil(Math.hypot(p2[0]-p1[0],p2[1]-p1[1])/0.4));
      for(let k=0;k<m;k++){
        const t=t1+(t2-t1)*k/m;
        const A1=lp(p0,p1,(t-t0)/(t1-t0)),A2=lp(p1,p2,(t-t1)/(t2-t1)),A3=lp(p2,p3,(t-t2)/(t3-t2));
        const B1=lp(A1,A2,(t-t0)/(t2-t0)),B2=lp(A2,A3,(t-t1)/(t3-t1)),C=lp(B1,B2,(t-t1)/(t2-t1));
        if(xs.length)acc+=Math.hypot(C[0]-xs[xs.length-1],C[1]-zs[zs.length-1]);
        xs.push(C[0]);zs.push(C[1]);ss.push(acc);
      }
      node[j]=acc+Math.hypot(p2[0]-xs[xs.length-1],p2[1]-zs[zs.length-1]);
    }
    acc=node[n-1];xs.push(pts[n-1][0]);zs.push(pts[n-1][1]);ss.push(acc);
    return {xs,zs,ss,node,Send:acc};
  }
  const timeTable=(c,P)=>{const T=[0];for(let i=1;i<c.ss.length;i++){const ds=c.ss[i]-c.ss[i-1];T[i]=T[i-1]+ds/vOf((c.ss[i]+c.ss[i-1])/2,P)}return T};
  function buildPath(b){
    const lane=b.lane-1,slow=lane<3,r=9+lane*1.1,rm=9+lane*1.1,MX=-L/2,wide=slow?0:6;
    const tw=T_WAIT_END,T=b.delay-tw,d=RUN[lane];
    // 待機後の加速: v=v0+(VL-v0)(1-(1-q)^k)。到達距離がdになるようkを決める
    const f=Math.max(0.5,Math.min(0.9,(d/T-V_WAIT)/(VL-V_WAIT))),k=f/(1-f);
    const dd=V_WAIT*T+(VL-V_WAIT)*T*(1-1/(k+1));
    b.ap={tw,T,k,x0:START_X-BOW-dd,z:startZ(lane)};
    const W=[b.ap.x0-V_WAIT*(tw-T_ARRIVE),b.ap.z];   // 待機位置(到着点)
    // ホーム側マークの周回: 下側を回ったあとは待機位置まで常に右向きに進む(逆戻りしない)
    const Gx=Math.min(MX,W[0]-14),Gz=rm+3+lane*0.6;
    const pts=[
      [b.Px,b.Pz],                                       // ピット
      [CENTER_X-8,CENTER_Z+r],                           // ポール手前(下側)
      [CENTER_X+r,CENTER_Z+r*0.1],                       // ポール右
      [CENTER_X+r*0.1,CENTER_Z-r],                       // ポール上(沖側)
      [Gx+26,-(rm+1)],                                   // マークの上側
      [Gx-rm-wide,0],                                    // マークの左(ダッシュはやや外側)
      [Gx,Gz],                                           // マークの下側
      [(Gx+W[0])/2,(Gz+W[1])/2],                         // 待機位置へ向かう
      W                                                  // 待機位置
    ];
    const c=crSpline(pts);
    const P={sAcc:Math.min(130,(c.node[1]-45)*0.7),Sb:c.node[1]-45,Sc:c.node[3],Send:c.Send,dDec:12,Vc:VMAX*VC_RATIO};
    P.a=VMAX*VMAX/(2*P.sAcc);
    const tdep=T0+1.5,Tfix=T_ARRIVE-tdep;
    // 出発(T0+1.5秒)から-15秒の到着までに収まるよう、ポール通過後の速度Vcを調整(目安は最高速の1/4)
    let lo=VMAX*0.08,hi=VMAX*0.6;
    for(let i=0;i<30;i++){P.Vc=(lo+hi)/2;const Tt=timeTable(c,P);if(Tt[Tt.length-1]>Tfix)lo=P.Vc;else hi=P.Vc}
    P.Vc=(lo+hi)/2;
    b.path={c,P,Tt:timeTable(c,P),tdep,W};
  }
  function posAtS(c,s){
    const {ss,xs,zs}=c;let lo=0,hi=ss.length-1;
    if(s<=0)return[xs[0],zs[0]];if(s>=ss[hi])return[xs[hi],zs[hi]];
    while(hi-lo>1){const m=(lo+hi)>>1;if(ss[m]>s)hi=m;else lo=m}
    const q=(s-ss[lo])/Math.max(1e-6,ss[hi]-ss[lo]);return[xs[lo]+(xs[hi]-xs[lo])*q,zs[lo]+(zs[hi]-zs[lo])*q];
  }
  function script(b,dt){
    const t=R.t;let v;
    if(t<T_ARRIVE){
      const {c,P,Tt,tdep}=b.path;let s=0,sp=0;
      if(t>tdep){
        const tt=t-tdep;let lo=0,hi=Tt.length-1;
        if(tt>=Tt[hi])s=c.Send;else{while(hi-lo>1){const m=(lo+hi)>>1;if(Tt[m]>tt)hi=m;else lo=m}
          s=c.ss[lo]+(c.ss[hi]-c.ss[lo])*(tt-Tt[lo])/Math.max(1e-6,Tt[hi]-Tt[lo])}
        sp=vOf(s,P);
      }
      const pa=posAtS(c,s-1.5),pb=posAtS(c,s+1.5),pc=posAtS(c,s),L2=Math.hypot(pb[0]-pa[0],pb[1]-pa[1])||1;
      v=[pc[0],pc[1],(pb[0]-pa[0])/L2*sp,(pb[1]-pa[1])/L2*sp];
      if(sp<0.01){v[2]=(pb[0]-pa[0])/L2*0.002;v[3]=(pb[1]-pa[1])/L2*0.002}
    }else if(t<b.ap.tw){
      v=[b.path.W[0]+V_WAIT*(t-T_ARRIVE),b.ap.z,V_WAIT,0];          // ほぼ停止して待機
    }else{
      const {T,k,x0,z}=b.ap,tau=t-b.ap.tw,q=Math.min(1,tau/T);
      const vv=V_WAIT+(VL-V_WAIT)*(1-Math.pow(1-q,k));
      const xx=x0+V_WAIT*tau+(VL-V_WAIT)*T*(q-(1-Math.pow(1-q,k+1))/(k+1));
      v=[xx,z,vv,0];
    }
    const [x,z,dx,dz]=v,hd=Math.hypot(dx,dz)>0.0001?Math.atan2(dx,dz):b.prevHd;
    let delta=hd-b.prevHd;while(delta>Math.PI)delta-=2*Math.PI;while(delta<-Math.PI)delta+=2*Math.PI;
    b.bank+=((-(dt>0?delta/dt:0)*.45)-b.bank)*Math.min(1,dt*5);
    b.prevHd=hd;b.hd=hd;b.x=x;b.z=z;b.v=Math.hypot(dx,dz)<0.01?0:Math.hypot(dx,dz);b.u=x+120;
  }
  // キーフレーム間をなめらかに補間して、その艇の目標時間差τを求める
  function tauAt(b,U){
    const {U:KU,T:KT}=b.kf,g=gAt(b.g,U);if(U<=KU[0])return KT[0]+g;
    for(let i=1;i<KU.length;i++)if(U<KU[i]){const q=sstep((U-KU[i-1])/(KU[i]-KU[i-1]));return KT[i-1]+(KT[i]-KT[i-1])*q+g}
    return KT[KT.length-1]+g;
  }
  function update(b,dt){
    const lane=b.lane;
    // --- 旋回半径(横位置) ---
    const k=turnOf(b.u),tr=SC.TR[k][lane],tph=(b.u-tStart(k))/ARC,fr=blend(b.u,100);
    const rt=radiusAt(SC.TR,lane,b.Sz,b.u);b.rt=rt;
    const mx=(fr>0.02?5:3)*dt;b.r+=Math.max(-mx,Math.min(mx,rt-b.r));
    b.tac=tph>-0.8&&tph<1.6?tr.tac:'';
    // --- 前後位置: 基準艇の軌跡を時間差τで追う ---
    const lag=paceAt(R.t-b.tau)[0],tauN=tauAt(b,lag),dTau=Math.max(-0.6,Math.min(0.6,(tauN-b.tau)/Math.max(dt,1e-4)));b.tau=tauN;
    const [ut,vr]=paceAt(R.t-b.tau);
    const a=((b.u%PU)+PU)%PU,g=inArcA(a)?Math.max(b.r,RMIN)/R0:1;
    let tv=Math.max(5,Math.min(24.7,(vr*(1-dTau)+KP*(ut-b.u))*g));
    if(b.finished)tv=7;
    b.v+=Math.max(-11*dt,Math.min(9*dt,tv-b.v));
    b.u+=b.v/g*dt;
    if(!b.finished&&b.u-US>=LAPS*PU){b.finished=true;b.fin=R.t-(b.u-US-LAPS*PU)/Math.max(b.v,1);R.finishOrder.push(b.lane)}
    b.lapNo=Math.min(LAPS,Math.max(1,Math.floor((b.u-US)/PU)+1));
  }
  function place(b,dt){
    pathPos(b.u,b.r,tmp);pathPos(b.u+0.8,b.r,tmp2);
    const hd=Math.atan2(tmp2.x-tmp.x,tmp2.z-tmp.z);
    let d=hd-b.prevHd;while(d>Math.PI)d-=6.2832;while(d<-Math.PI)d+=6.2832;
    const rate=dt>0?d/dt:0;b.prevHd=hd;b.hd=hd;b.x=tmp.x;b.z=tmp.z;
    b.bank+=((-rate*0.45)-b.bank)*Math.min(1,dt*5);
  }
  // 並走中に横幅が重なったら左右に押し合う(前後の順位は崩さない)
  function collide(){
    for(let i=0;i<6;i++){const a=boats[i];if(!a.crossed)continue;
      for(let j=i+1;j<6;j++){const b=boats[j];if(!b.crossed)continue;
        const du=a.u-b.u;if(Math.abs(du)>5.4)continue;
        const dr=a.r-b.r;if(Math.abs(dr)>=1.6)continue;
        // 後ろの艇が前の艇の横をすり抜けないよう、前後に重なっている間は今いる側に留める(間が空いてから切り込む)
        const front=du>=0?a:b,rear=du>=0?b:a,side=Math.abs(rear.r-front.r)>0.05?Math.sign(rear.r-front.r):(rear.rt>front.rt?1:-1);
        let want=front.r+side*1.6;if(side<0&&want<RMIN){front.r+=Math.min(0.1,RMIN+1.6-front.r);want=RMIN}
        rear.r+=Math.max(-0.13,Math.min(0.13,want-rear.r));        // 横移動はなめらかに(1フレーム最大13cm)
        if(Math.abs(du)<4.5){a.bumps=(a.bumps||0)+1;b.bumps=(b.bumps||0)+1}
      }}
  }
  R.step=function(dt){
    if(R.done&&R.t>R.endT+6)return;
    R.t+=dt;
    for(const b of boats){
      if(R.t<b.delay)script(b,dt);
      else{
        if(!b.crossed){b.crossed=true;b.u=US-BOW+VL*(R.t-b.delay-dt);b.v=VL;b.r=b.Sz;b.tau=b.kf.T[0]}
        update(b,dt);place(b,dt);
      }
    }
    collide();
    R.crossedAll=boats.every(b=>b.crossed);
    ranks();
    if(!R.t1&&boats.every(b=>b.u>=L+ARC+20)){R.t1=R.order.slice();for(const b of boats)b.turn1Rank=b.rank}
    if(!R.done&&R.finishOrder.length===6){R.done=true;R.endT=R.t;R.kimarite=kimarite()}
  };
  function kimarite(){
    if(R.serverKim)return R.serverKim;
    const w=R.finishOrder[0];
    return R.t1&&R.t1[0]===w?KIM_JP[R.k1]:'抜き';
  }
  for(const b of boats){buildPath(b);script(b,0)}
  ranks();
  return R;
}
