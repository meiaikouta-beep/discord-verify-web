// roulette_ui.js (v2 shared table) — 3D roulette table, betting phase, up to 4 seats shared by every player.
// Server is authoritative: this file only sends bet requests and draws the state it receives.
import * as THREE from '/casino/static/vendor/three.module.js';

const W = 1.1, H = 1.1, EDGE = 0.24;                 // cell size / how close to a line counts as "on the line"
const CHIPS = [100, 500, 1000, 5000, 10000];
const CHIP_STYLE = {
  100:   { c: '#e9e4d4', t: '#2b2b2b', s: '#9b9684', label: '100' },
  500:   { c: '#b3262e', t: '#ffffff', s: '#f2d3d5', label: '500' },
  1000:  { c: '#1f4fa8', t: '#ffffff', s: '#cfdcf5', label: '1K' },
  5000:  { c: '#1b7a45', t: '#ffffff', s: '#cdeedb', label: '5K' },
  10000: { c: '#17151a', t: '#f2c14e', s: '#f2c14e', label: '10K' },
};
const RED = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
const range = (a, b) => { const r = []; for (let i = a; i <= b; i++) r.push(i); return r; };
const ALL = range(1, 36);
const OUT_NUMS = {
  dozen1: range(1, 12), dozen2: range(13, 24), dozen3: range(25, 36),
  col1: ALL.filter(n => n % 3 === 1), col2: ALL.filter(n => n % 3 === 2), col3: ALL.filter(n => n % 3 === 0),
  red: ALL.filter(n => RED.has(n)), black: ALL.filter(n => !RED.has(n)),
  odd: ALL.filter(n => n % 2 === 1), even: ALL.filter(n => n % 2 === 0),
  low: range(1, 18), high: range(19, 36),
};
const OUT_LABEL = {
  dozen1: '1st 12', dozen2: '2nd 12', dozen3: '3rd 12', col1: '2 : 1', col2: '2 : 1', col3: '2 : 1',
  low: '1-18', even: 'EVEN', red: 'RED', black: 'BLACK', odd: 'ODD', high: '19-36',
};
const OUT_JP = {
  dozen1: '1〜12（ダズン）', dozen2: '13〜24（ダズン）', dozen3: '25〜36（ダズン）',
  col1: '1列目（カラム）', col2: '2列目（カラム）', col3: '3列目（カラム）',
  low: '1〜18', even: '偶数', red: '赤', black: '黒', odd: '奇数', high: '19〜36',
};
const OUT_MULT = { dozen1: 2, dozen2: 2, dozen3: 2, col1: 2, col2: 2, col3: 2, low: 1, even: 1, red: 1, black: 1, odd: 1, high: 1 };
const EVEN_ROW = ['low', 'even', 'red', 'black', 'odd', 'high'];

const SEAT_COLORS = ['#e5c35f', '#5fb8ff', '#ff6b8a', '#7be08f'];
const MAX_SEATS = 4;

const fmt = n => Number(n || 0).toLocaleString('ja-JP');

// ==SPIN-PLAN-BEGIN==
// Spin animation = pure function of (round id, winning number, seconds since betting closed).
// Same timeline as server/roulette.py: ball in at 0, lands at 15, wheel at rest at 20, popup at 22, next round at 29.
const TAU = Math.PI * 2, PK = TAU / 37;
const WHEEL_ORDER = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
const T_LAND = 15, T_STOP = 5, T_POP_DELAY = 2, T_POP_SHOW = 7;
const T_REVEAL = T_LAND + T_STOP + T_POP_DELAY, T_CYCLE = T_REVEAL + T_POP_SHOW;
const R_TRACK = 3.98, R_EDGE = 3.05, R_POCKET = 2.7, R_DROPPED = 3.15, BALL_R = 0.085;
const E_SLIDE = 8.5, E_DROP = 10.5, TB = 18, QB = 1.6, P_TAIL = 2.6, W15 = 1.25;
const trackH = r => r <= R_EDGE ? 0 : 0.45 * Math.pow(Math.min(1, (r - R_EDGE) / 1.1), 1.7);
const wrapPi = a => a - TAU * Math.round(a / TAU);
const smooth = x => { x = Math.min(1, Math.max(0, x)); return x * x * (3 - 2 * x); };
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
// Angles are clockwise from the far side seen from above: x = r sin a, z = -r cos a (a = PI is the front, nearest the viewer).
// rotor.rotation.y = rho(e) (counter-clockwise), so pocket i sits at world angle i*PK - rho. The ball runs clockwise.
function makePlan(roundId, number) {
  const R = mulberry32((roundId * 2654435761 + (number + 1) * 40503) >>> 0);
  const ak = Math.max(0, WHEEL_ORDER.indexOf(number)) * PK;
  const rs = R() * TAU, th0 = R() * TAU;
  // wheel: speeds up/down linearly until landing, then eases to rest with the winning pocket at the front
  const baseA = (2.4 + W15) / 2 * T_LAND + T_STOP * W15 / 3;
  const need = ak - Math.PI - rs;
  const total = need + TAU * Math.round((baseA - need) / TAU);
  const A = total - T_STOP * W15 / 3;
  const w0 = 2 * A / T_LAND - W15;
  const rho = e => {
    if (e <= T_LAND) return rs + w0 * e + (W15 - w0) * e * e / (2 * T_LAND);
    const u = Math.min(1, (e - T_LAND) / T_STOP);
    return rs + A + T_STOP * W15 * (1 - Math.pow(1 - u, 3)) / 3;
  };
  const rhoV = e => e <= T_LAND ? w0 + (W15 - w0) * e / T_LAND : W15 * Math.pow(1 - Math.min(1, (e - T_LAND) / T_STOP), 2);
  // ball on the track: decaying speed; pick the launch speed so the hand-over to the pocket ring lines up
  const Phi = e => TB / (QB + 1) * (1 - Math.pow(1 - e / TB, QB + 1));
  const Bv = (e, wb) => wb * Math.pow(1 - e / TB, QB);
  const Tt = T_LAND - E_DROP;
  let best = null;
  for (let wb = 8.5; wb <= 12; wb += 0.002) {
    const D0t = (Bv(E_DROP, wb) + rhoV(E_DROP)) * Tt / P_TAIL;
    const wF = wrapPi(th0 + wb * Phi(E_DROP) + rho(E_DROP) - ak + D0t);
    if (!best || Math.abs(wF) < Math.abs(best.wF)) best = { wb, wF, D0t };
  }
  const wb0 = best.wb, D0 = best.D0t - best.wF;
  const M = Math.round((th0 + wb0 * Phi(E_DROP) + rho(E_DROP) - ak + D0) / TAU);
  // bounces off the frets: [start, duration, height, pockets the ball ends up away from its final pocket]
  const hops = [
    { t0: 11.5, d: 0.55, h: 0.30, k: 3 + R() * 2 },
    { t0: 12.8, d: 0.45, h: 0.20, k: -(2 + R() * 2.5) },
    { t0: 13.8, d: 0.36, h: 0.12, k: 1 + R() * 1.5 },
    { t0: 14.45, d: 0.30, h: 0.07, k: 0 },
    { t0: 14.82, d: 0.22, h: 0.035, k: 0 },
  ];
  function hopState(e) {
    let K = 0, prev = 0, y = 0, rad = 0;
    for (let i = 0; i < hops.length; i++) {
      const hp = hops[i], u = (e - hp.t0) / hp.d;
      if (u <= 0) break;
      if (u >= 1) { prev = hp.k; K = prev; continue; }
      K = prev + (hp.k - prev) * smooth(u);
      y = hp.h * 4 * u * (1 - u);
      rad = (i % 2 ? -1 : 1) * 0.14 * Math.sin(Math.PI * u) * (hp.h > 0.1 ? 1 : 0.5);
      break;
    }
    return { K, y, rad };
  }
  function ball(e) {
    e = Math.max(0, e);
    let B, r, y;
    if (e < E_DROP) {
      B = th0 + wb0 * Phi(e);
      r = e < E_SLIDE ? R_TRACK : R_TRACK - (R_TRACK - R_DROPPED) * Math.pow((e - E_SLIDE) / (E_DROP - E_SLIDE), 1.8);
      y = trackH(r) + BALL_R;
    } else {
      const s = Math.min(1, (e - E_DROP) / Tt), hs = hopState(e);
      B = ak + TAU * M - D0 * Math.pow(1 - s, P_TAIL) + hs.K * PK - rho(e);
      const sr = Math.min(1, (e - E_DROP) / 1.0);
      r = R_POCKET + (R_DROPPED - R_POCKET) * (1 - sr) * (1 - sr) + hs.rad;
      y = trackH(r) + BALL_R + hs.y;
    }
    return { B, r, y };
  }
  return { rho: e => rho(Math.max(0, e)), ball, ak, number };
}
// ==SPIN-PLAN-END==

// ---- table geometry (x: along the 12 columns, z: toward the player) ----
function cellXZ(n) {
  if (n === 0) return [-6.5 * W, 0];
  const k = Math.floor((n - 1) / 3), r = 2 - ((n - 1) % 3);   // r=0 is the far row (3,6,9..)
  return [(k - 5.5) * W, (r - 1) * H];
}
const numAt = (k, r) => 3 * k + (3 - r);
const OUT_CELLS = [];
['dozen1', 'dozen2', 'dozen3'].forEach((id, d) => OUT_CELLS.push({ id, x: (4 * d - 4) * W, z: 2 * H, sx: 4 * W, sz: H }));
EVEN_ROW.forEach((id, i) => OUT_CELLS.push({ id, x: (2 * i - 5) * W, z: 3 * H, sx: 2 * W, sz: H }));
['col3', 'col2', 'col1'].forEach((id, r) => OUT_CELLS.push({ id, x: 6.5 * W, z: (r - 1) * H, sx: W, sz: H }));
const outCell = id => OUT_CELLS.find(o => o.id === id);

function spotCenter(nums) {
  const ns = nums.filter(n => n > 0);
  if (!ns.length) return cellXZ(0);
  const avg = a => a.reduce((s, v) => s + v, 0) / a.length;
  const pts = ns.map(cellXZ);
  let x = avg(pts.map(p => p[0])), z = avg(pts.map(p => p[1]));
  if (nums.includes(0)) {
    x = -6 * W;
    if (ns.length === 1) z = pts[0][1];
    else if (ns.length === 3) z = 1.5 * H;            // basket
  } else if (ns.length === 3 || ns.length === 6) z = 1.5 * H;   // street / six line sit on the player-side edge
  return [x, z];
}

function describe(spot) {
  if (spot.t) return [OUT_JP[spot.t], OUT_MULT[spot.t]];
  const n = spot.nums.length, z = spot.nums.includes(0);
  if (n === 1) return [spot.nums[0] + '番（ストレート）', 35];
  if (n === 2) return [spot.nums.join('・') + '（スプリット）', 17];
  if (n === 3) return [spot.nums.join('・') + (z ? '（トリオ）' : '（ストリート）'), 11];
  if (n === 4) return z ? ['0・1・2・3（バスケット）', 6] : [spot.nums.join('・') + '（コーナー）', 8];
  return [spot.nums.join('・') + '（シックスライン）', 5];
}

// Map a point on the felt to the bet under it (null if none).
function pick(x, z) {
  const u = x / W + 6, v = z / H + 1.5;
  const mkOut = id => ({ t: id, nums: OUT_NUMS[id], key: id, center: [outCell(id).x, outCell(id).z], glow: { [id]: 1, ...Object.fromEntries(OUT_NUMS[id].map(n => ['n' + n, 0.3])) } });
  const mkIn = nums => {
    const s = nums.slice().sort((a, b) => a - b);
    return { t: null, nums: s, key: s.join('-'), center: spotCenter(s), glow: Object.fromEntries(s.map(n => ['n' + n, 1])) };
  };
  if (v >= 3 && v < 4 && u >= 0 && u < 12) return mkOut('dozen' + (Math.floor(u / 4) + 1));
  if (v >= 4 && v < 5 && u >= 0 && u < 12) return mkOut(EVEN_ROW[Math.floor(u / 2)]);
  if (u >= 12 && u < 13 && v >= 0 && v < 3) return mkOut(['col3', 'col2', 'col1'][Math.floor(v)]);
  if (!(v >= 0 && v < 3)) return null;
  if (u >= -1 && u < -EDGE) return mkIn([0]);
  if (!(u >= -EDGE && u < 12)) return null;

  const uu = Math.max(u, 0);
  const i = Math.min(11, Math.floor(uu)), j = Math.min(2, Math.floor(v));
  const fu = uu - i, fv = v - j;
  const nL = fu < EDGE, nR = fu > 1 - EDGE, nT = fv < EDGE, nB = fv > 1 - EDGE;
  const gi = nL ? i : nR ? i + 1 : null;
  const gj = nT ? j : nB ? j + 1 : null;
  const cols = (gi === null ? [i] : [gi - 1, gi]).filter(k => k >= 0 && k <= 11);
  const withZero = gi === 0;
  const outer = gj === 0 || gj === 3;
  const rows = outer ? [0, 1, 2] : (gj === null ? [j] : [gj - 1, gj].filter(r => r >= 0 && r <= 2));
  if (withZero && outer) return mkIn([0, 1, 2, 3]);
  const nums = [];
  for (const k of cols) for (const r of rows) nums.push(numAt(k, r));
  if (withZero) nums.push(0);
  return mkIn(nums);
}

// ---- textures / materials (cached per open session) ----
let texCache = {}, chipMats = {}, chipGeo = null;
function setSRGB(t) { if ('colorSpace' in t) t.colorSpace = THREE.SRGBColorSpace; else if (THREE.sRGBEncoding) t.encoding = THREE.sRGBEncoding; }
function canvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); setSRGB(t); t.anisotropy = 4; return t;
}
function roundRect(g, x, y, w, h, r) {
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
function labelTex(key, text, bg, fg, wide) {
  if (texCache[key]) return texCache[key];
  const w = wide ? 384 : 128, h = 128;
  return texCache[key] = canvasTex(w, h, (g) => {
    g.fillStyle = bg; roundRect(g, 3, 3, w - 6, h - 6, 10); g.fill();
    g.lineWidth = 5; g.strokeStyle = '#d8b04a'; g.stroke();
    g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = `700 ${text.length > 3 ? 52 : 70}px "Georgia","Hiragino Mincho ProN",serif`;
    g.fillText(text, w / 2, h / 2 + 4);
  });
}
function chipMaterials(d) {
  if (chipMats[d]) return chipMats[d];
  const st = CHIP_STYLE[d];
  const side = canvasTex(256, 32, (g, w, h) => {
    g.fillStyle = st.c; g.fillRect(0, 0, w, h); g.fillStyle = st.s;
    for (let i = 0; i < 6; i++) g.fillRect(i * (w / 6) + 6, 0, w / 12, h);
  });
  side.wrapS = THREE.RepeatWrapping;
  const top = canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = st.c; g.beginPath(); g.arc(w / 2, h / 2, w / 2, 0, 7); g.fill();
    g.strokeStyle = st.s; g.lineWidth = 16; g.setLineDash([28, 22]); g.beginPath(); g.arc(w / 2, h / 2, w / 2 - 12, 0, 7); g.stroke();
    g.setLineDash([]); g.lineWidth = 5; g.beginPath(); g.arc(w / 2, h / 2, w / 2 - 52, 0, 7); g.stroke();
    g.fillStyle = st.t; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = '800 ' + (st.label.length > 2 ? 64 : 76) + 'px "Georgia",serif'; g.fillText(st.label, w / 2, h / 2 + 4);
  });
  const sideM = new THREE.MeshStandardMaterial({ map: side, roughness: 0.55 });
  const topM = new THREE.MeshStandardMaterial({ map: top, roughness: 0.4 });
  return chipMats[d] = [sideM, topM, topM];
}
function makeChip(d, scale = 1) {
  if (!chipGeo) chipGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.09, 40);
  const m = new THREE.Mesh(chipGeo, chipMaterials(d));
  m.scale.set(scale, 1, scale); m.userData.denom = d;
  return m;
}
function frameGeo(w, h, t) {
  const s = new THREE.Shape();
  s.moveTo(-w / 2, -h / 2); s.lineTo(w / 2, -h / 2); s.lineTo(w / 2, h / 2); s.lineTo(-w / 2, h / 2); s.closePath();
  const hole = new THREE.Path();
  hole.moveTo(-w / 2 + t, -h / 2 + t); hole.lineTo(-w / 2 + t, h / 2 - t); hole.lineTo(w / 2 - t, h / 2 - t); hole.lineTo(w / 2 - t, -h / 2 + t); hole.closePath();
  s.holes.push(hole);
  return new THREE.ShapeGeometry(s);
}
function amountSprite(text, color) {
  const tex = canvasTex(256, 96, (g, w, h) => {
    g.fillStyle = 'rgba(10,10,10,.82)'; roundRect(g, 6, 14, w - 12, h - 28, 24); g.fill();
    g.strokeStyle = color || '#d8b04a'; g.lineWidth = 6; g.stroke();
    g.fillStyle = '#ffe9a8'; g.font = '700 46px "Georgia",serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(text, w / 2, h / 2 + 2);
  });
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  sp.scale.set(1.0, 0.375, 1); sp.renderOrder = 10; return sp;
}

// ---- styles ----
function injectStyle() {
  if (document.getElementById('rl-style')) return;
  const s = document.createElement('style'); s.id = 'rl-style';
  s.textContent = `
#rl-root{position:fixed;inset:0;z-index:100000;background:#06120c;color:#f3e7c4;font-family:"Hiragino Sans","Yu Gothic UI",system-ui,sans-serif;user-select:none;-webkit-user-select:none;display:flex;flex-direction:column}
.rl-stage{position:relative;flex:1 1 auto;min-height:0;overflow:hidden}
#rl-canvas{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none}
.rl-top{position:absolute;left:0;right:0;top:0;display:flex;gap:14px;align-items:center;padding:10px 14px 8px;background:linear-gradient(#000c,#0000);flex-wrap:wrap;pointer-events:none}
.rl-top>*{pointer-events:auto}
.rl-title{font:700 22px Georgia,"Times New Roman",serif;letter-spacing:.14em;color:#e5c35f}
.rl-count{font-size:13px;color:#cdb978;border:1px solid #d8b04a55;border-radius:999px;padding:2px 10px;background:#0006}
.rl-timer{font:700 26px Georgia,serif;font-variant-numeric:tabular-nums;padding:2px 14px;border:1px solid #d8b04a88;border-radius:8px;background:#0007}
.rl-timer.hot{color:#ff7a6b;border-color:#ff7a6b}
.rl-hist{display:flex;gap:5px;flex:1;min-width:120px;overflow:hidden}
.rl-hist i{font-style:normal;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font:700 12px Georgia,serif;color:#fff;border:1px solid #fff5;flex:none}
.rl-btn{background:#1a0f12;color:#f3e7c4;border:1px solid #d8b04a;border-radius:8px;padding:8px 14px;font-size:14px;cursor:pointer}
.rl-btn:hover{background:#34191e}.rl-btn:focus-visible{outline:2px solid #ffe27a;outline-offset:2px}
.rl-hint{position:absolute;left:50%;transform:translateX(-50%);top:58px;padding:6px 16px;border-radius:999px;background:#000a;border:1px solid #d8b04a66;font-size:15px;white-space:nowrap;max-width:94vw;overflow:hidden;text-overflow:ellipsis;pointer-events:none}
.rl-act{position:absolute;right:12px;bottom:10px;display:flex;gap:8px}
.rl-toast{position:absolute;left:50%;bottom:64px;transform:translateX(-50%);padding:8px 18px;border-radius:10px;background:#000d;border:1px solid #d8b04a;opacity:0;transition:opacity .25s;pointer-events:none;max-width:90vw;text-align:center}
.rl-toast.on{opacity:1}.rl-toast.err{border-color:#ff7a6b;color:#ffd2cc}
.rl-result{position:absolute;left:50%;top:42%;transform:translate(-50%,-50%) scale(.9);padding:18px 40px;border-radius:16px;background:#000d;border:2px solid #e5c35f;text-align:center;opacity:0;transition:opacity .3s,transform .3s;pointer-events:none;max-width:90vw}
.rl-result.on{opacity:1;transform:translate(-50%,-50%) scale(1)}
.rl-result .n{font:700 64px Georgia,serif;line-height:1.1}.rl-result .m{font-size:18px;margin-top:6px}
.rl-seats{flex:none;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;padding:12px 14px calc(12px + env(safe-area-inset-bottom));background:linear-gradient(#06120c,#020805);border-top:1px solid #d8b04a44}
.rl-seat{--c:#e5c35f;position:relative;min-width:0;padding:10px 14px 10px;border-radius:14px;background:linear-gradient(160deg,#241a1ff2,#0a0f0cf2);box-shadow:0 0 18px -4px var(--c),inset 0 0 22px -12px var(--c);transition:opacity .25s,box-shadow .25s}
.rl-seat::before{content:"";position:absolute;inset:0;border-radius:inherit;padding:2px;background:linear-gradient(135deg,var(--c),#fffbe8 38%,var(--c) 62%,#6b5420);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box exclude,linear-gradient(#000 0 0);pointer-events:none}
.rl-seat::after{content:"";position:absolute;left:10px;right:10px;top:4px;height:1px;background:linear-gradient(90deg,#0000,var(--c),#0000);opacity:.8;pointer-events:none}
.rl-seat.mine{box-shadow:0 0 26px -2px var(--c),inset 0 0 26px -10px var(--c);animation:rl-pulse 2.4s ease-in-out infinite}
.rl-seat.empty{opacity:.42;box-shadow:none;background:#0a0f0c99}
.rl-seat.empty::before{background:repeating-linear-gradient(90deg,#d8b04a66 0 8px,#0000 8px 14px);opacity:.7}
@keyframes rl-pulse{50%{box-shadow:0 0 34px 0 var(--c),inset 0 0 30px -8px var(--c)}}
.rl-seat-head{display:flex;align-items:center;gap:8px;min-width:0}
.rl-dot{flex:none;width:11px;height:11px;border-radius:50%;background:var(--c);box-shadow:0 0 8px var(--c)}
.rl-name{flex:1;min-width:0;font:700 16px/1.2 "Hiragino Sans","Yu Gothic UI",system-ui,sans-serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rl-you{flex:none;font:700 10px Georgia,serif;letter-spacing:.12em;color:#1a1204;background:var(--c);border-radius:4px;padding:2px 6px;display:none}
.rl-seat.mine .rl-you{display:inline-block}
.rl-row{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-top:5px;font-size:12px;color:#cdb978}
.rl-row b{font:700 18px Georgia,serif;color:#ffe9a8;font-variant-numeric:tabular-nums;white-space:nowrap}
.rl-row b small{font:12px "Hiragino Sans",sans-serif;color:#cdb978;margin-left:2px}
.rl-net{height:16px;margin-top:2px;font:700 13px Georgia,serif;text-align:right;font-variant-numeric:tabular-nums}
.rl-net.win{color:#7be08f}.rl-net.lose{color:#ff8f82}
.rl-fade{position:absolute;inset:0;background:#000;opacity:0;pointer-events:none;transition:opacity .4s ease}
.rl-mini{position:absolute;left:12px;bottom:10px;width:min(46vw,580px);display:none;padding:6px 8px 8px;border-radius:10px;background:#000b;border:1px solid #d8b04a88;pointer-events:none}
#rl-root.rl-wv .rl-mini{display:block}
#rl-root.rl-wv .rl-act{display:none}
.rl-mini-h{font:700 11px Georgia,"Hiragino Sans",serif;letter-spacing:.12em;color:#cdb978;margin:0 0 4px 2px}
.rl-mini-t{position:relative;width:100%;aspect-ratio:14/5;container-type:inline-size;background:#0c6b3b;border-radius:4px;overflow:hidden}
.rl-mc{position:absolute;box-sizing:border-box;border:1px solid #d8b04a66;display:grid;place-items:center;font:700 3cqw Georgia,serif;color:#fff;line-height:1}
.rl-mc.red{background:#b3262e}.rl-mc.black{background:#1b1b1f}.rl-mc.green{background:#12763f}.rl-mc.out{background:#0c5a32;font-size:2.1cqw}
.rl-mc.out.red{background:#b3262e}.rl-mc.out.black{background:#1b1b1f}
.rl-mc.winout{box-shadow:inset 0 0 0 .5cqw #ffe27aaa}
.rl-mc.win{z-index:2;box-shadow:0 0 2cqw .6cqw #ffe27a,inset 0 0 0 .6cqw #ffe27a;animation:rl-win 1s ease-in-out infinite}
@keyframes rl-win{50%{filter:brightness(1.7)}}
.rl-mb{position:absolute;inset:0;z-index:3}
.rl-cd{position:absolute;transform:translate(-50%,-50%);min-width:3.6cqw;height:3.6cqw;padding:0 .6cqw;box-sizing:border-box;border-radius:99px;display:grid;place-items:center;font:700 2cqw Georgia,serif;color:#111;box-shadow:0 0 0 .3cqw #000c,0 .3cqw .6cqw #000a;line-height:1;white-space:nowrap}
.rl-result .rl-rl{margin-top:12px;display:grid;gap:6px;text-align:left;min-width:min(78vw,380px)}
.rl-result .rl-rr{display:grid;grid-template-columns:auto 1fr auto;gap:4px 10px;align-items:center;padding:6px 10px;border-radius:8px;background:#ffffff10;font-size:14px}
.rl-result .rl-rr i{width:10px;height:10px;border-radius:50%;background:var(--c);box-shadow:0 0 6px var(--c)}
.rl-result .rl-rr b{font:700 15px Georgia,"Hiragino Sans",serif;font-variant-numeric:tabular-nums}
.rl-result .rl-rr b.win{color:#7be08f}.rl-result .rl-rr b.lose{color:#ff8f82}
.rl-result .rl-rr small{grid-column:2 / 4;color:#cdb978;font-size:12px}
@media (max-width:760px){.rl-seats{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:8px 10px calc(8px + env(safe-area-inset-bottom))}.rl-seat{padding:7px 10px}.rl-name{font-size:14px}.rl-row{margin-top:2px}.rl-row b{font-size:15px}.rl-net{height:14px}}
@media (max-width:640px){.rl-mini{width:min(76vw,380px)}.rl-title{font-size:17px}.rl-timer{font-size:20px}.rl-hint{font-size:12px;top:96px}.rl-hist i{width:22px;height:22px;font-size:11px}}
@media (prefers-reduced-motion:reduce){.rl-toast,.rl-result{transition:none}.rl-seat.mine{animation:none}}`;
  s.textContent += `
#rl-root{background:radial-gradient(ellipse at 50% 0%,#3a0f1a 0%,#14060a 55%,#06120c 100%)}
.rl-vig{position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at 50% 46%,#0000 52%,#000b 100%)}
.rl-bulbs{position:absolute;left:0;right:0;height:12px;pointer-events:none}
.rl-bulbs.rl-bt{top:2px}.rl-bulbs.rl-bb{bottom:2px}
.rl-bulbs i{position:absolute;inset:0;background:radial-gradient(circle at 50% 50%,#fffbe0 0 1.5px,#ffd24a 2.6px,#ffb12077 4.8px,#0000 6.5px) 0 50%/26px 100% repeat-x;filter:drop-shadow(0 0 3px #ffc84a);animation:rl-blink 1s steps(1) infinite}
.rl-bulbs i+i{background-position:13px 50%;animation-delay:.5s}
@keyframes rl-blink{0%,49%{opacity:1}50%,100%{opacity:.18}}
.rl-top{padding-top:16px;background:linear-gradient(#000d,#0000)}
.rl-title{background:linear-gradient(90deg,#b8862b,#fff3b0,#e5c35f,#fff3b0,#b8862b);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:rl-shine 4s linear infinite;filter:drop-shadow(0 0 6px #e5c35f66)}
.rl-title::before{content:"♠ ♥ "}.rl-title::after{content:" ♦ ♣"}
@keyframes rl-shine{to{background-position:-200% 0}}
.rl-timer{border-color:#ffd24a;box-shadow:0 0 12px #ffb12066,inset 0 0 10px #ffb12033;text-shadow:0 0 8px #ffd24a}
.rl-timer.hot{box-shadow:0 0 16px #ff7a6b99,inset 0 0 10px #ff7a6b44;text-shadow:0 0 8px #ff7a6b}
.rl-btn{background:linear-gradient(#3a1a22,#1a0a0e);box-shadow:0 0 8px #d8b04a44,inset 0 1px 0 #ffe9a833}
.rl-btn:hover{background:linear-gradient(#5a2a34,#2a1016)}
.rl-seats{background:linear-gradient(#14060a,#020805);border-top:2px solid #d8b04a;box-shadow:0 -4px 18px #000a,0 -1px 0 #ffe9a866}
.rl-hint{background:linear-gradient(#000c,#1a0a0ecc);border-color:#d8b04a99;box-shadow:0 0 12px #d8b04a33}
.rl-vol{display:flex;align-items:center;gap:6px;padding:4px 10px;border:1px solid #d8b04a;border-radius:8px;background:linear-gradient(#3a1a22,#1a0a0e);color:#ffe9a8}
.rl-vol input{width:clamp(80px,14vw,150px);height:28px;margin:0;accent-color:#ffd24a;touch-action:pan-y;cursor:pointer}
.rl-help-btn{position:absolute;right:12px;bottom:56px;border-radius:999px;padding:7px 16px;border-color:#ffe27a;color:#ffe9a8}
#rl-root.rl-wv .rl-help-btn{display:none}
.rl-result{z-index:6;background:radial-gradient(ellipse at 50% 0%,#4a1424f2,#12060af5 70%);border:2px solid #ffe27a;box-shadow:0 0 0 3px #6b5420,0 0 44px 4px #e5c35f88,inset 0 0 40px #e5c35f22}
.rl-result .hd{font:700 13px Georgia,serif;letter-spacing:.4em;color:#e5c35f}
.rl-result .n{width:118px;height:118px;margin:8px auto 0;border-radius:50%;display:grid;place-items:center;font:700 60px Georgia,serif;color:#fff;border:4px solid #ffe27a;box-shadow:0 0 26px #ffe27a88,inset 0 0 18px #0009}
.rl-confetti{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:5}
.rl-confetti i{position:absolute;top:-16px;width:8px;height:14px;opacity:.95;animation:rl-fall linear forwards}
@keyframes rl-fall{to{transform:translate(var(--dx),115vh) rotate(var(--rot))}}
.rl-modal{position:absolute;inset:0;z-index:20;display:none;place-items:center;background:#000c;padding:16px}
.rl-modal.on{display:grid}
.rl-modal-card{position:relative;width:min(94vw,760px);max-height:92%;overflow:auto;padding:18px 22px 20px;border-radius:16px;background:radial-gradient(ellipse at 50% 0%,#3a0f1a,#12060a 75%);border:2px solid #ffe27a;box-shadow:0 0 0 3px #6b5420,0 0 50px #e5c35f66}
.rl-modal-card h2{margin:0 0 4px;font:700 22px Georgia,"Hiragino Sans",serif;letter-spacing:.12em;color:#ffe27a;text-align:center}
.rl-modal-card p{margin:4px 0 10px;font-size:13px;color:#cdb978;text-align:center}
.rl-modal-card table{width:100%;border-collapse:collapse;font-size:13px}
.rl-modal-card th{font-weight:700;color:#ffe27a;border-bottom:1px solid #d8b04a;padding:5px 6px;text-align:left;white-space:nowrap}
.rl-modal-card td{padding:5px 6px;border-bottom:1px solid #d8b04a33;vertical-align:top}
.rl-modal-card td.m{font:700 15px Georgia,serif;color:#7be08f;white-space:nowrap}
.rl-modal-card td.p{font:700 14px Georgia,serif;color:#ffe9a8;white-space:nowrap;text-align:right}
.rl-modal-card ul{margin:10px 0 12px;padding-left:18px;font-size:12.5px;color:#e8d9a8;line-height:1.6}
.rl-modal-card .rl-btn{display:block;margin:0 auto;padding:8px 36px}
@media (max-width:640px){.rl-modal-card{padding:12px 10px}.rl-modal-card table{font-size:11.5px}.rl-help-btn{bottom:52px}}
`;
  document.head.appendChild(s);
}

// ==AUDIO-BEGIN==
// BGM = client/casino_bgm.mp3 (looped). Sound effects are synthesized with WebAudio and mixed on top.
const BGM_URL = new URL('casino_bgm.mp3', import.meta.url).href;
function createAudio() {
  const AC = window.AudioContext || window.webkitAudioContext;
  let vol = 0.6;
  try { const v = localStorage.getItem('rl-vol'); if (v !== null) vol = Math.min(1, Math.max(0, +v || 0)); } catch (e) { /* ignore */ }
  const BGM_VOL = 0.5;
  let duck = 1;
  const bgm = new Audio(BGM_URL); bgm.loop = true; bgm.preload = 'auto';
  const applyBgm = () => { bgm.volume = BGM_VOL * vol * duck; };
  applyBgm();
  let ctx = null, master = null, noise = null;
  if (AC) {
    try {
      ctx = new AC();
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -16; comp.knee.value = 24; comp.ratio.value = 4;
      master = ctx.createGain(); master.gain.value = 1.5 * vol;
      master.connect(comp); comp.connect(ctx.destination);
      noise = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const d = noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    } catch (e) { ctx = null; }
  }
  const ready = () => !!ctx && ctx.state === 'running';
  const jit = () => 0.92 + Math.random() * 0.16;
  function burst(t, o) {
    const src = ctx.createBufferSource(); src.buffer = noise;
    const f = ctx.createBiquadFilter(); f.type = o.type || 'bandpass'; f.frequency.setValueAtTime(o.f, t); f.Q.value = o.q || 1;
    if (o.f2) f.frequency.exponentialRampToValueAtTime(o.f2, t + o.dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(o.vol, t + (o.atk || 0.002)); g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t, Math.random() * 1.5); src.stop(t + o.dur + 0.05);
  }
  function tone(t, o) {
    const os = ctx.createOscillator(); os.type = o.type || 'sine'; os.frequency.setValueAtTime(o.f, t);
    if (o.f2) os.frequency.exponentialRampToValueAtTime(o.f2, t + o.dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(o.vol, t + (o.atk || 0.004)); g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    os.connect(g); g.connect(master); os.start(t); os.stop(t + o.dur + 0.05);
  }
  const A = {};
  A.chip = (vol = 1) => {                       // chip lands on the felt (two clacks)
    if (!ready()) return; const t = ctx.currentTime, j = jit();
    burst(t, { f: 4200 * j, q: 2.5, dur: 0.04, vol: 0.5 * vol });
    tone(t, { f: 2300 * j, f2: 1500, dur: 0.05, vol: 0.16 * vol, type: 'triangle' });
    tone(t, { f: 240, f2: 110, dur: 0.07, vol: 0.28 * vol });
    const t2 = t + 0.05 + Math.random() * 0.02;
    burst(t2, { f: 3300 * j, q: 2.2, dur: 0.035, vol: 0.4 * vol });
    tone(t2, { f: 1900 * j, f2: 1300, dur: 0.04, vol: 0.12 * vol, type: 'triangle' });
  };
  A.chipBack = () => {                          // chip taken back
    if (!ready()) return; const t = ctx.currentTime, j = jit();
    burst(t, { f: 3000 * j, q: 2, dur: 0.05, vol: 0.28 }); tone(t, { f: 1500 * j, f2: 900, dur: 0.06, vol: 0.1, type: 'triangle' });
  };
  A.chipSel = () => {                           // chip picked from the tray
    if (!ready()) return; const t = ctx.currentTime, j = jit();
    burst(t, { f: 5000 * j, q: 3, dur: 0.025, vol: 0.22 }); tone(t, { f: 2600 * j, f2: 2000, dur: 0.03, vol: 0.07, type: 'triangle' });
  };
  A.launch = () => {                            // ball is thrown in against the spinning wheel
    if (!ready()) return; const t = ctx.currentTime;
    burst(t, { f: 500, f2: 3800, q: 1.2, dur: 0.55, vol: 0.28, atk: 0.15 });
    tone(t + 0.05, { f: 1300, f2: 900, dur: 0.18, vol: 0.1, type: 'triangle' });
    for (let i = 0; i < 8; i++) {
      const tt = t + 0.14 + i * (0.06 + i * 0.012);
      burst(tt, { f: 2800 + Math.random() * 900, q: 3, dur: 0.025, vol: 0.3 - i * 0.02 });
      tone(tt, { f: 1700 + Math.random() * 400, dur: 0.025, vol: 0.07, type: 'triangle' });
    }
  };
  A.tick = (vol = 0.5) => {                     // ball ticks over a fret
    if (!ready()) return; const t = ctx.currentTime, j = jit();
    burst(t, { f: 2600 * j, q: 3, dur: 0.02, vol: 0.3 * vol }); tone(t, { f: 1700 * j, dur: 0.02, vol: 0.09 * vol, type: 'triangle' });
  };
  A.bounce = (vol = 0.7) => {                   // ball is knocked out of a pocket
    if (!ready()) return; const t = ctx.currentTime, j = jit();
    tone(t, { f: 1500 * j, f2: 700, dur: 0.09, vol: 0.3 * vol, type: 'triangle' });
    burst(t, { f: 3500 * j, q: 2, dur: 0.03, vol: 0.32 * vol });
    tone(t, { f: 300, f2: 150, dur: 0.08, vol: 0.2 * vol });
  };
  A.land = () => {                              // ball settles into the winning pocket
    if (!ready()) return; const t = ctx.currentTime;
    tone(t, { f: 170, f2: 70, dur: 0.28, vol: 0.5 });
    burst(t, { f: 900, type: 'lowpass', dur: 0.14, vol: 0.4 });
    burst(t, { f: 3200, q: 2, dur: 0.04, vol: 0.35 });
    [[1318.5, 0.12, 1.3], [1760, 0.09, 1.1], [2637, 0.06, 0.9]].forEach(([f, v, d], i) => tone(t + 0.06 + i * 0.05, { f, dur: d, vol: v }));
    tone(t + 0.06, { f: 1318.5 * 2.76, dur: 0.4, vol: 0.04 });
  };
  A.popup = (kind) => {                         // result popup jingle
    if (!ready()) return; const t = ctx.currentTime;
    if (kind === 'win') {
      [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => { tone(t + i * 0.11, { f, dur: 0.45, vol: 0.17, type: 'triangle' }); tone(t + i * 0.11, { f: f * 2, dur: 0.3, vol: 0.05 }); });
      [523.25, 659.25, 783.99, 1046.5].forEach(f => tone(t + 0.48, { f, dur: 1.1, vol: 0.1, type: 'triangle' }));
      for (let i = 0; i < 9; i++) tone(t + 0.6 + i * 0.07, { f: 2000 + Math.random() * 2500, dur: 0.25, vol: 0.05 });
    } else if (kind === 'lose') {
      [392, 329.63].forEach((f, i) => tone(t + i * 0.16, { f, dur: 0.5, vol: 0.13, type: 'triangle' }));
    } else {
      [440, 659.25, 880].forEach((f, i) => tone(t + i * 0.09, { f, dur: 0.9, vol: 0.09 }));
    }
  };
  A.coins = () => {                             // coin shower after a win
    if (!ready()) return; const t = ctx.currentTime + 0.5;
    for (let i = 0; i < 16; i++) {
      const tt = t + i * (0.05 + Math.random() * 0.04), f = 2200 + Math.random() * 1400;
      tone(tt, { f, f2: f * 1.04, dur: 0.18, vol: 0.06 }); burst(tt, { f: 6000, q: 2, dur: 0.03, vol: 0.12 });
    }
  };
  let hum = null;
  A.startSpin = () => {                         // wheel hum + ball rolling on the track (levels follow the animation)
    if (!ready() || hum) return; const t = ctx.currentTime;
    const mk = (type, f, q) => {
      const src = ctx.createBufferSource(); src.buffer = noise; src.loop = true;
      const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q;
      const g = ctx.createGain(); g.gain.value = 0; src.connect(fl); fl.connect(g); g.connect(master); src.start(t, Math.random()); return { src, fl, g };
    };
    const motor = ctx.createOscillator(); motor.type = 'sawtooth'; motor.frequency.value = 48;
    const mf = ctx.createBiquadFilter(); mf.type = 'lowpass'; mf.frequency.value = 180;
    const mg = ctx.createGain(); mg.gain.value = 0; motor.connect(mf); mf.connect(mg); mg.connect(master); motor.start(t);
    hum = { wheel: mk('lowpass', 300, 0.7), roll: mk('bandpass', 900, 2.5), motor, mg };
  };
  A.setSpin = (w, r) => {
    if (!hum || !ctx) return; const t = ctx.currentTime;
    hum.wheel.g.gain.setTargetAtTime(w * 0.12, t, 0.1); hum.wheel.fl.frequency.setTargetAtTime(200 + w * 400, t, 0.1);
    hum.roll.g.gain.setTargetAtTime(r * 0.26, t, 0.06); hum.roll.fl.frequency.setTargetAtTime(450 + r * 2200, t, 0.06);
    hum.motor.frequency.setTargetAtTime(38 + w * 30, t, 0.1); hum.mg.gain.setTargetAtTime(w * 0.05, t, 0.1);
  };
  A.stopSpin = () => {
    if (!hum || !ctx) return; const h = hum; hum = null; const t = ctx.currentTime;
    [h.wheel.g, h.roll.g, h.mg].forEach(g => g.gain.setTargetAtTime(0, t, 0.08));
    setTimeout(() => { try { h.wheel.src.stop(); h.roll.src.stop(); h.motor.stop(); } catch (e) { /* ignore */ } }, 700);
  };
  A.getVol = () => vol;
  A.setVol = v => {
    vol = Math.min(1, Math.max(0, v));
    try { localStorage.setItem('rl-vol', String(vol)); } catch (e) { /* ignore */ }
    applyBgm(); if (master && ctx) master.gain.setTargetAtTime(1.5 * vol, ctx.currentTime, 0.03);
  };
  A.setDuck = k => { duck = k; applyBgm(); };
  const unlock = () => {
    try { if (ctx && ctx.state !== 'running') ctx.resume(); } catch (e) { /* ignore */ }
    if (bgm.paused && !document.hidden) bgm.play().catch(() => {});
  };
  const onVis = () => {
    if (document.hidden) { bgm.pause(); try { ctx && ctx.suspend(); } catch (e) { /* ignore */ } } else unlock();
  };
  ['pointerdown', 'keydown', 'touchend'].forEach(ev => window.addEventListener(ev, unlock, true));
  document.addEventListener('visibilitychange', onVis);
  unlock();
  A.destroy = () => {
    ['pointerdown', 'keydown', 'touchend'].forEach(ev => window.removeEventListener(ev, unlock, true));
    document.removeEventListener('visibilitychange', onVis);
    A.stopSpin();
    try { bgm.pause(); bgm.removeAttribute('src'); bgm.load(); } catch (e) { /* ignore */ }
    try { ctx && ctx.close(); } catch (e) { /* ignore */ }
  };
  return A;
}
// ==AUDIO-END==

const numColor = n => n === 0 ? '#12763f' : RED.has(n) ? '#b3262e' : '#1b1b1f';
let S = null;

export function openRoulette() {
  if (S) return;
  injectStyle();
  texCache = {}; chipMats = {}; chipGeo = null;

  const root = document.createElement('div');
  root.id = 'rl-root';
  root.innerHTML = `
    <div class="rl-stage" id="rl-stage">
      <canvas id="rl-canvas"></canvas>
      <div class="rl-vig"></div><div class="rl-bulbs rl-bt"><i></i><i></i></div><div class="rl-bulbs rl-bb"><i></i><i></i></div>
      <div class="rl-fade" id="rl-fade"></div>
      <div class="rl-top">
        <div class="rl-title">ROULETTE</div>
        <div class="rl-count" id="rl-count">着席 -/${MAX_SEATS}</div>
        <div class="rl-timer" id="rl-timer">--:--</div>
        <div class="rl-hist" id="rl-hist" aria-label="直近の当選番号"></div>
        <label class="rl-vol" title="音量"><span>♪</span><input type="range" id="rl-vol" min="0" max="100" step="1" aria-label="音量"></label>
        <button class="rl-btn" id="rl-close" type="button">閉じる</button>
      </div>
      <div class="rl-hint" id="rl-hint">手前のチップを選んで、テーブルをクリックしてベット</div>
      <div class="rl-act">
        <button class="rl-btn" id="rl-undo" type="button">1つ戻す</button>
        <button class="rl-btn" id="rl-clear" type="button">全部戻す</button>
      </div>
      <button class="rl-btn rl-help-btn" id="rl-help-btn" type="button">配当説明</button>
      <div class="rl-modal" id="rl-modal"><div class="rl-modal-card" role="dialog" aria-modal="true" aria-label="配当説明" id="rl-modal-card"></div></div>
      <div class="rl-mini" id="rl-mini"><div class="rl-mini-h">BETS</div><div class="rl-mini-t" id="rl-mini-t"><div class="rl-mb" id="rl-mb"></div></div></div>
      <div class="rl-toast" id="rl-toast" role="status"></div>
      <div class="rl-result" id="rl-result" role="status"></div>
    </div>
    <div class="rl-seats" id="rl-seats"></div>`;
  document.body.appendChild(root);
  const $ = id => root.querySelector('#' + id);
  const au = createAudio();
  const seatEls = [];
  for (let i = 0; i < MAX_SEATS; i++) {
    const d = document.createElement('div');
    d.className = 'rl-seat empty'; d.style.setProperty('--c', SEAT_COLORS[i]);
    d.innerHTML = '<div class="rl-seat-head"><span class="rl-dot"></span><span class="rl-name"></span><span class="rl-you">YOU</span></div>'
      + '<div class="rl-row"><span>所持金</span><b class="rl-b-bal">-</b></div>'
      + '<div class="rl-row"><span>ベット合計</span><b class="rl-b-tot">-</b></div>'
      + '<div class="rl-net"></div>';
    $('rl-seats').appendChild(d);
    seatEls.push({ el: d, name: d.querySelector('.rl-name'), bal: d.querySelector('.rl-b-bal'), tot: d.querySelector('.rl-b-tot'), net: d.querySelector('.rl-net') });
  }

  const canvas = $('rl-canvas');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  if ('outputColorSpace' in renderer) renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x06120c);
  const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);

  scene.add(new THREE.HemisphereLight(0xfff1d0, 0x15251c, 1.5));
  const key = new THREE.DirectionalLight(0xffe2ad, 2.2); key.position.set(-4, 12, 8); scene.add(key);
  const fill = new THREE.DirectionalLight(0x9fc8ff, 0.5); fill.position.set(8, 6, -4); scene.add(fill);

  // ---- table body ----
  const TX0 = -9.2, TX1 = 9.2, TZ0 = -4.7, TZ1 = 6.0;
  const tcx = (TX0 + TX1) / 2, tcz = (TZ0 + TZ1) / 2, tw = TX1 - TX0, td = TZ1 - TZ0;
  const feltTex = canvasTex(1536, 894, (g, w, h) => {
    const gr = g.createRadialGradient(w / 2, h * 0.45, 40, w / 2, h / 2, w * 0.62);
    gr.addColorStop(0, '#13874a'); gr.addColorStop(1, '#09451f'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(255,255,255,0.045)'; g.lineWidth = 2;
    for (let k = -h; k < w + h; k += 64) { g.beginPath(); g.moveTo(k, 0); g.lineTo(k + h, h); g.stroke(); g.beginPath(); g.moveTo(k + h, 0); g.lineTo(k, h); g.stroke(); }
    g.strokeStyle = '#d8b04a'; g.lineWidth = 5; roundRect(g, 26, 26, w - 52, h - 52, 28); g.stroke();
    g.lineWidth = 2; roundRect(g, 42, 42, w - 84, h - 84, 20); g.stroke();
    g.fillStyle = 'rgba(216,176,74,0.55)'; g.font = '700 72px Georgia,"Segoe UI Symbol",serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    [['\u2660', 100, 100], ['\u2665', w - 100, 100], ['\u2666', 100, h - 100], ['\u2663', w - 100, h - 100]].forEach(([c, x, y]) => g.fillText(c, x, y));
  });
  const felt = new THREE.Mesh(new THREE.PlaneGeometry(tw, td), new THREE.MeshStandardMaterial({ map: feltTex, roughness: 0.95 }));
  felt.rotation.x = -Math.PI / 2; felt.position.set(tcx, 0, tcz); scene.add(felt);
  const wood = new THREE.MeshStandardMaterial({ color: 0x3b1f12, roughness: 0.55, metalness: 0.1 });
  const brass = new THREE.MeshStandardMaterial({ color: 0xc9a227, roughness: 0.3, metalness: 0.85 });
  const rim = (x, z, w, d) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.5, d), wood); m.position.set(x, 0.05, z); scene.add(m); };
  rim(tcx, TZ0 - 0.5, tw + 2, 1); rim(tcx, TZ1 + 0.5, tw + 2, 1); rim(TX0 - 0.5, tcz, 1, td); rim(TX1 + 0.5, tcz, 1, td);
  const inlay = (x, z, w, d) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.04, d), brass); m.position.set(x, 0.31, z); scene.add(m); };
  const tbA = new THREE.MeshStandardMaterial({ color: 0x3a2a08, emissive: 0xffc84a, emissiveIntensity: 1.2 });
  const tbB = new THREE.MeshStandardMaterial({ color: 0x3a2a08, emissive: 0xffc84a, emissiveIntensity: 0.3 });
  const tbGeo = new THREE.SphereGeometry(0.11, 12, 8);
  let tbi = 0;
  const bulbAt = (x, z) => { const m = new THREE.Mesh(tbGeo, (tbi++ & 1) ? tbA : tbB); m.position.set(x, 0.44, z); scene.add(m); };
  for (let x = TX0 - 1; x <= TX1 + 1.01; x += 0.7) { bulbAt(x, TZ0 - 0.5); bulbAt(x, TZ1 + 0.5); }
  for (let z = TZ0 + 0.35; z < TZ1 + 0.2; z += 0.7) { bulbAt(TX0 - 0.5, z); bulbAt(TX1 + 0.5, z); }
  inlay(tcx, TZ0 - 0.04, tw, 0.08); inlay(tcx, TZ1 + 0.04, tw, 0.08); inlay(TX0 - 0.04, tcz, 0.08, td); inlay(TX1 + 0.04, tcz, 0.08, td);
  const carpet = canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = '#2a0a14'; g.fillRect(0, 0, w, h);
    g.strokeStyle = '#6b5420'; g.lineWidth = 3;
    g.beginPath(); g.moveTo(w / 2, 8); g.lineTo(w - 8, h / 2); g.lineTo(w / 2, h - 8); g.lineTo(8, h / 2); g.closePath(); g.stroke();
    g.fillStyle = '#8a6a22'; g.beginPath(); g.arc(w / 2, h / 2, 9, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#4a1422'; [[0, 0], [w, 0], [0, h], [w, h]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 30, 0, Math.PI * 2); g.fill(); });
  });
  carpet.wrapS = carpet.wrapT = THREE.RepeatWrapping; carpet.repeat.set(14, 14);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), new THREE.MeshStandardMaterial({ map: carpet, roughness: 1 }));
  floor.rotation.x = -Math.PI / 2; floor.position.y = -0.6; scene.add(floor);

  const wm = new THREE.Mesh(new THREE.PlaneGeometry(9, 1.7), new THREE.MeshBasicMaterial({
    map: canvasTex(900, 170, (g, w, h) => {
      g.fillStyle = '#d8b04a'; g.globalAlpha = 0.55; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.font = '700 120px Georgia,serif'; g.fillText('R O U L E T T E', w / 2, h / 2);
    }), transparent: true, depthWrite: false }));
  wm.rotation.x = -Math.PI / 2; wm.position.set(0, 0.012, -3.2); scene.add(wm);

  // ---- number cells + glow overlays ----
  const glow = {};                  // id -> {fill, frame, cur}
  const addCell = (id, x, z, sx, sz, tex) => {
    const cell = new THREE.Mesh(new THREE.PlaneGeometry(sx * 0.95, sz * 0.95), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.8 }));
    cell.rotation.x = -Math.PI / 2; cell.position.set(x, 0.02, z); scene.add(cell);
    const mat = () => new THREE.MeshBasicMaterial({ color: 0xffe27a, transparent: true, opacity: 0, depthWrite: false, toneMapped: false });
    const fillM = new THREE.Mesh(new THREE.PlaneGeometry(sx * 0.95, sz * 0.95), mat());
    fillM.rotation.x = -Math.PI / 2; fillM.position.set(x, 0.03, z); scene.add(fillM);
    const frameM = new THREE.Mesh(frameGeo(sx * 0.97, sz * 0.97, 0.07), mat());
    frameM.rotation.x = -Math.PI / 2; frameM.position.set(x, 0.035, z); scene.add(frameM);
    glow[id] = { fill: fillM, frame: frameM, cur: 0 };
  };
  for (let n = 0; n <= 36; n++) {
    const [x, z] = cellXZ(n);
    addCell('n' + n, x, z, W, n === 0 ? 3 * H : H, labelTex('n' + n, String(n), numColor(n), '#fff'));
  }
  for (const o of OUT_CELLS) {
    const bg = o.id === 'red' ? '#b3262e' : o.id === 'black' ? '#1b1b1f' : '#0c5a32';
    addCell(o.id, o.x, o.z, o.sx, o.sz, labelTex(o.id, OUT_LABEL[o.id], bg, '#fff', o.sx > W * 1.5));
  }
  const marker = new THREE.Mesh(new THREE.RingGeometry(0.13, 0.22, 28), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95, toneMapped: false, depthTest: false }));
  marker.rotation.x = -Math.PI / 2; marker.position.y = 0.08; marker.visible = false; marker.renderOrder = 9; scene.add(marker);

  // ---- chip tray (select your chip here) ----
  const tray = new THREE.Group(); scene.add(tray);
  const trayMeshes = [], trayStacks = {};
  CHIPS.forEach((d, i) => {
    const g = new THREE.Group(); g.position.set((i - 2) * 1.9, 0.04, 4.95);
    for (let k = 0; k < 6; k++) { const c = makeChip(d); c.position.y = 0.05 + k * 0.095; g.add(c); trayMeshes.push(c); }
    tray.add(g); trayStacks[d] = g;
  });
  const selRing = new THREE.Mesh(new THREE.RingGeometry(0.5, 0.62, 40), new THREE.MeshBasicMaterial({ color: 0xffe27a, transparent: true, opacity: 0.9, toneMapped: false }));
  selRing.rotation.x = -Math.PI / 2; selRing.position.y = 0.03; scene.add(selRing);

  const betGroup = new THREE.Group(); scene.add(betGroup);

  // ---- wheel scene (shown from the moment betting closes until the next round opens) ----
  const wscene = new THREE.Scene();
  wscene.background = new THREE.Color(0x050d09);
  const wcam = new THREE.PerspectiveCamera(40, 1, 0.1, 100);
  wscene.add(new THREE.HemisphereLight(0xfff1d0, 0x1a1210, 1.2));
  const wkey = new THREE.DirectionalLight(0xffe2ad, 2.6); wkey.position.set(-5, 11, 7); wscene.add(wkey);
  const wfill = new THREE.DirectionalLight(0x9fc8ff, 0.7); wfill.position.set(8, 6, -5); wscene.add(wfill);
  const wback = new THREE.DirectionalLight(0xffc880, 0.9); wback.position.set(0, 3, -9); wscene.add(wback);
  let pmrem = null, envTex = null;
  try {                                   // small studio environment so the brass and lacquer have something to reflect
    pmrem = new THREE.PMREMGenerator(renderer);
    const es = new THREE.Scene();
    es.background = new THREE.Color(0x1a1410);
    const panel = (c, w, h, x, y, z) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(3), side: THREE.DoubleSide }));
      m.position.set(x, y, z); m.lookAt(0, 0, 0); es.add(m);
    };
    panel(0xfff2d6, 14, 6, 0, 12, 4); panel(0xbfd8ff, 8, 8, -12, 5, 0); panel(0xffd9a0, 8, 8, 12, 4, 6); panel(0x442a1a, 30, 30, 0, -10, 0);
    envTex = pmrem.fromScene(es, 0.03).texture;
    wscene.environment = envTex;
    es.traverse(o => { o.geometry?.dispose?.(); o.material?.dispose?.(); });
  } catch (e) { console.warn('roulette env map skipped', e); }

  const stdMat = o => new THREE.MeshStandardMaterial(o);
  const woodW = stdMat({ color: 0x4a2412, roughness: 0.38, metalness: 0.12, side: THREE.DoubleSide });
  const lacqW = stdMat({ color: 0x2b1409, roughness: 0.2, metalness: 0.3, side: THREE.DoubleSide });
  const goldW = stdMat({ color: 0xd9b13a, roughness: 0.3, metalness: 0.9 });
  const coneW = stdMat({ color: 0x6a3b1c, roughness: 0.3, metalness: 0.2 });
  const V2 = a => a.map(p => new THREE.Vector2(p[0], p[1]));
  const wfelt = new THREE.Mesh(new THREE.CircleGeometry(14, 64), stdMat({ map: canvasTex(1024, 1024, (g, w, h) => {
    const gr = g.createRadialGradient(w / 2, h / 2, 20, w / 2, h / 2, w / 2);
    gr.addColorStop(0, '#12803f'); gr.addColorStop(0.55, '#0a4a26'); gr.addColorStop(1, '#030f08'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(255,255,255,0.04)'; g.lineWidth = 2;
    for (let k = -h; k < w + h; k += 56) { g.beginPath(); g.moveTo(k, 0); g.lineTo(k + h, h); g.stroke(); g.beginPath(); g.moveTo(k + h, 0); g.lineTo(k, h); g.stroke(); }
    g.strokeStyle = '#d8b04a'; [[0.372, 5], [0.4, 2], [0.47, 3]].forEach(([f, lw]) => { g.lineWidth = lw; g.beginPath(); g.arc(w / 2, h / 2, f * w, 0, Math.PI * 2); g.stroke(); });
  }), roughness: 0.95 }));
  wfelt.rotation.x = -Math.PI / 2; wfelt.position.y = -0.85; wscene.add(wfelt);
  // static bowl: wooden rim + sloped ball track (same height function the ball uses)
  wscene.add(new THREE.Mesh(new THREE.LatheGeometry(V2([[4.95, -0.8], [4.95, 0.45], [4.85, 0.58], [4.55, 0.62], [4.3, 0.54], [4.2, 0.5]]), 96), woodW));
  const trk = [];
  for (let r = 4.2; r >= R_EDGE - 1e-6; r -= 0.05) trk.push([r, trackH(r)]);
  trk.push([3.0, -0.05], [2.9, -0.8], [0.01, -0.8]);
  wscene.add(new THREE.Mesh(new THREE.LatheGeometry(V2(trk), 96), lacqW));
  const goldRing = (r, y, t) => {
    const m = new THREE.Mesh(new THREE.TorusGeometry(r, t, 8, 96), goldW);
    m.rotation.x = Math.PI / 2; m.position.y = y; wscene.add(m);
  };
  goldRing(4.62, 0.62, 0.03); goldRing(4.2, 0.5, 0.03); goldRing(3.07, 0.0, 0.025);

  // rotor: numbered pockets, frets, cone, turret and the four-armed cross
  const rotor = new THREE.Group(); wscene.add(rotor);
  const ringTex = canvasTex(2048, 2048, (g, w, h) => {
    const cx = w / 2, cy = h / 2, sc = (w / 2) / R_EDGE, rIn = 2.35 * sc, rOut = R_EDGE * sc;
    g.fillStyle = '#c9a227'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 37; i++) {
      const n = WHEEL_ORDER[i], a0 = (i - 0.5) * PK - Math.PI / 2, a1 = (i + 0.5) * PK - Math.PI / 2;
      g.beginPath(); g.arc(cx, cy, rOut, a0, a1); g.arc(cx, cy, rIn, a1, a0, true); g.closePath();
      g.fillStyle = n === 0 ? '#12763f' : RED.has(n) ? '#b3262e' : '#16161a'; g.fill();
      g.save(); g.translate(cx, cy); g.rotate(i * PK); g.translate(0, -(rIn + (rOut - rIn) * 0.52)); g.rotate(Math.PI);   // digits read upright at the front
      g.fillStyle = '#fff'; g.font = '700 104px Georgia,serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(n), 0, 0); g.restore();
    }
  });
  const pockets = new THREE.Mesh(new THREE.RingGeometry(2.35, R_EDGE, 74, 1), stdMat({ map: ringTex, roughness: 0.32, metalness: 0.1 }));
  pockets.rotation.x = -Math.PI / 2; pockets.position.y = 0.002; rotor.add(pockets);
  const fretGeo = new THREE.BoxGeometry(0.025, 0.11, 0.72);
  for (let i = 0; i < 37; i++) {
    const b = (i + 0.5) * PK, f = new THREE.Mesh(fretGeo, goldW);
    f.position.set(2.7 * Math.sin(b), 0.055, -2.7 * Math.cos(b)); f.rotation.y = Math.PI - b; rotor.add(f);
  }
  rotor.add(new THREE.Mesh(new THREE.LatheGeometry(V2([[2.35, 0], [2.3, 0.06], [1.5, 0.4], [0.95, 0.62], [0.6, 0.72], [0.45, 0.74]]), 72), coneW));
  rotor.add(new THREE.Mesh(new THREE.LatheGeometry(V2([[0.5, 0.72], [0.38, 0.78], [0.22, 1.0], [0.13, 1.3], [0.01, 1.34]]), 40), goldW));
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.2, 24, 16), goldW); knob.position.y = 1.45; rotor.add(knob);
  for (let k = 0; k < 4; k++) {
    const arm = new THREE.Group(); arm.rotation.y = k * Math.PI / 2;
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.1, 10), goldW); rod.rotation.z = Math.PI / 2; rod.position.set(0.55, 1.0, 0); arm.add(rod);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.075, 14, 10), goldW); tip.position.set(1.1, 1.0, 0); arm.add(tip);
    rotor.add(arm);
  }
  const winRing = new THREE.Mesh(new THREE.RingGeometry(0.13, 0.23, 32), new THREE.MeshBasicMaterial({ color: 0xffe27a, transparent: true, opacity: 0, toneMapped: false, depthWrite: false }));
  winRing.rotation.x = -Math.PI / 2; winRing.position.y = 0.03; rotor.add(winRing);
  const ballMesh = new THREE.Mesh(new THREE.SphereGeometry(BALL_R, 24, 16), stdMat({ color: 0xf6f6f0, roughness: 0.15, metalness: 0.1, emissive: 0x2a2a28 }));
  ballMesh.scale.setScalar(1.9); wscene.add(ballMesh);

  // ---- casino decor around the wheel: chasing bulbs, drifting gold dust, win sparkle ----
  const wbMats = [0, 1, 2].map(() => stdMat({ color: 0x3a2a08, emissive: 0xffc84a, emissiveIntensity: 0.4 }));
  const wbGeo = new THREE.SphereGeometry(0.13, 12, 8);
  for (let i = 0; i < 44; i++) { const a = i / 44 * TAU, m = new THREE.Mesh(wbGeo, wbMats[i % 3]); m.position.set(5.6 * Math.cos(a), -0.66, 5.6 * Math.sin(a)); wscene.add(m); }
  const DN = 140, dustPos = new Float32Array(DN * 3), dustSeed = [], dustSp = [];
  for (let i = 0; i < DN; i++) { dustPos[i * 3] = (Math.random() - 0.5) * 18; dustPos[i * 3 + 2] = (Math.random() - 0.5) * 14; dustSeed.push(Math.random() * 7); dustSp.push(0.15 + Math.random() * 0.3); }
  const dustGeo = new THREE.BufferGeometry(); dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
  const dust = new THREE.Points(dustGeo, new THREE.PointsMaterial({ color: 0xffe9a8, size: 0.07, transparent: true, opacity: 0.7, depthWrite: false }));
  dust.frustumCulled = false; wscene.add(dust);
  const BN = 70, burstPos = new Float32Array(BN * 3), bvel = new Float32Array(BN * 3), bo = [0, 0, 0];
  const burstGeo = new THREE.BufferGeometry(); burstGeo.setAttribute('position', new THREE.BufferAttribute(burstPos, 3));
  const burst = new THREE.Points(burstGeo, new THREE.PointsMaterial({ color: 0xfff0b0, size: 0.13, transparent: true, opacity: 0, depthWrite: false, toneMapped: false }));
  burst.frustumCulled = false; burst.visible = false; wscene.add(burst);
  let burstT = -99;
  function triggerBurst(t, p) {
    burstT = t; bo[0] = p.x; bo[1] = p.y; bo[2] = p.z;
    for (let i = 0; i < BN; i++) { const a = Math.random() * TAU, sp = 0.8 + Math.random() * 2.2; bvel[i * 3] = Math.cos(a) * sp; bvel[i * 3 + 1] = 1.5 + Math.random() * 2.5; bvel[i * 3 + 2] = Math.sin(a) * sp; }
    burst.visible = true;
  }
  function animDecor(t) {
    const k = Math.floor(t * 7) % 3;
    wbMats.forEach((m, i) => { m.emissiveIntensity = i === k ? 1.8 : 0.25; });
    const on = Math.sin(t * 5) > 0;
    tbA.emissiveIntensity = on ? 1.6 : 0.3; tbB.emissiveIntensity = on ? 0.3 : 1.6;
    if (S.view !== 'wheel') return;
    for (let i = 0; i < DN; i++) dustPos[i * 3 + 1] = -0.5 + ((dustSeed[i] + t * dustSp[i]) % 7);
    dustGeo.attributes.position.needsUpdate = true;
    const age = t - burstT;
    if (age < 1.8) {
      for (let i = 0; i < BN; i++) {
        burstPos[i * 3] = bo[0] + bvel[i * 3] * age; burstPos[i * 3 + 1] = bo[1] + bvel[i * 3 + 1] * age - 2.6 * age * age; burstPos[i * 3 + 2] = bo[2] + bvel[i * 3 + 2] * age;
      }
      burstGeo.attributes.position.needsUpdate = true; burst.material.opacity = 1 - age / 1.8;
    } else burst.visible = false;
  }

  // ---- mini table: where everybody bet (DOM, shown beside the wheel) ----
  const miniBox = $('rl-mini-t'), miniBets = $('rl-mb'), miniCells = {};
  const miniPct = (x, z) => [((x / W + 7) / 14) * 100, ((z / H + 1.5) / 5) * 100];
  const addMini = (id, x, z, sx, sz, text, cls) => {
    const d = document.createElement('div'); d.className = 'rl-mc ' + cls;
    d.style.left = ((x - sx / 2) / W + 7) / 14 * 100 + '%'; d.style.top = ((z - sz / 2) / H + 1.5) / 5 * 100 + '%';
    d.style.width = sx / W / 14 * 100 + '%'; d.style.height = sz / H / 5 * 100 + '%';
    d.textContent = text; miniBox.insertBefore(d, miniBets); miniCells[id] = d;
  };
  for (let n = 0; n <= 36; n++) {
    const [x, z] = cellXZ(n);
    addMini('n' + n, x, z, W, n === 0 ? 3 * H : H, String(n), n === 0 ? 'green' : RED.has(n) ? 'red' : 'black');
  }
  for (const o of OUT_CELLS) addMini(o.id, o.x, o.z, o.sx, o.sz, OUT_LABEL[o.id], 'out' + (o.id === 'red' ? ' red' : o.id === 'black' ? ' black' : ''));
  const abbr = a => a >= 1000 ? (a % 1000 ? (a / 1000).toFixed(1) : a / 1000) + 'K' : String(a);
  function drawMiniBets() {
    miniBets.textContent = '';
    const spots = new Map();
    for (const p of S.players) for (const b of (p.bets || [])) {
      const key = outCell(b.t) ? b.t : b.nums.join('-');
      if (!spots.has(key)) spots.set(key, { b, list: [] });
      spots.get(key).list.push({ seat: p.seat, amount: b.amount });
    }
    for (const { b, list } of spots.values()) {
      const [cx, cz] = outCell(b.t) ? [outCell(b.t).x, outCell(b.t).z] : spotCenter(b.nums);
      const [px, py] = miniPct(cx, cz);
      list.forEach((e, k) => {
        const d = document.createElement('div'); d.className = 'rl-cd';
        d.style.left = px + '%'; d.style.top = py + '%'; d.style.background = SEAT_COLORS[e.seat % MAX_SEATS];
        d.style.marginLeft = (k - (list.length - 1) / 2) * 3.9 + 'cqw';
        d.textContent = abbr(e.amount); miniBets.appendChild(d);
      });
    }
  }
  function markWin(number) {
    for (const id in miniCells) miniCells[id].classList.remove('win', 'winout');
    if (number == null) return;
    miniCells['n' + number]?.classList.add('win');
    for (const id in OUT_NUMS) if (OUT_NUMS[id].includes(number)) miniCells[id]?.classList.add('winout');
  }

  // ---- session state ----
  S = {
    root, renderer, scene, camera, raf: 0, selected: 1000, spot: null, hoverChip: null, armed: null,
    state: null, offset: 0, sending: 0, toastT: 0, resultT: 0, lastW: 0, lastH: 0,
    me: -1, players: [], nets: {}, netT: 0, betSig: '', closeT: 0,
    view: 'table', fadeTo: null, fadeT: 0, viewInit: false, plan: null, popup: false, hintTxt: '',
  };

  function fit() {
    const w = canvas.clientWidth || window.innerWidth, h = canvas.clientHeight || window.innerHeight;
    if (w === S.lastW && h === S.lastH) return;
    S.lastW = w; S.lastH = h;
    renderer.setSize(w, h, false);
    const aspect = w / h; camera.aspect = aspect; wcam.aspect = aspect; wcam.updateProjectionMatrix();
    const tanV = Math.tan(camera.fov * Math.PI / 360);
    const distW = 9.5 / (tanV * aspect * 0.97) + 2.7;           // whole table width in view
    const distH = 3.69 / (tanV * 0.94) + 2.6;                    // number grid .. chip tray in view (stage is short: panels sit below)
    const dist = Math.max(distW, distH, 11);
    const tgt = new THREE.Vector3(0, 0, 1.1);
    const dir = new THREE.Vector3(0, 0.82, 0.57).normalize();
    camera.position.copy(tgt).addScaledVector(dir, dist);
    camera.lookAt(tgt); camera.updateProjectionMatrix();
  }

  // ---- bets drawn on the table (everyone's, seat colour on the amount tag) ----
  const owned = [];
  const seatMats = SEAT_COLORS.map(c => new THREE.MeshBasicMaterial({ color: new THREE.Color(c), transparent: true, opacity: 0.9, toneMapped: false }));
  const baseGeo = new THREE.RingGeometry(0.27, 0.36, 28);
  function clearBetMeshes() {
    for (const o of owned) { o.material?.map?.dispose?.(); o.material?.dispose?.(); }
    owned.length = 0;
    while (betGroup.children.length) betGroup.remove(betGroup.children[0]);
  }
  function drawBets() {
    clearBetMeshes();
    const spots = new Map();                                      // same spot -> everyone who bet there
    for (const p of S.players) for (const b of (p.bets || [])) {
      const key = outCell(b.t) ? b.t : b.nums.join('-');           // server sends t='straight'/'split'.. for inside bets: key by position, not by type
      if (!spots.has(key)) spots.set(key, { b, list: [] });
      spots.get(key).list.push({ seat: p.seat, amount: b.amount });
    }
    for (const { b, list } of spots.values()) {
      const [cx, cz] = b.t && outCell(b.t) ? [outCell(b.t).x, outCell(b.t).z] : spotCenter(b.nums);
      list.forEach((e, k) => {
        const g = new THREE.Group(); g.position.set(cx + (k - (list.length - 1) / 2) * 0.34, 0.03, cz);
        const base = new THREE.Mesh(baseGeo, seatMats[e.seat % MAX_SEATS]);
        base.rotation.x = -Math.PI / 2; base.position.y = 0.012; g.add(base);
        let rest = e.amount, y = 0;
        for (const d of [...CHIPS].reverse()) {
          let n = Math.floor(rest / d); rest -= n * d;
          while (n-- > 0 && y < 16) { const c = makeChip(d, 0.66); c.position.y = 0.05 + y * 0.09; g.add(c); y++; }
        }
        const sp = amountSprite(fmt(e.amount), SEAT_COLORS[e.seat % MAX_SEATS]);
        sp.position.set(0, 0.25 + y * 0.09 + 0.2, 0.3 + (list.length > 1 ? k * 0.3 : 0));
        owned.push(sp); g.add(sp); betGroup.add(g);
      });
    }
  }

  // ---- HUD ----
  const colorBg = n => n === 0 ? '#12763f' : RED.has(n) ? '#b3262e' : '#222';
  const mine = () => S.players.find(p => p.seat === S.me) || null;
  function drawHud() {
    const st = S.state; if (!st) return;
    $('rl-count').textContent = `着席 ${S.players.length}/${st.max_seats || MAX_SEATS}`;
    const h = $('rl-hist'); h.textContent = '';
    for (const n of st.history || []) { const i = document.createElement('i'); i.textContent = n; i.style.background = colorBg(n); h.appendChild(i); }
    for (let i = 0; i < MAX_SEATS; i++) {
      const el = seatEls[i], p = S.players.find(x => x.seat === i);
      el.el.classList.toggle('empty', !p);
      el.el.classList.toggle('mine', !!p && i === S.me);
      if (!p) { el.name.textContent = '空席'; el.bal.textContent = '-'; el.tot.textContent = '-'; el.net.textContent = ''; continue; }
      el.name.textContent = p.name || 'Player';
      el.bal.innerHTML = ''; el.bal.append(fmt(p.balance)); const u1 = document.createElement('small'); u1.textContent = 'pt'; el.bal.appendChild(u1);
      el.tot.innerHTML = ''; el.tot.append(fmt(p.total_bet)); const u2 = document.createElement('small'); u2.textContent = 'pt'; el.tot.appendChild(u2);
      const n = S.nets[i];
      el.net.textContent = n === undefined ? '' : n > 0 ? `+${fmt(n)} pt` : n === 0 ? '±0' : `${fmt(n)} pt`;
      el.net.className = 'rl-net' + (n > 0 ? ' win' : n < 0 ? ' lose' : '');
    }
  }
  function toast(msg, err) {
    const t = $('rl-toast'); t.textContent = msg; t.classList.toggle('err', !!err); t.classList.add('on');
    clearTimeout(S.toastT); S.toastT = setTimeout(() => t.classList.remove('on'), 2600);
  }
  function showResult(m) {
    const col = m.number === 0 ? '緑' : RED.has(m.number) ? '赤' : '黒';
    const r = $('rl-result'); r.textContent = '';
    const n = document.createElement('div'); n.className = 'n'; n.textContent = m.number;
    n.style.background = colorBg(m.number); n.style.color = '#fff';
    const hd = document.createElement('div'); hd.className = 'hd'; hd.textContent = 'WINNING NUMBER';
    const lb = document.createElement('div'); lb.className = 'm'; lb.textContent = `当選番号（${col}）`;
    const list = document.createElement('div'); list.className = 'rl-rl';
    const rows = (m.results || []).filter(x => x.stake > 0).sort((a, b) => a.seat - b.seat);
    if (!rows.length) { const e = document.createElement('div'); e.className = 'm'; e.textContent = '今回のベットはありませんでした'; list.appendChild(e); }
    for (const x of rows) {
      const net = x.payout - x.stake, row = document.createElement('div'); row.className = 'rl-rr';
      row.style.setProperty('--c', SEAT_COLORS[x.seat % MAX_SEATS]);
      const dot = document.createElement('i'), nm = document.createElement('span'), amt = document.createElement('b'), sub = document.createElement('small');
      nm.textContent = x.name || 'Player';
      amt.textContent = net > 0 ? `+${fmt(net)} pt` : net === 0 ? '±0 pt' : `${fmt(net)} pt`;
      amt.className = net > 0 ? 'win' : net < 0 ? 'lose' : '';
      sub.textContent = `賭け金 ${fmt(x.stake)} G　配当 ${fmt(x.payout)} G（賭け金込み）`;
      row.append(dot, nm, amt, sub); list.appendChild(row);
    }
    r.append(hd, n, lb, list);
    const mineRow = (m.results || []).find(x => x.seat === S.me && x.stake > 0);
    const mnet = mineRow ? mineRow.payout - mineRow.stake : null;
    au.popup(mnet === null || mnet === 0 ? 'neutral' : mnet > 0 ? 'win' : 'lose');
    if (mnet > 0) { au.coins(); confetti(90); } else if ((m.results || []).some(x => x.payout > 0)) confetti(30);
    r.classList.add('on'); S.popup = true;
    clearTimeout(S.resultT); S.resultT = setTimeout(() => { r.classList.remove('on'); S.popup = false; }, T_POP_SHOW * 1000);
  }

  function confetti(n) {
    if (reduced) return;
    const box = document.createElement('div'); box.className = 'rl-confetti';
    const cols = ['#ffe27a', '#ff6b8a', '#5fb8ff', '#7be08f', '#ffffff', '#e5c35f'];
    for (let i = 0; i < n; i++) {
      const p = document.createElement('i');
      p.style.left = Math.random() * 100 + '%'; p.style.background = cols[i % cols.length];
      p.style.setProperty('--dx', (Math.random() * 160 - 80) + 'px'); p.style.setProperty('--rot', (Math.random() * 900 - 450) + 'deg');
      p.style.animationDuration = (2.4 + Math.random() * 1.8) + 's'; p.style.animationDelay = Math.random() * 0.8 + 's';
      box.appendChild(p);
    }
    $('rl-stage').appendChild(box); setTimeout(() => box.remove(), 5400);
  }
  function notice(msg) {
    const r = $('rl-result'); r.textContent = '';
    const d = document.createElement('div'); d.className = 'm'; d.textContent = msg; r.appendChild(d);
    r.classList.add('on'); clearTimeout(S.resultT); S.resultT = setTimeout(() => r.classList.remove('on'), 6000);
  }

  // ---- messages from the server ----
  function onMsg(e) {
    const m = e.detail; if (!m || !S) return;
    if (m.type === 'roulette_state') {
      S.state = m; S.me = typeof m.me === 'number' ? m.me : -1; S.players = Array.isArray(m.players) ? m.players : [];
      S.offset = m.server_now - Date.now() / 1000; S.sending = 0;
      const sig = JSON.stringify(S.players.map(p => [p.seat, p.bets]));
      const rid = m.round ? m.round.id : null;
      if (S.prevTot && S.prevRid === rid) {                     // chip sounds: someone added / removed bets in this round
        let up = 0, down = 0;
        for (const p of S.players) { const tot = p.total_bet || 0, was = S.prevTot[p.seat] || 0; if (tot > was) up = Math.max(up, p.seat === S.me ? 1 : 0.5); else if (tot < was && p.seat === S.me) down = 1; }
        if (up) au.chip(up); else if (down) au.chipBack();
      }
      S.prevRid = rid; S.prevTot = {}; for (const p of S.players) S.prevTot[p.seat] = p.total_bet || 0;
      if (sig !== S.betSig) { S.betSig = sig; drawBets(); drawMiniBets(); }
      const rd = m.round;
      if (rd && rd.status === 'open') {                        // next betting round: close the popup, clear the winner mark
        markWin(null);
        if (S.popup) { $('rl-result').classList.remove('on'); S.popup = false; clearTimeout(S.resultT); }
      } else if (rd && rd.status === 'settled') markWin(rd.result);
      drawHud();
    } else if (m.type === 'roulette_result') {
      markWin(m.number);
      showResult(m);
      S.nets = {};
      for (const r of (m.results || [])) if (r.stake > 0) S.nets[r.seat] = r.payout - r.stake;
      clearTimeout(S.netT); S.netT = setTimeout(() => { S.nets = {}; drawHud(); }, 8000);
      drawHud();
    } else if (m.type === 'roulette_full') {
      notice(m.message || '満席です');
      clearTimeout(S.closeT); S.closeT = setTimeout(closeRoulette, 2600);
    } else if (m.type === 'roulette_error') {
      S.sending = 0; toast(m.message || 'エラーが発生しました', true);
    }
  }
  window.addEventListener('ts:roulette', onMsg);
  const send = o => { if (!window.__tsBrSend || !window.__tsBrSend(o)) { toast('サーバーに接続中です。少し待ってください', true); return false; } return true; };
  send({ type: 'roulette_state' });
  const poll = setInterval(() => { if (!S.state) send({ type: 'roulette_state' }); }, 3000);
  const keepalive = setInterval(() => { if (S.state) window.__tsBrSend?.({ type: 'roulette_state' }); }, 20000);   // keeps the seat while the table is open

  // ---- pointer handling ----
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.02), hit = new THREE.Vector3();
  function locate(ev) {
    const r = canvas.getBoundingClientRect();
    ndc.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    const ch = ray.intersectObjects(trayMeshes, false)[0];
    if (ch) return { chip: ch.object.userData.denom, spot: null };
    return ray.ray.intersectPlane(plane, hit) ? { chip: null, spot: pick(hit.x, hit.z) } : { chip: null, spot: null };
  }
  function setHover(loc) {
    if (S.view !== 'table' || S.fadeTo) { S.hoverChip = null; S.spot = null; return; }
    S.hoverChip = loc.chip; S.spot = loc.spot;
    if (loc.spot) {
      const [name, mult] = describe(loc.spot);
      $('rl-hint').textContent = `${name}　的中で ${mult} 倍（賭け金に加えて ${mult} 倍の配当）　選択中: ${fmt(S.selected)} pt`;
    } else if (loc.chip) $('rl-hint').textContent = `${fmt(loc.chip)} pt のチップ`;
    else $('rl-hint').textContent = `選択中のチップ: ${fmt(S.selected)} pt　テーブルをクリックしてベット`;
    canvas.style.cursor = (loc.spot || loc.chip) ? 'pointer' : 'default';
  }
  const serverNow = () => Date.now() / 1000 + S.offset;
  function remaining() { const r = S.state?.round; return r && (!r.status || r.status === 'open') ? r.closes_at - serverNow() : 0; }
  function place(spot) {
    const st = S.state, me = mine();
    if (!st || !st.round || !me) return toast('準備中です', true);
    if (remaining() <= 0.5) return toast('ベットは締め切られました', true);
    if (S.sending && Date.now() - S.sending < 1500) return;
    if (me.balance < S.selected) return toast('所持金が足りません', true);
    const op = (crypto.randomUUID ? crypto.randomUUID() : 'op' + Math.random().toString(36).slice(2) + Date.now());
    if (send({ type: 'roulette_bet', t: spot.t, nums: spot.nums, amount: S.selected, op_id: op })) S.sending = Date.now();
  }
  const tableOnly = () => S.view !== 'table' || S.fadeTo;       // no betting while the wheel is on screen
  const onMove = ev => { if (tableOnly()) return; if (ev.pointerType !== 'touch') setHover(locate(ev)); };
  const onDown = ev => {
    if (tableOnly() || ev.button > 0) return;
    const loc = locate(ev); setHover(loc);
    if (loc.chip) { if (S.selected !== loc.chip) au.chipSel(); S.selected = loc.chip; S.armed = null; return setHover(loc); }
    if (!loc.spot) { S.armed = null; return; }
    if (ev.pointerType === 'touch' && S.armed !== loc.spot.key) { S.armed = loc.spot.key; return toast('もう一度タップでベット'); }
    S.armed = null; place(loc.spot);
  };
  canvas.addEventListener('pointermove', onMove);
  canvas.addEventListener('pointerdown', onDown);
  canvas.addEventListener('pointerleave', () => setHover({ chip: null, spot: null }));
  $('rl-close').onclick = closeRoulette;
  const volEl = $('rl-vol'); volEl.value = Math.round(au.getVol() * 100);
  volEl.oninput = () => au.setVol(volEl.value / 100);
  const HELP = [
    ['ストレート', '1つの数字（0〜36）', '数字のマスの中央をクリック', 35],
    ['スプリット', '隣り合う2つの数字', '2つの数字の境目の線', 17],
    ['ストリート', '縦に並ぶ3つの数字（例 1・2・3）', '3つ並びの列の手前または奥の端の線', 11],
    ['トリオ', '0・1・2 または 0・2・3', '0と数字の境目の角', 11],
    ['コーナー', '4つの数字（例 1・2・4・5）', '4つのマスが接する角', 8],
    ['バスケット', '0・1・2・3', '0の列の手前または奥の端の角', 6],
    ['シックスライン', '隣り合う2列の6つの数字', '2列にまたがる端の線', 5],
    ['ダズン', '1st 12 / 2nd 12 / 3rd 12（各12個）', '手前の大きなマス', 2],
    ['コラム', '横一列の12個', '右端の 2:1 のマス', 2],
    ['赤 / 黒', '赤または黒の18個', 'RED / BLACK', 1],
    ['偶数 / 奇数', '偶数または奇数の18個', 'EVEN / ODD', 1],
    ['ロー / ハイ', '1〜18 または 19〜36', '1-18 / 19-36', 1],
  ];
  (function buildHelp() {
    const c = $('rl-modal-card');
    const rows = HELP.map(([n, d, w, x]) => `<tr><td><b>${n}</b><br><span style="color:#cdb978">${d}</span></td><td>${w}</td><td class="m">${x} 倍</td><td class="p">${fmt(100 * (x + 1))} G</td></tr>`).join('');
    c.innerHTML = `<h2>配当説明</h2><p>ヨーロピアン・ルーレット（0が1つ・全37マス）</p>
      <table><thead><tr><th>賭け方</th><th>賭ける場所</th><th>配当</th><th style="text-align:right">100 pt賭けて的中</th></tr></thead><tbody>${rows}</tbody></table>
      <ul><li>配当は賭け金に加えて受け取れます。例：100 ptを数字1つに賭けて的中すると、賭け金100 pt＋配当3,500 ptで合計3,600 ptが戻ります。</li>
      <li>0が出ると、赤黒・偶奇・ロー/ハイ・ダズン・コラムはすべてハズレです（0を含む賭けだけが的中）。</li>
      <li>チップは 100 / 500 / 1,000 / 5,000 / 10,000 pt。1ラウンドの賭け金上限は1,000,000 ptです。</li>
      <li>締め切り後はベットの追加・取り消しはできません。</li></ul>
      <button class="rl-btn" id="rl-modal-close" type="button">閉じる</button>`;
    c.querySelector('#rl-modal-close').onclick = () => $('rl-modal').classList.remove('on');
  })();
  $('rl-help-btn').onclick = () => $('rl-modal').classList.add('on');
  $('rl-modal').addEventListener('pointerdown', ev => { if (ev.target === $('rl-modal')) $('rl-modal').classList.remove('on'); });
  $('rl-undo').onclick = () => { if (!tableOnly()) send({ type: 'roulette_undo' }); };
  $('rl-clear').onclick = () => { if (!tableOnly()) send({ type: 'roulette_clear' }); };
  const onKey = ev => { if (ev.key === 'Escape') { if ($('rl-modal').classList.contains('on')) $('rl-modal').classList.remove('on'); else closeRoulette(); } };
  window.addEventListener('keydown', onKey);
  window.addEventListener('resize', fit);

  // ---- render loop ----
  const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  let rafId = 0;
  let errShown = false;
  function frame(now) {
    if (!S) return;
    rafId = requestAnimationFrame(frame);
    try { draw(now); } catch (e) {
      console.error('roulette frame error', e);
      if (!errShown) { errShown = true; const h = root.querySelector('#rl-hint'); if (h) h.textContent = '描画エラー: ' + (e && e.message || e); }
    }
  }
  function draw(now) {
    fit();
    const t = now / 1000;
    animDecor(t);
    // glow targets from the hovered spot
    const want = S.spot ? S.spot.glow : {};
    const pulse = reduced ? 1 : 0.75 + 0.25 * Math.sin(t * 6);
    for (const id in glow) {
      const g = glow[id], tgt = want[id] || 0;
      g.cur += (tgt - g.cur) * 0.35;
      g.fill.material.opacity = g.cur * 0.28 * pulse;
      g.frame.material.opacity = Math.min(1, g.cur * 1.2) * (0.7 + 0.3 * pulse);
    }
    marker.visible = !!S.spot && !S.spot.t && S.spot.nums.length > 1;
    if (S.spot) marker.position.set(S.spot.center[0], 0.08, S.spot.center[1]);
    // chip tray selection
    for (const d of CHIPS) {
      const sel = d === S.selected, hov = d === S.hoverChip;
      const target = sel ? 0.22 : hov ? 0.1 : 0;
      const g = trayStacks[d]; g.position.y += (0.04 + target - g.position.y) * 0.25;
    }
    const sg = trayStacks[S.selected];
    selRing.position.set(sg.position.x, 0.03, sg.position.z); selRing.material.opacity = reduced ? 0.9 : 0.6 + 0.4 * Math.sin(t * 5);
    // which screen: betting table, or the wheel from "bets closed" until the next round opens
    const rd = S.state?.round, el = $('rl-timer');
    const wantView = rd && rd.status && rd.status !== 'open' ? 'wheel' : 'table';
    if (S.state) {
      if (!S.viewInit) { S.viewInit = true; setView(wantView, true); }
      else if (wantView !== (S.fadeTo || S.view)) setView(wantView, false);
    }
    if (S.view === 'wheel' && rd && rd.result != null) {
      const e = serverNow() - rd.closes_at;
      drawWheel(rd, e, t);
      el.textContent = e < T_LAND + T_STOP ? '回転中' : '結果発表'; el.classList.remove('hot');
      setHint(e < 0 ? '締め切り — ホイールが回ります' : e < E_DROP ? 'ボールが回っています…' : e < T_LAND ? 'ボールが落ちていきます…'
        : e < T_LAND + T_STOP ? '入賞！ホイールが止まります' : '結果発表…');
      renderer.render(wscene, wcam);
      return;
    }
    // timer (betting)
    const rem = remaining();
    if (rd) {
      if (rem > 0) { const s = Math.ceil(rem); el.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
      else el.textContent = rd.status && rd.status !== 'open' ? '結果発表' : '締め切り';
      el.classList.toggle('hot', rem > 0 && rem <= 30);
    }
    renderer.render(scene, camera);
  }
  function setHint(txt) { if (S.hintTxt !== txt) { S.hintTxt = txt; $('rl-hint').textContent = txt; } }
  function setView(v, instant) {
    const f = $('rl-fade');
    if (instant) { clearTimeout(S.fadeT); S.fadeTo = null; S.view = v; f.style.opacity = 0; applyView(); return; }
    if (S.fadeTo === v) return;
    S.fadeTo = v; f.style.opacity = 1; clearTimeout(S.fadeT);
    S.fadeT = setTimeout(() => { if (!S) return; S.view = S.fadeTo; S.fadeTo = null; applyView(); f.style.opacity = 0; }, 430);
  }
  function applyView() {
    root.classList.toggle('rl-wv', S.view === 'wheel');
    $('rl-modal').classList.remove('on'); au.setDuck(S.view === 'wheel' ? 0.6 : 1);
    if (S.view !== 'wheel') { au.stopSpin(); S.snd = null; }
    S.spot = null; S.hoverChip = null; S.hintTxt = ''; canvas.style.cursor = 'default';
    if (S.view === 'table') $('rl-hint').textContent = `選択中のチップ: ${fmt(S.selected)} pt　テーブルをクリックしてベット`;
  }
  // sounds follow the same clock as the animation (so late joiners hear only what is still to come)
  function sfxWheel(key, e, p, b, t) {
    const rho = p.rho(e);
    let q = S.snd;
    const rel0 = Math.floor((b.B + rho) / PK);
    if (!q || q.key !== key) {
      S.snd = { key, e, B: b.B, rho, y: b.y, vy: 0, mb: 1e-3, mr: 1e-3, rel: rel0, lb: -9, lt: -9, landed: e >= T_LAND };
      if (e < 3) au.launch();
      if (e < T_LAND + T_STOP) au.startSpin();
      return;
    }
    const dt = e - q.e;
    if (dt <= 0.002) return;
    if (dt > 0.5) { q.e = e; q.B = b.B; q.rho = rho; q.y = b.y; q.rel = rel0; if (e < T_LAND + T_STOP) au.startSpin(); return; }
    const sb = Math.abs(wrapPi(b.B - q.B)) / dt, sr = Math.abs(wrapPi(rho - q.rho)) / dt;
    q.mb = Math.max(q.mb, sb); q.mr = Math.max(q.mr, sr);
    const onTrack = b.r > R_EDGE + 0.1 && e < T_LAND;
    const fall = e < E_SLIDE ? 1 : Math.max(0.35, 1 - (e - E_SLIDE) / (E_DROP - E_SLIDE) * 0.65);
    au.setSpin(Math.min(1, sr / q.mr), onTrack ? Math.min(1, sb / q.mb) * fall : 0);
    if (rel0 !== q.rel && e > E_SLIDE && e < T_LAND + 0.3 && t - q.lt > 0.04) {
      au.tick(Math.max(0.3, 0.75 - 0.5 * (e - E_SLIDE) / (T_LAND - E_SLIDE))); q.lt = t;
    }
    const vy = (b.y - q.y) / dt;
    if (e > E_DROP - 0.3 && q.vy < -0.15 && vy > 0 && t - q.lb > 0.07) { au.bounce(Math.max(0.35, Math.min(1, -q.vy * 0.5))); q.lb = t; }
    if (!q.landed && e >= T_LAND) { q.landed = true; au.land(); triggerBurst(t, ballMesh.position); }
    if (e > T_LAND + T_STOP + 0.3) au.stopSpin();
    q.e = e; q.B = b.B; q.rho = rho; q.y = b.y; q.vy = vy; q.rel = rel0;
  }
  let planFor = '';
  function drawWheel(rd, e, t) {
    const key = rd.id + ':' + rd.result;
    if (planFor !== key) {
      planFor = key; S.plan = makePlan(rd.id, rd.result);
      winRing.position.set(R_POCKET * Math.sin(S.plan.ak), 0.03, -R_POCKET * Math.cos(S.plan.ak));
    }
    const p = S.plan;
    rotor.rotation.y = p.rho(e);
    const b = p.ball(e);
    ballMesh.position.set(b.r * Math.sin(b.B), b.y + BALL_R * 0.9, -b.r * Math.cos(b.B));
    sfxWheel(key, e, p, b, t);
    winRing.material.opacity = e < T_LAND ? 0 : smooth((e - T_LAND) / 0.6) * (reduced ? 0.9 : 0.55 + 0.45 * Math.sin(t * 5));
    // camera: whole bowl while spinning, then eases in toward the winning pocket at the front
    const tanV = Math.tan(wcam.fov * Math.PI / 360), asp = wcam.aspect || 1;
    const dist0 = Math.max(4.5 / (tanV * 0.93), 4.8 / (tanV * asp * 0.96));   // bowl fills most of the stage
    const k = smooth((e - T_LAND) / T_STOP);
    const dir = new THREE.Vector3(0, 0.80, 0.60).lerp(new THREE.Vector3(0, 0.62, 0.78), k).normalize();
    const tgt = new THREE.Vector3((reduced ? 0 : Math.sin(t * 0.4) * 0.22) * (1 - k), 0, 0.3 + 0.9 * k);
    wcam.position.copy(tgt).addScaledVector(dir, dist0 * (1 - 0.17 * k));
    wcam.lookAt(tgt);
  }
  fit();
  rafId = requestAnimationFrame(frame);

  const sess = S;                      // closeRoulette() nulls S before cleanup runs
  S.cleanup = () => {
    au.destroy(); clearInterval(poll); clearInterval(keepalive); clearTimeout(sess.toastT); clearTimeout(sess.resultT); clearTimeout(sess.netT); clearTimeout(sess.closeT); clearTimeout(sess.fadeT);
    window.removeEventListener('ts:roulette', onMsg);
    window.removeEventListener('keydown', onKey);
    window.removeEventListener('resize', fit);
    cancelAnimationFrame(rafId);
    clearBetMeshes();
    scene.traverse(o => { o.geometry?.dispose?.(); const m = o.material; (Array.isArray(m) ? m : [m]).forEach(x => { x?.map?.dispose?.(); x?.dispose?.(); }); });
    wscene.traverse(o => { o.geometry?.dispose?.(); const m = o.material; (Array.isArray(m) ? m : [m]).forEach(x => { x?.map?.dispose?.(); x?.dispose?.(); }); });
    try { envTex?.dispose?.(); pmrem?.dispose?.(); } catch (e) { /* ignore */ }
    Object.values(texCache).forEach(t => t.dispose());
    Object.values(chipMats).forEach(a => a.forEach(m => { m.map?.dispose?.(); m.dispose?.(); }));
    seatMats.forEach(m => m.dispose()); baseGeo.dispose();
    chipGeo?.dispose?.(); texCache = {}; chipMats = {}; chipGeo = null;
    renderer.dispose();
  };
}

export function closeRoulette() {
  if (!S) return;
  window.__tsBrSend?.({ type: 'roulette_leave' });
  const s = S; S = null;
  try { s.cleanup && s.cleanup(); } catch (e) { console.error('roulette cleanup', e); }
  s.root.remove();
}
