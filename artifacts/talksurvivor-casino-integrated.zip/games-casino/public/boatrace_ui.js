const BG = ['#fff', '#222', '#e5393b', '#3f83d6', '#f2e04a', '#4aaf4f'];
const FG = ['#222', '#fff', '#fff', '#fff', '#222', '#fff'];
const GR = { SG: '#b8860b', G1: '#d33', G2: '#e8861a', G3: '#2a9d4a', '一般': '#6b7a8c' };
const KINDS = [['tan3', '3連単'], ['fuku3', '3連複'], ['tan2', '2連単'], ['fuku2', '2連複'], ['wide', '拡連複'], ['tan1', '単勝'], ['fuku1', '複勝']];
const DEPTH = { tan3: 3, fuku3: 3, tan2: 2, fuku2: 2, wide: 2, tan1: 1, fuku1: 1 };
const KN = Object.fromEntries(KINDS);
let root, stack = [], pending = new Map(), seq = 0, timer = 0, balance = null, curDate = '';
let uncertainRequestId = null;
let purchaseUncertain = false; // A timed-out purchase must never be submitted again automatically.
// Persist only an opaque purchase request ID; the server authenticates status queries.
// Keep unresolved IDs across Activity reloads, but never replay a purchase automatically.
const BR_PENDING_KEY = 'ts_br_pending_purchase_v1'; // Legacy, unscoped ID; never restore across accounts.
const BR_PENDING_PREFIX = 'ts_br_pending_purchase_v2_';
let purchaseOwner = null;
let ownerEpoch = 0; // Increment on account switch to invalidate in-flight UI operations.
function scopedPendingKey() { return purchaseOwner ? BR_PENDING_PREFIX + purchaseOwner : null; }
function readPendingPurchase() {
  const key = scopedPendingKey();
  if (!key) return null;
  try {
    const id = localStorage.getItem(key);
    return id && /^[A-Za-z0-9_-]{8,128}$/.test(id) ? id : null;
  } catch (_) { return null; }
}
function savePendingPurchase(id) {
  const key = scopedPendingKey();
  if (!key || !/^[A-Za-z0-9_-]{8,128}$/.test(id)) return false;
  try { localStorage.setItem(key, id); return true; } catch (_) { return false; }
}
function clearPendingPurchase() {
  const key = scopedPendingKey();
  if (key) { try { localStorage.removeItem(key); } catch (_) {} }
  uncertainRequestId = null;
  purchaseUncertain = false;
}
// The owner is supplied by the authenticated server response, never by client input.
// On account changes, pending IDs from other accounts remain in their own storage slots.
function bindPurchaseOwner(owner) {
  if (typeof owner !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(owner)) throw new Error('認証ユーザーを確認できません');
  if (purchaseOwner !== owner) {
    purchaseOwner = owner;
    ownerEpoch += 1;
    uncertainRequestId = readPendingPurchase();
    purchaseUncertain = !!uncertainRequestId;
    showNetworkStatus();
  }
}
async function ensurePurchaseOwner() {
  const d = await ask('br_my', {});
  bindPurchaseOwner(d.owner);
  // Never auto-import the legacy global ID: it might belong to a different account.
  return d;
}
let bet = { key: '', kind: 'tan3', sel: new Set(), amt: 100, box: new Set() };

function uiDialog(msg, ok) {
  return new Promise(res => {
    const o = document.createElement('div');
    o.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:#0008;display:flex;align-items:center;justify-content:center;padding:20px';
    const b = document.createElement('div');
    b.style.cssText = 'background:#fff;color:#222;border-radius:12px;padding:18px;max-width:340px;width:100%;font-size:15px;line-height:1.5;white-space:pre-wrap';
    const m = document.createElement('div'); m.textContent = msg; b.appendChild(m);
    const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:10px;margin-top:14px';
    const mk = (t, bg, v) => { const x = document.createElement('button'); x.textContent = t; x.style.cssText = `flex:1;border:0;border-radius:8px;padding:12px;font-size:15px;font-weight:700;color:#fff;background:${bg}`; x.onclick = () => { o.remove(); res(v); }; row.appendChild(x); };
    if (!ok) mk('キャンセル', '#789', false);
    mk('OK', '#e8861a', true);
    b.appendChild(row); o.appendChild(b); document.body.appendChild(o);
  });
}
const uiAlert = m => uiDialog(m, true);
const uiConfirm = m => uiDialog(m, false);
function css() {
  if (document.getElementById('brui-css')) return;
  const s = document.createElement('style');
  s.id = 'brui-css';
  s.textContent = `#brui{position:fixed;inset:0;z-index:99999;background:#eef2f7;color:#223;font:16px/1.4 sans-serif;display:flex;flex-direction:column}
#brui .br-net{padding:7px 10px;background:#fff3cd;color:#643c00;font-size:13px;border-bottom:1px solid #dfbd62}#brui .br-net button{margin-left:8px;padding:4px 8px;border:1px solid #a88;background:#fff;border-radius:5px}
#brui .hd{background:#0a4d8c;color:#fff;display:flex;align-items:center;gap:8px;padding:10px 12px;font-weight:700;font-size:16px}
#brui .hd button{background:#ffffff33;color:#fff;border:0;border-radius:6px;padding:6px 10px;font-size:16px}
#brui .hd .t{flex:1;text-align:center}
#brui .bd{flex:1;overflow:auto;padding:10px;-webkit-overflow-scrolling:touch}
#brui .nv{display:flex;gap:6px;padding:6px 8px calc(6px + env(safe-area-inset-bottom));background:#0a4d8c}
#brui .nv button{flex:1;padding:10px 0;border:0;border-radius:8px;background:#ffffff33;color:#fff;font-weight:700;font-size:16px}
#brui .nv button.on{background:#fff;color:#0a4d8c}
#brui .nv .vl{display:flex;align-items:center;gap:2px;color:#fff;font-size:16px;flex:0 0 28%}
#brui .nv .vl input{width:100%;min-width:0}
#brui table.sr td,#brui table.sr th{padding:2px 3px;font-size:13px;white-space:nowrap}
#brui table.sr .rk{display:inline-block;min-width:14px;text-align:center;border-radius:3px;font-weight:700}
#brui .card{background:#fff;border-radius:10px;padding:10px;margin-bottom:8px;box-shadow:0 1px 3px #0002}
#brui .vn{display:flex;align-items:center;gap:8px}
#brui .tag{color:#fff;border-radius:4px;padding:1px 6px;font-size:14px;font-weight:700}
#brui .mut{color:#789;font-size:14px}
#brui table{width:100%;border-collapse:collapse;font-size:15px}
#brui td,#brui th{border:1px solid #d5dde8;padding:4px;text-align:center}
#brui th{background:#e4ecf6}
#brui .wk{display:inline-block;width:28px;height:28px;line-height:26px;text-align:center;border-radius:4px;font-weight:700;border:1px solid #888;font-size:15px}
#brui button{color:#223}
#brui .rn{display:flex;flex-wrap:wrap;gap:6px}
#brui .rn button{border:1px solid #9db8d8;background:#e6f0fb;color:#16365f;font-weight:700;border-radius:6px;padding:5px 0;width:calc(25% - 6px);font-size:16px;line-height:1.25}
#brui .rn button .mut{color:#4b6b90;font-weight:400;font-size:13px}
#brui .rn button.dn{background:#e3e6eb;color:#7d8696;border-color:#c5cbd4}
#brui .rn button.dn .mut{color:#8d95a3}
#brui .rn button.cl{background:#fde3e3;color:#9a3030;border-color:#e6b3b3}
#brui .rn button.cl .mut{color:#a85656}
#brui .tabs{display:flex;gap:4px;margin-bottom:8px}
#brui .tabs button{flex:1;padding:8px 2px;border:0;border-radius:6px;background:#d3e0f0;color:#1d3a63;font-weight:700;font-size:15px}
#brui .tabs button.on{background:#0a4d8c;color:#fff}
#brui .tabs.w{flex-wrap:wrap}
#brui .tabs.w button{flex:0 0 calc(25% - 4px)}
#brui .lk{color:#0a4d8c;text-decoration:underline;cursor:pointer}
#brui .big{font-size:18px;font-weight:700}
#brui .btn{border:0;border-radius:8px;padding:10px 14px;color:#fff;font-weight:700;font-size:16px;background:#0a4d8c}
#brui .btn.o{background:#e8861a}#brui .btn.r{background:#d33}#brui .btn.g{background:#2a9d4a}
#brui .og{flex:1;min-width:104px;border:1px solid #1a3d8f;background:#fff}
#brui .oh{font-weight:700;text-align:center;padding:3px 1px;font-size:14px;white-space:nowrap;overflow:hidden}
#brui .og table td{border:1px solid #cfd8e6;padding:0;height:31px}
#brui .lc{width:24px;font-weight:700;text-align:center;font-size:14px}
#brui .oc{text-align:right;padding-right:4px!important;font-size:14px;font-variant-numeric:tabular-nums}
#brui .oc.hi{color:#d00}
#brui .oc.sel{background:#ffd54a;outline:2px solid #e88a00;outline-offset:-2px;font-weight:700}
#brui .tp .oc{cursor:pointer}
#brui .bar{position:sticky;bottom:-10px;background:#fff;border-top:2px solid #0a4d8c;padding:8px;margin:8px -10px -10px}
#brui input[type=number]{width:90px;padding:6px;font-size:18px}@media(max-width:480px){#brui .bd{padding:6px}#brui table.sr td,#brui table.sr th{padding:2px 2px;font-size:12px}#brui .og{min-width:calc(50% - 4px)}#brui .rn button{width:calc(33.3% - 6px);padding:10px 0}#brui .tabs.w button{flex:0 0 calc(33.3% - 4px)}}`;
  document.head.appendChild(s);
}

// One pending request owns its timer and is settled at most once.  Late replies
// (including replies after reconnect) cannot resolve a different request.
function rejectPendingRequests(reason) {
  for (const [req, p] of pending) {
    clearTimeout(p.to);
    pending.delete(req);
    p.rej(new Error(reason));
  }
}
function ask(type, params) {
  return new Promise((res, rej) => {
    const req = ++seq;
    const to = setTimeout(() => {
      const p = pending.get(req);
      if (!p) return;
      pending.delete(req);
      p.rej(new Error('timeout'));
    }, 10000);
    pending.set(req, { res, rej, to, type });
    try {
      if (!window.__tsBrSend || !window.__tsBrSend({ type, req, ...params })) {
        clearTimeout(to);
        pending.delete(req);
        rej(new Error('offline'));
      }
    } catch (_) {
      clearTimeout(to);
      pending.delete(req);
      rej(new Error('transport_error'));
    }
  });
}

window.addEventListener('ts:br', ev => {
  const m = ev.detail, p = pending.get(m?.req);
  if (!p || m.type !== p.type) return;
  clearTimeout(p.to);
  pending.delete(m.req);
  if (!m.data || typeof m.data !== 'object' || Array.isArray(m.data)) {
    p.rej(new Error('invalid_response'));
  } else if (m.data.ok === false) {
    p.rej(new Error(m.data.error || 'サーバー処理に失敗しました'));
  } else {
    p.res(m.data);
  }
});

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const wk = c => `<span class="wk" style="background:${BG[c - 1]};color:${FG[c - 1]}">${c}</span>`;
const gt = g => `<span class="tag" style="background:${GR[g] || '#678'}">${esc(g)}</span>`;
const fmt = s => { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const yen = n => Number(n).toLocaleString() + ' pt';
const sname = n => String(n).split('　')[0];
const sortKey = (a, b) => a.localeCompare(b, undefined, { numeric: true });
const chips = c => c.split('-').map(x => wk(+x)).join('');

// Recovery never replays a bet. A successful read of br_my also triggers
// server-side settlement, so it is the authoritative points/history refresh.
async function recoverySnapshot() {
  const d = await ensurePurchaseOwner();
  if (!d || !Array.isArray(d.bets) || !Number.isFinite(Number(d.balance)))
    throw new Error('購入履歴・残高の応答が不正です');
  return { balance: d.balance, bets: d.bets,
    settled: d.bets.filter(b => b.status !== 'open').length,
    payout: d.bets.reduce((sum, b) => sum + Number(b.payout || 0), 0) };
}
function networkMessage() {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return '通信が切断されています。再接続後、購入履歴と残高を確認してください。';
  if (purchaseUncertain) return '直前の投票が成立したか不明です。再投票する前に購入履歴・残高を確認してください。';
  return '';
}
function showNetworkStatus() {
  if (!root) return;
  let n = root.querySelector('#bru-network');
  const msg = networkMessage();
  if (!msg) { n?.remove(); return; }
  if (!n) { n = document.createElement('div'); n.id = 'bru-network'; n.className = 'br-net'; root.querySelector('.hd')?.after(n); }
  n.textContent = msg;
  const b = document.createElement('button'); b.textContent = '購入履歴を確認';
  b.onclick = () => { if (!root) return; stack = []; go(pageBets, {tab:'bets'}); };
  n.appendChild(b);
}
window.addEventListener('online', showNetworkStatus);
window.addEventListener('offline', () => { rejectPendingRequests('offline'); showNetworkStatus(); });

function shell(page) {
  css();
  root = document.createElement('div');
  root.id = 'brui';
  root.innerHTML = '<div class="hd"><button id="bru-back">戻る</button><div class="t" id="bru-t"></div><button id="bru-x">閉じる</button></div><div class="bd" id="bru-b"></div><div class="nv"><button data-nv="home">開催一覧</button><button data-nv="vote">投票</button>  <button data-nv="bets">購入履歴・結果</button><label class="vl">🔊<input type="range" id="bru-vol" min="0" max="1" step="0.05"></label></div>';
  document.body.appendChild(root);
  showNetworkStatus();
    const vs = root.querySelector('#bru-vol');
    vs.value = localStorage.getItem('brVol') ?? 0.8;
    vs.oninput = () => { localStorage.setItem('brVol', vs.value); window.dispatchEvent(new Event('brvol')); };
  root.querySelector('#bru-x').onclick = close;
  root.querySelector('#bru-back').onclick = () => { stack.pop(); const t = stack.pop(); if (t) go(t.fn, t.arg); else close(); };
  root.querySelectorAll('[data-nv]').forEach(b => b.onclick = () => { if (b.dataset.nv === 'vote') return openBetPanel(null); stack = []; go({ home: pageHome, bets: pageBets }[b.dataset.nv], {}); });
}

let onCloseCb = null;
function close() { clearInterval(timer); if (bp) closeBetPanel(); root?.remove(); root = null; stack = []; const cb = onCloseCb; onCloseCb = null; if (cb) cb(); }

function go(fn, arg) {
  stack.push({ fn, arg });
  clearInterval(timer);
  const nv = { pageHome: 'home', pageBets: 'bets' }[fn.name] || '';
  root?.querySelectorAll('[data-nv]').forEach(b => b.classList.toggle('on', b.dataset.nv === nv));
  fn(arg || {});
  showNetworkStatus();
}

const isCurrent = entry => !!root && stack[stack.length - 1] === entry;
const body = (title, html) => { if (!root) return; root.querySelector('#bru-t').textContent = title; const b = root.querySelector('#bru-b'); b.innerHTML = html; b.scrollTop = 0; };
const err = e => body('エラー', `<div class="card">読み込めませんでした: ${esc(e.message)}<div style="margin-top:8px">通信状態を確認して、もう一度開いてください。</div></div>`);

async function loadBalance() {
  try { const d = await ask('br_my', {}); balance = d.balance; return d; } catch (e) { return null; }
}

// ---------------------------------------------------------------- オッズ表(枠色つき)
function oddsGrid(kind, odds, entries, sel) {
  const nm = n => esc(sname(entries[n - 1]?.name || ''));
  const depth = DEPTH[kind], keys = Object.keys(odds).sort(sortKey);
  const cell = (k, cls) => { const v = odds[k]; return `<td class="oc ${v >= 1000 ? 'hi' : ''} ${sel?.has(k) ? 'sel' : ''}" data-c="${k}">${v.toFixed(1)}</td>`; };
  const lc = c => `<td class="lc" style="background:${BG[c - 1]};color:${FG[c - 1]}">${c}</td>`;
  const tree = new Map();
  for (const k of keys) {
    const p = k.split('-').map(Number);
    if (!tree.has(p[0])) tree.set(p[0], new Map());
    if (depth === 3) { const m = tree.get(p[0]); if (!m.has(p[1])) m.set(p[1], []); m.get(p[1]).push(p); }
    else if (depth === 2) { const m = tree.get(p[0]); m.set(p[1], [p]); }
    else tree.get(p[0]).set(0, [p]);
  }
  let h = '';
  for (const [g, sub] of tree) {
    let rows = '';
    if (depth === 3) {
      for (const [s, list] of sub) list.forEach((p, i) => { rows += `<tr>${i === 0 ? `<td class="lc" rowspan="${list.length}" style="background:${BG[s - 1]};color:${FG[s - 1]}">${s}</td>` : ''}${lc(p[2])}${cell(p.join('-'))}</tr>`; });
    } else if (depth === 2) {
      for (const [, list] of sub) rows += `<tr>${lc(list[0][1])}${cell(list[0].join('-'))}</tr>`;
    } else {
      rows += `<tr>${cell(String(g))}</tr>`;
    }
    h += `<div class="og"><div class="oh" style="background:${BG[g - 1]};color:${FG[g - 1]}">${g} ${nm(g)}</div><table>${rows}</table></div>`;
  }
  const n = tree.size;
  return `<div style="overflow-x:auto"><div class="tp" style="display:flex;gap:3px;min-width:${Math.min(n, 6) * 104}px">${h}</div></div>`;
}

// ---------------------------------------------------------------- 開催一覧
async function pageHome() {
  const entry = stack[stack.length - 1];
  body('開催一覧', '<div class="card">読み込み中…</div>');
  const render = async first => {
    let d;
    try { d = await ask('br_list', {}); } catch (e) { if (first && isCurrent(entry)) err(e); return; }
    if (!isCurrent(entry)) return;
    curDate = d.date;
    const sc = root.querySelector('#bru-b').scrollTop;
    const nextAt = v => v.next_no ? `${v.next_no}R 締切 ${v.next_deadline}（あと${fmt(v.next_in)}）` : '本日終了';
    const open = d.venues.filter(v => v.open), shut = d.venues.filter(v => !v.open);
    body('開催一覧 ' + d.label,   open.map(v => `<div class="card"><div class="vn"><span class="big">${esc(v.name)}</span>${gt(v.grade)}${v.night ? '<span class="tag" style="background:#334">ナイター</span>' : ''}<span class="mut" style="margin-left:auto">${v.day}日目/${v.days}日${v.final ? ' 最終日' : ''}</span></div><div>${esc(v.title)}</div><div class="mut">${v.from}〜${v.to} / ${v.first}〜${v.last}</div><div style="margin:4px 0;color:#c33;font-weight:700">${nextAt(v)}</div><div style="display:flex;gap:8px"><button class="btn" style="flex:1" data-bet="${v.venue}" data-no="${v.next_no}">${v.next_no ? '出走表' : '結果を見る'}</button>${v.watch_no ? `<button class="btn r" style="flex:1" data-w="${v.venue}" data-no="${v.watch_no}">レースを見る ${v.watch_no}R</button>` : ''}</div></div>`).join('')
      + `<div class="mut">非開催: ${shut.map(v => esc(v.name)).join('、')}</div>`);
    root.querySelector('#bru-b').scrollTop = sc;
    root.querySelectorAll('[data-bet]').forEach(el => el.onclick = () => go(pageRace, { venue: +el.dataset.bet, date: d.date, no: +el.dataset.no || 12, tab: +el.dataset.no ? 'card' : 'res' }));
    root.querySelectorAll('[data-w]').forEach(el => el.onclick = () => watch({ venue: +el.dataset.w, date: d.date, no: +el.dataset.no }));
  };
  await render(true);
  if (!isCurrent(entry)) return;
  clearInterval(timer);
  timer = setInterval(() => render(false), 2000);
}

// ---------------------------------------------------------------- レース詳細

function genBox(kind, lanes) {
  const L = [...lanes].sort((x, y) => x - y), out = [], d = DEPTH[kind];
  const ordered = kind === 'tan3' || kind === 'tan2';
  if (d === 1) return L.map(String);
  const rec = (cur, used) => {
    if (cur.length === d) { out.push((ordered ? cur : [...cur].sort((x, y) => x - y)).join('-')); return; }
    for (const x of L) {
      if (used.has(x)) continue;
      if (!ordered && cur.length && x < cur[cur.length - 1]) continue;
      used.add(x); cur.push(x); rec(cur, used); cur.pop(); used.delete(x);
    }
  };
  rec([], new Set());
  return out;
}

const LANE_BG = ['', '#fff', '#222', '#e33', '#27c', '#fd0', '#2a4'], LANE_FG = ['', '#000', '#fff', '#fff', '#fff', '#000', '#fff'];
function seriesTable(d) {
  const n = d.days, head = k => k === n ? '最終日' : k === n - 1 ? '準優日' : k === 1 ? '初日' : k + '日目';
  const cell = items => (items = items.filter(x => x.rank)).length ? items.map(x => {
    const bg = x.rank ? LANE_BG[x.course] : '#ddd', fg = x.rank ? LANE_FG[x.course] : '#666';
    const sg = x.stage !== 'prelim' ? 'color:#c33;font-weight:700' : '';
    return `<div style="display:flex;gap:3px;align-items:center;justify-content:center"><span style="${sg}">${x.race}R</span><span>${x.course}</span><span>${x.rank ? x.st.toFixed(2) : '-'}</span><span class="rk" style="background:${bg};color:${fg};border:1px solid #888">${x.rank || '・'}</span></div>`;
  }).join('') : '<span class="mut">-</span>';
  const rows = d.entries.map(e => {
    const s = e.series;
    return `<tr><td>${wk(e.course)}</td><td style="text-align:left">${esc(sname(e.name))}</td><td><b>${s.pts}</b><div class="mut">${s.rate ? s.rate.toFixed(2) : '-'}</div></td>`
      + Array.from({ length: n }, (_, k) => `<td>${cell(s.days[k] || [])}</td>`).join('') + '</tr>';
  }).join('');
  return `<div class="card" style="overflow:auto"><b>今節成績</b> <span class="mut">R数 コース ST 着順</span><table class="sr"><tr><th>枠</th><th>選手</th><th>得点<br>率</th>${Array.from({ length: n }, (_, k) => `<th>${head(k + 1)}</th>`).join('')}</tr>${rows}</table></div>`;
}

async function pageRace(a) {
  const entry = stack[stack.length - 1];
  body('出走表', '<div class="card">読み込み中…</div>');
  let d;
  try { d = await ask('br_race', { venue: a.venue, date: a.date, no: a.no }); } catch (e) { if (isCurrent(entry)) err(e); return; }
  if (!isCurrent(entry)) return;
  if (!d) return err(new Error('データなし'));
  let tab = a.tab || 'card';
  const openBet = tab === 'bet' && !a.betShown;   // 開催一覧の「出走表・投票」から来たら投票パネルも開く
  if (tab === 'bet') tab = d.status === 'done' ? 'res' : 'card';
  const off = d.server_ms - Date.now(), dl = d.server_ms + d.remain * 1000, st0 = d.start_ms, endAt = dl + 300000;
  const stTxt = { open: '受付中', closed: '締切（まもなく発走）', running: 'レース中', done: '結果確定' }[d.status];
  let h = `<div class="card"><div class="vn"><span class="big">${esc(d.name)} ${d.no}R</span>${gt(d.grade)}${d.stage !== 'prelim' ? `<span class="tag" style="background:#c33">${d.stage_name}</span>` : ''}<span class="mut" style="margin-left:auto">${d.day}日目/${d.days}日</span></div><div>${esc(d.title)}</div><div style="color:#c33;font-weight:700">${stTxt} <span id="bru-rem"></span></div>${d.live ? `<button class="btn r" id="bru-watch" style="margin-top:6px;width:100%">レースを見る</button>` : '<div class="mut" style="margin-top:4px">締切後に「レースを見る」が押せます</div>'}</div>`;
  h += '<div class="rn" style="margin-bottom:8px">' + d.schedule.map(r => `<button data-n="${r.no}" class="${r.status === 'done' ? 'dn' : r.status === 'open' ? '' : 'cl'}" ${r.no === d.no ? 'style="border:2px solid #e88a00;background:#ffe9a8;color:#222"' : ''}>${r.no}R<br><span class="mut">${r.deadline}</span></button>`).join('') + '</div>';
  h += `<div class="tabs">${[['card', '出走表'], ['odds', 'オッズ'], ['res', '結果']].map(([k, n]) => `<button data-t="${k}" class="${tab === k ? 'on' : ''}">${n}</button>`).join('')}</div>`;
  const kinds = (cur, att) => `<div class="tabs w">${KINDS.map(([id, n]) => `<button ${att}="${id}" class="${cur === id ? 'on' : ''}">${n}</button>`).join('')}</div>`;
  if (tab === 'card') {
    h += '<div class="card" style="overflow:auto"><table><tr><th>枠</th><th>選手</th><th>級</th><th>勝率</th><th>2連率</th><th>平均ST</th><th>モーター</th><th>ボート</th></tr>'
      + d.entries.map(e => `<tr><td>${wk(e.course)}</td><td style="text-align:left"><span class="lk" data-r="${e.no}">${esc(e.name)}</span><div class="mut">${e.no} ${esc(e.branch)} ${e.age}歳 ${e.weight}kg</div></td><td>${e.grade}</td><td>${e.win.toFixed(2)}</td><td>${e.r2.toFixed(1)}</td><td>${e.st.toFixed(2)}</td><td>${e.motor}<div class="mut">${e.motor_r2.toFixed(1)}%</div></td><td>${e.boat}<div class="mut">${e.boat_r2.toFixed(1)}%</div></td></tr>`).join('')       + '</table></div>' + seriesTable(d);
  } else if (tab === 'odds') {
    const k = a.kind || 'tan3';
    h += kinds(k, 'data-k') + `<div class="card" style="padding:6px"><b>${KN[k]}オッズ</b>${oddsGrid(k, d.odds[k], d.entries)}</div>`;
  } else {
    if (!d.result) h += '<div class="card">結果はレース終了後に確定します。</div>';
    else h += resultBlock(d);
  }
  h += betsBlock(d.bets, false);
  h += `<div class="bar"><button class="btn o" data-betbtn style="width:100%;font-size:17px;padding:12px">${betLabel()}</button></div>`;
  body(d.name + ' ' + d.no + 'R', h);
  const R = root;
  R.querySelectorAll('[data-n]').forEach(b => b.onclick = () => go(pageRace, { ...a, no: +b.dataset.n }));
  R.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { stack.pop(); go(pageRace, { ...a, tab: b.dataset.t }); });
  R.querySelectorAll('[data-k]').forEach(b => b.onclick = () => { stack.pop(); go(pageRace, { ...a, tab: 'odds', kind: b.dataset.k }); });
  R.querySelectorAll('[data-r]').forEach(b => b.onclick = () => go(pageRacer, { no: +b.dataset.r }));
  R.querySelector('#bru-watch')?.addEventListener('click', () => watch(a, d));
  R.querySelector('[data-betbtn]').onclick = () => openBetPanel({ venue: a.venue, date: d.date || a.date, no: a.no });
  if (openBet) { a.betShown = true; openBetPanel({ venue: a.venue, date: d.date || a.date, no: a.no }); }
  const rem = R.querySelector('#bru-rem');
  if (d.status !== 'done') {
    timer = setInterval(() => {
      if (!isCurrent(entry)) return;
      const now = Date.now() + off, el = root?.querySelector('#bru-rem');
      if (el) el.textContent = d.status === 'open' ? `締切まで ${fmt((dl - now) / 1000)}` : d.status === 'closed' ? `発走まで ${fmt((st0 - now) / 1000)}` : '';
      if ((d.status === 'open' && now >= dl) || (d.status === 'closed' && now >= st0) || (d.status === 'running' && now >= endAt + 2000)) { clearInterval(timer); stack.pop(); go(pageRace, a); }
    }, 500);
  }
}

// ================================================================ 投票パネル(ポップアップ)
// どの画面からでも開ける。選んだ組み合わせは「ベットリスト」に貯めておき、金額を決めてまとめて投票する。
const SLIP_KEY = 'ts_br_slip_v1';
const SLIP_MAX = 300;
let slip = (() => {
  try {
    const a = JSON.parse(localStorage.getItem(SLIP_KEY) || '[]');
    return Array.isArray(a) ? a.filter(x => x && KN[x.kind] && typeof x.combo === 'string' && Number.isSafeInteger(x.amount) && x.venue && x.no && x.date).slice(0, SLIP_MAX) : [];
  } catch (_) { return []; }
})();
let slipAmt = 1;        // 追加時の既定口数(1口=100 pt)
const saveSlip = () => { try { localStorage.setItem(SLIP_KEY, JSON.stringify(slip)); } catch (_) {} };
const raceKey = x => `${x.venue}|${x.date}|${x.no}`;
const betLabel = () => slip.length ? `投票（ベットリスト ${slip.length}件）` : '投票';

function bpCss() {
  if (document.getElementById('brbp-css')) return;
  const s = document.createElement('style');
  s.id = 'brbp-css';
  s.textContent = `#brbp{position:fixed;inset:0;z-index:100500;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;font:15px/1.4 sans-serif;color:#223;overflow:auto}
#brbp button{color:#223}
#brbp .bp{background:#eef4fb;width:min(1100px,100%);display:flex;flex-direction:column;border-radius:10px;box-shadow:0 6px 24px #0006}
#brbp .bp-hd{background:#0a4d8c;color:#fff;display:flex;align-items:center;gap:8px;padding:8px 10px;font-weight:700;position:sticky;top:-10px;z-index:3;border-radius:10px 10px 0 0}
#brbp .bp-mini{display:none}
#brbp .bp-hd .t{flex:1}
#brbp .bp-hd button{background:#ffffff33;color:#fff;border:0;border-radius:6px;padding:6px 12px;font-size:15px}
#brbp .bp-body{display:flex;gap:8px;padding:8px;align-items:flex-start}
#brbp .bp-l{flex:1 1 60%;min-width:0}
#brbp .bp-r{flex:1 1 40%;min-width:280px;background:#fff8f8;border:2px solid #e05050;border-radius:8px;padding:6px;position:sticky;top:0}
#brbp .box{background:#fff;border-radius:8px;padding:6px;margin-bottom:6px;box-shadow:0 1px 2px #0002}
#brbp select{font-size:16px;padding:5px;border-radius:6px;max-width:100%}
#brbp .rr{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
#brbp .rr button{flex:0 0 calc(16.66% - 4px);border:1px solid #9db8d8;background:#e6f0fb;color:#16365f;font-weight:700;border-radius:5px;padding:4px 0;font-size:14px;line-height:1.2}
#brbp .rr button span{color:#4b6b90;font-weight:400}
#brbp .rr button.cl{background:#e3e6eb;color:#7d8696;border-color:#c5cbd4}
#brbp .rr button.cl span{color:#8d95a3}
#brbp .rr button.on{background:#ffd54a;border:2px solid #e88a00;color:#222}
#brbp .rr button.on span{color:#5a4400}
#brbp .tb{display:flex;gap:3px;margin-bottom:5px;flex-wrap:wrap}
#brbp .tb button{flex:1;min-width:58px;border:0;border-radius:6px;padding:7px 2px;font-weight:700;font-size:14px;background:#1f5aa8;color:#fff}
#brbp .tb button.on{background:#ffd54a;color:#222}
#brbp .tb.top button{background:#d3e0f0;color:#1d3a63;border-radius:8px 8px 0 0}
#brbp .tb.top button.on{background:#0a4d8c;color:#fff}
#brbp table{width:100%;border-collapse:collapse}
#brbp td,#brbp th{border:1px solid #ccd5e2;padding:3px;text-align:center;font-size:14px}
#brbp th{background:#e4ecf6;font-weight:700}
#brbp .pk{min-width:40px;height:34px;border:0;border-radius:4px;background:#1f4f9a;color:#fff;font-weight:800;font-size:16px;width:100%}
#brbp .pk.on{background:#ffd54a;color:#222}
#brbp .all{border:0;background:#1f4f9a;color:#fff;border-radius:4px;font-size:12px;padding:4px 2px;width:100%}
#brbp .nm{text-align:left;white-space:nowrap;max-width:9em;overflow:hidden;text-overflow:ellipsis}
#brbp .ft{display:flex;align-items:center;gap:8px;justify-content:flex-end;margin-top:6px;flex-wrap:wrap}
#brbp .cnt{background:#222;color:#ffd54a;font-weight:800;font-size:18px;padding:3px 12px;border-radius:4px;min-width:56px;text-align:right;font-variant-numeric:tabular-nums}
#brbp .btn{border:0;border-radius:8px;padding:9px 14px;color:#fff;font-weight:700;font-size:15px;background:#1f5aa8}
#brbp .btn.o{background:#e8861a}#brbp .btn.gy{background:#789}
#brbp .btn:disabled{opacity:.45}
#brbp .sl{max-height:46vh;overflow:auto;margin:4px 0}
#brbp .sl td{font-size:13px;padding:2px}
#brbp .sl input{width:46px;font-size:15px;padding:3px;text-align:right;background:#fff;color:#222;border:1px solid #9ab;border-radius:4px}
#brbp .sl .dx{border:0;background:none;color:#1f5aa8;font-size:18px;font-weight:800;padding:0 4px}
#brbp .sl td{background:#fff}
#brbp .sl tr.cl td{background:#f3d6d6}
#brbp .sum{display:flex;justify-content:space-between;align-items:center;margin:3px 0}
#brbp .sum b{background:#222;color:#ffd54a;padding:2px 10px;border-radius:4px;font-size:17px;font-variant-numeric:tabular-nums}
#brbp .vc{display:block;width:100%;text-align:left;background:#e6f0fb;color:#16365f;border:1px solid #9db8d8;border-radius:8px;padding:8px;margin-bottom:6px;font-size:15px}
#brbp .oc{cursor:pointer}
#brbp .oc.sel{background:#ffd54a;outline:2px solid #e88a00;outline-offset:-2px;font-weight:700}
#brbp .og{flex:1;min-width:104px;border:1px solid #1a3d8f;background:#fff}
#brbp .oh{font-weight:700;text-align:center;padding:3px 1px;font-size:14px;white-space:nowrap;overflow:hidden}
#brbp .og table td{border:1px solid #cfd8e6;padding:0;height:31px}
#brbp .lc{width:24px;font-weight:700;text-align:center;font-size:14px}
#brbp .oc{text-align:right;padding-right:4px!important;font-size:14px;font-variant-numeric:tabular-nums}
#brbp .oc.hi{color:#d00}
#brbp .wk{display:inline-block;width:26px;height:26px;line-height:24px;text-align:center;border-radius:4px;font-weight:700;border:1px solid #888;font-size:14px}
#brbp .msg{background:#fff3cd;border:1px solid #e0b54a;border-radius:8px;padding:12px;font-weight:700;color:#8a4b00;margin-bottom:6px}
@media(max-width:760px){#brbp{padding:0}#brbp .bp{border-radius:0;min-height:100%}#brbp .bp-hd{top:0;border-radius:0}#brbp .bp-mini{display:flex;position:sticky;bottom:0;z-index:3;align-items:center;gap:8px;background:#0a4d8c;color:#fff;padding:8px 10px calc(8px + env(safe-area-inset-bottom));font-weight:700}#brbp .bp-mini b{color:#ffd54a;font-size:17px}#brbp .bp-mini button{margin-left:auto;background:#e8861a;color:#fff;border:0;border-radius:8px;padding:8px 12px;font-weight:700;font-size:15px}#brbp .bp-body{flex-direction:column;align-items:stretch;padding:6px}#brbp .tb button{min-width:0;flex:1 1 calc(25% - 3px);font-size:13px;padding:7px 1px}#brbp .pk{min-width:0;height:36px}#brbp td,#brbp th{padding:2px;font-size:13px}#brbp .bp-r{position:static;min-width:0}#brbp .sl{max-height:none}#brbp .rr button{flex:0 0 calc(25% - 4px)}#brbp .nm{max-width:6.5em}#brbp th.op,#brbp td.op{display:none}}`;
  document.head.appendChild(s);
}

// 選択から組番を作る。cols=各列で選んだ枠の集合
function genForm(kind, cols) {
  const d = DEPTH[kind], ordered = kind === 'tan3' || kind === 'tan2' || d === 1, out = new Set();
  const rec = (i, cur) => {
    if (i === d) { out.add((ordered ? cur : [...cur].sort((x, y) => x - y)).join('-')); return; }
    for (const x of cols[i]) if (!cur.includes(x)) rec(i + 1, [...cur, x]);
  };
  rec(0, []);
  return [...out];
}

let bp = null;   // 開いている投票パネルの状態
function openBetPanel(target) {
  bpCss();
  document.getElementById('brbp')?.remove();
  const el = document.createElement('div');
  el.id = 'brbp';
  el.innerHTML = '<div class="bp"><div class="bp-hd"><span class="t">投票</span><span id="bp-bal" style="font-weight:400;font-size:14px"></span><button id="bp-x">閉じる</button></div><div class="bp-body"><div class="bp-l" id="bp-l"></div><div class="bp-r" id="bp-r"></div></div><div class="bp-mini"><span>ベットリスト <b id="bp-mn">0</b>件 / <b id="bp-mt">0</b>G</span><button id="bp-go">リストを見る</button></div></div>';
  (root || document.body).appendChild(el);
  bp = { el, venue: target?.venue || 0, date: target?.date || curDate, no: target?.no || 0, d: null, list: null,
    tab: 'pick', kind: bet.kind || 'tan3', mode: 'normal', cols: [new Set(), new Set(), new Set()], box: new Set(), osel: new Set(), timer: 0 };
  el.querySelector('#bp-x').onclick = closeBetPanel;
  el.querySelector('#bp-go').onclick = () => el.querySelector('#bp-r').scrollIntoView({ behavior: 'smooth', block: 'start' });
  el.addEventListener('click', e => { if (e.target === el) closeBetPanel(); });
  renderSlip();
  bpLoad();
  loadBalance().then(() => { if (bp?.el === el) el.querySelector('#bp-bal').textContent = balance == null ? '' : '所持 ' + yen(balance); });
  bp.timer = setInterval(bpTick, 1000);
}
function closeBetPanel() {
  if (!bp) return;
  clearInterval(bp.timer);
  bp.el.remove();
  bp = null;
  root?.querySelectorAll('[data-betbtn]').forEach(b => { b.textContent = betLabel(); });
  const nb = root?.querySelector('[data-nv="vote"]'); if (nb) nb.textContent = slip.length ? `投票(${slip.length})` : '投票';
}
const resetPick = () => { bp.cols = [new Set(), new Set(), new Set()]; bp.box = new Set(); bp.osel = new Set(); };

async function bpLoad() {
  const me = bp;
  const L = me.el.querySelector('#bp-l');
  try {
    if (!me.list) { me.list = await ask('br_list', {}); if (!me.date) me.date = me.list.date; }
  } catch (e) { if (bp === me) L.innerHTML = `<div class="msg">読み込めませんでした: ${esc(e.message)}</div>`; return; }
  if (bp !== me) return;
  if (!me.venue) return renderVenues();
  if (!me.no) { const v = me.list.venues.find(x => x.venue === me.venue); me.no = v?.next_no || 12; }
  L.innerHTML = '<div class="box">読み込み中…</div>';
  try { me.d = await ask('br_race', { venue: me.venue, date: me.date, no: me.no }); } catch (e) { if (bp === me) L.innerHTML = `<div class="msg">読み込めませんでした: ${esc(e.message)}</div>`; return; }
  if (bp !== me) return;
  me.off = me.d ? me.d.server_ms - Date.now() : 0;
  renderPick();
}

// 場の選択(下部の「投票」ボタンから開いたとき)
function renderVenues() {
  const L = bp.el.querySelector('#bp-l'), vs = bp.list.venues.filter(v => v.open);
  L.innerHTML = '<div class="box"><b>レース場を選んでください</b></div>' + vs.map(v => `<button class="vc" data-pv="${v.venue}" ${v.next_no ? '' : 'style="opacity:.6"'}><b>${esc(v.name)}</b> ${gt(v.grade)} <span class="mut">${v.day}日目/${v.days}日</span><br><span style="color:#c33;font-weight:700">${v.next_no ? `${v.next_no}R 締切 ${v.next_deadline}（あと${fmt(v.next_in)}）` : '本日の投票は終了しました'}</span></button>`).join('')
    + (vs.length ? '' : '<div class="msg">開催中のレース場はありません</div>');
  L.querySelectorAll('[data-pv]').forEach(b => b.onclick = () => { bp.venue = +b.dataset.pv; bp.no = 0; resetPick(); bpLoad(); });
}

function remainText() {
  const d = bp?.d;
  if (!d) return '';
  const left = (d.server_ms + d.remain * 1000) - (Date.now() + bp.off);
  return left > 0 ? `締切まで ${fmt(left / 1000)}` : '締め切られています';
}
function bpTick() {
  if (!bp?.d) return;
  const r = bp.el.querySelector('#bp-rem');
  if (r) r.textContent = remainText();
  const left = (bp.d.server_ms + bp.d.remain * 1000) - (Date.now() + bp.off);
  if (bp.d.status === 'open' && left <= 0) { bp.d.status = 'closed'; renderPick(); }
  bp.el.querySelectorAll('.sl tr[data-dl]').forEach(tr => tr.classList.toggle('cl', +tr.dataset.dl <= Date.now() + bp.off));
}

function renderPick() {
  const me = bp, d = me.d, L = me.el.querySelector('#bp-l');
  if (!d) { L.innerHTML = '<div class="msg">レースが見つかりません</div>'; return; }
  const vs = me.list.venues.filter(v => v.open);
  let h = `<div class="box"><div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><select id="bp-v">${vs.map(v => `<option value="${v.venue}" ${v.venue === me.venue ? 'selected' : ''}>${esc(v.name)}</option>`).join('')}</select>`
    + `<b>${d.no}R</b>${gt(d.grade)}<span class="mut">${esc(d.title)}</span><span id="bp-rem" style="margin-left:auto;color:#c33;font-weight:700">${remainText()}</span></div>`
    + `<div class="rr">${d.schedule.map(r => `<button data-pr="${r.no}" class="${r.no === d.no ? 'on' : r.status === 'open' ? '' : 'cl'}">${r.no}R<br><span style="font-size:12px">${r.deadline}</span></button>`).join('')}</div></div>`;
  if (d.status !== 'open') {
    h += `<div class="msg">${esc(d.name)} ${d.no}R は締め切られています。別のレースを選んでください。</div>`;
  } else {
    h += `<div class="tb top">${[['pick', '投票'], ['odds', 'オッズ投票']].map(([k, n]) => `<button data-ptab="${k}" class="${me.tab === k ? 'on' : ''}">${n}</button>`).join('')}</div>`;
    h += `<div class="box"><div class="tb">${KINDS.map(([k, n]) => `<button data-pk="${k}" class="${me.kind === k ? 'on' : ''}">${n}</button>`).join('')}</div>`;
    if (me.tab === 'pick') {
      const one = DEPTH[me.kind] === 1;
      if (!one) h += `<div class="tb">${[['normal', '通常投票'], ['box', 'ボックス投票'], ['form', 'フォーメーション投票']].map(([k, n]) => `<button data-pm="${k}" class="${me.mode === k ? 'on' : ''}" style="background:${me.mode === k ? '#ffd54a' : '#2a6fc0'}">${n}</button>`).join('')}</div>`;
      const mode = one ? 'normal' : me.mode, ord = me.kind === 'tan3' || me.kind === 'tan2';
      const ncol = mode === 'box' ? 1 : DEPTH[me.kind];
      const head = mode === 'box' ? ['選択'] : Array.from({ length: ncol }, (_, i) => one ? (me.kind === 'tan1' ? '1着' : '3着内') : ord ? `${i + 1}着` : `${i + 1}艇目`);
      h += `<table><tr><th>枠</th><th>選手名</th><th>級別</th><th class="op">年齢</th><th class="op">支部</th>${head.map(x => `<th style="width:52px">${x}</th>`).join('')}</tr>`;
      h += d.entries.map(e => `<tr><td>${wk(e.course)}</td><td class="nm">${esc(e.name)}</td><td>${esc(e.grade)}</td><td class="op">${e.age}</td><td class="op">${esc(e.branch)}</td>`
        + Array.from({ length: ncol }, (_, i) => { const on = mode === 'box' ? me.box.has(e.course) : me.cols[i].has(e.course); return `<td style="padding:2px"><button class="pk ${on ? 'on' : ''}" data-c="${i}" data-l="${e.course}">${e.course}</button></td>`; }).join('') + '</tr>').join('');
      h += `<tr><td colspan="3" style="text-align:right" class="mut">全通り</td><td class="op"></td><td class="op"></td>${Array.from({ length: ncol }, (_, i) => `<td style="padding:2px"><button class="all" data-all="${i}">全通り</button></td>`).join('')}</tr></table>`;
    } else {
      h += `<div class="mut" style="margin:2px 0 4px">オッズをタップして選択（もう一度タップで解除）</div>${oddsGrid(me.kind, d.odds[me.kind], d.entries, me.osel)}`;
    }
    h += `<div class="ft"><span>この選択</span><span class="cnt" id="bp-n">0</span><span>ベット</span><button class="btn gy" id="bp-clr">選択解除</button><button class="btn" id="bp-add">ベットリストに追加</button></div></div>`;
  }
  L.innerHTML = h;
  L.querySelector('#bp-v').onchange = e => { me.venue = +e.target.value; me.no = 0; resetPick(); bpLoad(); };
  L.querySelectorAll('[data-pr]').forEach(b => b.onclick = () => { me.no = +b.dataset.pr; resetPick(); bpLoad(); });
  if (d.status !== 'open') return;
  L.querySelectorAll('[data-ptab]').forEach(b => b.onclick = () => { me.tab = b.dataset.ptab; resetPick(); renderPick(); });
  L.querySelectorAll('[data-pk]').forEach(b => b.onclick = () => { me.kind = b.dataset.pk; bet.kind = me.kind; resetPick(); renderPick(); });
  L.querySelectorAll('[data-pm]').forEach(b => b.onclick = () => { me.mode = b.dataset.pm; resetPick(); renderPick(); });
  const one = DEPTH[me.kind] === 1, mode = one ? 'normal' : me.mode;
  L.querySelectorAll('.pk').forEach(b => b.onclick = () => {
    const i = +b.dataset.c, l = +b.dataset.l;
    if (mode === 'box') { me.box.has(l) ? me.box.delete(l) : me.box.add(l); }
    else if (mode === 'normal' && !one) { const on = me.cols[i].has(l); me.cols[i] = new Set(on ? [] : [l]); }
    else { me.cols[i].has(l) ? me.cols[i].delete(l) : me.cols[i].add(l); }
    renderPick();
  });
  L.querySelectorAll('[data-all]').forEach(b => b.onclick = () => {
    const i = +b.dataset.all, s = mode === 'box' ? me.box : me.cols[i], full = s.size === 6;
    const n = full ? new Set() : new Set([1, 2, 3, 4, 5, 6]);
    if (mode === 'box') me.box = n; else me.cols[i] = n;
    if (mode === 'normal' && !one && !full) me.mode = 'form';     // 全通りは複数選択になるのでフォーメーションへ
    renderPick();
  });
  L.querySelectorAll('.tp .oc').forEach(c => c.onclick = () => { const k = c.dataset.c; me.osel.has(k) ? me.osel.delete(k) : me.osel.add(k); c.classList.toggle('sel', me.osel.has(k)); L.querySelector('#bp-n').textContent = combos().length; });
  L.querySelector('#bp-n').textContent = combos().length;
  L.querySelector('#bp-clr').onclick = () => { resetPick(); renderPick(); };
  L.querySelector('#bp-add').onclick = () => {
    const cs = combos();
    if (!cs.length) return uiAlert(mode === 'box' && me.tab === 'pick' ? `${KN[me.kind]}のボックスは${DEPTH[me.kind]}艇以上選んでください` : '組み合わせを選んでください');
    const have = new Set(slip.map(x => raceKey(x) + '|' + x.kind + '|' + x.combo));
    let added = 0;
    for (const c of cs) {
      const id = raceKey(d) + '|' + me.kind + '|' + c;
      if (have.has(id)) continue;
      if (slip.length >= SLIP_MAX) { uiAlert(`ベットリストは${SLIP_MAX}件までです`); break; }
      slip.push({ venue: d.venue, vname: d.name, date: d.date, no: d.no, kind: me.kind, combo: c, odds: d.odds[me.kind]?.[c] ?? null, amount: slipAmt * 100, dl: d.server_ms + d.remain * 1000 - me.off });
      added++;
    }
    saveSlip(); resetPick(); renderPick(); renderSlip();
    if (added < cs.length) uiAlert(`${added}件を追加しました（${cs.length - added}件はすでにリストにあります）`);
  };
}
function combos() {
  const me = bp, valid = me.d?.odds?.[me.kind] || {};
  let cs;
  if (me.tab === 'odds') cs = [...me.osel];
  else {
    const one = DEPTH[me.kind] === 1, mode = one ? 'normal' : me.mode;
    if (one) cs = [...me.cols[0]].map(String);
    else if (mode === 'box') cs = me.box.size >= DEPTH[me.kind] ? genBox(me.kind, me.box) : [];
    else cs = genForm(me.kind, me.cols);
  }
  return cs.filter(c => c in valid).sort(sortKey);
}

// ---- ベットリスト(右側)
function renderSlip() {
  if (!bp) return;
  const R = bp.el.querySelector('#bp-r'), now = Date.now() + (bp.off || 0);
  const total = slip.reduce((s, x) => s + x.amount, 0);
  R.innerHTML = `<div style="display:flex;align-items:center;gap:6px"><b style="flex:1">ベットリスト</b><button class="btn gy" id="bp-del" style="padding:5px 10px">全削除</button></div>`
    + (slip.length ? `<div class="sl"><table><tr><th>No</th><th>場 R</th><th>式別</th><th>組番</th><th>オッズ</th><th>金額</th><th></th></tr>${slip.map((x, i) => `<tr data-dl="${x.dl || 0}" class="${x.dl && x.dl <= now ? 'cl' : ''}"><td>${i + 1}</td><td>${esc(x.vname)}<br>${x.no}R</td><td>${KN[x.kind]}</td><td style="white-space:nowrap">${chips(x.combo)}</td><td>${x.odds == null ? '-' : Number(x.odds).toFixed(1)}</td><td style="white-space:nowrap"><input type="number" min="1" step="1" data-ai="${i}" value="${x.amount / 100}">00 pt</td><td><button class="dx" data-di="${i}" title="削除">✕</button></td></tr>`).join('')}</table></div>`
      : '<div class="mut" style="padding:14px 4px">投票・オッズ投票で組み合わせを選び、「ベットリストに追加」を押してください。</div>')
    + `<div style="display:flex;align-items:center;gap:4px;margin:4px 0;flex-wrap:wrap"><span>一括入力</span><input type="number" id="bp-ba" min="1" step="1" value="${slipAmt}" style="width:56px;font-size:16px;padding:3px;text-align:right;background:#fff;color:#222;border:1px solid #9ab;border-radius:4px">00 pt<button class="btn" id="bp-bset" style="padding:5px 10px">全てに反映</button></div>`
    + `<div class="sum"><span>合計ベット数</span><span><b>${slip.length}</b> 件</span></div><div class="sum"><span>総購入金額</span><span><b id="bp-tot">${total.toLocaleString()}</b> G</span></div>`
    + `<button class="btn o" id="bp-buy" style="width:100%;margin-top:6px;font-size:17px;padding:12px" ${slip.length ? '' : 'disabled'}>投票入力完了</button>`;
  R.querySelector('#bp-del').onclick = async () => { if (!slip.length || !await uiConfirm('ベットリストを全て削除しますか？')) return; slip = []; saveSlip(); renderSlip(); };
  R.querySelectorAll('[data-di]').forEach(b => b.onclick = () => { slip.splice(+b.dataset.di, 1); saveSlip(); renderSlip(); });
  R.querySelectorAll('[data-ai]').forEach(inp => {
    inp.oninput = () => { const v = Math.floor(Number(inp.value)); if (Number.isSafeInteger(v) && v >= 1 && v <= 1000) { slip[+inp.dataset.ai].amount = v * 100; saveSlip(); const t = slip.reduce((s, x) => s + x.amount, 0).toLocaleString(); R.querySelector('#bp-tot').textContent = t; bp.el.querySelector('#bp-mt').textContent = t; } };
    inp.onblur = () => { inp.value = slip[+inp.dataset.ai].amount / 100; };
  });
  const ba = R.querySelector('#bp-ba');
  ba.oninput = () => { const v = Math.floor(Number(ba.value)); if (Number.isSafeInteger(v) && v >= 1 && v <= 1000) slipAmt = v; };
  R.querySelector('#bp-bset').onclick = () => { for (const x of slip) x.amount = slipAmt * 100; saveSlip(); renderSlip(); };
  R.querySelector('#bp-buy').onclick = submitSlip;
  bp.el.querySelector('#bp-mn').textContent = slip.length;
  bp.el.querySelector('#bp-mt').textContent = total.toLocaleString();
}

// ---- まとめて投票(レースごとに送信)
let slipBusy = false;
async function submitSlip() {
  if (slipBusy || !slip.length) return;
  if (purchaseUncertain) return uiAlert('前回の投票が未確認です。購入履歴から状態を確認してから、新しい投票を行ってください。');
  const bad = slip.find(x => !Number.isSafeInteger(x.amount) || x.amount < 100 || x.amount % 100);
  if (bad) return uiAlert('金額は100 pt単位で入力してください');
  slipBusy = true;
  const btn = bp?.el.querySelector('#bp-buy'); if (btn) btn.disabled = true;
  try {
    // 締切済みのレースを先に確認して除く
    const groups = new Map();
    for (const x of slip) { const k = raceKey(x); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(x); }
    const closed = [];
    for (const [k, items] of groups) {
      let d = null;
      try { d = await ask('br_race', { venue: items[0].venue, date: items[0].date, no: items[0].no }); } catch (_) {}
      if (!d || d.status !== 'open') { closed.push(`${items[0].vname} ${items[0].no}R（${items.length}件）`); groups.delete(k); }
    }
    if (closed.length) {
      const ok = await uiConfirm(`締め切られています:\n${closed.join('\n')}\n\nこのレースのベットをリストから削除${groups.size ? 'して、残りを投票' : ''}します。`);
      if (!ok) return;
      const keep = new Set(groups.keys());
      slip = slip.filter(x => keep.has(raceKey(x))); saveSlip(); renderSlip();
      if (!groups.size) return;
    }
    const total = [...groups.values()].flat().reduce((s, x) => s + x.amount, 0);
    const lines = [...groups.values()].map(it => `${it[0].vname} ${it[0].no}R ${it.length}件 ${yen(it.reduce((s, x) => s + x.amount, 0))}`);
    await ensurePurchaseOwner();
    const owner = purchaseOwner, epoch = ownerEpoch;
    if (purchaseUncertain) return uiAlert('このアカウントに未確認の購入があります。購入履歴から確認してください。');
    if (!await uiConfirm(`${lines.join('\n')}\n合計 ${yen(total)} で投票します`)) return;
    let paid = 0;
    for (const [k, items] of groups) {
      for (let i = 0; i < items.length; i += 120) {
        const part = items.slice(i, i + 120);
        if (purchaseOwner !== owner || ownerEpoch !== epoch) { await uiAlert('アカウントが切り替わりました。投票を中止しました。'); return; }
        const request_id = (globalThis.crypto?.randomUUID?.() || `${Date.now()}_${Math.random().toString(36).slice(2)}_${Math.random().toString(36).slice(2)}`).replace(/[^A-Za-z0-9_-]/g, '');
        if (!savePendingPurchase(request_id)) { await uiAlert('購入確認IDを保存できません。安全のため投票を中止しました。'); return; }
        uncertainRequestId = request_id; purchaseUncertain = true; showNetworkStatus();
        let r;
        try {
          r = await ask('br_bet', { venue: part[0].venue, date: part[0].date, no: part[0].no, items: part.map(x => ({ kind: x.kind, combo: x.combo, amount: x.amount })), request_id });
        } catch (e) {
          const msg = String(e.message || '');
          if (/締め切/.test(msg) || /ポイント/.test(msg) || /正しく/.test(msg)) { clearPendingPurchase(); showNetworkStatus(); await uiAlert(`${part[0].vname} ${part[0].no}R: ${msg}${paid ? `\n（ここまでに ${yen(paid)} 投票済み）` : ''}`); return; }
          showNetworkStatus();
          await uiAlert(`投票を確認できませんでした: ${msg}。通信が切れた場合は、再投票前に購入履歴を確認してください。${paid ? `\n（ここまでに ${yen(paid)} 投票済み）` : ''}`);
          return;
        }
        clearPendingPurchase(); showNetworkStatus();
        paid += r?.total || part.reduce((s, x) => s + x.amount, 0);
        const done = new Set(part);
        slip = slip.filter(x => !done.has(x)); saveSlip(); renderSlip();
      }
    }
    await loadBalance();
    if (bp) bp.el.querySelector('#bp-bal').textContent = balance == null ? '' : '所持 ' + yen(balance);
    await uiAlert(`投票しました（${yen(paid)}）。購入履歴で確認できます。`);
  } finally {
    slipBusy = false;
    const b2 = bp?.el.querySelector('#bp-buy'); if (b2) b2.disabled = !slip.length;
  }
}

function resultBlock(d, dark) {
  const r = d.result, b = dark ? 'border:1px solid #fff5' : '';
  const e = c => d.entries[c - 1];
  return `<div class="card" style="${dark ? 'background:none;box-shadow:none;color:#fff' : ''}"><div class="big">🏁 結果　決まり手: ${esc(r.kimarite)}</div><table style="${dark ? 'color:#fff' : ''}"><tr><th>着</th><th>枠</th><th>選手</th><th>ST</th></tr>${r.order.map((c, i) => `<tr><td>${i + 1}</td><td>${wk(c)}</td><td style="text-align:left">${esc(e(c).name)}</td><td>${r.st[c - 1].toFixed(2)}</td></tr>`).join('')}</table></div>`
    + `<div class="card" style="${dark ? 'background:none;box-shadow:none;color:#fff' : ''}"><b>確定オッズ・払戻(100 pt)</b><table style="${dark ? 'color:#fff' : ''}"><tr><th>賞式</th><th>組番</th><th>オッズ</th><th>払戻</th></tr>${KINDS.map(([k, n]) => Object.entries(r.pay[k]).map(([c, v]) => `<tr><td>${n}</td><td>${chips(c)}</td><td>${v.toFixed(1)}</td><td>${Math.floor(v * 100).toLocaleString()} pt</td></tr>`).join('')).join('')}</table></div>`;
}

// ---------------------------------------------------------------- レース観戦
async function watch(a, d0) {
  let d = d0;
  if (!d?.live) { try { d = await ask('br_race', { venue: a.venue, date: a.date, no: a.no }); } catch (e) { return uiAlert('読み込めませんでした'); } }
  if (!d) return;
  if (!d.live) { stack.length && stack[stack.length - 1].fn === pageRace ? 0 : go(pageRace, { venue: a.venue, date: a.date, no: a.no, tab: 'card' }); return; }
  const live = {
    seed: d.live.seed, odds: d.odds?.tan3, order: d.live.order, st: d.live.st, kimarite: d.live.kimarite, startMs: d.start_ms, offset: d.server_ms - Date.now(), html: '', sound: soundFor(d),
    bets: async () => betsBlock((await ask('br_race', { venue: d.venue, date: d.date, no: d.no }))?.bets, true),
    onDone: async () => {
      for (let i = 0; i < 40; i++) {
        try {
          const r = await ask('br_race', { venue: d.venue, date: d.date, no: d.no });
          if (r?.result) {
            let my = [];
            try { my = (await ask('br_my', {})).bets.filter(b => b.venue === d.venue && b.date === d.date && b.race === d.no); } catch (e) { /* ignore */ }
            live.html = '<div style="text-align:left">' + resultBlock(r, true) + myBlock(my) + '</div>';
            return;
          }
        } catch (e) { /* retry */ }
        await new Promise(s => setTimeout(s, 2000));
      }
    }
  };
  const m = await import('/casino/static/boatrace3d.js?v=br33vol');
  m.openBoatRace({ raceNo: d.no, raceName: (d.stage !== 'prelim' ? d.stage_name + ' ' : '') + d.title, names: d.entries.map(e => e.name.replace(/　/g, '')), racers: d.entries.map(e => ({ name: e.name, branch: e.branch, grade: e.grade, age: e.age })), live });
}

function betsBlock(bets, dark) {
  const st = dark ? 'background:none;box-shadow:none;color:#fff;padding:0' : '';
  if (!bets?.length) return `<div class="card" style="${st}"><b>みんなの投票</b><div class="mut">まだ投票はありません</div></div>`;
  return `<div class="card" style="${st}"><b>みんなの投票</b> <span class="mut">${bets.length}人 / 合計 ${yen(bets.reduce((s, u) => s + u.total, 0))}</span>${bets.map(u => `<div style="border-top:1px solid #8884;margin-top:4px;padding-top:2px"><b>${esc(u.name)}</b> <span class="mut">${yen(u.total)}</span><div>${u.items.slice(0, 30).map(i => `<span style="display:inline-block;margin-right:8px">${i.name} ${chips(i.combo)} ${yen(i.amount)}</span>`).join('')}${u.items.length > 30 ? `…他${u.items.length - 30}点` : ''}</div></div>`).join('')}</div>`;
}

function soundFor(d) {
  const g = d.grade === 'SG' ? 'sg' : (d.grade === 'G1' || d.grade === 'G2') ? 'g1' : 'ippan', k = d.kind === 'final' ? 'final' : 'yosen';
  // loop: レース画面を開いてから結果表示まで鳴らし続ける音。intro(ピット離れ)・bgm(レース中)はそのタイミングで重ねて流す
  return { loop: '/casino/static/br_race_loop.wav?v=2', intro: `/casino/static/br_in_${g}_${k}.mp3?v=2`, bgm: `/casino/static/br_bgm_${k}.mp3?v=2` };
}

function myBlock(my) {
  if (!my.length) return '<div style="margin:6px 0">このレースの投票はありません</div>';
  const pay = my.reduce((s, b) => s + b.payout, 0), cost = my.reduce((s, b) => s + b.amount, 0);
  return `<div class="card" style="background:none;box-shadow:none;color:#fff"><b>あなたの投票</b>（購入 ${yen(cost)} / 払戻 ${yen(pay)}）${my.map(b => `<div>${b.kind_name} ${chips(b.combo)} ${yen(b.amount)} ${b.status === 'win' ? '<b style="color:#ffd54a">的中 +' + yen(b.payout) + '</b>' : b.status === 'lose' ? 'ハズレ' : '集計中'}</div>`).join('')}</div>`;
}

// ---------------------------------------------------------------- 購入履歴・結果
async function pageBets(a) {
  const entry = stack[stack.length - 1];
  const tab = a.tab || 'bets';
  body('購入履歴・結果', '<div class="card">読み込み中…</div>');
  const tabs = `<div class="tabs">${[['bets', '自分の投票'], ['res', '本日の結果']].map(([k, n]) => `<button data-t="${k}" class="${tab === k ? 'on' : ''}">${n}</button>`).join('')}</div><div style="text-align:right;margin:6px 0"><button data-br-refresh type="button">最新情報に更新</button></div>`;
  let h = tabs;
  try {
    if (tab === 'bets') {
      const d = await ensurePurchaseOwner();
      if (!isCurrent(entry)) return;
      balance = d.balance;
      // Successful history retrieval confirms connectivity, not whether an unknown purchase succeeded.
      // Keep the warning until the user explicitly acknowledges reviewing history.
      const cost = d.bets.reduce((s, b) => s + b.amount, 0), pay = d.bets.reduce((s, b) => s + b.payout, 0), fin = d.bets.filter(b => b.status !== 'open');
      const fc = fin.reduce((s, b) => s + b.amount, 0);
      if (purchaseUncertain) h += '<div class="card" style="background:#fff3cd">直前の投票の成立状況を確認してください。<button id="bru-check-status" type="button">購入IDで照会</button> <button id="bru-reconcile" type="button">残高・払戻を再照合</button> <button id="bru-reviewed" type="button">履歴を確認しました</button><div id="bru-reconcile-summary" role="status"></div></div>';
      h += `<div class="card">所持ポイント: <b>${yen(d.balance)}</b><br>確定分 購入 ${yen(fc)} / 払戻 ${yen(pay)} → <b style="color:${pay - fc >= 0 ? '#c00' : '#00a'}">${pay - fc >= 0 ? '+' : ''}${yen(pay - fc)}</b></div>`;
      h += d.bets.length ? '<div class="card" style="padding:4px;overflow:auto"><table><tr><th>レース</th><th>賞式</th><th>組番</th><th>金額</th><th>オッズ</th><th>結果</th></tr>' + d.bets.map(b => `<tr style="${b.status === 'win' ? 'background:#fff3c4' : ''}"><td>${esc(b.name)}<br>${esc(b.label)} ${b.race}R</td><td>${b.kind_name}</td><td>${chips(b.combo)}</td><td>${yen(b.amount)}</td><td>${b.odds.toFixed(1)}</td><td>${b.status === 'open' ? '未確定' : b.status === 'win' ? `<b style="color:#c00">的中<br>+${yen(b.payout)}</b>` : 'ハズレ'}</td></tr>`).join('') + '</table></div>' : '<div class="card">まだ投票していません</div>';
    } else {
      const d = await ask('br_results', {});
      h += d.results.length ? '<div class="card" style="padding:4px;overflow:auto"><table><tr><th>レース</th><th>着順</th><th>3連単</th></tr>' + d.results.map(r => `<tr class="lk" data-rr="${r.venue}" data-date="${esc(r.date || d.date)}" data-no="${r.no}"><td>${esc(r.name)} ${r.no}R<div class="mut">${r.time}</div></td><td>${r.order.slice(0, 3).map(wk).join('')}</td><td>${Math.floor(r.tan3 * 100).toLocaleString()} pt</td></tr>`).join('') + '</table></div>' : '<div class="card">まだ確定したレースはありません</div>';
      if (!isCurrent(entry)) return;
      curDate = d.date;
    }
  } catch (e) { if (isCurrent(entry)) err(e); return; }
  if (!isCurrent(entry)) return;
  body('購入履歴・結果', h);
  const checkStatus = root.querySelector('#bru-check-status');
  if (checkStatus) checkStatus.onclick = async () => {
    if (!uncertainRequestId || !purchaseOwner) return uiAlert('照会用の購入IDとアカウントを確認できません。');
    checkStatus.disabled = true;
    try {
      const statusOwner = purchaseOwner, statusEpoch = ownerEpoch;
      const d = await ask('br_bet_status', { request_id: uncertainRequestId });
      if (purchaseOwner !== statusOwner || ownerEpoch !== statusEpoch) return;
      if (!isCurrent(entry)) return;
      if (d.status === 'confirmed') {
        clearPendingPurchase(); showNetworkStatus();
        await uiAlert(`購入が成立しています（${yen(d.total)}）。購入履歴を更新します。`);
        if (isCurrent(entry)) { stack.pop(); go(pageBets, { tab: 'bets' }); }
      } else {
        await uiAlert('この購入IDの確定記録は見つかりません。未成立と断定せず、履歴・残高を確認してください。自動再購入はしません。');
      }
    } catch (e) { await uiAlert(`照会できませんでした: ${e.message}`); }
    finally { checkStatus.disabled = false; }
  };
  const reconcile = root.querySelector('#bru-reconcile');
  if (reconcile) reconcile.onclick = async () => {
    if (!isCurrent(entry)) return;
    reconcile.disabled = true;
    try {
      const snapshot = await recoverySnapshot();
      if (!isCurrent(entry)) return;
      balance = snapshot.balance;
      const summary = root.querySelector('#bru-reconcile-summary');
      if (summary) summary.textContent = `最新残高: ${yen(snapshot.balance)} / 舟券: ${snapshot.bets.length}件 / 確定: ${snapshot.settled}件 / 払戻: ${yen(snapshot.payout)}。購入IDの未確認状態は維持しています。`;
    } catch (e) {
      if (isCurrent(entry)) await uiAlert(`再照合できませんでした: ${e.message}`);
    } finally { reconcile.disabled = false; }
  };
  const reviewed = root.querySelector('#bru-reviewed');
  if (reviewed) reviewed.onclick = async () => {
    if (!await uiConfirm('購入IDの照会で未確定の場合、購入が成立していないとは限りません。購入履歴と残高を確認しましたか？')) return;
    clearPendingPurchase(); showNetworkStatus(); reviewed.parentElement.remove();
  };
  root.querySelector('[data-br-refresh]').onclick = () => { if (!isCurrent(entry)) return; stack.pop(); go(pageBets, { tab }); };
  root.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { stack.pop(); go(pageBets, { tab: b.dataset.t }); });
  root.querySelectorAll('[data-rr]').forEach(el => el.onclick = () => go(pageRace, { venue: +el.dataset.rr, date: el.dataset.date || curDate, no: +el.dataset.no, tab: 'res' }));
}

// ---------------------------------------------------------------- 選手詳細
async function pageRacer(a) {
  const entry = stack[stack.length - 1];
  body('選手詳細', '<div class="card">読み込み中…</div>');
  let d;
  try { d = await ask('br_racer', { no: a.no }); } catch (e) { if (isCurrent(entry)) err(e); return; }
  if (!isCurrent(entry)) return;
  if (!d) return err(new Error('選手が見つかりません'));
  const r = d.racer;
  let h = `<div class="card"><div class="mut">${r.no} ${esc(r.kana)}</div><div class="big">${esc(r.name)} ${gt(r.grade)}</div><div class="mut">${esc(r.branch)} / ${r.birth} (${r.age}歳) / ${r.height}cm ${r.weight}kg / ${esc(r.blood)}型</div></div>`;
  h += `<div class="card"><b>期別成績</b><table><tr><th>勝率</th><th>2連率</th><th>3連率</th><th>1着</th><th>2着</th><th>出走</th><th>優出</th><th>優勝</th><th>平均ST</th></tr><tr><td>${r.win.toFixed(2)}</td><td>${r.r2.toFixed(1)}</td><td>${r.r3.toFixed(1)}</td><td>${r.w1}</td><td>${r.w2}</td><td>${r.starts}</td><td>${r.fin}</td><td>${r.champ}</td><td>${r.st.toFixed(2)}</td></tr></table></div>`;
  h += '<div class="card"><b>コース別成績</b><table><tr><th>コース</th><th>進入率</th><th>回数</th><th>3連率</th><th>平均ST</th><th>平均着順</th></tr>' + d.course.map(c => `<tr><td>${wk(c.course)}</td><td>${c.enter}%</td><td>${c.n}</td><td>${c.r3.toFixed(1)}</td><td>${c.st.toFixed(2)}</td><td>${c.rank.toFixed(2)}</td></tr>`).join('') + '</table></div>';
  h += '<div class="card"><b>本日の出場</b>' + (d.today.length ? d.today.map(t => `<div>${esc(t.venue)} ${esc(t.title)} ${t.races.join('・')}R</div>`).join('') : '<div class="mut">出場なし</div>') + '</div>';
  h += '<div class="card"><b>出場予定</b>' + (d.schedule.length ? d.schedule.map(s => `<div>${esc(s.from)}〜${esc(s.to)} ${esc(s.venue)} ${gt(s.grade)} ${esc(s.title)}</div>`).join('') : '<div class="mut">なし</div>') + '</div>';
  h += '<div class="card"><b>過去3節成績</b>' + (d.past.length ? d.past.map(s => `<div>${esc(s.from)}〜${esc(s.to)} ${esc(s.venue)} ${gt(s.grade)}<br>着順: ${esc(s.line)}</div>`).join('') : '<div class="mut">なし</div>') + '</div>';
  body(r.name, h);
}

export function openBoatLeague(o) {
  if (root) return;
  onCloseCb = o?.onClose || null;
  shell();
  // Resolve account identity before restoring a saved purchase ID.
  ensurePurchaseOwner().catch(() => { /* purchases stay blocked until identity resolves */ });
  go(pageHome, {});
  if (o?.page === 'vote') openBetPanel(null);
}

// 投票したレースの3分前に知らせるポップアップ
const alerted = new Set();
let alertTimer = null;
export function startRaceAlerts() {
  if (alertTimer) return;
  const tick = async () => {
    if (document.getElementById('br-alert')) return;
    let d;
    try { d = await ask('br_my', {}); } catch (e) { return; }
    const off = d.now_ms - Date.now(), now = Date.now() + off;
    const due = d.bets.filter(b => b.status === 'open' && b.deadline_ms && b.deadline_ms - now <= 180000 && b.deadline_ms - now > -20000 && !alerted.has(b.venue + '|' + b.date + '|' + b.race));
    if (!due.length) return;
    const b = due[0], key = b.venue + '|' + b.date + '|' + b.race;
    alerted.add(key);
    raceAlert(b, off);
  };
  alertTimer = setInterval(tick, 15000);
  tick();
}

function raceAlert(b, off) {
  const o = document.createElement('div');
  o.id = 'br-alert';
  o.style.cssText = 'position:fixed;inset:0;z-index:2147483100;background:#0007;display:flex;align-items:center;justify-content:center;padding:20px';
  o.innerHTML = `<div style="background:#fff;color:#222;border-radius:14px;padding:20px;max-width:340px;width:100%;text-align:center;font-family:sans-serif"><div style="font-size:19px;font-weight:800;color:#c33">🚤 間もなくレースが始まります</div><div style="margin:10px 0;font-size:16px">${esc(b.name)} ${b.race}R<br><span id="br-al-t" style="font-size:14px;color:#556"></span></div><div style="display:flex;gap:10px"><button id="br-al-x" style="flex:1;border:0;border-radius:8px;padding:12px;font-size:15px;font-weight:700;color:#fff;background:#789">閉じる</button><button id="br-al-w" style="flex:1;border:0;border-radius:8px;padding:12px;font-size:15px;font-weight:700;color:#fff;background:#e8861a">レースを見る</button></div></div>`;
  document.body.appendChild(o);
  const t = o.querySelector('#br-al-t'), w = o.querySelector('#br-al-w');
  let go = false, tm = null, busy = false;
  const stop = () => { clearInterval(tm); o.remove(); };
  o.querySelector('#br-al-x').onclick = stop;
  const update = async () => {
    const rem = Math.round((b.deadline_ms - (Date.now() + off)) / 1000);
    t.textContent = rem > 0 ? `締切まで ${Math.floor(rem / 60)}:${String(rem % 60).padStart(2, '0')}` + (go ? '\n始まると自動で観戦画面に移ります' : '') : (go ? 'レース準備中…' : '締切しました');
    if (go && rem <= 0 && !busy) {
      busy = true;
      try {
        const r = await ask('br_race', { venue: b.venue, date: b.date, no: b.race });
        if (r?.live) { stop(); watch({ venue: b.venue, date: b.date, no: b.race }, r); return; }
      } catch (e) { /* retry */ }
      busy = false;
    }
  };
  t.style.whiteSpace = 'pre-wrap';
  w.onclick = () => { go = true; w.disabled = true; w.style.opacity = '.5'; w.textContent = '待機中…'; update(); };
  tm = setInterval(update, 1500);
  update();
}
