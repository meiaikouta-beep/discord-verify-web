// V71: coin-sand panel is positioned beside the cabinet, not over the reels.
(()=>{
const overlay=document.getElementById('ts-pachi-fullscreen-v10');
if(!overlay)return;
const cabinet=document.getElementById('ts-pachi-preview-v10');

const panel=document.createElement('section');panel.id='pachi-coin-sand-v71';panel.hidden=true;
panel.innerHTML=`<div class="sand-light"></div><div style="text-align:center;font-weight:900;letter-spacing:2px">MEDAL SAND</div><div class="sand-screen"><div>残金</div><strong id="sand-money-v71">0 pt</strong><hr><div>貯メダル</div><strong id="sand-saved-v71">0 枚</strong><hr><div>カード残金</div><strong id="sand-card-cash-v71">0 pt</strong><hr><div>クレジット</div><strong id="sand-credit-v71">0 枚</strong><hr><div id="sand-card-status-v71">カード未挿入</div></div><div class="sand-card">🎴 TS CASINO MEMBER</div><div>入金額（1,000ポイント単位）</div><input id="sand-deposit-v71" type="number" min="1000" max="10000" step="1000" value="1000"><div class="sand-buttons"><button data-action="deposit_cash">入金</button><button data-action="lend">貸出 46枚</button><button data-action="issue_card">カード発行</button><button data-action="insert_card">カード挿入</button><button data-action="eject_card">カード返却</button><button data-action="replay">再プレイ</button><button data-action="save">貯メダル</button><button data-action="sand_to_card">残金をカードへ</button><button data-action="bank_exchange">貯メダル換金</button><button data-action="card_cashout">カード残金を換金</button></div><div style="font-size:10px;color:#ffdba4">貯メダル・再プレイはカード挿入中／換金はカード返却後（50枚＝1,000pt）</div>`;
// V12: cabinet and coin sand share one flex-layout parent inside the overlay.
const pair=document.createElement('div');
pair.id='ts-pachi-pair-v12';
cabinet.parentNode.insertBefore(pair,cabinet);
pair.appendChild(cabinet);
pair.appendChild(panel);
panel.style.setProperty('z-index', '2147483646', 'important');

const feedback=document.createElement("div");feedback.id="sand-feedback-v71";feedback.setAttribute("role","status");feedback.textContent="";panel.appendChild(feedback);
let cardInserted=false,gotState=false,retryTimer=0;function retryState(n){clearTimeout(retryTimer);if(gotState||n>8)return;window.dispatchEvent(new Event('pachi:medal-refresh'));retryTimer=setTimeout(()=>retryState(n+1),700);}
// Isolate the coin-sand controls from the cabinet's global input handlers.
for(const type of ['pointerdown','pointerup','mousedown','mouseup','touchstart','touchend','keydown','keyup']){
 panel.addEventListener(type,e=>e.stopPropagation());
}
let pending=null;
let requestSerial=0;
let fbTimer=0;function status(message){feedback.textContent=message;clearTimeout(fbTimer);if(message)fbTimer=setTimeout(()=>{feedback.textContent='';},4000);}
for(const b of panel.querySelectorAll('button[data-action]')){
 b.type='button';
 b.addEventListener('click',e=>{
  e.preventDefault();e.stopPropagation();
  const action=b.dataset.action;
  const saved=Number(panel.querySelector('#sand-saved-v71').textContent.replace(/[^0-9]/g,'')),cardCash=Number(panel.querySelector('#sand-card-cash-v71').textContent.replace(/[^0-9]/g,''));
  const amount=action==='deposit_cash'?Number(panel.querySelector('#sand-deposit-v71').value):action==='lend'?1000:action==='sand_to_card'?Number(panel.querySelector('#sand-money-v71').textContent.replace(/[^0-9]/g,'')):action==='save'?Number(panel.querySelector('#sand-credit-v71').textContent.replace(/[^0-9]/g,'')):action==='replay'?Math.min(50,saved):action==='bank_exchange'?Math.floor(saved/50)*50:action==='card_cashout'?cardCash:0;
  if(action==='deposit_cash'&&(!Number.isSafeInteger(amount)||amount<1000||amount>10000||amount%1000)){
   status('入金は1,000〜10,000ポイントの1,000ポイント単位です');return;
  }
  if(false){status('残高を取得中です。もう一度押してください');window.dispatchEvent(new Event('pachi:medal-refresh'));return;}
   if(['save','replay','sand_to_card','bank_exchange','card_cashout'].includes(action)&&amount<=0){status('移動できるメダルがありません');return;}
  if(['save','replay','sand_to_card'].includes(action)&&!cardInserted){status('先に会員カードを挿入してください');return;}
  if(['bank_exchange','card_cashout'].includes(action)&&cardInserted){status('先に会員カードを返却してください');return;}
  if(pending){status('前の操作を確認中です。少しお待ちください');return;}
  status('処理中: '+b.textContent.trim());
  const serial=++requestSerial;
  pending={action,time:Date.now(),serial};
  window.dispatchEvent(new CustomEvent('pachi:medal-action',{detail:{action,amount}}));
  setTimeout(()=>{if(pending&&pending.serial===serial){pending=null;status('操作結果を確認できませんでした。残高を再照会してから操作してください');window.dispatchEvent(new Event('pachi:medal-refresh'));}},8000);
 });
}
window.addEventListener('pachi:medal-state',e=>{const d=e.detail;panel.querySelector('#sand-money-v71').textContent=Number(d.sand_balance).toLocaleString()+' pt';panel.querySelector('#sand-saved-v71').textContent=Number(d.saved_medals).toLocaleString()+' 枚';panel.querySelector('#sand-card-cash-v71').textContent=Number(d.card_cash||0).toLocaleString()+' pt';panel.querySelector('#sand-credit-v71').textContent=Number(d.credit).toLocaleString()+' 枚';gotState=true;cardInserted=!!d.card_inserted;panel.querySelector('#sand-card-status-v71').textContent=cardInserted?'カード挿入中':'カード未挿入';});
window.addEventListener('pachi:medal-result',e=>{
 const d=e.detail||{};
 if(d.refresh){status(d.message||'残高を取得できません');return;}
 if(!pending||pending.action!==d.action)return;
 pending=null;
 status(d.ok?'操作が完了しました':(d.message||'操作に失敗しました'));
});
// V12: no viewport geometry, translate, or absolute placement.
// CSS lays out the cabinet and coin sand as a single centered unit.
let lastVisible=false;
function syncSand(){
 const visible=!overlay.hidden;
 if(visible!==lastVisible){
  lastVisible=visible;
  panel.hidden=!visible;
  if(visible){
   status('残高を照会中…');
   panel.scrollTop=0;
   gotState=false;retryState(0);
  }
 }
 requestAnimationFrame(syncSand);
}
requestAnimationFrame(syncSand);
})();
