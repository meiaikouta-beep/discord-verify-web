'use strict';

const TRIGGER_JA={
 'level-up':'レベルアップ','use-item':'アイテム使用',trade:'通信交換',shed:'ヌケニン分岐',spin:'回転',
 'three-critical-hits':'1戦で急所3回','take-damage':'1戦で49以上のダメージを受ける','agile-style-move':'早業を20回使う',
 'strong-style-move':'力業を20回使う','recoil-damage':'反動ダメージを受ける','tower-of-darkness':'あくの塔','tower-of-waters':'みずの塔',other:'特殊条件'
};
const LOCATION_REGION={
 'eterna-forest':'シンオウ','mount-coronet':'シンオウ','route-217':'シンオウ',
 'twist-mountain':'イッシュ','chargestone-cave':'イッシュ','pinwheel-forest':'イッシュ',
 'kalos-route-13':'カロス','kalos-route-20':'カロス','frost-cavern':'カロス',
 'petalburg-woods':'ホウエン','shoal-cave':'ホウエン','new-mauville':'ホウエン',
 'lush-jungle':'アローラ','blush-mountain':'アローラ','vast-poni-canyon':'アローラ','mount-lanakila':'アローラ'
};
const j=x=>{try{return typeof x==='string'?JSON.parse(x):x||{}}catch{return{}}};
const key=o=>o?.name||o?.key||null;
const species=o=>{const m=String(o?.url||'').match(/\/(\d+)\/?$/);return m?Number(m[1]):o?.id??o?.name??o?.key??null};
function detail(rule){const d=j(rule.raw_json);return{...d,trigger:key(d.trigger)||rule.api_trigger||rule.bot_trigger||'other',item:key(d.item)||rule.api_item_key||rule.required_item_key||null,held:key(d.held_item)||rule.api_held_item_key||null,time:d.time_of_day||rule.api_time_of_day||'',gender:d.gender??rule.api_gender,knownMove:key(d.known_move)||rule.api_known_move||null,knownType:key(d.known_move_type)||rule.api_known_move_type||null,location:key(d.location)||rule.api_location||null,minHappiness:d.min_happiness??rule.api_min_happiness,minAffection:d.min_affection??rule.api_min_affection,minBeauty:d.min_beauty??rule.api_min_beauty,minLevel:d.min_level??rule.required_level??rule.api_min_level,rain:!!(d.needs_overworld_rain??rule.api_needs_overworld_rain),partySpecies:species(d.party_species)||rule.api_party_species_id||null,partyType:key(d.party_type)||rule.api_party_type||null,relative:d.relative_physical_stats,tradeSpecies:species(d.trade_species)||null,upside:!!d.turn_upside_down,fromSpecies:Number(rule.from_species_id)||Number(String(rule.from_pokemon_key||'').match(/^S:(\d+)$/)?.[1])||null};}
const add=(a,ok,text,code)=>{if(!ok)a.push({code,text})};
function check(rule,mon,ctx={}){
 const d=detail(rule),missing=[],moves=ctx.moves||[],inv=ctx.inventory||new Set(),progress=ctx.progress||{};
 add(missing,!d.minLevel||mon.level>=d.minLevel,`Lv${d.minLevel}以上`,'level');
 if(d.gender!=null){const want=String(d.gender)==='1'?'female':String(d.gender)==='2'?'male':String(d.gender);add(missing,mon.gender===want,want==='male'?'♂である':'♀である','gender')}
 if(d.time){const hour=ctx.hour??12,want=d.time==='day'?hour>=6&&hour<18:hour<6||hour>=18;add(missing,want,d.time==='day'?'昼（6〜18時）':'夜（18〜6時）','time')}
 if(d.minHappiness!=null)add(missing,(progress.friendship??70)>=d.minHappiness,`なつき度 ${progress.friendship??70}/${d.minHappiness}`,'friendship');
 if(d.minAffection!=null){const need=d.minAffection>=2?160:120;add(missing,(progress.friendship??70)>=need,`なつき度 ${progress.friendship??70}/${need}`,'affection')}
 if(d.minBeauty!=null)add(missing,false,'うつくしさ条件は未対応（きれいなウロコ通信を使用）','beauty');
 if(d.knownMove)add(missing,moves.some(m=>m.en===d.knownMove||m.name_en===d.knownMove),`${d.knownMove}を覚えている`,'known-move');
 if(d.knownType)add(missing,moves.some(m=>m.type===d.knownType),`${d.knownType}タイプの技を覚えている`,'known-type');
 if(d.partySpecies)add(missing,(ctx.partySpecies||[]).map(String).includes(String(d.partySpecies)),`手持ちに指定ポケモンがいる`,'party-species');
 if(d.partyType)add(missing,(ctx.partyTypes||[]).includes(d.partyType),`手持ちに${d.partyType}タイプがいる`,'party-type');
 if(d.relative!=null){const n=Number(d.relative),ok=n===1?mon.attack>mon.defense:n===-1?mon.attack<mon.defense:mon.attack===mon.defense;add(missing,ok,n===1?'こうげき＞ぼうぎょ':n===-1?'こうげき＜ぼうぎょ':'こうげき＝ぼうぎょ','stats')}
 if(d.rain)add(missing,ctx.weather==='rain','雨のバトルを経験する','rain');
 if(d.location){const region=LOCATION_REGION[d.location];add(missing,region?ctx.region===region:false,region?`${region}で条件を満たす`:`場所「${d.location}」は未割り当て`,'location')}
 let consume=null,consumeMoney=0,action=null;
 if(d.trigger==='use-item'){consume=d.item;add(missing,ctx.trigger==='item'&&ctx.item===d.item,`${d.item}を使う`,'trigger-item')}
 else if(d.trigger==='trade'){
   if(d.held){consume=d.held;add(missing,inv.has(d.held),`${d.held}をバッグに用意する`,'held-item')}
   if(d.tradeSpecies)add(missing,String(ctx.tradeSpecies||'')===String(d.tradeSpecies),'指定された相手と交換する','trade-species');
   add(missing,ctx.trigger==='trade','通信交換する','trigger-trade');
 }else if(d.trigger==='level-up'){add(missing,ctx.trigger==='level-up'||ctx.trigger==='manual','レベルアップする','trigger-level');if(d.upside){action='rotate';add(missing,ctx.action==='rotate','回転進化を選ぶ（端末逆さ条件のWeb版）','rotate')}}
 else if(d.trigger==='three-critical-hits'){add(missing,(progress.criticalHits||0)>=3,`1戦の急所 ${progress.criticalHits||0}/3`,'critical-hits');action='special'}
 else if(d.trigger==='take-damage'){add(missing,(progress.damageTaken||0)>=49,`1戦の被ダメージ ${progress.damageTaken||0}/49`,'damage-taken');action='special'}
 else if(d.trigger==='spin'){action='spin';if(d.held){consume=d.held;add(missing,inv.has(d.held),`${d.held}をバッグに用意する`,'held-item')}add(missing,ctx.action==='spin','アメざいを選んで回転進化する','spin')}
 else if(d.trigger==='shed'){add(missing,false,'テッカニン進化時に自動判定','shed')}
 else if(['tower-of-darkness','tower-of-waters'].includes(d.trigger)){action=d.trigger;add(missing,(progress.friendship??70)>=160,`なつき度 ${progress.friendship??70}/160`,'friendship');add(missing,ctx.action===d.trigger,`${TRIGGER_JA[d.trigger]}を選ぶ`,'tower')}
 else if(['agile-style-move','strong-style-move'].includes(d.trigger)){const n=d.knownMove?(progress.uses?.[d.knownMove]||0):(progress.moveUses||0);add(missing,n>=20,`指定技の使用 ${n}/20`,'move-uses');action='special'}
 else if(d.trigger==='recoil-damage'){add(missing,(progress.recoilDamage||0)>=294,`反動ダメージ ${progress.recoilDamage||0}/294`,'recoil');action='special'}
 else if(d.trigger==='other'){
   action='special';const battles=progress.battle_count||progress.battleCount||0;
   if(d.fromSpecies===57){const n=progress.uses?.['rage-fist']||0;add(missing,n>=20,`ふんどのこぶし使用 ${n}/20`,'move-uses')}
   else if(d.fromSpecies===625)add(missing,battles>=3,`バトル経験 ${battles}/3（かしらのしるし戦のWeb版）`,'battle-count');
   else if([922,946,953].includes(d.fromSpecies))add(missing,battles>=10,`バトル経験 ${battles}/10（1000歩のWeb版）`,'battle-count');
   else if(d.fromSpecies===924)add(missing,mon.level>=25,'Lv25以上でバトルする','level');
   else if(d.fromSpecies===963){add(missing,mon.level>=38,'Lv38以上','level');add(missing,battles>=3,`バトル経験 ${battles}/3（共闘のWeb版）`,'battle-count')}
   else if(d.fromSpecies===999){consumeMoney=9990;add(missing,(ctx.money||0)>=consumeMoney,`9,990円を用意する（コイン999枚のWeb版）`,'money')}
   else add(missing,false,'この特殊進化には個別設定が必要','unsupported-trigger');
 }else add(missing,false,`${TRIGGER_JA[d.trigger]||d.trigger}は個別設定が必要`,'unsupported-trigger');
 return{ok:missing.length===0,missing,detail:d,consume,consumeMoney,action,triggerJa:TRIGGER_JA[d.trigger]||d.trigger};
}
module.exports={detail,check,TRIGGER_JA,LOCATION_REGION};
