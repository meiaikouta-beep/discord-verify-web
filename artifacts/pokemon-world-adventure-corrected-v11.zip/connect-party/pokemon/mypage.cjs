// ============================================================
// マイページ（pokemon3.py の「🪪｜マイページ」＝トレーナーカードのうち、所持金・収集データ・ジムバッジ・ロケット団の証）
//   お気に入り（VC経験値）と孵化器（VC卵）は、Web版では扱わないため載せない
//   ジムバッジは region_name != 'team rocket'、ロケット団の証は region_name = 'team rocket'（元botと同じ）。コンプ条件は 9個 / 2個
// server.cjs から create(ctx) で使う。ctx = { all, one, Z, REGION_JA }
// ============================================================
const ROCKET_NAME = { "ムサシの証": "ムサシ", "コジロウの証": "コジロウ", musashi: "ムサシ", kojirou: "コジロウ" };
const GYM_ALL = 9, ROCKET_ALL = 2;

function create(ctx) {
  const { all, one, Z, REGION_JA } = ctx;
  function view(g, uid) {
    const G = BigInt(g), U = BigInt(uid);
    const money = one("SELECT money FROM users WHERE guild_id = ? AND user_id = ?", G, U)?.money ?? 0;
    const gym = all("SELECT region_name, badge_name FROM user_gym_badges WHERE guild_id=? AND user_id=? AND region_name != 'team rocket' ORDER BY region_name ASC", G, U)
      .map(b => ({ region: REGION_JA[String(b.region_name).toLowerCase()] || b.region_name, badge: b.badge_name }));
    const rocket = all("SELECT badge_name FROM user_gym_badges WHERE guild_id=? AND user_id=? AND region_name = 'team rocket' ORDER BY badge_name ASC", G, U)
      .map(b => ({ who: ROCKET_NAME[b.badge_name] || b.badge_name, badge: b.badge_name }));
    const s = Z.summary(g, uid);
    return { ok: true, money, seen: s.seen, caught: s.caught, total: s.total, owned: s.owned, gym, gymAll: GYM_ALL, gymComplete: gym.length >= GYM_ALL, rocket, rocketAll: ROCKET_ALL, rocketComplete: rocket.length >= ROCKET_ALL };
  }
  return { view };
}
module.exports = { create, GYM_ALL };
