// ============================================================
// ポケモン図鑑（pokemon3.py の「ポケモン検索（図鑑）」＋マイページの図鑑／地方コンプ状況をWeb用に移植）
//   元bot：図鑑番号 or 名前で検索 → 種族の詳細（説明・タイプ・特性・種族値・サーバー内の所持者）
//          マイページ：見つけた数／捕まえた数／所持している種類／地方ごとのコンプ状況
//   Web版：一覧（検索・絞り込み・ページ送り）と詳細を1つの画面にまとめた。user_pokedex の記録を「見つけた／捕まえた」の印として表示する
// server.cjs から create(ctx) で使う。ctx = { all, one, sessions }
// ============================================================
const PAGE = 30;
const REGION_ORDER = ["カントー", "ジョウト", "ホウエン", "シンオウ", "イッシュ", "カロス", "アローラ", "ガラル", "ヒスイ", "パルデア", "ウルトラビースト"];   // 元botのマイページと同じ並び

function create(ctx) {
  const { all, one, sessions, profileName = () => null } = ctx;
  const local = (url, kind) => url ? `/poke/${kind}/${url.slice(url.lastIndexOf("/") + 1)}` : null;
  const img = (m, shiny) => (shiny && local(m.shiny_image_url, "art-shiny")) || local(m.image_url, "art");
  const clip = (t, n) => { t = String(t || "").replace(/[\f\r\n]+/g, " ").replace(/\s+/g, " ").trim(); return t.length > n ? t.slice(0, n - 1) + "…" : t; };
  const json = t => { try { return JSON.parse(t || "{}"); } catch { return {}; } };
  const HABITAT = { cave:"洞窟",forest:"森",grassland:"草原",mountain:"山岳",rare:"珍しい場所","rough-terrain":"荒れ地",sea:"海",urban:"街・建物","waters-edge":"水辺" };
  const METHOD = { "level-up":"レベルアップ",machine:"わざマシン",egg:"タマゴ技",tutor:"教え技" };

  function habitat(m) {
    const raw = json(m.raw_species_json), key = raw.habitat?.name || raw.habitat || null;
    const where = m.spawn_enabled ? [m.region_name_ja, "冒険で出現"].filter(Boolean).join("・") : m.region_name_ja || null;
    return { key, name: HABITAT[key] || (key ? String(key) : "生息地データなし"), region: m.region_name_ja || null, encounter: where };
  }

  function sizeInfo(m) {
    const raw = json(m.raw_pokemon_json), heightDm = Number(raw.height ?? m.height), weightHg = Number(raw.weight);
    const heightM = Number.isFinite(heightDm) && heightDm > 0 ? heightDm / 10 : null;
    const weightKg = Number.isFinite(weightHg) && weightHg > 0 ? weightHg / 10 : null;
    const heightText = heightM == null ? null : heightM < .5 ? "ひざより低い" : heightM < 1.2 ? "人の腰くらい" : heightM < 1.9 ? "人と同じくらい" : heightM < 3 ? "人よりかなり大きい" : "建物級の大きさ";
    const weightText = weightKg == null ? null : weightKg < 5 ? "とても軽い" : weightKg < 30 ? "持ち上げられる重さ" : weightKg < 100 ? "大人ひとり分ほど" : weightKg < 500 ? "大型動物級" : "車両級の重さ";
    return { heightM, weightKg, humanHeightM: 1.7, heightRatio: heightM == null ? null : Math.min(2.5, heightM / 1.7), heightText, weightText };
  }

  function learnset(m) {
    const keys = m.pokemon_key === `S:${m.species_id}` ? [m.pokemon_key] : [m.pokemon_key, `S:${m.species_id}`];
    const qs = keys.map(() => "?").join(",");
    const rows = all(`SELECT l.move_id,l.learn_method,MIN(COALESCE(l.learn_level,0)) learn_level,mm.name_ja,mm.name_en,mm.type,mm.type_ja,mm.power,mm.accuracy,mm.pp,mm.damage_class
      FROM pokemon_learnset l JOIN pokemon_moves_master mm ON mm.move_id=l.move_id WHERE l.pokemon_key IN (${qs})
      GROUP BY l.move_id,l.learn_method ORDER BY CASE l.learn_method WHEN 'level-up' THEN 0 WHEN 'machine' THEN 1 WHEN 'egg' THEN 2 WHEN 'tutor' THEN 3 ELSE 4 END,learn_level,mm.name_ja`,...keys);
    return rows.map(x => ({ id:x.move_id,name:x.name_ja||x.name_en,type:x.type,typeJa:x.type_ja||x.type,power:x.power,accuracy:x.accuracy,pp:x.pp,damageClass:x.damage_class,method:x.learn_method,methodJa:METHOD[x.learn_method]||x.learn_method,level:x.learn_method==='level-up'?Number(x.learn_level||1):null }));
  }

  function evoCondition(e) {
    const out=[];
    if(e.api_min_level)out.push(`Lv${e.api_min_level}`);
    if(e.api_min_happiness)out.push(`なつき度${e.api_min_happiness}以上`);
    if(e.api_item_key||e.required_item_key)out.push(`${e.api_item_key||e.required_item_key}を使う`);
    if(e.api_held_item_key)out.push(`${e.api_held_item_key}を持って通信交換`);
    if(e.api_trigger==='trade'&&!e.api_held_item_key)out.push("通信交換");
    if(e.api_time_of_day)out.push(e.api_time_of_day==='night'?"夜":"昼");
    if(e.api_gender)out.push(e.api_gender==='female'?"♀":"♂");
    if(e.api_known_move)out.push(`${e.api_known_move}を覚えている`);
    if(e.api_known_move_type)out.push(`${e.api_known_move_type}タイプの技を覚えている`);
    if(e.api_location)out.push(e.api_location);
    if(e.api_needs_overworld_rain)out.push("雨のとき");
    return out.join("・") || e.api_trigger_ja || (e.api_trigger==='level-up'?"レベルアップ":"特殊な条件");
  }

  function evolution(m) {
    const rows=all(`SELECT e.*,fm.display_name_ja fn,fm.species_id fno,fm.image_url fi,fm.shiny_image_url fsi,tm.display_name_ja tn,tm.species_id tno,tm.image_url ti,tm.shiny_image_url tsi
      FROM pokemon_evolution_rules e JOIN pokemon_master fm ON fm.pokemon_key=e.from_pokemon_key JOIN pokemon_master tm ON tm.pokemon_key=e.to_pokemon_key`);
    const adj=new Map();for(const e of rows){for(const [a,b] of [[e.from_pokemon_key,e.to_pokemon_key],[e.to_pokemon_key,e.from_pokemon_key]])(adj.get(a)||adj.set(a,[]).get(a)).push(b)}
    const component=new Set([m.pokemon_key]),queue=[m.pokemon_key];while(queue.length&&component.size<80){const k=queue.shift();for(const n of adj.get(k)||[])if(!component.has(n)){component.add(n);queue.push(n)}}
    const edges=rows.filter(e=>component.has(e.from_pokemon_key)&&component.has(e.to_pokemon_key));
    const data=new Map([[m.pokemon_key,m]]);for(const e of edges){data.set(e.from_pokemon_key,{pokemon_key:e.from_pokemon_key,display_name_ja:e.fn,species_id:e.fno,image_url:e.fi,shiny_image_url:e.fsi});data.set(e.to_pokemon_key,{pokemon_key:e.to_pokemon_key,display_name_ja:e.tn,species_id:e.tno,image_url:e.ti,shiny_image_url:e.tsi})}
    const incoming=new Map([...component].map(k=>[k,0]));for(const e of edges)incoming.set(e.to_pokemon_key,(incoming.get(e.to_pokemon_key)||0)+1);
    const depth=new Map(),todo=[...component].filter(k=>!incoming.get(k));for(const k of todo)depth.set(k,0);if(!todo.length){depth.set(m.pokemon_key,0);todo.push(m.pokemon_key)}
    while(todo.length){const k=todo.shift(),d=depth.get(k)||0;for(const e of edges.filter(x=>x.from_pokemon_key===k)){const nd=d+1;if(!depth.has(e.to_pokemon_key)||depth.get(e.to_pokemon_key)<nd){depth.set(e.to_pokemon_key,nd);todo.push(e.to_pokemon_key)}}}
    const nodes=[...component].map(k=>{const x=data.get(k)||one("SELECT pokemon_key,display_name_ja,species_id,image_url,shiny_image_url FROM pokemon_master WHERE pokemon_key=?",k)||{};return{key:k,no:x.species_id,name:x.display_name_ja||k,img:img(x,false),stage:depth.get(k)||0,current:k===m.pokemon_key}}).sort((a,b)=>a.stage-b.stage||a.no-b.no);
    return { nodes, edges:edges.map(e=>({from:e.from_pokemon_key,to:e.to_pokemon_key,condition:evoCondition(e)})), stages:[...new Set(nodes.map(n=>n.stage))].map(stage=>({stage,nodes:nodes.filter(n=>n.stage===stage)})) };
  }

  // ---------- 全体の進み具合（元botのマイページと同じ数え方：種類＝図鑑No単位） ----------
  function summary(G, U) {
    const seen = one("SELECT COUNT(DISTINCT species_id) c FROM user_pokedex WHERE guild_id=? AND user_id=? AND seen_count > 0", G, U).c;
    const caught = one("SELECT COUNT(DISTINCT species_id) c FROM user_pokedex WHERE guild_id=? AND user_id=? AND caught_count > 0", G, U).c;
    const owned = one("SELECT COUNT(DISTINCT species_id) c FROM user_pokemon_owned WHERE guild_id=? AND user_id=?", G, U).c;
    const total = one("SELECT COUNT(DISTINCT species_id) c FROM pokemon_master").c;
    const tot = new Map(all("SELECT region_name_ja r, COUNT(DISTINCT species_id) c FROM pokemon_master WHERE region_name_ja IS NOT NULL AND region_name_ja != '' GROUP BY region_name_ja").map(r => [r.r, r.c]));
    const own = new Map(all("SELECT m.region_name_ja r, COUNT(DISTINCT o.species_id) c FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key = o.pokemon_key WHERE o.guild_id=? AND o.user_id=? GROUP BY m.region_name_ja", G, U).map(r => [r.r, r.c]));
    const regions = [...tot.keys()].sort((a, b) => (REGION_ORDER.indexOf(a) < 0 ? 99 : REGION_ORDER.indexOf(a)) - (REGION_ORDER.indexOf(b) < 0 ? 99 : REGION_ORDER.indexOf(b)))
      .map(r => ({ name: r, owned: own.get(r) || 0, total: tot.get(r) }));
    return { seen, caught, owned, total, regions };
  }

  // ---------- 一覧：図鑑番号 or 名前（部分一致）、状態・地方で絞り込み。図鑑番号順 ----------
  function list(g, uid, b) {
    const G = BigInt(g), U = BigInt(uid), where = [], args = [];
    const q = String(b.q || "").trim().slice(0, 30);
    if (q) {
      if (/^\d+$/.test(q)) { where.push("m.species_id = ?"); args.push(Number(q)); }
      else { const like = `%${q.replace(/[\\%_]/g, c => "\\" + c)}%`; where.push("(m.display_name_ja LIKE ? ESCAPE '\\' OR m.name_ja LIKE ? ESCAPE '\\')"); args.push(like, like); }
    }
    const st = String(b.state || "all");
    if (st === "caught") where.push("COALESCE(d.caught_count,0) > 0");
    else if (st === "seen") where.push("COALESCE(d.seen_count,0) > 0 AND COALESCE(d.caught_count,0) = 0");
    else if (st === "unseen") where.push("COALESCE(d.seen_count,0) = 0 AND COALESCE(d.caught_count,0) = 0");
    const reg = String(b.region || "").slice(0, 20);
    if (reg) { where.push("m.region_name_ja = ?"); args.push(reg); }
    const W = where.length ? "WHERE " + where.join(" AND ") : "";
    const FROM = "FROM pokemon_master m LEFT JOIN user_pokedex d ON d.pokemon_key = m.pokemon_key AND d.guild_id = ? AND d.user_id = ?";
    const total = one(`SELECT COUNT(*) c ${FROM} ${W}`, G, U, ...args).c;
    const pages = Math.max(1, Math.ceil(total / PAGE)), page = Math.max(0, Math.min(pages - 1, Math.floor(Number(b.page)) || 0));
    const rows = all(`SELECT m.pokemon_key k, m.species_id no, m.display_name_ja dn, m.type1, m.type2, m.type1_ja, m.type2_ja, m.image_url, m.shiny_image_url,
      COALESCE(d.seen_count,0) seen, COALESCE(d.caught_count,0) caught, COALESCE(d.shiny_caught,0) shiny
      ${FROM} ${W} ORDER BY m.species_id ASC, m.pokemon_key ASC LIMIT ${PAGE} OFFSET ${page * PAGE}`, G, U, ...args);
    const items = rows.map(r => ({ key: r.k, no: r.no, name: r.dn || r.k, img: img(r, false), types: [r.type1, r.type2].filter(Boolean), caught: r.caught > 0, seen: r.seen > 0 || r.caught > 0, shiny: r.shiny > 0 }));
    return { total, page, pages, items };
  }

  // ---------- 詳細：説明・タイプ・特性・種族値・自分の記録・サーバー内の所持者 ----------
  function detail(g, uid, key) {
    const G = BigInt(g), U = BigInt(uid), m = one("SELECT * FROM pokemon_master WHERE pokemon_key = ?", String(key || ""));
    if (!m) return { error: "ポケモンが見つかりません" };
    const my = one("SELECT seen_count, caught_count, normal_caught, shiny_caught, first_seen_at, first_caught_at FROM user_pokedex WHERE guild_id=? AND user_id=? AND pokemon_key=?", G, U, m.pokemon_key) || {};
    const mine = one("SELECT COUNT(*) c FROM user_pokemon_owned WHERE guild_id=? AND user_id=? AND pokemon_key=?", G, U, m.pokemon_key).c;
    const owners = all("SELECT CAST(user_id AS TEXT) u, COUNT(*) c FROM user_pokemon_owned WHERE guild_id=? AND pokemon_key=? GROUP BY user_id ORDER BY c DESC, user_id ASC", G, m.pokemon_key);
    const names = new Map(); for (const s of sessions.values()) if (s.g === g) names.set(s.uid, s.name);
    const ab = [m.ability1_ja && m.ability1_ja !== "なし" ? { name: m.ability1_ja, hidden: false } : null, m.ability2_ja && m.ability2_ja !== "なし" ? { name: m.ability2_ja, hidden: false } : null, m.hidden_ability_ja && m.hidden_ability_ja !== "なし" ? { name: m.hidden_ability_ja, hidden: true } : null].filter(Boolean);
    const base = { hp: m.base_hp || 0, attack: m.base_attack || 0, defense: m.base_defense || 0, sp_attack: m.base_sp_attack || 0, sp_defense: m.base_sp_defense || 0, speed: m.base_speed || 0 };
    const known = !!(my.seen_count > 0 || my.caught_count > 0);
    return { ok: true, key: m.pokemon_key, no: m.species_id, name: m.display_name_ja || m.pokemon_key, img: img(m, false), shinyImg: img(m, true) !== img(m, false) ? img(m, true) : null,
      types: [m.type1, m.type2].filter(Boolean), typesJa: [m.type1_ja, m.type2_ja].filter(t => t && t !== "なし"), region: m.region_name_ja || null,
      flavor: clip(m.flavor_text_ja, 400) || null, abilities: ab, base, total: Object.values(base).reduce((a, b) => a + b, 0),
      my: { known, seen: my.seen_count || 0, caught: my.caught_count || 0, normal: my.normal_caught || 0, shiny: my.shiny_caught || 0, firstSeen: my.first_seen_at || null, firstCaught: my.first_caught_at || null, have: mine },
      habitat:habitat(m),size:sizeInfo(m),moves:learnset(m),evolution:evolution(m),
      owners: owners.map(o => ({ name: names.get(o.u) || profileName(g,o.u) || "不明なトレーナー", me: o.u === String(uid), count: o.c })), ownerTotal: owners.reduce((a, o) => a + o.c, 0), ownerUsers: owners.length };
  }

  return { summary: (g, uid) => summary(BigInt(g), BigInt(uid)), list, detail };
}

module.exports = { create };
