// ============================================================
// ポケモン 通信交換（pokemon3.py の「ポケモンセンター：通信交換」をWeb用に移植）
//   元botの流れ：相手を選ぶ → 自分のポケモンを出す → 相手が応じるポケモンを出す → 双方が最終確認 → 交換 → 通信進化
//   Web版：同じ流れを、サーバー上の「交換の部屋」（メモリ）と1.5秒ごとのポーリングで二人に同期する
//   演出は画面側（index.html）で再生する。交換そのものはサーバーが確認ボタンの時点で一気に確定する
// server.cjs から create(ctx) で使う。
//   ctx = { all, one, run, tx, monImg, hasActiveBattle, sessions, pendingEvo, evolveTrade, log }
// ============================================================
const INVITE_SEC = 300;       // 元botの TargetRespondView(timeout=300)
const CONFIRM_SEC = 180;      // 元botの FinalConfirmView(timeout=180)
const KEEP_SEC = 600;         // 終わった交換の結果を各自が受け取れるよう残しておく時間
const ONLINE_SEC = 90;        // この秒数以内に操作があった人を「いま遊んでいる人」とみなす
const LIST_MAX = 40;

function create(ctx) {
  const { all, one, run, tx, monImg, hasActiveBattle, sessions, pendingEvo, evolveTrade, log } = ctx;
  const now = () => Math.floor(Date.now() / 1000);
  const slots = new Map();      // uid → 交換（終わったものも、本人が閉じるまで残る）
  let seq = 0;
  const finished = t => t.phase === "done" || t.phase === "cancelled";

  // ---------- 表示用 ----------
  const SEL = `SELECT o.*, m.display_name_ja dn, m.image_url m_img, m.shiny_image_url m_simg FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key = o.pokemon_key`;
  const card = o => o && ({
    id: o.owned_id, no: o.species_id, name: o.nickname || o.dn || o.pokemon_key, level: o.level, gender: o.gender || null, shiny: !!o.is_shiny,
    img: monImg({ image_url: o.m_img, shiny_image_url: o.m_simg }, o.is_shiny), ability: o.ability_ja || null,
    hp: o.max_hp, attack: o.attack, defense: o.defense, spAttack: o.sp_attack, spDefense: o.sp_defense, speed: o.speed });
  const getMon = (G, U, id) => card(one(`${SEL} WHERE o.owned_id = ? AND o.guild_id = ? AND o.user_id = ?`, id, G, U));
  const deposited = (G, U, id) => !!one("SELECT 1 x FROM user_pokemon_farm_deposits WHERE guild_id=? AND user_id=? AND owned_id=?", G, U, id);
  const online = s => s && s.exp > Date.now() && Date.now() - (s.seen || 0) < ONLINE_SEC * 1000;

  // ---------- 期限切れの処理 ----------
  function sweep() {
    const t0 = now();
    for (const [uid, t] of slots) {
      if (!finished(t) && t.expires <= t0) { t.phase = "cancelled"; t.reason = t.phase0 === "invite" || t.b.mon == null ? "相手が応じなかったため、交換は取り消されました" : "確認が時間内に終わらなかったため、交換は取り消されました"; t.ended = t0; }
      if (finished(t) && t0 - (t.ended || t0) > KEEP_SEC) slots.delete(uid);
    }
  }
  const timer = setInterval(sweep, 15000); timer.unref?.();

  // ---------- 検索（元botの「ポケモン名、または個体ID」） ----------
  function candidates(g, uid, q) {
    const G = BigInt(g), U = BigInt(uid), kw = String(q ?? "").trim().slice(0, 20);
    const base = `${SEL} WHERE o.guild_id = ? AND o.user_id = ? AND o.owned_id NOT IN (SELECT owned_id FROM user_pokemon_farm_deposits WHERE guild_id = ? AND user_id = ?)`;
    let rows;
    if (!kw) rows = all(`${base} ORDER BY o.owned_id DESC LIMIT ${LIST_MAX}`, G, U, G, U);
    else if (/^\d+$/.test(kw)) rows = all(`${base} AND o.owned_id = ? ORDER BY o.owned_id DESC LIMIT ${LIST_MAX}`, G, U, G, U, Number(kw));
    else rows = all(`${base} AND (m.display_name_ja LIKE ? OR m.name_ja LIKE ? OR o.nickname LIKE ?) ORDER BY o.owned_id DESC LIMIT ${LIST_MAX}`, G, U, G, U, `%${kw}%`, `%${kw}%`, `%${kw}%`);
    return { ok: true, mons: rows.map(card), more: rows.length >= LIST_MAX };
  }

  // ---------- 相手の一覧（いまアクティビティを開いている同じサーバーの人） ----------
  function partners(g, uid, q) {
    sweep();
    const kw = String(q ?? "").trim().toLowerCase(), out = [];
    for (const s of sessions.values()) {
      if (s.uid === uid || s.g !== g || !online(s)) continue;
      if (kw && !String(s.name).toLowerCase().includes(kw)) continue;
      if (out.some(x => x.uid === s.uid)) continue;
      const t = slots.get(s.uid);
      out.push({ uid: s.uid, name: s.name, busy: !!(t && !finished(t)) });
      if (out.length >= 25) break;
    }
    return { ok: true, players: out };
  }

  // ---------- 見え方（その人から見た交換） ----------
  function viewFor(uid) {
    sweep();
    const t = slots.get(uid); if (!t) return { trade: null };
    const me = t.a.uid === uid ? t.a : t.b, th = me === t.a ? t.b : t.a, G = BigInt(t.g);
    const mine = me.mon != null ? (t.snap[me.uid] || getMon(G, BigInt(me.uid), me.mon)) : null;
    const theirs = th.mon != null ? (t.snap[th.uid] || getMon(G, BigInt(th.uid), th.mon)) : null;
    const v = { id: t.id, role: me === t.a ? "launcher" : "target", phase: t.phase, partner: { name: th.name }, mine, theirs, myOk: !!me.ok, theirOk: !!th.ok, remainSec: Math.max(0, t.expires - now()), reason: t.reason || null };
    if (t.phase === "done") v.result = { gave: t.result.byUid[me.uid].gave, got: t.result.byUid[me.uid].got, evo: t.result.evo, partnerName: th.name, myName: me.name };
    return { trade: v };
  }

  // ---------- 申し込み（元botの 相手選択 → 自分のポケモン決定） ----------
  function offer(g, uid, toUid, ownedId) {
    sweep();
    const to = String(toUid), id = Math.floor(Number(ownedId));
    if (hasActiveBattle(uid)) return { error: "バトル中は交換できません" };
    if (to === uid) return { error: "自分とは交換できません" };
    const ts = [...sessions.values()].find(s => s.uid === to && s.g === g && online(s)); if (!ts) return { error: "その相手はいま見つかりません。相手がアクティビティを開いているか確かめてください" };
    if (hasActiveBattle(to)) return { error: "相手はバトル中です" };
    const mine = slots.get(uid), his = slots.get(to);
    if (mine && !finished(mine)) return { error: "すでに交換の途中です" };
    if (his && !finished(his)) return { error: "相手はほかの交換の途中です" };
    const G = BigInt(g), U = BigInt(uid), me = [...sessions.values()].find(s => s.uid === uid && s.g === g);
    const m = getMon(G, U, id); if (!m) return { error: "そのポケモンは持っていません" };
    if (deposited(G, U, id)) return { error: "牧場に預けているポケモンは交換に出せません" };
    const t = { id: ++seq, g, phase: "invite", phase0: "invite", created: now(), expires: now() + INVITE_SEC, a: { uid, name: me?.name || "あなた", mon: id, ok: false }, b: { uid: to, name: ts.name, mon: null, ok: false }, snap: {}, result: null };
    slots.set(uid, t); slots.set(to, t); return { ok: true };
  }

  // ---------- 相手が応じるポケモンを決める ----------
  function respond(g, uid, tradeId, ownedId) {
    sweep();
    const t = slots.get(uid); if (!t || t.id !== Number(tradeId) || t.b.uid !== uid) return { error: "この交換には応じられません" };
    if (t.phase !== "invite") return { error: "この交換はもう受け付けていません" };
    if (hasActiveBattle(uid)) return { error: "バトル中は交換できません" };
    const G = BigInt(g), U = BigInt(uid), id = Math.floor(Number(ownedId));
    const m = getMon(G, U, id); if (!m) return { error: "そのポケモンは持っていません" };
    if (deposited(G, U, id)) return { error: "牧場に預けているポケモンは交換に出せません" };
    if (!getMon(BigInt(t.g), BigInt(t.a.uid), t.a.mon)) { cancel0(t, "相手のポケモンが見つからなくなったため、交換は取り消されました"); return { error: "相手のポケモンが見つかりません" }; }
    t.b.mon = id; t.phase = "confirm"; t.phase0 = "confirm"; t.expires = now() + CONFIRM_SEC; t.a.ok = false; t.b.ok = false; return { ok: true };
  }

  function cancel0(t, reason) { t.phase = "cancelled"; t.reason = reason; t.ended = now(); }
  function cancel(g, uid, tradeId, declined) {
    const t = slots.get(uid); if (!t || t.id !== Number(tradeId)) return { error: "交換が見つかりません" };
    if (finished(t)) return { ok: true };
    const mine = t.a.uid === uid ? t.a : t.b, th = mine === t.a ? t.b : t.a;
    cancel0(t, declined ? `${mine.name}さんが交換をことわりました` : `${mine.name}さんが交換をやめました`); return { ok: true };
  }
  // 結果を見終わった／取り消しを見た人の部屋を片づける
  function close(uid, tradeId) { const t = slots.get(uid); if (t && t.id === Number(tradeId) && finished(t)) slots.delete(uid); return { ok: true }; }

  // ---------- 最終確認 → 双方が押したら、その場で交換を確定 ----------
  function confirm(g, uid, tradeId) {
    sweep();
    const t = slots.get(uid); if (!t || t.id !== Number(tradeId)) return { error: "交換が見つかりません" };
    if (t.phase !== "confirm") return { error: "いまは確認できません" };
    (t.a.uid === uid ? t.a : t.b).ok = true;
    if (!(t.a.ok && t.b.ok)) return { ok: true, waiting: true };
    try { execute(t); } catch (e) { log("trade", e.stack || e.message); cancel0(t, "交換の処理に失敗したため、取り消されました（ポケモンは入れ替わっていません）"); }
    return { ok: true };
  }

  function execute(t) {
    const G = BigInt(t.g), A = BigInt(t.a.uid), B = BigInt(t.b.uid), ia = t.a.mon, ib = t.b.mon;
    if (hasActiveBattle(t.a.uid) || hasActiveBattle(t.b.uid)) return cancel0(t, "バトル中の人がいたため、交換は取り消されました");
    tx(() => {
      const ma = getMon(G, A, ia), mb = getMon(G, B, ib);
      if (!ma || !mb || deposited(G, A, ia) || deposited(G, B, ib)) { cancel0(t, "ポケモンの状態が変わったため、交換は取り消されました"); return; }
      // 1. 所持者の入れ替え（元botと同じ）。チームからは外す／お気に入り・目印は新しい持ち主に引き継がない
      run("UPDATE user_pokemon_owned SET user_id = ?, is_starred = 0 WHERE owned_id = ?", B, ia);
      run("UPDATE user_pokemon_owned SET user_id = ?, is_starred = 0 WHERE owned_id = ?", A, ib);
      run("DELETE FROM pokemon_user_group_members WHERE owned_id IN (?, ?)", ia, ib);
      run("DELETE FROM user_favorite_pokemon WHERE owned_id IN (?, ?)", ia, ib);
      pendingEvo.get(t.a.uid)?.delete(ia); pendingEvo.get(t.b.uid)?.delete(ib);
      // 2. 通信進化。持ち物・交換相手なども共通進化判定で確認し、必要な持ち物は交換に出した側のバッグから消費する。
      const evo = [];
      for (const [id, owner, ownerUid, prev,otherSpecies,itemOwner] of [[ia, B, t.b.uid, ma,mb.no,A], [ib, A, t.a.uid, mb,ma.no,B]]) {
        const r = evolveTrade(G, owner, id, otherSpecies,itemOwner); if (!r || r.error) continue;
        evo.push({ ownedId: id, ownerUid, fromName: prev.name, fromImg: prev.img, toName: r.name, toImg: r.img, level: r.level, hp: r.hp, attack: r.attack, defense: r.defense, sp_attack: r.sp_attack, sp_defense: r.sp_defense, speed: r.speed });
      }
      t.snap = { [t.a.uid]: ma, [t.b.uid]: mb };   // 演出は「交換前の姿」で見せる
      t.result = { byUid: { [t.a.uid]: { gave: ma, got: mb }, [t.b.uid]: { gave: mb, got: ma } }, evo: evo.map(e => ({ ...e, mine: null })) };
      t.phase = "done"; t.ended = now(); t.expires = now() + KEEP_SEC;
    });
    if (t.phase === "done") log("trade", t.a.uid, t.result.byUid[t.a.uid].gave.name, "<->", t.b.uid, t.result.byUid[t.b.uid].gave.name, t.result.evo.length ? `evo×${t.result.evo.length}` : "");
  }

  // viewFor で「自分のポケモンが進化したか」を判定できるよう、進化結果に持ち主の名前と自分用フラグを付ける
  const baseView = viewFor;
  function view(uid) {
    const v = baseView(uid);
    if (v.trade?.result) { const t = slots.get(uid); v.trade.result.evo = v.trade.result.evo.map(e => ({ ...e, mine: e.ownerUid === uid, ownerName: e.ownerUid === t.a.uid ? t.a.name : t.b.name })); }
    return v;
  }

  return { candidates, partners, view, offer, respond, cancel, confirm, close };
}
module.exports = { create, INVITE_SEC, CONFIRM_SEC };
