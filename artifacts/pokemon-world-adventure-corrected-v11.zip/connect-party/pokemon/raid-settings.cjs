module.exports = {
  "RAID_CATEGORY_WEIGHTS_BY_RANK": {
    "1": {
      "final": 97,
      "mega": 1,
      "legendary": 1,
      "mythical": 1
    },
    "2": {
      "final": 90,
      "mega": 3,
      "legendary": 3,
      "mythical": 4
    },
    "3": {
      "final": 85,
      "mega": 4,
      "legendary": 5,
      "mythical": 6
    },
    "4": {
      "final": 70,
      "mega": 8,
      "legendary": 8,
      "mythical": 14
    },
    "5": {
      "final": 40,
      "mega": 22,
      "legendary": 23,
      "mythical": 15
    },
    "6": {
      "special_form": 100
    }
  },
  "RAID_RANK_SETTINGS": {
    "1": {
      "label": "★1",
      "rank_name": "初級レイド",
      "level": 45,
      "iv_hp": 15,
      "iv_attack": 15,
      "iv_defense": 15,
      "iv_sp_attack": 15,
      "iv_sp_defense": 15,
      "iv_speed": 15,
      "hp_multiplier": 20,
      "atk_multiplier": 1.0,
      "def_multiplier": 1.0,
      "spatk_multiplier": 1.0,
      "spdef_multiplier": 1.0,
      "speed_multiplier": 1.0,
      "ball_count": 1
    },
    "2": {
      "label": "★2",
      "rank_name": "中級レイド",
      "level": 55,
      "iv_hp": 20,
      "iv_attack": 20,
      "iv_defense": 20,
      "iv_sp_attack": 20,
      "iv_sp_defense": 20,
      "iv_speed": 20,
      "hp_multiplier": 20,
      "atk_multiplier": 1.1,
      "def_multiplier": 1.1,
      "spatk_multiplier": 1.1,
      "spdef_multiplier": 1.1,
      "speed_multiplier": 1.1,
      "ball_count": 2
    },
    "3": {
      "label": "★3",
      "rank_name": "上級レイド",
      "level": 70,
      "iv_hp": 25,
      "iv_attack": 25,
      "iv_defense": 25,
      "iv_sp_attack": 25,
      "iv_sp_defense": 25,
      "iv_speed": 25,
      "hp_multiplier": 20,
      "atk_multiplier": 1.15,
      "def_multiplier": 1.15,
      "spatk_multiplier": 1.15,
      "spdef_multiplier": 1.15,
      "speed_multiplier": 1.1,
      "ball_count": 3
    },
    "4": {
      "label": "★4",
      "rank_name": "超級レイド",
      "level": 85,
      "iv_hp": 31,
      "iv_attack": 31,
      "iv_defense": 31,
      "iv_sp_attack": 31,
      "iv_sp_defense": 31,
      "iv_speed": 31,
      "hp_multiplier": 20,
      "atk_multiplier": 1.3,
      "def_multiplier": 1.25,
      "spatk_multiplier": 1.3,
      "spdef_multiplier": 1.25,
      "speed_multiplier": 1.2,
      "ball_count": 4
    },
    "5": {
      "label": "★5",
      "rank_name": "伝説レイド",
      "level": 100,
      "iv_hp": 31,
      "iv_attack": 31,
      "iv_defense": 31,
      "iv_sp_attack": 31,
      "iv_sp_defense": 31,
      "iv_speed": 31,
      "hp_multiplier": 25,
      "atk_multiplier": 1.2,
      "def_multiplier": 1.2,
      "spatk_multiplier": 1.2,
      "spdef_multiplier": 1.2,
      "speed_multiplier": 1.2,
      "ball_count": 5
    },
    "6": {
      "label": "★MAX",
      "rank_name": "最凶レイド",
      "level": 100,
      "iv_hp": 31,
      "iv_attack": 31,
      "iv_defense": 31,
      "iv_sp_attack": 31,
      "iv_sp_defense": 31,
      "iv_speed": 31,
      "hp_multiplier": 28,
      "atk_multiplier": 1.3,
      "def_multiplier": 1.3,
      "spatk_multiplier": 1.3,
      "spdef_multiplier": 1.3,
      "speed_multiplier": 1.2,
      "ball_count": 5
    }
  }
};
