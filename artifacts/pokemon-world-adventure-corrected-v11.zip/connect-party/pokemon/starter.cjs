// ============================================================
// ポケモン スターター選択（pokemon3.py の「ポケモンスタート」＝オーキド博士の最初の1匹をWeb用に移植）
//   元botの流れ：一覧から選ぶ → 能力を見て（個体値はこの時点で決まる）→ 決定 / キャンセル → Lv5で仲間になる
//   決定時：所持金20000のユーザー行を作り、ポケモンを登録、Lv5までに覚える技を自動登録、図鑑に登録
//   すでにポケモンを持っている人は選べない（元botの has_started_pokemon と同じ）
// server.cjs から create(ctx) で使う。ctx = { all, one, run, tx, E, P }
// ============================================================
const STARTER_REGIONS = {kanto:{ja:'カントー',ids:[1,4,7]},johto:{ja:'ジョウト',ids:[152,155,158]},hoenn:{ja:'ホウエン',ids:[252,255,258]},sinnoh:{ja:'シンオウ',ids:[387,390,393]},unova:{ja:'イッシュ',ids:[495,498,501]},kalos:{ja:'カロス',ids:[650,653,656]},alola:{ja:'アローラ',ids:[722,725,728]},galar:{ja:'ガラル',ids:[810,813,816]},hisui:{ja:'ヒスイ',ids:[722,155,501]},paldea:{ja:'パルデア',ids:[906,909,912]}};
const STARTER_SPECIES_IDS = [...new Set(Object.values(STARTER_REGIONS).flatMap(r=>r.ids))];
const PENDING_MS = 30 * 60 * 1000;

function create(ctx) {
  const { all, one, run, tx, E, P, trainerName=()=>null } = ctx;
  const local = (url, kind) => url ? `/poke/${kind}/${url.slice(url.lastIndexOf("/") + 1)}` : null;
  const pending = new Map();   // uid → { key, ivs, t }。選んだ時の個体値をサーバーが覚えておく（決定時に画面から送らせない）
  const started = (G, U) => !!one("SELECT owned_id FROM user_pokemon_owned WHERE guild_id=? AND user_id=? LIMIT 1", G, U);
  const rowOf = no => one("SELECT * FROM pokemon_master WHERE species_id = ? AND is_default = 1 LIMIT 1", no);
  const rollIvs = () => ({ hp: E.rnd(0, 31), attack: E.rnd(0, 31), defense: E.rnd(0, 31), sp_attack: E.rnd(0, 31), sp_defense: E.rnd(0, 31), speed: E.rnd(0, 31) });

  const regionOf = value => STARTER_REGIONS[String(value)] ? String(value) : Object.keys(STARTER_REGIONS).find(k=>STARTER_REGIONS[k].ja===String(value)) || 'kanto';
  function list(g, uid, region) {
    if (started(BigInt(g), BigInt(uid))) return { error: "すでにポケモンを持っています" };
    const rk=regionOf(region),items = STARTER_REGIONS[rk].ids.map(rowOf).filter(Boolean).map(r => ({ no: r.species_id, name: r.display_name_ja, img: local(r.image_url, "art"), types: [r.type1, r.type2].filter(Boolean), typesJa: [r.type1_ja, r.type2_ja].filter(t => t && t !== "なし") }));
    return { ok: true, region:rk,regionJa:STARTER_REGIONS[rk].ja,regions:Object.entries(STARTER_REGIONS).map(([key,v])=>({key,ja:v.ja})),items };
  }
  // 選んだポケモンを見せる（個体値をここで決める。選び直すたびに引き直し＝元botと同じ）
  function preview(g, uid, no, region) {
    const G = BigInt(g), U = BigInt(uid); if (started(G, U)) return { error: "すでにポケモンを持っています" };
    const rk=regionOf(region);no = Math.floor(Number(no)); if (!STARTER_REGIONS[rk].ids.includes(no)) return { error: "選んだ地方の御三家ではありません" };
    const m = rowOf(no); if (!m) return { error: "ポケモンのデータがまだありません（同期が必要です）" };
    const ivs = rollIvs(), nature = P.randomNature(), st = E.calcStats(m, 5, ivs, {}, nature.key); pending.set(uid, { key: m.pokemon_key, ivs, nature, region:rk, t: Date.now() });
    return { ok: true, no, name: m.display_name_ja, img: local(m.image_url, "art"), types: [m.type1, m.type2].filter(Boolean), typesJa: [m.type1_ja, m.type2_ja].filter(t => t && t !== "なし"), flavor: String(m.flavor_text_ja || "").replace(/[\f\r\n]+/g, " ") || null,
      nature: nature.ja, stats: { hp: st.max_hp, attack: st.attack, defense: st.defense, sp_attack: st.sp_attack, sp_defense: st.sp_defense, speed: st.speed } };
  }
  function confirm(g, uid) {
    const G = BigInt(g), U = BigInt(uid), p = pending.get(uid);
    if (!p || Date.now() - p.t > PENDING_MS) return { error: "もういちどポケモンを選んでください" };
    return tx(() => {
      if (started(G, U)) return { error: "すでにポケモンを持っています" };
      const m = one("SELECT * FROM pokemon_master WHERE pokemon_key = ? LIMIT 1", p.key); if (!m) return { error: "ポケモンが見つかりません" };
      const iv = p.ivs, nature = p.nature || P.randomNature(), st = E.calcStats(m, 5, iv, {}, nature.key);
      const pool = [[m.ability1_en, m.ability1_ja], [m.ability2_en, m.ability2_ja]].filter(a => a[0]), ab = pool.length ? pool[E.rnd(0, pool.length - 1)] : ["none", "なし"];   // 通常特性からランダム（元botと同じ）
      run("INSERT OR IGNORE INTO users (guild_id, user_id, money, created_at) VALUES (?, ?, 20000, strftime('%s','now'))", G, U);
      const values={guild_id:G,user_id:U,pokemon_key:m.pokemon_key,species_id:m.species_id,nickname:null,level:5,exp:P.expFor(5,P.growthType(m)),gender:E.pickGender(m.gender_rate,m.gender_lock),is_shiny:0,
        hp:st.max_hp,max_hp:st.max_hp,attack:st.attack,defense:st.defense,sp_attack:st.sp_attack,sp_defense:st.sp_defense,speed:st.speed,
        iv_hp:iv.hp,iv_attack:iv.attack,iv_defense:iv.defense,iv_sp_attack:iv.sp_attack,iv_sp_defense:iv.sp_defense,iv_speed:iv.speed,nature_key:nature.key,nature_name_ja:nature.ja,
        image_url:m.image_url,obtained_type:'starter',caught_at:Math.floor(Date.now()/1000),ability_key:ab[0],ability_name_ja:ab[1],ability_en:ab[0],ability_ja:ab[1],original_trainer_id:String(uid),original_trainer_name:trainerName(uid),origin_region:STARTER_REGIONS[p.region]?.ja||'カントー'};
      const columns=Object.keys(values),r=run(`INSERT INTO user_pokemon_owned (${columns.join(',')}) VALUES (${columns.map(()=>'?').join(',')})`,...columns.map(k=>values[k]));
      const id = Number(r.lastInsertRowid);
      // Lv5までに覚えるレベルアップ技（同じ技の重複は除く）
      const learned = all("SELECT l.move_id,COALESCE(mm.pp,10) pp FROM pokemon_learnset l JOIN pokemon_moves_master mm ON mm.move_id=l.move_id WHERE l.pokemon_key = ? AND l.learn_level <= 5 AND l.learn_method = 'level-up' GROUP BY l.move_id ORDER BY MIN(l.learn_level) ASC", m.pokemon_key);
      const activeFrom = Math.max(0, learned.length - 4);
      learned.forEach((mv, i) => run("INSERT INTO owned_pokemon_moves (owned_id,slot,move_id,active,current_pp,max_pp) VALUES (?,?,?,?,?,?)", id, i + 1, mv.move_id, i >= activeFrom ? 1 : 0, mv.pp, mv.pp));
      run(`INSERT INTO user_pokedex (guild_id,user_id,pokemon_key,species_id,seen_count,caught_count,normal_caught,shiny_caught,first_seen_at,first_caught_at) VALUES (?,?,?,?,1,1,1,0,strftime('%s','now'),strftime('%s','now'))
        ON CONFLICT(guild_id,user_id,pokemon_key) DO UPDATE SET seen_count=seen_count+1, caught_count=caught_count+1`, G, U, m.pokemon_key, m.species_id);
      pending.delete(uid);
      return { ok: true, name: m.display_name_ja, ownedId: id };
    });
  }
  return { started: (g, uid) => started(BigInt(g), BigInt(uid)), list, preview, confirm };
}
module.exports = { create, STARTER_SPECIES_IDS,STARTER_REGIONS };
