// ポケモンワールド。センター、町、草原、洞窟、水辺を別マップとして管理する。
const REGIONS = [
  ['kanto','カントー',[1,4,7],'若葉と石畳の地方'],['johto','ジョウト',[152,155,158],'歴史ある森と社の地方'],
  ['hoenn','ホウエン',[252,255,258],'海と火山の地方'],['sinnoh','シンオウ',[387,390,393],'雪山と湖の地方'],
  ['unova','イッシュ',[495,498,501],'都市と橋の地方'],['kalos','カロス',[650,653,656],'花と石造りの地方'],
  ['alola','アローラ',[722,725,728],'常夏の島々'],['galar','ガラル',[810,813,816],'草原と競技場の地方'],
  ['hisui','ヒスイ',[722,155,501],'開拓時代の大地'],['paldea','パルデア',[906,909,912],'学院を囲む大地']
].map(([key,ja,starters,summary])=>({key,ja,starters,summary}));
const BY_KEY=Object.fromEntries(REGIONS.map(r=>[r.key,r])),BY_JA=Object.fromEntries(REGIONS.map(r=>[r.ja,r]));

const CENTER=[
 {id:'oak',kind:'facility',action:'oak',label:'オーキド博士',x:0,z:-8,r:3.2},{id:'heal',kind:'facility',action:'heal',label:'回復カウンター',x:-8,z:-8,r:3.5},
 {id:'box',kind:'facility',action:'box',label:'ボックス・チーム端末',x:8,z:-8,r:3.5},{id:'region',kind:'facility',action:'region',label:'地方転送端末',x:-10,z:1,r:3.5},
 {id:'trade',kind:'facility',action:'trade',label:'通信交換',x:10,z:1,r:3.5},{id:'friend',kind:'facility',action:'friend',label:'フレンドバトル受付',x:-7,z:8,r:3.5},
 {id:'exit',kind:'warp',to:'town',label:'町へ出る',x:0,z:12,r:4},{id:'raid-info',kind:'facility',action:'raid',label:'レイド案内',x:7,z:8,r:3.5}
];
const TOWN=[
 {id:'center',kind:'warp',to:'center',label:'ポケモンセンター',x:0,z:17,r:5},{id:'shop',kind:'facility',action:'shop',label:'フレンドリィショップ',x:-18,z:11,r:4.5},
 {id:'gym',kind:'facility',action:'gym',label:'ポケモンジム',x:19,z:10,r:5},{id:'farm',kind:'facility',action:'farm',label:'牧場',x:-22,z:-14,r:5},
 {id:'raid',kind:'facility',action:'raid',label:'レイドステーション',x:22,z:-15,r:5},{id:'town-exit',kind:'warp',to:'route',label:'町の出口・草原へ',x:0,z:-29,r:5}
];
const ROUTE=[
 {id:'town-gate',kind:'warp',to:'town',label:'町へ戻る',x:0,z:27,r:5},{id:'trainer',kind:'facility',action:'trainer',label:'ポケモントレーナー',x:0,z:3,r:3.2},
 {id:'grass-a',kind:'encounter',method:'grass',label:'草むら',x:-12,z:5,r:9},{id:'grass-b',kind:'encounter',method:'grass',label:'草むら',x:11,z:-7,r:9},
 {id:'cave-gate',kind:'warp',to:'cave',label:'岩山の洞窟へ',x:-23,z:-24,r:6},{id:'coast-gate',kind:'warp',to:'coast',label:'海岸・水辺へ',x:23,z:-24,r:6}
];
const CAVE=[
 {id:'route-gate',kind:'warp',to:'route',label:'草原へ戻る',x:0,z:26,r:5},{id:'cave-a',kind:'encounter',method:'cave',label:'洞窟の奥',x:-9,z:-3,r:13},
 {id:'cave-b',kind:'encounter',method:'cave',label:'地底広場',x:11,z:-16,r:12}
];
const COAST=[
 {id:'route-gate',kind:'warp',to:'route',label:'草原へ戻る',x:0,z:27,r:5},{id:'water',kind:'encounter',method:'surf',label:'波乗りエリア',x:10,z:-8,r:18},
 {id:'dock',kind:'encounter',method:'fishing',label:'釣り桟橋',x:-16,z:-11,r:7}
];
const MAPS={center:CENTER,town:TOWN,route:ROUTE,cave:CAVE,coast:COAST};
const WARP={
 'center:town':{x:0,z:8,direction:0},'town:center':{x:0,z:9,direction:Math.PI},'town:route':{x:0,z:23,direction:Math.PI},
 'route:town':{x:0,z:-24,direction:0},'route:cave':{x:0,z:21,direction:Math.PI},'cave:route':{x:-18,z:-19,direction:0},
 'route:coast':{x:0,z:22,direction:Math.PI},'coast:route':{x:18,z:-19,direction:0}
};
const BOUNDS={center:[-15,15,-11,13],town:[-42,42,-36,28],route:[-42,42,-36,30],cave:[-34,34,-32,30],coast:[-38,38,-32,30]};
const TOWN_BLOCKS=[[0,17,12,8],[-18,11,9,7],[19,10,13,10],[-22,-14,12,8],[22,-15,11,9]];
const mapOf=k=>k==='field'?'town':MAPS[k]?k:'center';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0)),dist=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
function blocked(map,x,z){if(map==='center')return Math.abs(x)<8.5&&z>-9.05&&z<-6.95;if(map==='town')return TOWN_BLOCKS.some(([cx,cz,w,d])=>Math.abs(x-cx)<w/2+.45&&Math.abs(z-cz)<d/2+.45);return false}
const jst=now=>new Date(now+9*3600000);
function worldClock(now=Date.now()){const d=jst(now),h=d.getUTCHours(),month=d.getUTCMonth()+1;return{time:h<5?'night':h<10?'morning':h<17?'day':h<20?'evening':'night',timeJa:h<5?'深夜':h<10?'朝':h<17?'昼':h<20?'夕方':'夜',season:[12,1,2].includes(month)?'winter':[3,4,5].includes(month)?'spring':[6,7,8].includes(month)?'summer':'autumn',seasonJa:[12,1,2].includes(month)?'冬':[3,4,5].includes(month)?'春':[6,7,8].includes(month)?'夏':'秋'}}
function hash(s){let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function weather(region,now=Date.now()){const hour=Math.floor((now+9*3600000)/3600000),n=hash(region+':'+hour)%100,pools={hoenn:[[35,'rain','雨'],[47,'sun','強い日差し']],sinnoh:[[32,'snow','雪'],[44,'fog','霧']],hisui:[[35,'snow','雪'],[48,'fog','霧']],alola:[[18,'rain','スコール'],[42,'sun','強い日差し']],paldea:[[18,'rain','雨'],[30,'sun','強い日差し']],galar:[[28,'rain','雨'],[40,'fog','霧']]},p=pools[region]||[[20,'rain','雨'],[30,'fog','霧']];for(const[limit,key,ja]of p)if(n<limit)return{key,ja};return{key:'clear',ja:'晴れ'}}

function create({db,one,run,busy=()=>false}){
 db.exec(`CREATE TABLE IF NOT EXISTS web_world_state(guild_id INTEGER NOT NULL,user_id INTEGER NOT NULL,region_key TEXT NOT NULL DEFAULT 'kanto',map_kind TEXT NOT NULL DEFAULT 'center',x REAL NOT NULL DEFAULT 0,z REAL NOT NULL DEFAULT 6,direction REAL NOT NULL DEFAULT 0,steps INTEGER NOT NULL DEFAULT 0,last_encounter_at INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(guild_id,user_id));`);
 const ids=(g,u)=>[BigInt(g),BigInt(u)];
 function ensure(g,u){const[G,U]=ids(g,u);run(`INSERT OR IGNORE INTO web_world_state(guild_id,user_id,updated_at) VALUES(?,?,strftime('%s','now'))`,G,U);return one('SELECT * FROM web_world_state WHERE guild_id=? AND user_id=?',G,U)}
 function snapshot(g,u,now=Date.now()){const s=ensure(g,u),r=BY_KEY[s.region_key]||REGIONS[0],map=mapOf(s.map_kind),clock=worldClock(now),w=weather(r.key,now);return{ok:true,region:r,regions:REGIONS,map,position:{x:Number(s.x),z:Number(s.z),direction:Number(s.direction)},steps:Number(s.steps),clock,weather:w,triggers:MAPS[map]}}
 function setRegion(g,u,key){const s=ensure(g,u),r=BY_KEY[String(key)]||BY_JA[String(key)];if(!r)return{error:'その地方には移動できません'};if(mapOf(s.map_kind)!=='center')return{error:'地方の変更はポケモンセンターの転送端末で行ってください'};if(busy(String(u)))return{error:'バトル中は地方を変更できません'};const[G,U]=ids(g,u);run(`UPDATE web_world_state SET region_key=?,x=0,z=6,direction=0,updated_at=strftime('%s','now') WHERE guild_id=? AND user_id=?`,r.key,G,U);return snapshot(g,u)}
 function move(g,u,pos){const s=ensure(g,u);if(busy(String(u)))return{error:'バトル中は移動できません'};const rawX=Number(pos.x),rawZ=Number(pos.z);if(!Number.isFinite(rawX)||!Number.isFinite(rawZ))return{error:'位置情報が正しくありません'};const map=mapOf(s.map_kind),[x1,x2,z1,z2]=BOUNDS[map];let x=clamp(rawX,x1,x2),z=clamp(rawZ,z1,z2),d=clamp(pos.direction,-6.4,6.4),delta=Math.hypot(rawX-Number(s.x),rawZ-Number(s.z));if(delta>22)return{error:'移動距離が大きすぎます',position:{x:Number(s.x),z:Number(s.z),direction:Number(s.direction)}};if(blocked(map,x,z))return{error:'建物やカウンターの中には移動できません',position:{x:Number(s.x),z:Number(s.z),direction:Number(s.direction)}};const add=delta>.65?Math.max(1,Math.floor(delta/1.2)):0,[G,U]=ids(g,u);run(`UPDATE web_world_state SET map_kind=?,x=?,z=?,direction=?,steps=steps+?,updated_at=strftime('%s','now') WHERE guild_id=? AND user_id=?`,map,x,z,d,add,G,U);return{ok:true,position:{x,z,direction:d},steps:Number(s.steps)+add}}
 function interact(g,u,id){const s=ensure(g,u),map=mapOf(s.map_kind),t=MAPS[map].find(x=>x.id===String(id));if(!t)return{error:'調べられるものがありません'};if(dist({x:Number(s.x),z:Number(s.z)},t)>t.r+2.5)return{error:'もう少し近づいてください'};if(t.kind==='warp'){const to=t.to,w=WARP[`${map}:${to}`];if(!w)return{error:'移動先が見つかりません'};const[G,U]=ids(g,u);run(`UPDATE web_world_state SET map_kind=?,x=?,z=?,direction=?,steps=0,updated_at=strftime('%s','now') WHERE guild_id=? AND user_id=?`,to,w.x,w.z,w.direction,G,U);return{ok:true,action:'warp',world:snapshot(g,u)}}return{ok:true,action:t.action,label:t.label,method:t.method||null,scene:sceneFor(s.region_key,t.method||t.action,snapshot(g,u).weather,snapshot(g,u).clock)}}
 function sceneFor(region,method,w,c){let stage={grass:'field',fishing:'water',surf:'water',cave:'cave',gym:'stadium',raid:'raid',friend:'stadium'}[method]||'field';if(region==='sinnoh'||region==='hisui')stage=method==='cave'?'cave':method==='gym'?'stadium':method==='surf'||method==='fishing'?'water':'snow';if(region==='hoenn'&&method==='gym')stage='volcano';return{stage,region,method,weather:w?.key||'clear',time:c?.time||'day'}}
 function encounter(g,u,method){const s=ensure(g,u),map=mapOf(s.map_kind);method=String(method);const allowed={route:['grass'],cave:['cave'],coast:['surf','fishing']}[map]||[];if(!allowed.includes(method))return{error:map==='town'?'町の中では野生のポケモンは出ません':'このマップではその方法を使えません'};const here={x:Number(s.x),z:Number(s.z)},zones=MAPS[map].filter(t=>t.kind==='encounter'&&t.method===method&&dist(here,t)<=t.r+1);if(!zones.length)return{error:method==='fishing'?'釣り桟橋で使ってください':'対応する場所まで移動してください'};const now=Date.now();if(now-Number(s.last_encounter_at||0)*1000<2500)return{error:'少し待ってから探してください'};if(method==='grass'&&Number(s.steps)<4)return{ok:true,encounter:false,message:'草むらをもう少し歩いてみよう'};const[G,U]=ids(g,u);run(`UPDATE web_world_state SET steps=0,last_encounter_at=?,updated_at=strftime('%s','now') WHERE guild_id=? AND user_id=?`,Math.floor(now/1000),G,U);const snap=snapshot(g,u,now);return{ok:true,encounter:true,region:snap.region.ja,regionKey:snap.region.key,method,scene:sceneFor(snap.region.key,method,snap.weather,snap.clock),conditions:{...snap.clock,weather:snap.weather}}}
 function faint(g,u){ensure(g,u);const[G,U]=ids(g,u);run(`UPDATE web_world_state SET map_kind='center',x=0,z=9,direction=3.14,steps=0,updated_at=strftime('%s','now') WHERE guild_id=? AND user_id=?`,G,U);return snapshot(g,u)}
 return{snapshot,setRegion,move,interact,encounter,faint,sceneFor,REGIONS,CENTER,TOWN,ROUTE,CAVE,COAST}
}
module.exports={create,REGIONS,CENTER,TOWN,ROUTE,CAVE,COAST,OUTDOOR:TOWN,worldClock,weather};
