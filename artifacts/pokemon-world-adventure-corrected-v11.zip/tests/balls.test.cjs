'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),B=require('../connect-party/pokemon/balls.cjs'),E=require('../connect-party/pokemon/engine.cjs');
const bonus=(key,ctx={})=>B.profile(key,ctx).bonus;

test('基本・タイプ・状態・UBボールの倍率',()=>{
 assert.equal(bonus('poke-ball'),1);assert.equal(bonus('great-ball'),1.5);assert.equal(bonus('ultra-ball'),2);assert.equal(bonus('master-ball'),999);
 assert.equal(bonus('net-ball',{types:['water']}),3.5);assert.equal(bonus('net-ball',{types:['fire']}),1);
 assert.equal(bonus('dream-ball',{status:'sleep'}),4);assert.equal(bonus('dream-ball',{status:'burn'}),1);
 assert.equal(bonus('beast-ball',{ultraBeast:true}),5);assert.equal(bonus('beast-ball',{ultraBeast:false}),.1);
});

test('ターン・レベル・捕獲履歴の条件倍率',()=>{
 assert.equal(bonus('quick-ball',{turns:0}),5);assert.equal(bonus('quick-ball',{turns:1}),1);
 assert.equal(bonus('timer-ball',{turns:0}),1);assert.equal(bonus('timer-ball',{turns:5}),2.5);assert.equal(bonus('timer-ball',{turns:20}),4);
 assert.equal(bonus('nest-ball',{level:1}),4);assert.equal(bonus('nest-ball',{level:30}),1.1);assert.equal(bonus('nest-ball',{level:50}),1);
 assert.equal(bonus('repeat-ball',{caughtBefore:true}),3.5);assert.equal(bonus('repeat-ball',{caughtBefore:false}),1);
});

test('スピード・レベル・性別・進化条件とヘビーボール',()=>{
 assert.equal(bonus('fast-ball',{baseSpeed:100}),4);assert.equal(bonus('fast-ball',{baseSpeed:99}),1);
 assert.equal(bonus('level-ball',{playerLevel:80,level:20}),8);assert.equal(bonus('level-ball',{playerLevel:60,level:30}),4);assert.equal(bonus('level-ball',{playerLevel:31,level:30}),2);
 assert.equal(bonus('love-ball',{sameSpecies:true,playerGender:'male',gender:'female'}),8);assert.equal(bonus('love-ball',{sameSpecies:true,playerGender:'male',gender:'male'}),1);
 assert.equal(bonus('moon-ball',{moonStone:true}),4);assert.equal(B.profile('heavy-ball',{weight:999}).rateAdd,-20);assert.equal(B.profile('heavy-ball',{weight:3000}).rateAdd,30);
});

test('対応外を拒否し数値倍率を捕獲式へ渡せる',()=>{
 assert.equal(B.profile('dive-ball'),null);assert.match(B.UNSUPPORTED['dive-ball'],/釣り/);
 const normal=E.captureChance(100,50,100,1),boosted=E.captureChance(100,50,100,4);assert.ok(boosted>normal);assert.equal(E.captureChance(100,100,3,999),1);
 assert.ok(B.keys.length>=23);assert.equal(new Set(B.keys).size,B.keys.length);
});
