
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users (
    guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, money INTEGER DEFAULT 0, created_at INTEGER, PRIMARY KEY (guild_id, user_id)
);
CREATE TABLE IF NOT EXISTS pokemon_master (
    pokemon_key TEXT PRIMARY KEY, species_id INTEGER NOT NULL, pokeapi_pokemon_id INTEGER NOT NULL, name_ja TEXT, name_en TEXT,
    form_key TEXT, form_name_ja TEXT, display_name_ja TEXT, gender_lock TEXT, type1 TEXT, type2 TEXT, type1_ja TEXT, type2_ja TEXT,
    base_hp INTEGER, base_attack INTEGER, base_defense INTEGER, base_sp_attack INTEGER, base_sp_defense INTEGER, base_speed INTEGER,
    image_url TEXT, shiny_image_url TEXT, sprite_url TEXT, shiny_sprite_url TEXT, cry_url TEXT, is_default INTEGER DEFAULT 0,
    is_mega INTEGER DEFAULT 0, is_gmax INTEGER DEFAULT 0, is_regional INTEGER DEFAULT 0, region_form TEXT, is_legendary INTEGER DEFAULT 0,
    is_mythical INTEGER DEFAULT 0, is_ultra_beast INTEGER DEFAULT 0, gender_rate INTEGER, capture_rate INTEGER, egg_groups_json TEXT,
    generation_no INTEGER, region_name_ja TEXT, flavor_text_ja TEXT, evolution_stage TEXT DEFAULT 'none', evolution_stage_no INTEGER DEFAULT 0,
    spawn_weight INTEGER DEFAULT 100, rarity INTEGER DEFAULT 1, spawn_enabled INTEGER DEFAULT 1, raw_pokemon_json TEXT, raw_species_json TEXT, cached_at INTEGER,
    
    -- ✨ 追加: ポケモンが持つ特性の候補（マスタ用）
    ability1_en TEXT, ability1_ja TEXT,
    ability2_en TEXT, ability2_ja TEXT,
    hidden_ability_en TEXT, hidden_ability_ja TEXT,
    height INTEGER DEFAULT 10
);
CREATE INDEX IF NOT EXISTS idx_pokemon_master_species ON pokemon_master(species_id);
CREATE INDEX IF NOT EXISTS idx_pokemon_master_spawn ON pokemon_master(spawn_enabled, rarity);

CREATE TABLE IF NOT EXISTS pokemon_moves_master (
    move_id INTEGER PRIMARY KEY, name_en TEXT, name_ja TEXT, type TEXT, type_ja TEXT, power INTEGER, accuracy INTEGER, pp INTEGER,
    damage_class TEXT, damage_class_ja TEXT, effect_ja TEXT, flavor_text_ja TEXT, raw_json TEXT, cached_at INTEGER
);

CREATE TABLE IF NOT EXISTS pokemon_move_effect_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    move_id INTEGER NOT NULL,

    effect_type TEXT NOT NULL,
    target_side TEXT DEFAULT 'target',

    chance INTEGER DEFAULT 100,
    value INTEGER DEFAULT 0,

    stat_key TEXT,
    status_key TEXT,
    weather_key TEXT,
    terrain_key TEXT,

    message TEXT,
    extra_json TEXT,

    priority INTEGER DEFAULT 100,
    source TEXT DEFAULT 'manual',

    FOREIGN KEY (move_id) REFERENCES pokemon_moves_master(move_id)
);

CREATE INDEX IF NOT EXISTS idx_move_effect_rules_move_id
ON pokemon_move_effect_rules(move_id);

CREATE TABLE IF NOT EXISTS pokemon_learnset (
    pokemon_key TEXT NOT NULL, move_id INTEGER NOT NULL, learn_method TEXT NOT NULL, learn_method_ja TEXT, learn_level INTEGER DEFAULT 0,
    version_group TEXT, PRIMARY KEY (pokemon_key, move_id, learn_method, learn_level, version_group)
);
CREATE TABLE IF NOT EXISTS pokemon_items_master (
    item_key TEXT PRIMARY KEY, item_id INTEGER, name_en TEXT, name_ja TEXT, category TEXT, item_type TEXT DEFAULT 'misc',
    buy_price INTEGER DEFAULT 0, sell_price INTEGER DEFAULT 0, rarity INTEGER DEFAULT 1, is_shop_item INTEGER DEFAULT 0,
    stack_limit INTEGER DEFAULT 9999, effect_ja TEXT, flavor_text_ja TEXT, sprite_url TEXT, raw_json TEXT, cached_at INTEGER
);
CREATE TABLE IF NOT EXISTS pokemon_evolution_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT, from_pokemon_key TEXT NOT NULL, to_pokemon_key TEXT NOT NULL, from_species_id INTEGER, to_species_id INTEGER,
    api_trigger TEXT, api_trigger_ja TEXT, api_min_level INTEGER, api_item_key TEXT, api_held_item_key TEXT, api_time_of_day TEXT, api_gender TEXT,
    api_known_move TEXT, api_known_move_type TEXT, api_location TEXT, api_min_happiness INTEGER, api_min_beauty INTEGER, api_min_affection INTEGER,
    api_needs_overworld_rain INTEGER DEFAULT 0, api_party_species_id INTEGER, api_party_type TEXT, bot_trigger TEXT DEFAULT 'auto',
    required_item_key TEXT, required_item_qty INTEGER DEFAULT 0, required_level INTEGER, required_money INTEGER DEFAULT 0, raw_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_evo_from ON pokemon_evolution_rules(from_pokemon_key);

CREATE TABLE IF NOT EXISTS user_pokemon_owned (
    owned_id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, pokemon_key TEXT NOT NULL, species_id INTEGER NOT NULL,
    nickname TEXT, level INTEGER DEFAULT 5, exp INTEGER DEFAULT 0, gender TEXT, is_shiny INTEGER DEFAULT 0, is_starred INTEGER NOT NULL DEFAULT 0, hp INTEGER, max_hp INTEGER,
    attack INTEGER, defense INTEGER, sp_attack INTEGER, sp_defense INTEGER, speed INTEGER, iv_hp INTEGER, iv_attack INTEGER, iv_defense INTEGER,
    iv_sp_attack INTEGER, iv_sp_defense INTEGER, iv_speed INTEGER, nature_key TEXT, nature_name_ja TEXT, image_url TEXT, obtained_type TEXT DEFAULT 'capture', caught_at INTEGER,
    
    -- ✨ 追加: この個体が実際に獲得した特性（個体用）
    ability_key TEXT, ability_name_ja TEXT, ability_en TEXT, ability_ja TEXT,
    
    FOREIGN KEY (pokemon_key) REFERENCES pokemon_master(pokemon_key)
);
CREATE INDEX IF NOT EXISTS idx_owned_user ON user_pokemon_owned(guild_id, user_id);

CREATE TABLE IF NOT EXISTS owned_pokemon_moves (
    owned_id INTEGER NOT NULL, slot INTEGER NOT NULL, move_id INTEGER NOT NULL, PRIMARY KEY (owned_id, slot),
    FOREIGN KEY (owned_id) REFERENCES user_pokemon_owned(owned_id), FOREIGN KEY (move_id) REFERENCES pokemon_moves_master(move_id)
);
CREATE TABLE IF NOT EXISTS user_pokedex (
    guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, pokemon_key TEXT NOT NULL, species_id INTEGER NOT NULL, seen_count INTEGER DEFAULT 0,
    caught_count INTEGER DEFAULT 0, normal_caught INTEGER DEFAULT 0, shiny_caught INTEGER DEFAULT 0, first_seen_at INTEGER, first_caught_at INTEGER,
    PRIMARY KEY (guild_id, user_id, pokemon_key)
);
CREATE TABLE IF NOT EXISTS inventory (
    guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, item_key TEXT NOT NULL, qty INTEGER DEFAULT 0, PRIMARY KEY (guild_id, user_id, item_key)
);
CREATE TABLE IF NOT EXISTS sync_state (key TEXT PRIMARY KEY, value TEXT, updated_at INTEGER);
CREATE TABLE IF NOT EXISTS pokemon_spawn_settings (
    guild_id INTEGER PRIMARY KEY, channel_id INTEGER, base_weight INTEGER DEFAULT 100, middle_weight INTEGER DEFAULT 30, final_weight INTEGER DEFAULT 8,
    none_weight INTEGER DEFAULT 30, regional_weight INTEGER DEFAULT 8, base_min_level INTEGER DEFAULT 3, base_max_level INTEGER DEFAULT 10,
    middle_min_level INTEGER DEFAULT 10, middle_max_level INTEGER DEFAULT 25, final_min_level INTEGER DEFAULT 25, final_max_level INTEGER DEFAULT 50,
    none_min_level INTEGER DEFAULT 5, none_max_level INTEGER DEFAULT 30, regional_min_level INTEGER DEFAULT 10, regional_max_level INTEGER DEFAULT 35, updated_at INTEGER
);
CREATE TABLE IF NOT EXISTS pokemon_user_groups (
    group_id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, group_name TEXT NOT NULL, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS pokemon_user_group_members (
    group_id INTEGER NOT NULL, owned_id INTEGER NOT NULL, slot INTEGER NOT NULL, PRIMARY KEY (group_id, slot),
    FOREIGN KEY (group_id) REFERENCES pokemon_user_groups(group_id), FOREIGN KEY (owned_id) REFERENCES user_pokemon_owned(owned_id)
);
CREATE TABLE IF NOT EXISTS pokemon_quick_battle_history (
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    battle_type TEXT NOT NULL,
    region_name TEXT NOT NULL,
    group_id INTEGER NOT NULL,
    trainer_name TEXT,
    trainer_rank INTEGER,
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    PRIMARY KEY (guild_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_pokemon_user_groups_user ON pokemon_user_groups(guild_id, user_id);
CREATE TABLE IF NOT EXISTS bot_settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS gym_leaders (
    leader_id TEXT PRIMARY KEY,
    name_ja TEXT NOT NULL,
    gym_name TEXT NOT NULL,
    type_name TEXT NOT NULL,
    order_index INTEGER DEFAULT 0,
    badge_name TEXT
);

CREATE TABLE IF NOT EXISTS gym_leader_teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    leader_id TEXT NOT NULL,
    pokemon_key TEXT NOT NULL,
    level INTEGER NOT NULL,
    is_ace INTEGER DEFAULT 0,
    FOREIGN KEY (leader_id) REFERENCES gym_leaders(leader_id)
);

CREATE TABLE IF NOT EXISTS user_gym_progress (
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    leader_id TEXT NOT NULL,
    is_defeated INTEGER DEFAULT 0, -- 1: 勝利済み
    PRIMARY KEY (guild_id, user_id, leader_id)
);

CREATE TABLE IF NOT EXISTS user_gym_badges (
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    region_name TEXT NOT NULL,
    badge_name TEXT NOT NULL,
    PRIMARY KEY (
        guild_id,
        user_id,
        region_name,
        badge_name
    )
);

CREATE TABLE IF NOT EXISTS bot_settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS user_favorite_pokemon (
    user_id INTEGER PRIMARY KEY,
    owned_id INTEGER NOT NULL,
    created_at INTEGER DEFAULT (strftime('%s','now')),

    FOREIGN KEY (owned_id) REFERENCES user_pokemon_owned(owned_id)
);

CREATE TABLE IF NOT EXISTS vc_reward_settings (
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    is_enabled INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT (strftime('%s','now')),
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS pokemon_farm_shop_items (
    farm_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    genre TEXT NOT NULL,
    price INTEGER NOT NULL DEFAULT 0,
    grade INTEGER NOT NULL DEFAULT 1,
    multiplier REAL NOT NULL DEFAULT 1.0,
    effect_time INTEGER NOT NULL DEFAULT 0,
    description TEXT
);

CREATE TABLE IF NOT EXISTS user_pokemon_farm_items (
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    farm_item_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,

    PRIMARY KEY (guild_id, user_id, farm_item_id),

    FOREIGN KEY (farm_item_id)
        REFERENCES pokemon_farm_shop_items(farm_item_id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS user_pokemon_farm_deposits (
    farm_deposit_id INTEGER PRIMARY KEY AUTOINCREMENT,

    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    owned_id INTEGER NOT NULL,

    farm_exp INTEGER NOT NULL DEFAULT 0,
    deposited_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),

    UNIQUE(guild_id, user_id, owned_id),

    FOREIGN KEY (owned_id)
        REFERENCES user_pokemon_owned(owned_id)
        ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_farm_deposits_user
ON user_pokemon_farm_deposits(guild_id, user_id);

CREATE TABLE IF NOT EXISTS user_pokemon_farm_eggs (
    farm_egg_id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,

    pokemon_key TEXT NOT NULL,
    species_id INTEGER NOT NULL,
    parent_male_owned_id INTEGER,
    parent_female_owned_id INTEGER,

    hatch_at INTEGER NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),

    is_hatched INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS user_pokemon_farm_hatched (
    farm_hatched_id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,

    pokemon_key TEXT NOT NULL,
    species_id INTEGER NOT NULL,
    level INTEGER NOT NULL DEFAULT 1,
    exp INTEGER NOT NULL DEFAULT 0,
    gender TEXT,
    ability_en TEXT,
    ability_ja TEXT,

    hp INTEGER,
    max_hp INTEGER,
    attack INTEGER,
    defense INTEGER,
    sp_attack INTEGER,
    sp_defense INTEGER,
    speed INTEGER,

    iv_hp INTEGER,
    iv_attack INTEGER,
    iv_defense INTEGER,
    iv_sp_attack INTEGER,
    iv_sp_defense INTEGER,
    iv_speed INTEGER,

    image_url TEXT,
    moves_json TEXT,
    hatched_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS user_pokemon_farm_active_effects (
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    genre TEXT NOT NULL,

    farm_item_id INTEGER NOT NULL,
    multiplier REAL NOT NULL DEFAULT 1.0,
    expires_at INTEGER NOT NULL,

    PRIMARY KEY (guild_id, user_id, genre),

    FOREIGN KEY (farm_item_id)
        REFERENCES pokemon_farm_shop_items(farm_item_id)
        ON DELETE CASCADE
);
