'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const EV=require('../connect-party/pokemon/evolution.cjs');

const mon={level:30,gender:'female',attack:80,defense:70};
const rule=(trigger,extra={})=>({id:1,api_trigger:trigger,raw_json:JSON.stringify({trigger:{name:trigger},...extra})});
const ok=(r,ctx={},m=mon)=>EV.check(r,m,{trigger:'manual',hour:12,progress:{friendship:70,uses:{}},moves:[],inventory:new Set(),partySpecies:[],partyTypes:[],...ctx});

test('レベル・性別・昼夜・なつき度を同時に判定する',()=>{
 const r=rule('level-up',{min_level:30,gender:1,time_of_day:'day',min_happiness:160});
 assert.equal(ok(r,{progress:{friendship:159}}).ok,false);
 assert.deepEqual(ok(r,{progress:{friendship:160}}).missing,[]);
 assert.equal(ok(r,{hour:23,progress:{friendship:200}}).missing.some(x=>x.code==='time'),true);
 assert.equal(ok(r,{progress:{friendship:200}},{...mon,gender:'male'}).missing.some(x=>x.code==='gender'),true);
});

test('技・手持ち・能力比較・天候・場所を判定する',()=>{
 const r=rule('level-up',{known_move:{name:'ancient-power'},known_move_type:{name:'dark'},party_species:{url:'https://pokeapi.co/api/v2/pokemon-species/223/'},party_type:{name:'electric'},relative_physical_stats:1,needs_overworld_rain:true,location:{name:'mount-coronet'}});
 const ctx={moves:[{en:'ancient-power',type:'dark'}],partySpecies:[25,223],partyTypes:['electric'],weather:'rain',region:'シンオウ'};
 assert.equal(ok(r,ctx).ok,true);
 assert.equal(ok(r,{...ctx,partySpecies:[25]}).missing.some(x=>x.code==='party-species'),true);
 assert.equal(ok(r,{...ctx,weather:'sun'}).missing.some(x=>x.code==='rain'),true);
});

test('石・通信持ち物・交換相手を判定し消費物を返す',()=>{
 const stone=rule('use-item',{item:{name:'fire-stone'}});
 assert.equal(ok(stone,{trigger:'item',item:'fire-stone'}).consume,'fire-stone');
 assert.equal(ok(stone,{trigger:'item',item:'water-stone'}).ok,false);
 const trade=rule('trade',{held_item:{name:'metal-coat'},trade_species:{url:'https://pokeapi.co/api/v2/pokemon-species/616/'}});
 const c=ok(trade,{trigger:'trade',tradeSpecies:616,inventory:new Set(['metal-coat'])});
 assert.equal(c.ok,true);assert.equal(c.consume,'metal-coat');
 assert.equal(ok(trade,{trigger:'trade',tradeSpecies:588,inventory:new Set(['metal-coat'])}).missing.some(x=>x.code==='trade-species'),true);
});

test('特殊進化の戦績と明示操作を判定する',()=>{
 assert.equal(ok(rule('three-critical-hits'),{progress:{criticalHits:3}}).ok,true);
 assert.equal(ok(rule('take-damage'),{progress:{damageTaken:49}}).ok,true);
 assert.equal(ok(rule('recoil-damage'),{progress:{recoilDamage:294}}).ok,true);
 const agile=rule('agile-style-move',{known_move:{name:'psyshield-bash'}});
 assert.equal(ok(agile,{moves:[{en:'psyshield-bash',type:'psychic'}],progress:{uses:{'psyshield-bash':20}}}).ok,true);
 const spin=rule('spin',{held_item:{name:'strawberry-sweet'}});
 assert.equal(ok(spin,{action:'spin',inventory:new Set(['strawberry-sweet'])}).ok,true);
 assert.equal(ok(rule('tower-of-darkness'),{action:'tower-of-darkness',progress:{friendship:160}}).ok,true);
});

test('誤進化につながる未割当条件は通さない',()=>{
 assert.equal(ok(rule('other')).ok,false);
 assert.equal(ok(rule('level-up',{min_beauty:170})).ok,false);
 assert.equal(ok(rule('level-up',{location:{name:'unknown-cave'}})).ok,false);
 assert.equal(ok(rule('shed')).ok,false);
});

test('端末操作と本編固有条件をWeb用条件へ置き換える',()=>{
 const inkay=rule('level-up',{min_level:30,turn_upside_down:true});inkay.from_species_id=686;
 assert.equal(ok(inkay).ok,false);assert.equal(ok(inkay,{action:'rotate'}).ok,true);
 const primeape=rule('other');primeape.from_species_id=57;
 assert.equal(ok(primeape,{progress:{uses:{'rage-fist':20}}}).ok,true);
 const pawmo=rule('other');pawmo.from_species_id=922;
 assert.equal(ok(pawmo,{progress:{battle_count:10}}).ok,true);
 const gimmighoul=rule('other');gimmighoul.from_species_id=999;
 const coin=ok(gimmighoul,{money:9990});assert.equal(coin.ok,true);assert.equal(coin.consumeMoney,9990);
});
