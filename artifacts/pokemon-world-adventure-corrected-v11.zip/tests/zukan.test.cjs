'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {DatabaseSync}=require('node:sqlite');

const db=new DatabaseSync(':memory:',{enableForeignKeyConstraints:false});
db.exec(fs.readFileSync(path.join(__dirname,'bot-schema.sql'),'utf8'));
db.exec(`
INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,type1_ja,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,image_url,region_name_ja,spawn_enabled,raw_species_json,raw_pokemon_json,ability1_ja)
VALUES
 ('S:1',1,1,'フシギダネ','grass','くさ',45,49,49,65,65,45,'https://img/1.png','カントー',1,'{"habitat":{"name":"grassland"}}','{"height":7,"weight":69}','しんりょく'),
 ('S:2',2,2,'フシギソウ','grass','くさ',60,62,63,80,80,60,'https://img/2.png','カントー',1,'{"habitat":{"name":"grassland"}}','{"height":10,"weight":130}','しんりょく');
INSERT INTO pokemon_moves_master(move_id,name_en,name_ja,type,type_ja,power,accuracy,pp,damage_class) VALUES
 (1,'tackle','たいあたり','normal','ノーマル',40,100,35,'physical'),(2,'protect','まもる','normal','ノーマル',0,NULL,10,'status');
INSERT INTO pokemon_learnset(pokemon_key,move_id,learn_method,learn_level,version_group) VALUES
 ('S:1',1,'level-up',1,'test'),('S:1',2,'machine',0,'test');
INSERT INTO pokemon_evolution_rules(from_pokemon_key,to_pokemon_key,api_trigger,api_min_level) VALUES('S:1','S:2','level-up',16);
INSERT INTO users(guild_id,user_id,money) VALUES(1,1,0),(1,2,0);
INSERT INTO user_pokemon_owned(guild_id,user_id,pokemon_key,species_id) VALUES(1,2,'S:1',1);
INSERT INTO user_pokedex(guild_id,user_id,pokemon_key,species_id,seen_count,caught_count) VALUES(1,1,'S:1',1,1,1);
`);
const all=(s,...a)=>db.prepare(s).all(...a),one=(s,...a)=>db.prepare(s).get(...a);
const Z=require('../connect-party/pokemon/zukan.cjs').create({all,one,sessions:new Map(),profileName:(g,u)=>u==='2'?'表示名ユーザー':null});

test('図鑑詳細に進化系統・生息地・技・高さ重さを返す',()=>{
 const d=Z.detail('1','1','S:1');
 assert.equal(d.habitat.name,'草原');assert.equal(d.habitat.encounter,'カントー・冒険で出現');
 assert.equal(d.size.heightM,.7);assert.equal(d.size.weightKg,6.9);
 assert.deepEqual(d.moves.map(x=>[x.name,x.methodJa,x.level]),[['たいあたり','レベルアップ',1],['まもる','わざマシン',null]]);
 assert.deepEqual(d.evolution.stages.map(x=>x.nodes.map(n=>n.name)),[['フシギダネ'],['フシギソウ']]);
 assert.equal(d.evolution.edges[0].condition,'Lv16');
});

test('図鑑の所持者はユーザーIDではなく表示名を返す',()=>{
 const d=Z.detail('1','1','S:1');assert.equal(d.owners[0].name,'表示名ユーザー');assert.equal(d.owners[0].me,false);
});
