"""サービスや/etcを書き換えず、仮配置先で成功・再適用・失敗時復旧を検証。"""
from pathlib import Path
from unittest.mock import patch
import io
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

class InstallTest(unittest.TestCase):
    def check_install(self, fail=False, missing_friend=False, repeat=False):
        with tempfile.TemporaryDirectory(prefix='pokemon-install-test-') as folder:
            temp = Path(folder)
            app = temp / 'app'
            shutil.copytree(ROOT / 'connect-party/pokemon', app)
            if missing_friend:
                (app / 'friend.cjs').unlink()
            before = {str(p.relative_to(app)): p.read_bytes() for p in app.rglob('*') if p.is_file()}
            config = temp / 'games-party.env'
            config.write_text('POKEMON_PORT=8501\n')
            source = (ROOT / 'install-integrated.py').read_text()
            source = source.replace("Path('/opt/games-pokemon')", repr(app))
            source = source.replace("Path('/etc/games-party.env')", repr(config))
            source = source.replace("Path('/etc/games-hub.env')", repr(temp / 'games-hub.env'))
            source = source.replace("Path('/root/games-pokemon-integrated-backup-'", "Path(" + repr(str(temp / 'backup-')))
            class Opener:
                def open(self, *args, **kwargs):
                    if fail:
                        raise OSError('simulated failure')
                    return io.BytesIO(b'{"ok":true}')
            def run():
                with patch('subprocess.run'), patch('time.sleep'), patch('urllib.request.build_opener', return_value=Opener()):
                    exec(compile(source, 'installer-test', 'exec'), {'__file__': str(ROOT / 'install-integrated.py'), 'PosixPath': Path})
            if fail:
                with self.assertRaises(SystemExit):
                    run()
                self.assertEqual(before, {str(p.relative_to(app)):p.read_bytes() for p in app.rglob('*') if p.is_file()})
                self.assertEqual(config.read_text(), 'POKEMON_PORT=8501\n')
            else:
                run()
                if repeat:
                    run()
                for p in (ROOT / 'connect-party/pokemon').rglob('*'):
                    if p.is_file():
                        self.assertEqual(p.read_bytes(), (app / p.relative_to(ROOT / 'connect-party/pokemon')).read_bytes())
                self.assertEqual(config.read_text().count('POKEMON_RAID_TEST_SOLO=1'), 1)

    def test_success_and_repeat(self):
        self.check_install(repeat=True)

    def test_add_friend_module(self):
        self.check_install(missing_friend=True)

    def test_rollback(self):
        self.check_install(fail=True)

if __name__ == '__main__':
    unittest.main()
