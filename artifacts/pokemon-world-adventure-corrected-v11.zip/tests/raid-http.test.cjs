'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'raid-http-')),file=path.join(dir,'fixture.sqlite');
const db=new DatabaseSync(file,{enableForeignKeyConstraints:false});
db.exec(fs.readFileSync(path.join(__dirname,'bot-schema.sql'),'utf8'));
db.exec(`CREATE TABLE IF NOT EXISTS bot_settings(key TEXT PRIMARY KEY,value TEXT);
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate) VALUES ('S:3',3,3,'フシギバナ','grass',80,80,80,80,80,80,'final',255);
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate,image_url) VALUES ('S:26',26,26,'ライチュウ','electric',60,90,55,90,80,110,'final',190,'https://fixture/26.png');
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate,image_url) VALUES
 ('S:290',290,290,'ツチニン','bug',31,45,90,30,30,40,'base',255,'https://fixture/290.png'),
 ('S:291',291,291,'テッカニン','bug',61,90,45,50,50,160,'final',120,'https://fixture/291.png'),
 ('S:292',292,292,'ヌケニン','bug',1,90,45,30,30,40,'final',45,'https://fixture/292.png');
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate,image_url) VALUES
 ('S:95',95,95,'イワーク','rock',35,45,160,30,45,70,'base',45,'https://fixture/95.png'),
 ('S:208',208,208,'ハガネール','steel',75,85,200,55,65,30,'final',25,'https://fixture/208.png');
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate,is_mega,image_url) VALUES ('M:3',10003,3,'メガフシギバナ','grass',80,80,80,80,80,80,'final',255,1,'https://fixture/3.png');
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate,is_legendary,image_url) VALUES ('L:3',10004,3,'伝説テスト','grass',80,80,80,80,80,80,'final',255,1,'https://fixture/3.png');
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate,is_mythical,image_url) VALUES ('Y:3',10005,3,'幻テスト','grass',80,80,80,80,80,80,'final',255,1,'https://fixture/3.png');
 INSERT INTO pokemon_evolution_rules(from_pokemon_key,to_pokemon_key) VALUES ('S:1','S:2'),('S:2','S:3');
 INSERT INTO pokemon_evolution_rules(from_pokemon_key,to_pokemon_key,api_trigger,api_min_happiness,raw_json) VALUES ('S:25','S:26','level-up',80,'{"trigger":{"name":"level-up"},"min_happiness":80}');
 INSERT INTO pokemon_evolution_rules(from_pokemon_key,to_pokemon_key,api_trigger,api_min_level,raw_json) VALUES ('S:290','S:291','level-up',20,'{"trigger":{"name":"level-up"},"min_level":20}');
 INSERT INTO pokemon_evolution_rules(from_pokemon_key,to_pokemon_key,api_trigger,api_min_level,raw_json) VALUES ('S:290','S:292','shed',20,'{"trigger":{"name":"shed"},"min_level":20}');
 INSERT INTO pokemon_evolution_rules(from_pokemon_key,to_pokemon_key,api_trigger,api_held_item_key,raw_json) VALUES ('S:95','S:208','trade','metal-coat','{"trigger":{"name":"trade"},"held_item":{"name":"metal-coat"}}');
 INSERT INTO pokemon_moves_master(move_id,name_en,name_ja,type,power,accuracy,pp,damage_class) VALUES (1,'tackle','たいあたり','normal',40,100,35,'physical'),(2,'solar-beam','ソーラービーム','grass',120,100,10,'special');
 INSERT INTO pokemon_learnset(pokemon_key,move_id,learn_method,learn_level) VALUES ('S:3',1,'level-up',1),('S:26',1,'level-up',1),('M:3',1,'level-up',1),('L:3',1,'level-up',1),('Y:3',1,'level-up',1);`);
for(let i=1;i<=3;i++) db.exec(`INSERT INTO users(guild_id,user_id) VALUES(1,${i}); INSERT INTO pokemon_user_groups(group_id,guild_id,user_id,group_name) VALUES(${i},1,${i},'チーム${i}'); INSERT INTO user_pokemon_owned(owned_id,guild_id,user_id,pokemon_key,species_id,level,max_hp,hp,attack,defense,sp_attack,sp_defense,speed) VALUES(${i},1,${i},'S:3',3,100,9999,9999,999,999,999,999,100); INSERT INTO pokemon_user_group_members(group_id,owned_id,slot) VALUES(${i},${i},1); INSERT INTO owned_pokemon_moves VALUES(${i},1,1);`);
db.exec("INSERT INTO owned_pokemon_moves(owned_id,slot,move_id) VALUES(1,2,2)");
db.exec("INSERT INTO users(guild_id,user_id,money) VALUES(1,90000,0)");
db.exec("UPDATE pokemon_master SET image_url='https://fixture/3.png'");
db.exec("UPDATE pokemon_master SET region_name_ja='カントー',spawn_enabled=1,spawn_weight=100,is_default=1 WHERE pokemon_key='S:3'");
for(const [uid,id,name,type] of [[1,25,'ピカチュウ','electric'],[2,6,'リザードン','fire'],[3,9,'カメックス','water']]) {
 db.prepare('INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,image_url) VALUES (?,?,?,?,?,80,80,80,80,80,80,?)').run('S:'+id,id,id,name,type,'https://fixture/'+id+'.png');
 db.prepare('UPDATE user_pokemon_owned SET pokemon_key=?,species_id=? WHERE user_id=?').run('S:'+id,id,uid);
} 
db.exec("INSERT INTO user_pokemon_owned(owned_id,guild_id,user_id,pokemon_key,species_id,level,max_hp,hp,attack,defense,sp_attack,sp_defense,speed,gender) VALUES(10,1,1,'S:25',25,30,100,100,80,70,80,70,90,'female'); INSERT INTO owned_pokemon_moves VALUES(10,1,1)");
db.exec("INSERT INTO pokemon_user_groups(group_id,guild_id,user_id,group_name) VALUES(11,1,1,'進化テスト'); INSERT INTO user_pokemon_owned(owned_id,guild_id,user_id,pokemon_key,species_id,level,exp,max_hp,hp,attack,defense,sp_attack,sp_defense,speed,gender) VALUES(11,1,1,'S:290',290,20,8000,60,60,50,50,50,50,50,'male'); INSERT INTO pokemon_user_group_members(group_id,owned_id,slot) VALUES(11,11,1); INSERT INTO owned_pokemon_moves VALUES(11,1,1)");
db.exec("INSERT INTO user_pokemon_owned(owned_id,guild_id,user_id,pokemon_key,species_id,level,max_hp,hp,attack,defense,sp_attack,sp_defense,speed,gender) VALUES(12,1,1,'S:95',95,30,100,100,80,160,50,50,70,'male'),(13,1,2,'S:3',3,30,100,100,80,80,80,80,80,'female'); INSERT INTO owned_pokemon_moves VALUES(12,1,1),(13,1,1)");
db.exec(`CREATE TABLE pokemon_tm_data(item_key TEXT PRIMARY KEY,move_key TEXT);
 INSERT INTO pokemon_items_master(item_key,item_id,name_ja,item_type,buy_price,is_shop_item) VALUES
 ('poke-ball',1,'モンスターボール','ball',200,1),('quick-ball',2,'クイックボール','ball',1000,1),('dive-ball',3,'ダイブボール','ball',1000,1),('metal-coat',4,'メタルコート','evolution',0,0);
 INSERT INTO inventory(guild_id,user_id,item_key,qty) VALUES(1,1,'poke-ball',5),(1,1,'quick-ball',2),(1,1,'metal-coat',1),(1,1,'raid-ticket',3),(1,1,'rare-battle-ticket',1),(1,1,'protein',1),(1,1,'soothe-bell',1),(1,1,'potion',1);
 UPDATE users SET money=10000 WHERE user_id=1;`);
db.close();
// テスト内だけ設定ファイルを注入する。実際の設定・資格情報は読み書きしない。
const original=fs.readFileSync,interval=global.setInterval;
fs.readFileSync=function(f,...args){if(f==='/etc/games-hub.env')return `DISCORD_CLIENT_ID=test\nDISCORD_BOT_TOKEN=test\nADMIN_USER_IDS=1,2,3,90000\nPOKEMON_DB=${file}\nPOKEMON_RAID_TEST_SOLO=${process.env.RAID_SOLO_TEST==='1'?'1':'0'}\n`;if(f==='/etc/games-party.env')return '';return original.call(this,f,...args)};
global.setInterval=(...a)=>interval(...a).unref();
let S;try{S=require('../connect-party/pokemon/server.cjs')}finally{fs.readFileSync=original;global.setInterval=interval}
for(let i=1;i<=3;i++)S.sessions.set('test'+i,{uid:String(i),g:'1',name:'参加者'+i,exp:Date.now()+600000});
S.sessions.set('test4',{uid:'4',g:'1',name:'一般参加者',exp:Date.now()+600000});
S.sessions.set('test90000',{uid:'90000',g:'1',name:'管理対象',exp:Date.now()+600000});
for(let i=1;i<=3;i++)S.db.prepare("INSERT INTO web_user_profiles(guild_id,user_id,display_name,username) VALUES(1,?,?,?)").run(i,'表示名'+i,'user'+i);
S.db.prepare("INSERT INTO web_user_profiles(guild_id,user_id,display_name,username) VALUES(1,90000,'表示名管理対象','admin-target')").run();
async function main(){
 await new Promise(resolve=>S.server.listen(0,'127.0.0.1',resolve));const port=S.server.address().port;
 const post=async(user,route,b={})=>{const r=await fetch(`http://127.0.0.1:${port}/api/${route}`,{method:'POST',headers:{'content-type':'application/json','x-session':'test'+user},body:JSON.stringify(b)});return {status:r.status,data:await r.json()}};
 assert.equal((await post(9,'raid')).status,401);
 assert.equal((await post(4,'world')).status,200);assert.equal((await post(4,'admin')).status,403);
 const evoBefore=await post(1,'evolution/status',{ownedId:10});assert.equal(evoBefore.status,200);assert.equal(evoBefore.data.rules[0].ready,false);assert.equal(evoBefore.data.rules[0].missing.some(x=>x.code==='friendship'),true);
 S.db.prepare("INSERT INTO web_evolution_progress(owned_id,friendship) VALUES(10,80) ON CONFLICT(owned_id) DO UPDATE SET friendship=80").run();
 const evoReady=await post(1,'evolution/status',{ownedId:10});assert.equal(evoReady.data.rules[0].ready,true);
 const evolved=await post(1,'evolution/evolve',{ownedId:10,ruleId:evoReady.data.rules[0].id});assert.equal(evolved.status,200,JSON.stringify(evolved.data));assert.equal(evolved.data.name,'ライチュウ');
 assert.equal((await post(1,'evolution/status',{ownedId:10})).data.rules.length,0);
 const shedStatus=await post(1,'evolution/status',{ownedId:11});const ninjask=shedStatus.data.rules.find(x=>x.toName==='テッカニン');assert.ok(ninjask?.ready);
 const shed=await post(1,'evolution/evolve',{ownedId:11,ruleId:ninjask.id});assert.equal(shed.status,200,JSON.stringify(shed.data));assert.equal(shed.data.shed.name,'ヌケニン');
 assert.equal(S.db.prepare("SELECT COUNT(*) n FROM pokemon_user_group_members gm JOIN user_pokemon_owned o ON o.owned_id=gm.owned_id WHERE gm.group_id=11 AND o.pokemon_key='S:292'").get().n,1);
 assert.equal(S.db.prepare("SELECT caught_count FROM user_pokedex WHERE guild_id=1 AND user_id=1 AND pokemon_key='S:292'").get().caught_count,1);
 await post(2,'trade');const offered=await post(1,'trade/offer',{to:'2',ownedId:12});assert.equal(offered.status,200,JSON.stringify(offered.data));
 const tradeId=(await post(1,'trade')).data.trade.id;assert.equal((await post(2,'trade/respond',{tradeId,ownedId:13})).status,200);assert.equal((await post(1,'trade/confirm',{tradeId})).status,200);assert.equal((await post(2,'trade/confirm',{tradeId})).status,200);
 assert.equal(S.db.prepare('SELECT pokemon_key FROM user_pokemon_owned WHERE owned_id=12 AND user_id=2').get().pokemon_key,'S:208');assert.equal(S.db.prepare("SELECT qty FROM inventory WHERE guild_id=1 AND user_id=1 AND item_key='metal-coat'").get().qty,0);
 const shop=await post(1,'shop');assert.equal(shop.status,200);assert.equal(shop.data.items.find(x=>x.key==='quick-ball').supported,true);assert.equal(shop.data.items.find(x=>x.key==='dive-ball').supported,false);
 assert.equal((await post(1,'buy',{item:'dive-ball',qty:1})).status,400);const bought=await post(1,'buy',{item:'quick-ball',qty:1});assert.equal(bought.status,200);assert.equal(bought.data.balls['quick-ball'],3);
 const vitamin=await post(1,'item/vitamin',{ownedId:1,item:'protein'});assert.equal(vitamin.status,200,JSON.stringify(vitamin.data));assert.equal(S.db.prepare('SELECT ev_attack FROM user_pokemon_owned WHERE owned_id=1').get().ev_attack,10);assert.equal((await post(1,'mon/held',{ownedId:1,item:'soothe-bell'})).status,200);assert.equal(S.db.prepare('SELECT held_item_key FROM user_pokemon_owned WHERE owned_id=1').get().held_item_key,'soothe-bell');
 const world=await post(1,'world');assert.equal(world.status,200);assert.equal(world.data.map,'center');assert.equal(world.data.regions.length,10);assert.equal((await post(1,'world/region',{region:'hoenn'})).data.region.key,'hoenn');assert.equal((await post(1,'world/region',{region:'kanto'})).data.region.key,'kanto');assert.equal((await post(1,'world/move',{x:0,z:12,direction:0})).status,200);const outside=await post(1,'world/interact',{id:'exit'});assert.equal(outside.data.world.map,'town');assert.equal((await post(1,'world/start',{groupId:1,method:'grass'})).status,400);assert.equal((await post(1,'world/region',{region:'sinnoh'})).status,400);assert.equal((await post(1,'world/move',{x:0,z:-10,direction:0})).status,200);assert.equal((await post(1,'world/move',{x:0,z:-27,direction:0})).status,200);const route=await post(1,'world/interact',{id:'town-exit'});assert.equal(route.data.world.map,'route');assert.equal((await post(1,'world/move',{x:-12,z:5,direction:0})).status,200);const encounter=await post(1,'world/start',{groupId:1,method:'grass'});assert.equal(encounter.status,200,JSON.stringify(encounter.data));assert.equal(encounter.data.scene.stage,'field');assert.equal(encounter.data.fromWorld,true);await post(1,'act',{type:'run'});console.log('PASS HTTP world: center → town → route separation, town encounter rejection and grass battle scene');
 // 統合確認：フレンド対戦とレイドが互いの参加者をロックする。
 for(const u of [1,2,3])assert.equal((await post(u,'friend/state')).status,200);
 const challenge=await post(1,'friend/challenge',{to:'2',groupId:1});assert.equal(challenge.status,200);
 const accepted=await post(2,'friend/accept',{id:challenge.data.outgoing.id,groupId:2});assert.equal(accepted.status,200);
 assert.equal((await post(1,'raid/create',{rank:1})).status,400);
 const otherRaid=await post(3,'raid/create',{rank:1});assert.equal(otherRaid.status,200);
 assert.equal((await post(2,'raid/action',{id:otherRaid.data.room.id,version:otherRaid.data.room.version,type:'join'})).status,409);
 assert.equal((await post(3,'friend/challenge',{to:'1',groupId:3})).status,409);
 assert.equal((await post(1,'start',{groupId:1,region:'カントー'})).status,400);
 assert.equal((await post(1,'friend/act',{type:'move',idx:0})).status,200);
 const friendTurn=await post(2,'friend/act',{type:'move',idx:0,seen:1});assert.equal(friendTurn.status,200);assert.equal(friendTurn.data.battle.n,2);
 if(!friendTurn.data.battle.view.over)assert.equal((await post(1,'friend/act',{type:'forfeit'})).status,200);
 assert.ok((await post(2,'friend/state')).data.battle.view.over?.result);
 for(const u of [1,2])await post(u,'friend/leave');
 const cancelRaid=await post(3,'raid/action',{id:otherRaid.data.room.id,version:otherRaid.data.room.version,type:'leave'});assert.equal(cancelRaid.status,200);
 const chargeStart=await post(1,'start',{groupId:1,region:'カントー'});assert.equal(chargeStart.status,200,JSON.stringify(chargeStart.data));const chargeFirst=await post(1,'act',{type:'move',idx:1});assert.equal(chargeFirst.status,200,JSON.stringify(chargeFirst.data));assert.ok(chargeFirst.data.events.some(x=>x.t==='charge'&&x.name==='ソーラービーム'));assert.equal(chargeFirst.data.events.some(x=>x.t==='move'&&x.side==='p'),false);assert.equal(chargeFirst.data.charging.name,'ソーラービーム');const chargeSecond=await post(1,'act',{type:'continue'});assert.equal(chargeSecond.status,200,JSON.stringify(chargeSecond.data));assert.ok(chargeSecond.data.events.some(x=>x.t==='move'&&x.name==='ソーラービーム'));assert.equal(chargeSecond.data.charging,null);if(!chargeSecond.data.over)await post(1,'act',{type:'run'});console.log('PASS HTTP two-turn move charge event and automatic release without server error');
 S.db.prepare('UPDATE user_pokemon_owned SET hp=max_hp-100 WHERE owned_id=1').run();const wild=await post(1,'start',{groupId:1,region:'カントー'});assert.equal(wild.status,200,JSON.stringify(wild.data));const healed=await post(1,'act',{type:'item',item:'potion'});assert.equal(healed.status,200,JSON.stringify(healed.data));assert.ok(healed.data.events.some(x=>x.t==='heal'));const thrown=await post(1,'act',{type:'ball',ball:'quick-ball'});assert.equal(thrown.status,200,JSON.stringify(thrown.data));assert.equal(thrown.data.events[0].ball,'quick-ball');if(!thrown.data.over)await post(1,'act',{type:'run'});
 const rareBefore=S.db.prepare("SELECT qty FROM inventory WHERE guild_id=1 AND user_id=1 AND item_key='rare-battle-ticket'").get().qty;const rare=await post(1,'rare/start',{groupId:1});assert.equal(rare.status,200,JSON.stringify(rare.data));assert.equal(S.db.prepare("SELECT qty FROM inventory WHERE guild_id=1 AND user_id=1 AND item_key='rare-battle-ticket'").get().qty,rareBefore-1);await post(1,'act',{type:'run'});
 const monProfile=await post(1,'mon',{ownedId:1});assert.equal(monProfile.status,200,JSON.stringify(monProfile.data));assert.equal(monProfile.data.originalTrainer.name,'参加者1');
 const admin=await post(1,'admin',{q:'表示名管理対象'});assert.equal(admin.status,200);assert.ok(admin.data.counts.users>=3);assert.deepEqual(admin.data.users.map(x=>x.display_name),['表示名管理対象']);
 const money=await post(1,'admin/action',{userId:'90000',action:'money',amount:1234});assert.equal(money.status,200,JSON.stringify(money.data));assert.equal(S.db.prepare('SELECT money FROM users WHERE guild_id=1 AND user_id=90000').get().money,1234);
 const grant=await post(1,'admin/action',{userId:'90000',action:'item',item:'rare-battle-ticket',qty:2});assert.equal(grant.status,200,JSON.stringify(grant.data));assert.equal(S.db.prepare("SELECT qty FROM inventory WHERE guild_id=1 AND user_id=90000 AND item_key='rare-battle-ticket'").get().qty,2);
 console.log('PASS integration: friend challenge/accept/turn/result and mutual raid locks');
 let q=await post(1,'raid/create',{rank:1});assert.equal(q.status,200,JSON.stringify(q.data));let room=q.data.room;
 const act=async(u,type,more={})=>{const q=await post(u,'raid/action',{id:room.id,version:room.version,turn:room.turn,type,...more});assert.equal(q.status,200,JSON.stringify(q.data));room=q.data.room;};
 if(process.env.RAID_SOLO_TEST==='1') {
  assert.equal(room.requiredPlayers,1);await act(1,'party',{groupId:1});await act(1,'start');assert.equal(S.db.prepare("SELECT qty FROM inventory WHERE guild_id=1 AND user_id=1 AND item_key='raid-ticket'").get().qty,2);await act(1,'move',{idx:0});assert.equal(room.turn,2);
  console.log('PASS HTTP: configured solo mode, team load, start and one-player turn');return;
 }
 for(const u of [2,3])await act(u,'join');for(const u of [1,2,3])await act(u,'party',{groupId:u});
 assert.equal((await post(1,'team/delete',{groupId:1})).status,409);
 await act(1,'start');assert.equal(S.db.prepare("SELECT qty FROM inventory WHERE guild_id=1 AND user_id=1 AND item_key='raid-ticket'").get().qty,2);for(const u of [1,2,3])await act(u,'move',{idx:0});assert.equal(room.turn,2);
 if(process.env.RAID_BROWSER==='1') {
  const {chromium}=require('playwright');const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:860,height:420}});const errors=[];page.on('pageerror',e=>errors.push(e.stack||e.message));page.on('console',m=>{if(m.type()==='error')errors.push('console: '+m.text())});page.on('requestfailed',r=>errors.push('request: '+r.url()+' '+(r.failure()?.errorText||'')));
  // 実際のHTMLを読み、Discordログインだけを既存のテストセッションで置き換える。
  await page.route('**/poke/**',route=>route.fulfill({status:200,contentType:'image/png',body:fs.readFileSync(path.join(__dirname,'assets',new URL(route.request().url()).pathname.split('/').pop()))}));
  await page.route('**/api/login',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({session:'test1',me:{id:'1',name:'参加者1'},groups:[{id:1,name:'チーム1',members:[]}],regions:[],balls:{},money:0,gyms:[],rocket:[],badgeCount:0,trainerRegions:[],trainers:[]})}));
  await page.route(`http://127.0.0.1:${port}/`,route=>route.fulfill({status:200,contentType:'text/html',body:fs.readFileSync(path.join(__dirname,'../connect-party/pokemon/public/index.html'),'utf8').replace('login();\n})();', `window.__friendTest=()=>{raidStop();H={groups:[{id:1,name:'チーム1',members:[{name:'ピカチュウ',level:100,img:'/poke/art/25.png'}]}],regions:[],balls:{},money:0};return friendOpen()};window.__friendVisual=()=>({kind:B?.kind,seen:FB?.seen,waiting:B?.waiting,over:B?.over,models:sceneMons().length,raid:!!raidScene});window.__raidVisual=()=>({stage:curStage,count:sceneMons().length,models:sceneMons().map(m=>({side:m.side,x:m.x,z:m.z,vis:m.vis,loaded:m.im.naturalWidth>0})),seq:raidScene?.lastSeq,animating:raidScene?.animating,combat:!!raidScene?.combatCam,obstacles:solids.filter(s=>s.raidObstacle).length,camX:cam.x,camZ:cam.z});window.__raidTest=()=>{fast=true;muted=true;sess='test1';H={groups:[{id:1,name:'チーム1',members:[]}],regions:[],balls:{},money:0};return raidOpen()};window.__adminTest=async()=>{sess='test90000';AD=await api('admin',{q:'表示名管理対象'});adminDraw('表示名管理対象');return AD};window.__ballHeaderTest=()=>{H={groups:[],regions:[],balls:{'poke-ball':2,'quick-ball':3},money:100,gyms:[],rocket:[],badgeCount:0,trainerRegions:[],trainers:[],needStarter:false};legacyHome();const e=document.querySelector('.ball-summary');return{text:e.textContent,images:e.querySelectorAll('img').length}};window.__shopVisualTest=()=>{SH={money:5000,items:[{key:'quick-ball',name:'クイックボール',type:'ball',price:1000,desc:'最初のターンなら ×5',supported:true,have:3},{key:'dive-ball',name:'ダイブボール',type:'ball',price:1000,desc:'',supported:false,unsupported:'釣り・ダイビングの遭遇種別がまだありません',have:0}]};shTab='shop';shGen='ball';shopDraw()};window.__matchupTest=types=>matchup(types);window.__hudTest=(types,isP)=>hud({name:'テスト',level:50,hp:100,maxHp:100,status:null,types,shiny:false,conf:false,sub:false},isP);window.__animRate=ANIM_RATE;\n})();`)}));
  await page.goto(`http://127.0.0.1:${port}/`);
  await page.evaluate(()=>window.__adminTest());await page.locator('[data-ad-user="90000"]').waitFor({timeout:10000}).catch(async e=>{throw new Error('admin DOM: '+(await page.locator('body').innerText())+' / page errors: '+errors.join(' | '),{cause:e})});await page.locator('[data-ad-user="90000"]').click();await page.locator('#adMoneyValue').fill('77');await page.locator('#adMoneyGo').click();await page.waitForFunction(()=>document.body.textContent.includes('1,311円'));assert.equal(S.db.prepare('SELECT money FROM users WHERE guild_id=1 AND user_id=90000').get().money,1311);await page.locator('#adItemKey').selectOption('raid-ticket');await page.locator('#adItemQty').fill('2');await page.locator('#adItemGo').click();await page.waitForFunction(()=>document.body.textContent.includes('レイド券 2'));assert.equal(S.db.prepare("SELECT qty FROM inventory WHERE guild_id=1 AND user_id=90000 AND item_key='raid-ticket'").get().qty,2);console.log('PASS browser admin inline money/item controls and display-name search');
  const matchup=await page.evaluate(()=>window.__matchupTest(['fire','flying']));
  const weak=Object.fromEntries(matchup.weak.map(x=>[x.type,x.mult])),resist=Object.fromEntries(matchup.resist.map(x=>[x.type,x.mult]));
  assert.deepEqual(weak,{rock:4,electric:2,water:2});assert.equal(resist.ground,0);assert.equal(resist.bug,.25);assert.equal(resist.grass,.25);assert.equal(resist.fire,.5);assert.equal(await page.evaluate(()=>window.__animRate),1.15);
  assert.match(await page.evaluate(()=>window.__hudTest(['fire','flying'],false)),/class="matchups"/);assert.doesNotMatch(await page.evaluate(()=>window.__hudTest(['fire','flying'],true)),/class="matchups"/);
  const ballHeader=await page.evaluate(()=>window.__ballHeaderTest());assert.equal(ballHeader.images,2);assert.match(ballHeader.text,/×2/);assert.match(ballHeader.text,/×3/);assert.doesNotMatch(ballHeader.text,/モンスター|クイック/);
  await page.setViewportSize({width:1600,height:900});await page.screenshot({path:path.join(dir,'ball-header-desktop.png'),fullPage:true});await page.setViewportSize({width:860,height:420});
  await page.waitForFunction(()=>!!window.PokemonWorld,{timeout:10000});await page.evaluate(async()=>{const region={key:'kanto',ja:'カントー'},state={ok:true,region,regions:[region],map:'center',position:{x:0,z:6,direction:0},steps:0,clock:{time:'day',timeJa:'昼',season:'spring',seasonJa:'春'},weather:{key:'clear',ja:'晴れ'},triggers:[{id:'oak',kind:'facility',action:'oak',label:'オーキド博士',x:0,z:-8,r:3.2},{id:'heal',kind:'facility',action:'heal',label:'回復カウンター',x:-8,z:-8,r:3.5},{id:'box',kind:'facility',action:'box',label:'ボックス・チーム端末',x:8,z:-8,r:3.5},{id:'exit',kind:'warp',to:'town',label:'町へ出る',x:0,z:12,r:4}]};await window.PokemonWorld.open({api:async name=>name==='world'?state:{ok:true},toast:()=>{},needStarter:false,onAction:()=>{},onEncounter:async()=>{}})});await page.locator('.pw canvas').waitFor();await page.waitForTimeout(400);const c0=await page.evaluate(()=>({x:PokemonWorld.active.player.position.x,z:PokemonWorld.active.player.position.z}));await page.keyboard.down('KeyW');await page.waitForTimeout(350);await page.keyboard.up('KeyW');const c1=await page.evaluate(()=>({x:PokemonWorld.active.player.position.x,z:PokemonWorld.active.player.position.z,r:PokemonWorld.active.player.rotation.y}));assert.ok(c1.z<c0.z);assert.ok((-Math.sin(c1.r)*(c1.x-c0.x)-Math.cos(c1.r)*(c1.z-c0.z))/Math.hypot(c1.x-c0.x,c1.z-c0.z)>.9);assert.equal(await page.getByRole('button',{name:'← もどる'}).count(),1);assert.match(await page.locator('.pw-hud').innerText(),/ポケモンセンター/);await page.screenshot({path:path.join(dir,'world-center-landscape.png')});await page.evaluate(()=>window.PokemonWorld.close());console.log('PASS browser Center W-key direction and forward-facing character');
  await page.evaluate(async()=>{const region={key:'hoenn',ja:'ホウエン'},town={ok:true,region,regions:[region],map:'town',position:{x:0,z:8,direction:0},steps:0,clock:{time:'evening',timeJa:'夕方',season:'summer',seasonJa:'夏'},weather:{key:'rain',ja:'雨'},triggers:[{id:'center',kind:'warp',to:'center',label:'ポケモンセンター',x:0,z:17,r:5},{id:'shop',kind:'facility',action:'shop',label:'フレンドリィショップ',x:-18,z:11,r:4.5},{id:'gym',kind:'facility',action:'gym',label:'ポケモンジム',x:19,z:10,r:5},{id:'farm',kind:'facility',action:'farm',label:'牧場',x:-22,z:-14,r:5},{id:'raid',kind:'facility',action:'raid',label:'レイドステーション',x:22,z:-15,r:5},{id:'town-exit',kind:'warp',to:'route',label:'町の出口・草原へ',x:0,z:-29,r:5}]},center={...town,map:'center',position:{x:0,z:9,direction:0},triggers:[{id:'exit',kind:'warp',to:'town',label:'町へ出る',x:0,z:12,r:4}]};await window.PokemonWorld.open({api:async name=>name==='world'?town:name==='world/interact'?{action:'warp',world:center}:{ok:true},toast:()=>{},needStarter:false,onAction:()=>{},onEncounter:async()=>{throw Error('town encounter')}})});await page.locator('.pw canvas').waitFor();await page.waitForTimeout(400);assert.equal(await page.evaluate(()=>PokemonWorld.active.state.triggers.some(x=>x.kind==='encounter')),false);const t0=await page.evaluate(()=>({x:PokemonWorld.active.player.position.x,z:PokemonWorld.active.player.position.z}));await page.keyboard.down('KeyW');await page.waitForTimeout(350);await page.keyboard.up('KeyW');const t1=await page.evaluate(()=>({x:PokemonWorld.active.player.position.x,z:PokemonWorld.active.player.position.z,r:PokemonWorld.active.player.rotation.y}));assert.ok(t1.z>t0.z);assert.ok((-Math.sin(t1.r)*(t1.x-t0.x)-Math.cos(t1.r)*(t1.z-t0.z))/Math.hypot(t1.x-t0.x,t1.z-t0.z)>.9);assert.match(await page.locator('.pw-hud').innerText(),/ポケモンタウン/);await page.screenshot({path:path.join(dir,'world-town-landscape.png')});await page.locator('.pw-label',{hasText:'ポケモンセンター'}).click();await page.waitForFunction(()=>PokemonWorld.active?.state?.map==='center');await page.evaluate(()=>PokemonWorld.close());console.log('PASS browser Town W-key direction, forward-facing character, no encounters and click-to-enter');
  for(const map of['route','cave','coast']){await page.evaluate(async map=>{const region={key:'hoenn',ja:'ホウエン'},defs={route:[{id:'town-gate',kind:'warp',to:'town',label:'町へ戻る',x:0,z:27,r:5},{id:'grass-a',kind:'encounter',method:'grass',label:'草むら',x:-12,z:5,r:9},{id:'cave-gate',kind:'warp',to:'cave',label:'岩山の洞窟へ',x:-23,z:-24,r:6},{id:'coast-gate',kind:'warp',to:'coast',label:'海岸・水辺へ',x:23,z:-24,r:6}],cave:[{id:'route-gate',kind:'warp',to:'route',label:'草原へ戻る',x:0,z:26,r:5},{id:'cave-a',kind:'encounter',method:'cave',label:'洞窟の奥',x:-9,z:-3,r:13}],coast:[{id:'route-gate',kind:'warp',to:'route',label:'草原へ戻る',x:0,z:27,r:5},{id:'water',kind:'encounter',method:'surf',label:'波乗りエリア',x:10,z:-8,r:18},{id:'dock',kind:'encounter',method:'fishing',label:'釣り桟橋',x:-16,z:-11,r:7}]},state={ok:true,region,regions:[region],map,position:{x:0,z:20,direction:0},steps:0,clock:{time:'day',timeJa:'昼',season:'summer',seasonJa:'夏'},weather:{key:'clear',ja:'晴れ'},triggers:defs[map]};await PokemonWorld.open({api:async()=>state,toast:()=>{},needStarter:false,onAction:()=>{},onEncounter:async()=>{}})},map);await page.locator('.pw canvas').waitFor();assert.equal(await page.evaluate(m=>PokemonWorld.active.state.map===m,map),true);await page.screenshot({path:path.join(dir,`world-${map}-landscape.png`)});await page.evaluate(()=>PokemonWorld.close())}console.log('PASS browser separate route, cave and coast 3D maps');
  await page.evaluate(()=>window.__shopVisualTest());
  assert.equal(await page.getByRole('button',{name:'未対応'}).isDisabled(),true);assert.equal(await page.locator('img[src*="/balls/quick-ball.png"]').count(),1);await page.setViewportSize({width:1600,height:900});await page.screenshot({path:path.join(dir,'ball-shop-desktop.png'),fullPage:true});await page.setViewportSize({width:860,height:420});
  await page.evaluate(()=>window.__raidTest());
  await page.waitForSelector('#raidCombat');await page.getByRole('button',{name:'たいあたり',exact:false}).waitFor();
  assert.equal(await page.locator('#eh .matchups').count(),1);assert.ok(await page.locator('#eh .match-label.weak + .match-icons .match-icon').count()>0);assert.ok(await page.locator('#eh .match-label.resist + .match-icons .match-icon').count()>0);
  assert.equal(await page.locator('#raidCombat').count(),1);assert.equal(await page.locator('#raidCombat').evaluate(el=>el.scrollWidth<=el.clientWidth),true);
  const visual=await page.evaluate(()=>window.__raidVisual());assert.equal(visual.stage,'raid');assert.equal(visual.count,4);assert.ok(visual.models.every(m=>m.loaded));assert.equal(new Set(visual.models.map(m=>m.x+','+m.z)).size,4);
  const allies=visual.models.filter(m=>m.side==='p'),boss=visual.models.find(m=>m.side==='e');assert.equal(allies.length,3);assert.ok(allies.every(m=>Math.hypot(m.x,m.z+6)>10));assert.ok(Math.hypot(boss.x,boss.z+6)<1);
  assert.equal(await page.locator('#app').evaluate(el=>getComputedStyle(el).flexDirection),'row');
  await page.screenshot({path:path.join(dir,'raid-mobile-landscape.png'),fullPage:true});
  await page.setViewportSize({width:1600,height:900});await page.screenshot({path:path.join(dir,'raid-desktop.png'),fullPage:true});await page.setViewportSize({width:860,height:420});
  await page.getByRole('button',{name:'たいあたり',exact:false}).click();
  await page.waitForFunction(()=>document.querySelector('#raidCombat')?.textContent.includes('ほかの参加者の技選択を待っています'));
  room=(await post(1,'raid/action',{id:room.id,type:'status'})).data.room;
  for(const u of [2,3])await act(u,'move',{idx:0});
  await page.waitForFunction(()=>{const v=window.__raidVisual();return v?.combat&&(Math.abs(v.camX)>1||Math.abs(v.camZ-18)>2)},null,{timeout:30000});
  assert.ok((await page.evaluate(()=>window.__raidVisual())).obstacles>0);await page.screenshot({path:path.join(dir,'raid-attack-clear.png'),fullPage:true});
  await page.waitForFunction(()=>document.querySelector('#raidCombat')?.textContent.includes('T3'));
  await page.waitForFunction(()=>window.__raidVisual()?.animating===false);
  const seq=(await page.evaluate(()=>window.__raidVisual())).seq;
  await page.waitForTimeout(2500);assert.equal((await page.evaluate(()=>window.__raidVisual())).seq,seq);
  // 通常のポーリングで既存イベントを二重再生しない。
  await page.evaluate(()=>window.__raidTest());assert.equal((await page.evaluate(()=>window.__raidVisual())).seq,seq);
  for(let round=0;round<8&&room.phase==='battle';round++) {
   for(const u of [1,2,3])await act(u,'move',{idx:0});
   const expected=room.animationSeq;
   await page.waitForFunction(n=>window.__raidVisual()?.seq>=n&&!window.__raidVisual()?.animating,expected,{timeout:60000});
  }
  assert.equal(room.phase,'capture');await page.getByRole('button',{name:'レイドボールを投げる',exact:false}).waitFor();
  const beforeBalls=room.players[0].balls;
  await page.getByRole('button',{name:'レイドボールを投げる',exact:false}).click();
  await page.waitForFunction(()=>window.__raidVisual()?.animating===false&&document.querySelector('#raidCombat')?.textContent.includes('自分の捕獲は終了'),null,{timeout:60000});
  room=(await post(1,'raid/action',{id:room.id,type:'status'})).data.room;
  assert.equal(room.players[0].balls,beforeBalls-1);
  console.log('PASS browser victory, capture animation, no duplicate playback, reopen resume');
  console.log('PASS browser move submission and polling synchronization');
  for(const u of [2,3])await act(u,'leave');assert.equal(room.phase,'finished');
  // 戦闘後HP永続化が有効なので、次のフレンド対戦の描画試験前にセンターで回復する。
  assert.equal((await post(1,'center')).status,200);assert.equal((await post(2,'center')).status,200);
  await page.route('**/api/home',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({groups:[{id:1,name:'チーム1',members:[{name:'ピカチュウ',level:100,img:'/poke/art/25.png'}]}],regions:[],balls:{},money:0})}));
  await post(2,'friend/state');await page.evaluate(()=>window.__friendTest());
  await page.locator('[data-ch="2"]').click();
  await page.waitForFunction(()=>document.querySelector('#flCancel'));
  const incoming=(await post(2,'friend/state')).data.incoming.find(x=>x.fromUid==='1');assert.ok(incoming);
  assert.equal((await post(2,'friend/accept',{id:incoming.id,groupId:2})).status,200);
  await page.locator('.mv[data-i="0"]').waitFor({timeout:30000});
  const friendVisual=await page.evaluate(()=>window.__friendVisual());assert.equal(friendVisual.kind,'friend');assert.equal(friendVisual.models,2);assert.equal(friendVisual.raid,false);
  assert.equal(await page.locator('#eh .matchups').count(),1);assert.equal(await page.locator('#ph .matchups').count(),0);
  await page.locator('.mv[data-i="0"]').click();await page.waitForFunction(()=>window.__friendVisual()?.waiting===true);
  assert.equal((await post(2,'friend/act',{type:'move',idx:0,seen:1})).status,200);
  await page.waitForFunction(()=>window.__friendVisual()?.seen>=2&&!window.__friendVisual()?.waiting,null,{timeout:30000});
  assert.equal(await page.locator('#app').evaluate(el=>getComputedStyle(el).flexDirection),'row');
  await page.screenshot({path:path.join(dir,'friend-mobile-landscape.png'),fullPage:true});
  assert.equal((await post(2,'friend/act',{type:'forfeit'})).status,200);
  await page.locator('#fbAgain').waitFor({timeout:30000});assert.equal((await page.evaluate(()=>window.__friendVisual())).over.result,'win');
  console.log('PASS browser friend lobby challenge, battle effects, two-player turn, result, raid scene cleanup');
  assert.deepEqual(errors,[]);await browser.close();console.log('PASS browser raid screen, move controls, mobile landscape layout; screenshot '+path.join(dir,'raid-mobile-landscape.png'));
 }
 console.log('PASS HTTP: auth, 3 players, real bot schema, party load, mutation guard, synchronized turn');
}
main().then(()=>{S.server.close();S.db.close();}).catch(e=>{console.error(e);S.server.close();S.db.close();process.exit(1)});
