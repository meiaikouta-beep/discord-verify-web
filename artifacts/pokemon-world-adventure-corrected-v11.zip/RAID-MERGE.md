統合後の機能、未実装範囲、テスト、配置手順は `INTEGRATED-README.md` を参照してください。
ボールとチケットのPNGはバイナリのため `raid-integration.patch` だけでは配置できません。完全版ZIP内の `install-integrated.py` を使用してください。
