'use strict';

// 個体育成・永続化に関する共通処理。既存bot DBへ追加列を安全に足し、
// raw PokeAPI JSONから経験値タイプと努力値を読む。
const STATS=['hp','attack','defense','sp_attack','sp_defense','speed'];
const NATURES=[
 ['hardy','がんばりや',null,null],['lonely','さみしがり','attack','defense'],['brave','ゆうかん','attack','speed'],['adamant','いじっぱり','attack','sp_attack'],['naughty','やんちゃ','attack','sp_defense'],
 ['bold','ずぶとい','defense','attack'],['docile','すなお',null,null],['relaxed','のんき','defense','speed'],['impish','わんぱく','defense','sp_attack'],['lax','のうてんき','defense','sp_defense'],
 ['timid','おくびょう','speed','attack'],['hasty','せっかち','speed','defense'],['serious','まじめ',null,null],['jolly','ようき','speed','sp_attack'],['naive','むじゃき','speed','sp_defense'],
 ['modest','ひかえめ','sp_attack','attack'],['mild','おっとり','sp_attack','defense'],['quiet','れいせい','sp_attack','speed'],['bashful','てれや',null,null],['rash','うっかりや','sp_attack','sp_defense'],
 ['calm','おだやか','sp_defense','attack'],['gentle','おとなしい','sp_defense','defense'],['sassy','なまいき','sp_defense','speed'],['careful','しんちょう','sp_defense','sp_attack'],['quirky','きまぐれ',null,null]
].map(([key,ja,up,down])=>({key,ja,up,down}));
const NATURE=new Map(NATURES.map(n=>[n.key,n]));
const json=v=>{try{return JSON.parse(v||'{}')}catch{return{}}};
const nature=key=>NATURE.get(String(key||''))||NATURE.get('hardy');
const randomNature=(random=Math.random)=>NATURES[Math.floor(random()*NATURES.length)];
const natureMod=(key,stat)=>{const n=nature(key);return n.up===stat?1.1:n.down===stat?.9:1};

function growthType(master){
 const x=json(master?.raw_species_json),v=x.growth_rate?.name||x.growth_rate;
 return typeof v==='string'?v:'fast'; // 旧botの式(4/5 n^3)と同じ安全な既定値
}
function expFor(level,type='fast'){
 const n=Math.max(1,Math.min(100,Number(level)||1));let v;
 switch(type){
  case 'slow':v=5*n**3/4;break;
  case 'medium':case 'medium-fast':v=n**3;break;
  case 'medium-slow':v=6*n**3/5-15*n**2+100*n-140;break;
  case 'erratic':v=n<=50?n**3*(100-n)/50:n<=68?n**3*(150-n)/100:n<=98?n**3*((1911-10*n)/3)/500:n**3*(160-n)/100;break;
  case 'fluctuating':v=n<=15?n**3*((n+1)/3+24)/50:n<=36?n**3*(n+14)/50:n**3*(n/2+32)/50;break;
  default:v=4*n**3/5;
 }
 return Math.max(0,Math.floor(v));
}
function evYield(master){
 const x=json(master?.raw_pokemon_json),out=Object.fromEntries(STATS.map(k=>[k,0]));
 const map={'special-attack':'sp_attack','special-defense':'sp_defense'};
 for(const s of Array.isArray(x.stats)?x.stats:[]){const k=map[s.stat?.name]||s.stat?.name;if(k in out)out[k]=Math.max(0,Number(s.effort)||0)}
 if(!Object.values(out).some(Boolean)&&master){const k=STATS.toSorted((a,b)=>(Number(master['base_'+b])||0)-(Number(master['base_'+a])||0))[0];out[k]=1}
 return out;
}
function applyEv(current,yield_){
 const out={},total=STATS.reduce((n,k)=>n+(Number(current[k])||0),0);let room=Math.max(0,510-total);
 for(const k of STATS){const old=Math.max(0,Number(current[k])||0),add=Math.min(Math.max(0,Number(yield_[k])||0),252-old,room);out[k]=old+add;room-=add}
 return out;
}
function friendshipDelta(kind,{luxury=false,level=1}={}){
 const table={battle:1,level:3,walk:1,vitamin:5,groom:10,faint:-Math.max(1,Math.floor(level/10)),bitter:-10,trade:0};
 const n=table[kind]??0;return n>0?n+(luxury?1:0):n;
}
function ticketDrops(random=Math.random){const out=[];for(const [key,name] of [['rare-battle-ticket','レアバトルチケット'],['raid-ticket','レイドチケット']])if(random()<.02)out.push({key,name});return out}

const HELD={
 'leftovers':{name:'たべのこし',kind:'held'},'black-sludge':{name:'くろいヘドロ',kind:'held'},'life-orb':{name:'いのちのたま',kind:'held'},
 'choice-band':{name:'こだわりハチマキ',kind:'held'},'choice-specs':{name:'こだわりメガネ',kind:'held'},'choice-scarf':{name:'こだわりスカーフ',kind:'held'},
 'focus-sash':{name:'きあいのタスキ',kind:'held'},'assault-vest':{name:'とつげきチョッキ',kind:'held'},'eviolite':{name:'しんかのきせき',kind:'held'},
 'rocky-helmet':{name:'ゴツゴツメット',kind:'held'},'shell-bell':{name:'かいがらのすず',kind:'held'},'soothe-bell':{name:'やすらぎのすず',kind:'held'},'flame-orb':{name:'かえんだま',kind:'held'},'toxic-orb':{name:'どくどくだま',kind:'held'},
 'oran-berry':{name:'オレンのみ',kind:'berry'},'sitrus-berry':{name:'オボンのみ',kind:'berry'},'lum-berry':{name:'ラムのみ',kind:'berry'},
 'cheri-berry':{name:'クラボのみ',kind:'berry'},'chesto-berry':{name:'カゴのみ',kind:'berry'},'pecha-berry':{name:'モモンのみ',kind:'berry'},'rawst-berry':{name:'チーゴのみ',kind:'berry'},'aspear-berry':{name:'ナナシのみ',kind:'berry'}
};
const ITEMS=[
 ['rare-battle-ticket','レアバトルチケット','ticket',0,0,'レアバトルへ挑戦できる特別なチケット。'],['raid-ticket','レイドチケット','ticket',0,0,'参加者の誰かが1枚持っていればレイドへ挑戦できる。'],
 ['potion','キズぐすり','medicine',300,1,'HPを20回復する。'],['super-potion','いいキズぐすり','medicine',700,1,'HPを60回復する。'],['hyper-potion','すごいキズぐすり','medicine',1500,1,'HPを120回復する。'],['max-potion','まんたんのくすり','medicine',2500,1,'HPを全回復する。'],['full-restore','かいふくのくすり','medicine',3000,1,'HPと状態異常を全回復する。'],
 ['antidote','どくけし','medicine',200,1,'どくを治す。'],['paralyze-heal','まひなおし','medicine',200,1,'まひを治す。'],['awakening','ねむけざまし','medicine',200,1,'ねむりを治す。'],['burn-heal','やけどなおし','medicine',200,1,'やけどを治す。'],['ice-heal','こおりなおし','medicine',200,1,'こおりを治す。'],['full-heal','なんでもなおし','medicine',600,1,'状態異常を治す。'],
 ['ether','ピーピーエイド','medicine',1200,1,'1つの技のPPを10回復する。'],['max-ether','ピーピーリカバー','medicine',2000,1,'1つの技のPPを全回復する。'],['elixir','ピーピーエイダー','medicine',3000,1,'全技のPPを10回復する。'],['max-elixir','ピーピーマックス','medicine',4500,1,'全技のPPを全回復する。'],
 ['hp-up','マックスアップ','vitamin',10000,1,'HPの努力値を10上げる。'],['protein','タウリン','vitamin',10000,1,'こうげきの努力値を10上げる。'],['iron','ブロムヘキシン','vitamin',10000,1,'ぼうぎょの努力値を10上げる。'],
 ['calcium','リゾチウム','vitamin',10000,1,'とくこうの努力値を10上げる。'],['zinc','キトサン','vitamin',10000,1,'とくぼうの努力値を10上げる。'],['carbos','インドメタシン','vitamin',10000,1,'すばやさの努力値を10上げる。'],
 ['x-attack','プラスパワー','battle',500,1,'戦闘中にこうげきを2段階上げる。'],['x-defense','ディフェンダー','battle',500,1,'戦闘中にぼうぎょを2段階上げる。'],['x-sp-atk','スペシャルアップ','battle',500,1,'戦闘中にとくこうを2段階上げる。'],['x-sp-def','スペシャルガード','battle',500,1,'戦闘中にとくぼうを2段階上げる。'],['x-speed','スピーダー','battle',500,1,'戦闘中にすばやさを2段階上げる。']
];
for(const [key,v] of Object.entries(HELD))ITEMS.push([key,v.name,v.kind,1500,1,v.kind==='berry'?'条件を満たすと戦闘中に自動で発動する。':'ポケモンに持たせると戦闘中に効果を発揮する。']);

function migrate({db,all,one,run}){
 const cols=t=>new Set(all(`PRAGMA table_info(${t})`).map(x=>x.name));
 const add=(t,n,decl)=>{if(!cols(t).has(n))db.exec(`ALTER TABLE ${t} ADD COLUMN ${n} ${decl}`)};
 for(const k of STATS)add('user_pokemon_owned','ev_'+k,'INTEGER NOT NULL DEFAULT 0');
 for(const [n,d] of [['held_item_key','TEXT'],['persistent_status','TEXT'],['original_trainer_id','TEXT'],['original_trainer_name','TEXT'],['origin_region','TEXT'],['ribbons_json',"TEXT NOT NULL DEFAULT '[]'"],['marks_json',"TEXT NOT NULL DEFAULT '[]'"]])add('user_pokemon_owned',n,d);
 for(const [n,d] of [['active','INTEGER NOT NULL DEFAULT 1'],['current_pp','INTEGER'],['max_pp','INTEGER']])add('owned_pokemon_moves',n,d);
 for(const [n,d] of [['nature_key','TEXT'],['nature_name_ja','TEXT']])add('user_pokemon_farm_hatched',n,d);
 db.exec(`CREATE TABLE IF NOT EXISTS web_pvp_ratings(guild_id INTEGER NOT NULL,user_id INTEGER NOT NULL,rating INTEGER NOT NULL DEFAULT 1500,wins INTEGER NOT NULL DEFAULT 0,losses INTEGER NOT NULL DEFAULT 0,draws INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(guild_id,user_id));
 CREATE TABLE IF NOT EXISTS web_admin_log(id INTEGER PRIMARY KEY AUTOINCREMENT,admin_user_id TEXT NOT NULL,target_user_id TEXT,action TEXT NOT NULL,detail_json TEXT,created_at INTEGER NOT NULL DEFAULT(strftime('%s','now')))`);
 for(const [key,name,type,price,shop,desc] of ITEMS)run(`INSERT INTO pokemon_items_master(item_key,name_en,name_ja,item_type,buy_price,sell_price,is_shop_item,stack_limit,effect_ja) VALUES(?,?,?,?,?,?,?,9999,?) ON CONFLICT(item_key) DO UPDATE SET name_ja=COALESCE(pokemon_items_master.name_ja,excluded.name_ja),item_type=CASE WHEN pokemon_items_master.item_type IS NULL OR pokemon_items_master.item_type='misc' THEN excluded.item_type ELSE pokemon_items_master.item_type END,effect_ja=COALESCE(pokemon_items_master.effect_ja,excluded.effect_ja)`,key,key,name,type,price,Math.floor(price/2),shop,desc);
 db.exec(`UPDATE owned_pokemon_moves SET max_pp=COALESCE(max_pp,(SELECT pp FROM pokemon_moves_master m WHERE m.move_id=owned_pokemon_moves.move_id),10),current_pp=COALESCE(current_pp,(SELECT pp FROM pokemon_moves_master m WHERE m.move_id=owned_pokemon_moves.move_id),10)`);
 for(const r of all('SELECT owned_id,COUNT(*) c FROM owned_pokemon_moves WHERE active=1 GROUP BY owned_id HAVING c>4')){
  const keep=new Set(all('SELECT slot FROM owned_pokemon_moves WHERE owned_id=? ORDER BY slot DESC LIMIT 4',r.owned_id).map(x=>x.slot));
  for(const x of all('SELECT slot FROM owned_pokemon_moves WHERE owned_id=? AND active=1',r.owned_id))if(!keep.has(x.slot))run('UPDATE owned_pokemon_moves SET active=0 WHERE owned_id=? AND slot=?',r.owned_id,x.slot);
 }
 db.exec(`UPDATE user_pokemon_owned SET nature_key=COALESCE(NULLIF(nature_key,''),'hardy'),nature_name_ja=COALESCE(NULLIF(nature_name_ja,''),'がんばりや'),original_trainer_id=COALESCE(original_trainer_id,CAST(user_id AS TEXT)),ribbons_json=COALESCE(ribbons_json,'[]'),marks_json=COALESCE(marks_json,'[]')`);
 return {items:ITEMS.length};
}

module.exports={STATS,NATURES,nature,randomNature,natureMod,growthType,expFor,evYield,applyEv,friendshipDelta,ticketDrops,HELD,migrate,json};
