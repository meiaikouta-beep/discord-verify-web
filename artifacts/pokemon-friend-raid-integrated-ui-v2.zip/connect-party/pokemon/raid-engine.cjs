'use strict';
// 同じ戦闘計算を使い、全プレイヤー1回＋ボス2回の行動をまとめて解決する。
module.exports = function createRaidEngine(E, random = Math.random) {
  const I = E.raidInternals;
  if (!I) throw new Error('engine.cjs の raidInternals が必要です');
  const active = p => p.party[p.active];
  function mark(events,start,p,actor,target) {
    for(let i=start;i<events.length;i++) Object.assign(events[i],{
      uid:events[i].side==='e'?'boss':p.uid,actor:actor||p.uid,target:target||'boss'
    });
  }
  function state(r, p) { return { party: p.party, active: p.active, enemy: r.boss, fld: r.fld, sd: { p: p.sd, e: r.bossSd } }; }
  function init(r) {
    r.fld = E.fldOf({}); r.bossSd = {hz:{}}; r.boss.raidBoss = true;
    const events = [];
    for (const p of r.players) { p.sd = {hz:{}}; const s = state(r,p); E.fldOf(s); r.fld = s.fld; const start=events.length; E.enter(s,active(p),'p',events);mark(events,start,p,p.uid,'boss'); }
    const start=events.length;E.enter(state(r,r.players[0]),r.boss,'e',events);mark(events,start,r.players[0],'boss',r.players[0].uid);
    return events;
  }
  function turn(r) {
    const events = [], actions = [], moved = new Set();
    for (const p of r.players) {
      const b = active(p); if (!b || b.hp <= 0) continue;
      actions.push({p,b,m:b.moves[p.choice],speed:I.spdOf(state(r,p),'p',b),tie:random()});
    }
    for (let i=0;i<2;i++) actions.push({b:r.boss,speed:I.spdOf(state(r,r.players[0]),'e',r.boss),tie:random()});
    actions.sort((a,b)=>(I.prio(b.m||{})-I.prio(a.m||{})) || (r.fld.trick_room>0?-1:1)*(b.speed-a.speed) || b.tie-a.tie);
    function faint() {
      for (const p of r.players) {
        if (!active(p) || active(p).hp>0) continue;
        events.push({t:'faint',side:'p',uid:p.uid,actor:p.uid,target:p.uid,msg:`${p.name}の${active(p).name}は倒れた！`});
        const next=p.party.findIndex((b,i)=>i>p.active && b.hp>0);
        if (next<0) { p.active=p.party.length; continue; }
        const start=events.length;E.leave(state(r,p),'p',active(p),events); p.active=next;
        events.push({t:'switchIn',side:'p',mon:E.pub(active(p)),moves:active(p).moves.map(E.mPub),msg:`${p.name}は${active(p).name}を繰り出した！`});
        E.enter(state(r,p),active(p),'p',events);mark(events,start,p,p.uid,'boss');
      }
    }
    for (const a of actions) {
      if(r.boss.hp<=0 || !r.players.some(p=>active(p)?.hp>0)) break;
      if(a.b.hp<=0 || (a.p && active(a.p)!==a.b)) continue;
      const p=a.p || r.players.filter(p=>active(p)?.hp>0)[Math.floor(random()*r.players.filter(p=>active(p)?.hp>0).length)];
      const s=state(r,p), side=a.p?'p':'e', target=a.p?r.boss:active(p);
      let m=a.m;
      if(!a.p) {
        const ms=r.boss.moves; m=ms[Math.floor(random()*ms.length)];
        const heals=new Set(['rest','recover','soft-boiled','slack-off','roost','milk-drink','heal-order','shore-up','moonlight','morning-sun','synthesis','life-dew','jungle-healing','lunar-blessing']);
        const other=ms.filter(m=>!heals.has(m.en));
        if(heals.has(m.en) && other.length && random()<0.5) m=other[Math.floor(random()*other.length)];
      }
      if(!m || m.pp<=0) m={name:'わるあがき',en:'struggle',type:'normal',power:40,accuracy:null,pp:1,cls:'physical',rules:[]};
      const enc=a.b.vs.encore; if(enc?.t>0 && enc.mv?.pp>0) m=enc.mv;
      s.foeMv = a.p ? r.boss.moves[0] : active(p).moves[p.choice]; s.foeActed=moved.has(target);
      const start=events.length;
      const blocked=I.moveBlock(a.b,m);
      if(blocked) events.push({msg:blocked});
      else if(I.canAct(a.b,side,events)) I.useMove(a.b,target,m,side,events,s);
      mark(events,start,p,a.p?p.uid:'boss',a.p?'boss':p.uid);
      if(r.boss.hp<=0&&!events.some(e=>e.t==='faint'&&e.uid==='boss')) events.push({t:'faint',side:'e',uid:'boss',actor:'boss',target:'boss',msg:`${r.boss.name}を撃破した！`});
      a.b.acted=true; moved.add(a.b);
      // レイドは自動で次の個体へ進む。任意交代・強制交代は行わない。
      faint();
    }
    if(r.boss.hp>0 && r.players.some(p=>active(p)?.hp>0)) {
      for(const p of r.players) if(active(p)?.hp>0) {const start=events.length;I.endTurn(active(p),'p',events,state(r,p),r.boss);mark(events,start,p,p.uid,p.uid);}
      const p=r.players.find(p=>active(p)?.hp>0) || r.players[0];
      r.boss.raidEndTurn=true;
      try { const start=events.length;I.endTurn(r.boss,'e',events,state(r,p),active(p)||r.boss);mark(events,start,p,'boss','boss'); } finally { r.boss.raidEndTurn=false; }
      // 天気・フィールドは全体で1回だけ、各プレイヤーの壁も1回だけ減算。
      if(r.boss.hp<=0)events.push({t:'faint',side:'e',uid:'boss',actor:'boss',target:'boss',msg:`${r.boss.name}を撃破した！`});
      const s=state(r,p); I.tickField(s,events);
      for(const other of r.players) if(other!==p) for(const k of Object.keys(other.sd)) if(typeof other.sd[k]==='number' && other.sd[k]>0) other.sd[k]--;
      faint();
    }
    for(const p of r.players) { p.choice=null; for(const b of p.party) b.flinch=false; }
    r.boss.flinch=false;
    return events;
  }
  return {init,turn};
};
