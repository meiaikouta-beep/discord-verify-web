'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'raid-http-')),file=path.join(dir,'fixture.sqlite');
const db=new DatabaseSync(file,{enableForeignKeyConstraints:false});
db.exec(fs.readFileSync(path.join(__dirname,'bot-schema.sql'),'utf8'));
db.exec(`CREATE TABLE IF NOT EXISTS bot_settings(key TEXT PRIMARY KEY,value TEXT);
 INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,evolution_stage,capture_rate) VALUES ('S:3',3,3,'フシギバナ','grass',80,80,80,80,80,80,'final',255);
 INSERT INTO pokemon_evolution_rules(from_pokemon_key,to_pokemon_key) VALUES ('S:1','S:2'),('S:2','S:3');
 INSERT INTO pokemon_moves_master(move_id,name_en,name_ja,type,power,accuracy,pp,damage_class) VALUES (1,'tackle','たいあたり','normal',40,100,35,'physical');
 INSERT INTO pokemon_learnset(pokemon_key,move_id,learn_method,learn_level) VALUES ('S:3',1,'level-up',1);`);
for(let i=1;i<=3;i++) db.exec(`INSERT INTO users(guild_id,user_id) VALUES(1,${i}); INSERT INTO pokemon_user_groups(group_id,guild_id,user_id,group_name) VALUES(${i},1,${i},'チーム${i}'); INSERT INTO user_pokemon_owned(owned_id,guild_id,user_id,pokemon_key,species_id,level,max_hp,hp,attack,defense,sp_attack,sp_defense,speed) VALUES(${i},1,${i},'S:3',3,100,9999,9999,999,999,999,999,100); INSERT INTO pokemon_user_group_members(group_id,owned_id,slot) VALUES(${i},${i},1); INSERT INTO owned_pokemon_moves VALUES(${i},1,1);`);
db.exec("UPDATE pokemon_master SET image_url='https://fixture/3.png'");
for(const [uid,id,name,type] of [[1,25,'ピカチュウ','electric'],[2,6,'リザードン','fire'],[3,9,'カメックス','water']]) {
 db.prepare('INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,image_url) VALUES (?,?,?,?,?,80,80,80,80,80,80,?)').run('S:'+id,id,id,name,type,'https://fixture/'+id+'.png');
 db.prepare('UPDATE user_pokemon_owned SET pokemon_key=?,species_id=? WHERE user_id=?').run('S:'+id,id,uid);
} 
db.close();
// テスト内だけ設定ファイルを注入する。実際の設定・資格情報は読み書きしない。
const original=fs.readFileSync,interval=global.setInterval;
fs.readFileSync=function(f,...args){if(f==='/etc/games-hub.env')return `DISCORD_CLIENT_ID=test\nDISCORD_BOT_TOKEN=test\nADMIN_USER_IDS=1,2,3\nPOKEMON_DB=${file}\nPOKEMON_RAID_TEST_SOLO=${process.env.RAID_SOLO_TEST==='1'?'1':'0'}\n`;if(f==='/etc/games-party.env')return '';return original.call(this,f,...args)};
global.setInterval=(...a)=>interval(...a).unref();
let S;try{S=require('../connect-party/pokemon/server.cjs')}finally{fs.readFileSync=original;global.setInterval=interval}
for(let i=1;i<=3;i++)S.sessions.set('test'+i,{uid:String(i),g:'1',name:'参加者'+i,exp:Date.now()+600000});
async function main(){
 await new Promise(resolve=>S.server.listen(0,'127.0.0.1',resolve));const port=S.server.address().port;
 const post=async(user,route,b={})=>{const r=await fetch(`http://127.0.0.1:${port}/api/${route}`,{method:'POST',headers:{'content-type':'application/json','x-session':'test'+user},body:JSON.stringify(b)});return {status:r.status,data:await r.json()}};
 assert.equal((await post(9,'raid')).status,401);
 // 統合確認：フレンド対戦とレイドが互いの参加者をロックする。
 for(const u of [1,2,3])assert.equal((await post(u,'friend/state')).status,200);
 const challenge=await post(1,'friend/challenge',{to:'2',groupId:1});assert.equal(challenge.status,200);
 const accepted=await post(2,'friend/accept',{id:challenge.data.outgoing.id,groupId:2});assert.equal(accepted.status,200);
 assert.equal((await post(1,'raid/create',{rank:1})).status,400);
 const otherRaid=await post(3,'raid/create',{rank:1});assert.equal(otherRaid.status,200);
 assert.equal((await post(2,'raid/action',{id:otherRaid.data.room.id,version:otherRaid.data.room.version,type:'join'})).status,409);
 assert.equal((await post(3,'friend/challenge',{to:'1',groupId:3})).status,409);
 assert.equal((await post(1,'start',{groupId:1,region:'カントー'})).status,400);
 assert.equal((await post(1,'friend/act',{type:'move',idx:0})).status,200);
 const friendTurn=await post(2,'friend/act',{type:'move',idx:0,seen:1});assert.equal(friendTurn.status,200);assert.equal(friendTurn.data.battle.n,2);
 assert.equal((await post(1,'friend/act',{type:'forfeit'})).status,200);
 assert.equal((await post(2,'friend/state')).data.battle.view.over.result,'win');
 for(const u of [1,2])await post(u,'friend/leave');
 const cancelRaid=await post(3,'raid/action',{id:otherRaid.data.room.id,version:otherRaid.data.room.version,type:'leave'});assert.equal(cancelRaid.status,200);
 console.log('PASS integration: friend challenge/accept/turn/result and mutual raid locks');
 let q=await post(1,'raid/create',{rank:1});assert.equal(q.status,200);let room=q.data.room;
 const act=async(u,type,more={})=>{const q=await post(u,'raid/action',{id:room.id,version:room.version,turn:room.turn,type,...more});assert.equal(q.status,200,JSON.stringify(q.data));room=q.data.room;};
 if(process.env.RAID_SOLO_TEST==='1') {
  assert.equal(room.requiredPlayers,1);await act(1,'party',{groupId:1});await act(1,'start');await act(1,'move',{idx:0});assert.equal(room.turn,2);
  console.log('PASS HTTP: configured solo mode, team load, start and one-player turn');return;
 }
 for(const u of [2,3])await act(u,'join');for(const u of [1,2,3])await act(u,'party',{groupId:u});
 assert.equal((await post(1,'team/delete',{groupId:1})).status,409);
 await act(1,'start');for(const u of [1,2,3])await act(u,'move',{idx:0});assert.equal(room.turn,2);
 if(process.env.RAID_BROWSER==='1') {
  const {chromium}=require('playwright');const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:420,height:860}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  // 実際のHTMLを読み、Discordログインだけを既存のテストセッションで置き換える。
  await page.route('**/poke/**',route=>route.fulfill({status:200,contentType:'image/png',body:fs.readFileSync(path.join(__dirname,'assets',new URL(route.request().url()).pathname.split('/').pop()))}));
  await page.route('**/api/login',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({session:'test1',me:{id:'1',name:'参加者1'},groups:[{id:1,name:'チーム1',members:[]}],regions:[],balls:{},money:0,gyms:[],rocket:[],badgeCount:0,trainerRegions:[],trainers:[]})}));
  await page.route(`http://127.0.0.1:${port}/`,route=>route.fulfill({status:200,contentType:'text/html',body:fs.readFileSync(path.join(__dirname,'../connect-party/pokemon/public/index.html'),'utf8').replace('login();\n})();', `window.__friendTest=()=>{raidStop();H={groups:[{id:1,name:'チーム1',members:[{name:'ピカチュウ',level:100,img:'/poke/art/25.png'}]}],regions:[],balls:{},money:0};return friendOpen()};window.__friendVisual=()=>({kind:B?.kind,seen:FB?.seen,waiting:B?.waiting,over:B?.over,models:sceneMons().length,raid:!!raidScene});window.__raidVisual=()=>({stage:curStage,count:sceneMons().length,models:sceneMons().map(m=>({x:m.x,z:m.z,vis:m.vis,loaded:m.im.naturalWidth>0})),seq:raidScene?.lastSeq,animating:raidScene?.animating});window.__raidTest=()=>{fast=true;muted=true;sess='test1';H={groups:[{id:1,name:'チーム1',members:[]}],regions:[],balls:{},money:0};return raidOpen()};\n})();`)}));
  await page.goto(`http://127.0.0.1:${port}/`);
  await page.evaluate(()=>window.__raidTest());
  await page.waitForSelector('#raidCombat');await page.getByRole('button',{name:'たいあたり',exact:false}).waitFor();
  assert.equal(await page.locator('#raidCombat').count(),1);assert.equal(await page.locator('#raidCombat').evaluate(el=>el.scrollWidth<=el.clientWidth),true);
  const visual=await page.evaluate(()=>window.__raidVisual());assert.equal(visual.stage,'raid');assert.equal(visual.count,4);assert.ok(visual.models.every(m=>m.loaded));assert.equal(new Set(visual.models.map(m=>m.x+','+m.z)).size,4);
  await page.screenshot({path:path.join(dir,'raid-mobile.png'),fullPage:true});
  await page.getByRole('button',{name:'たいあたり',exact:false}).click();
  await page.waitForFunction(()=>document.querySelector('#raidCombat')?.textContent.includes('ほかの参加者の技選択を待っています'));
  room=(await post(1,'raid/action',{id:room.id,type:'status'})).data.room;
  for(const u of [2,3])await act(u,'move',{idx:0});
  await page.waitForFunction(()=>document.querySelector('#raidCombat')?.textContent.includes('T3'));
  await page.waitForFunction(()=>window.__raidVisual()?.animating===false);
  const seq=(await page.evaluate(()=>window.__raidVisual())).seq;
  await page.waitForTimeout(2500);assert.equal((await page.evaluate(()=>window.__raidVisual())).seq,seq);
  // 通常のポーリングで既存イベントを二重再生しない。
  await page.evaluate(()=>window.__raidTest());assert.equal((await page.evaluate(()=>window.__raidVisual())).seq,seq);
  for(let round=0;round<8&&room.phase==='battle';round++) {
   for(const u of [1,2,3])await act(u,'move',{idx:0});
   const expected=room.animationSeq;
   await page.waitForFunction(n=>window.__raidVisual()?.seq>=n&&!window.__raidVisual()?.animating,expected,{timeout:60000});
  }
  assert.equal(room.phase,'capture');await page.getByRole('button',{name:'レイドボールを投げる',exact:false}).waitFor();
  const beforeBalls=room.players[0].balls;
  await page.getByRole('button',{name:'レイドボールを投げる',exact:false}).click();
  await page.waitForFunction(()=>window.__raidVisual()?.animating===false&&document.querySelector('#raidCombat')?.textContent.includes('自分の捕獲は終了'),null,{timeout:60000});
  room=(await post(1,'raid/action',{id:room.id,type:'status'})).data.room;
  assert.equal(room.players[0].balls,beforeBalls-1);
  console.log('PASS browser victory, capture animation, no duplicate playback, reopen resume');
  console.log('PASS browser move submission and polling synchronization');
  for(const u of [2,3])await act(u,'leave');assert.equal(room.phase,'finished');
  await page.route('**/api/home',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({groups:[{id:1,name:'チーム1',members:[{name:'ピカチュウ',level:100,img:'/poke/art/25.png'}]}],regions:[],balls:{},money:0})}));
  await post(2,'friend/state');await page.evaluate(()=>window.__friendTest());
  await page.locator('[data-ch="2"]').click();
  await page.waitForFunction(()=>document.querySelector('#flCancel'));
  const incoming=(await post(2,'friend/state')).data.incoming.find(x=>x.fromUid==='1');assert.ok(incoming);
  assert.equal((await post(2,'friend/accept',{id:incoming.id,groupId:2})).status,200);
  await page.locator('.mv[data-i="0"]').waitFor({timeout:30000});
  const friendVisual=await page.evaluate(()=>window.__friendVisual());assert.equal(friendVisual.kind,'friend');assert.equal(friendVisual.models,2);assert.equal(friendVisual.raid,false);
  await page.locator('.mv[data-i="0"]').click();await page.waitForFunction(()=>window.__friendVisual()?.waiting===true);
  assert.equal((await post(2,'friend/act',{type:'move',idx:0,seen:1})).status,200);
  await page.waitForFunction(()=>window.__friendVisual()?.seen>=2&&!window.__friendVisual()?.waiting,null,{timeout:30000});
  await page.screenshot({path:path.join(dir,'friend-mobile.png'),fullPage:true});
  assert.equal((await post(2,'friend/act',{type:'forfeit'})).status,200);
  await page.locator('#fbAgain').waitFor({timeout:30000});assert.equal((await page.evaluate(()=>window.__friendVisual())).over.result,'win');
  console.log('PASS browser friend lobby challenge, battle effects, two-player turn, result, raid scene cleanup');
  assert.deepEqual(errors,[]);await browser.close();console.log('PASS browser raid screen, move controls, mobile layout; screenshot '+path.join(dir,'raid-mobile.png'));
 }
 console.log('PASS HTTP: auth, 3 players, real bot schema, party load, mutation guard, synchronized turn');
}
main().then(()=>{S.server.close();S.db.close();}).catch(e=>{console.error(e);S.server.close();S.db.close();process.exit(1)});
