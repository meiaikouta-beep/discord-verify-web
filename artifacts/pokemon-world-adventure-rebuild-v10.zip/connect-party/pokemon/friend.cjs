// ============================================================
// フレンドバトル（2人対戦）。元botの「フレンドバトル」の移植。
// 流れ：ロビー（同じサーバーでこの画面を開いている人が一覧に出る）→ 挑戦状 → 相手がチームを選んで受ける → 対戦。
// 勝敗に報酬はない。HP・状態異常・PPは通常戦と同じく保存し、全員を使った交代あり・両者が技を選ぶと1ターン進む。
// 画面は約1.2秒ごとに /api/friend/state を呼んで同期する（サーバー側は状態をメモリに持つ）。
// ============================================================
const PRESENCE_TTL = 20e3;       // この秒数以内に画面から呼ばれた人だけ「オンライン」
const CHALLENGE_TTL = 120e3;     // 挑戦状の有効期間
const AWAY_LIMIT = 60e3;         // 対戦中、この間まったく呼ばれなければ切断扱い
const IDLE_LIMIT = 300e3;        // 相手を待たせたまま5分何も選ばなければ時間切れ
const KEEP_OVER = 300e3;         // 終わった対戦を覚えておく時間
const STAGES = ['field','water','rock','cave','snow','stadium','volcano'];

function create({ all, one, run, E, loadParty, markSeen, pveActive, persistParty, normalizeParty, recordPvp, log }) {
  const presence = new Map();    // uid → { g, name, t }
  const challenges = new Map();  // id → { id, g, from:{uid,name,groupId}, to:{uid,name}, t, status }
  const battles = new Map();     // battle id → B
  const byUser = new Map();      // uid → B
  let seq = 0;
  const now = () => Date.now();

  const touch = s => presence.set(s.uid, { g: s.g, name: s.name, t: now() });
  const online = (uid, g) => { const p = presence.get(uid); return !!p && p.g === g && now() - p.t < PRESENCE_TTL; };
  const inBattle = uid => { const B = byUser.get(uid); return !!(B && !B.over); };
  const sideOf = (B, uid) => (B.p.uid === uid ? "p" : "e");
  const opp = s => (s === "p" ? "e" : "p");
  const partyOf = (B, s) => (s === "p" ? B.S.party : B.S.eparty);
  const alive = (B, s) => partyOf(B, s).filter(b => b.hp > 0).length;
  const persist=B=>{persistParty?.({party:B.S.party});persistParty?.({party:B.S.eparty})};
  const ratingOf=(g,u)=>one("SELECT rating FROM web_pvp_ratings WHERE guild_id=? AND user_id=?",BigInt(g),BigInt(u))?.rating??1500;

  // ---------------- ロビー ----------------
  function challengeView(c) { return { id: c.id, from: c.from.name, fromUid: c.from.uid, to: c.to.name, toUid: c.to.uid, mode:c.mode||'normal',stage:c.stage,status: c.status, left: Math.max(0, Math.ceil((c.t + CHALLENGE_TTL - now()) / 1000)) }; }
  function sweepChallenges() {
    for (const [id, c] of challenges) {
      if (c.status === "pending" && now() - c.t > CHALLENGE_TTL) c.status = "expired";
      if (c.status !== "pending" && now() - c.t > CHALLENGE_TTL + 60e3) challenges.delete(id);
    }
  }
  function lobby(s) {
    sweepChallenges();
    const players = [];
    for (const [uid, p] of presence) {
      if (uid === s.uid || p.g !== s.g || now() - p.t >= PRESENCE_TTL) continue;
      players.push({ uid, name: p.name, rating:ratingOf(s.g,uid), busy: inBattle(uid) || pveActive(uid) });
    }
    players.sort((a, b) => a.name.localeCompare(b.name, "ja"));
    const incoming = [...challenges.values()].filter(c => c.status === "pending" && c.to.uid === s.uid && c.g === s.g).map(challengeView);
    const out = [...challenges.values()].filter(c => c.from.uid === s.uid).sort((a, b) => b.t - a.t)[0];
    return { rating:ratingOf(s.g,s.uid),players, incoming, outgoing: out ? challengeView(out) : null };
  }
  function challenge(s, toUid, groupId,mode='normal',stage='auto') {
    touch(s); toUid = String(toUid);
    if (toUid === s.uid) return { error: "自分には申し込めません" };
    if (pveActive(s.uid)) return { error: "ほかのバトル中です" };
    if (inBattle(s.uid)) return { error: "対戦中です" };
    if (!online(toUid, s.g)) return { error: "その人は今、フレンドバトルの画面にいません" };
    if (inBattle(toUid) || pveActive(toUid)) return { error: "その人は対戦中です" };
    const L = loadParty(BigInt(s.g), BigInt(s.uid), Number(groupId)); if (L.error) return L;
    for (const c of challenges.values()) if (c.from.uid === s.uid && c.status === "pending") c.status = "cancelled";
    mode=['normal','flat50','ranked'].includes(mode)?mode:'normal';stage=STAGES.includes(stage)?stage:STAGES[Math.floor(Math.random()*STAGES.length)];const c = { id: ++seq, g: s.g,mode,stage, from: { uid: s.uid, name: s.name, groupId: Number(groupId) }, to: { uid: toUid, name: presence.get(toUid).name }, t: now(), status: "pending" };
    challenges.set(c.id, c); return { ok: true, ...lobby(s) };
  }
  function cancel(s) { for (const c of challenges.values()) if (c.from.uid === s.uid && c.status === "pending") c.status = "cancelled"; return { ok: true, ...lobby(s) }; }
  function decline(s, id) {
    const c = challenges.get(Number(id)); if (!c || c.to.uid !== s.uid || c.status !== "pending") return { error: "挑戦状が見つかりません" };
    c.status = "declined"; return { ok: true, ...lobby(s) };
  }
  function accept(s, id, groupId) {
    touch(s); sweepChallenges();
    const c = challenges.get(Number(id)); if (!c || c.to.uid !== s.uid || c.status !== "pending") return { error: "挑戦状が見つかりません（期限切れかもしれません）" };
    if (pveActive(s.uid) || inBattle(s.uid)) return { error: "ほかのバトル中です" };
    if (inBattle(c.from.uid) || pveActive(c.from.uid)) { c.status = "cancelled"; return { error: "相手はすでに対戦中です" }; }
    if (!online(c.from.uid, s.g)) { c.status = "cancelled"; return { error: "挑戦者がいなくなりました" }; }
    const G = BigInt(s.g), La = loadParty(G, BigInt(c.from.uid), c.from.groupId);
    if (La.error) { c.status = "cancelled"; return { error: `挑戦者のチームに問題があります：${La.error}` }; }
    const Lb = loadParty(G, BigInt(s.uid), Number(groupId)); if (Lb.error) return Lb;
    if(c.mode==='flat50'||c.mode==='ranked'){normalizeParty?.(La.party,50);normalizeParty?.(Lb.party,50)}
    c.status = "accepted";
    const S = { party: La.party, active: 0, eparty: Lb.party, ei: 0, names: { p: c.from.name, e: s.name }, over: null };
    const B = { id: ++seq, g: s.g,mode:c.mode,scene:{stage:c.stage,method:'friend'}, p: { uid: c.from.uid, name: c.from.name }, e: { uid: s.uid, name: s.name }, S, phase: "turn", acts: { p: null, e: null }, sw: {}, need: { p: false, e: false }, over: null, n: 0, log: [], t: now(), turnStart: now(), lastAct: { p: now(), e: now() } };
    battles.set(B.id, B); byUser.set(B.p.uid, B); byUser.set(B.e.uid, B);
    try { for (const [who, foe] of [["p", S.eparty[0]], ["e", S.party[0]]]) { const sp = one("SELECT species_id FROM pokemon_master WHERE pokemon_key = ?", foe.key)?.species_id; markSeen(G, BigInt(B[who].uid), foe.key, sp); } } catch (e) { log("friend markSeen", e.message); }
    const ev = E.pvpStart(S); B.n = 1; B.log.push({ n: 1, p: E.pvpView(ev, "p"), e: E.pvpView(ev, "e") });
    B.init = { p: viewFor(B, "p"), e: viewFor(B, "e") };
    log("friend start", B.p.uid, "vs", B.e.uid);
    return { ok: true, battle: battleState(s, 0) };
  }

  // ---------------- 対戦 ----------------
  function overFor(B, who) {
    if (!B.over) return null;
    const w = B.over.winner;
    return { kind: "friend", result: w == null ? "draw" : w === who ? "win" : "lose", foe: B[opp(who)].name, reason: B.over.reason };
  }
  function viewFor(B, who) {
    const S = B.S, o = opp(who), me = E.monOf(S, who), foe = E.monOf(S, o), party = partyOf(B, who);
    const needMe = B.phase === "switch" && !!B.need[who] && B.sw[who] == null;
    const waiting = !B.over && (B.phase === "turn" ? B.acts[who] != null : !needMe);
    return { kind: "friend", id: B.id,mode:B.mode||'normal',scene:B.scene, foe: B[o].name, n: B.n, eleft: alive(B, o), etotal: partyOf(B, o).length,
      p: E.pub(me), e: E.pub(foe), moves: me.moves.map(E.mPub), party: party.map((b, i) => ({ ...E.pub(b), idx: i, active: b === me })),
      needSwitch: needMe, waiting, fld: S.fld ? { w: S.fld.weather, t: S.fld.terrain, r: S.fld.trick_room > 0 } : null, over: overFor(B, who), trapped: !!(me.vs.trapped || me.vs.pt > 0) };
  }
  function finish(B, winner, reason, ev) {
    B.over = { winner, reason }; B.overAt = now();recordPvp?.(B,winner);
    persist(B);
    for (const w of ["p", "e"]) if (byUser.get(B[w].uid) === B) { /* 結果表示のため byUser は残す（inBattle は over で false になる） */ }
    log("friend end", B.p.uid, B.e.uid, winner || "draw", reason);
  }
  function push(B, ev) { B.n++; B.log.push({ n: B.n, p: E.pvpView(ev, "p"), e: E.pvpView(ev, "e") }); if (B.log.length > 60) B.log.shift(); B.turnStart = now(); }
  function engineCall(B,kind,arg){const S=B.S,before=structuredClone(S);try{return kind==='turn'?E.pvpTurn(S,arg):E.pvpReplace(S,arg)}catch(error){log('friend engine recovered',B.id,kind,error?.stack||error);for(const k of Object.keys(S))delete S[k];Object.assign(S,before);const saved=[];for(const b of[...(S.party||[]),...(S.eparty||[])])for(const m of b.moves||[]){saved.push([m,m.rules]);m.rules=[]}try{const ev=kind==='turn'?E.pvpTurn(S,arg):E.pvpReplace(S,arg);ev.unshift({t:'text',msg:'技の追加効果を安全処理に切り替えた。'});return ev}catch(second){log('friend engine cancelled',B.id,kind,second?.stack||second);for(const k of Object.keys(S))delete S[k];Object.assign(S,structuredClone(before));return[{t:'text',msg:'技処理を取り消した。PPとターンは消費していない。'}]}finally{for(const[m,rules]of saved)m.rules=rules}}}
  function resolve(B) {
    const S = B.S; let ev;
    if (B.phase === "turn") { ev = engineCall(B,'turn',{ p: B.acts.p, e: B.acts.e }); B.acts = { p: null, e: null }; }
    else { ev = engineCall(B,'replace',B.sw); B.sw = {}; S.pivot = {}; }
    const aP = alive(B, "p"), aE = alive(B, "e");
    B.need = { p: false, e: false };
    if (aP === 0 || aE === 0) {
      const w = aP === 0 && aE === 0 ? null : aP === 0 ? "e" : "p";
      for (const s of ["p", "e"]) if (alive(B, s) === 0) ev.push({ t: "text", msg: `${S.names[s]}は戦えるポケモンがいなくなった！` });
      ev.push({ t: "text", msg: w ? `${S.names[w]}の勝利！` : "引き分け！" });
      push(B, ev); finish(B, w, "wipe"); return;
    }
    for (const s of ["p", "e"]) B.need[s] = E.monOf(S, s).hp <= 0 || (!!S.pivot?.[s] && alive(B, s) > 1);
    B.phase = B.need.p || B.need.e ? "switch" : "turn"; S.pivot = {};
    push(B, ev);persist(B);
  }
  function forfeit(B, loser, reason, text) {
    const w = opp(loser); push(B, [{ t: "text", msg: text }, { t: "text", msg: `${B.S.names[w]}の勝利！` }]); finish(B, w, reason);
  }
  // 切断・時間切れの判定（状態を読むたびに呼ぶ）
  function check(B) {
    if (B.over) return;
    const away = s => { const p = presence.get(B[s].uid); return !p || now() - p.t > AWAY_LIMIT; };
    const a = away("p"), b = away("e");
    if (a && b) { finish(B,null,"abandoned",[]); return; }
    if (a) return forfeit(B, "p", "disconnect", `${B.S.names.p}との通信が切れた……`);
    if (b) return forfeit(B, "e", "disconnect", `${B.S.names.e}との通信が切れた……`);
    if (now() - B.turnStart > IDLE_LIMIT) {
      const wait = ["p", "e"].filter(s => B.phase === "turn" ? B.acts[s] == null : B.need[s] && B.sw[s] == null);
      if (wait.length === 2) { push(B, [{ t: "text", msg: "どちらも動かなかったので、引き分けになった！" }]); finish(B, null, "timeout"); }
      else if (wait.length === 1) forfeit(B, wait[0], "timeout", `${B.S.names[wait[0]]}は時間切れになった……`);
    }
  }
  function battleState(s, seen) {
    const B = byUser.get(s.uid); if (!B) return null;
    check(B); const who = sideOf(B, s.uid); seen = Math.max(0, Math.floor(Number(seen)) || 0);
    return { id: B.id, turns: B.log.filter(t => t.n > seen).map(t => ({ n: t.n, events: t[who] })), n: B.n, init: seen === 0 ? B.init[who] : null, view: viewFor(B, who) };
  }
  function state(s, seen) {
    touch(s); const r = lobby(s);
    return { ...r, battle: battleState(s, seen) };
  }
  function act(s, a) {
    touch(s); const B = byUser.get(s.uid); if (!B || B.over) return { error: "バトル中ではありません" };
    const who = sideOf(B, s.uid), S = B.S, me = E.monOf(S, who), party = partyOf(B, who);
    if (a.type === "forfeit") { forfeit(B, who, "forfeit", `${S.names[who]}は降参した……`); return { ok: true, battle: battleState(s, Number(a.seen) || 0) }; }
    const idx = Math.floor(Number(a.idx));
    if (B.phase === "turn") {
      if (B.acts[who]) return { error: "すでに選択しています。相手を待っています" };
      if (a.type === "move") {
        const m = me.moves[idx];
        if (idx === -1 && me.moves.every(x => x.pp <= 0)) B.acts[who] = { type: "move", idx: -1 };
        else if (!m) return { error: "その技は使えません" };
        else if (m.pp <= 0) return { error: "その技はPPがありません" };
        else B.acts[who] = { type: "move", idx };
      } else if (a.type === "switch") {
        const t = party[idx]; if (!t || t.hp <= 0 || t === me) return { error: "そのポケモンは出せません" };
        if (me.vs.trapped || me.vs.pt > 0) return { error: `${me.name}は逃げられない！` };
        B.acts[who] = { type: "switch", idx };
      } else return { error: "不明な操作です" };
      if (B.acts.p && B.acts.e) resolve(B);
    } else {
      if (!B.need[who] || B.sw[who] != null) return { error: "今は選べません" };
      const t = party[idx]; if (a.type !== "switch" || !t || t.hp <= 0 || t === me) return { error: "そのポケモンは出せません" };
      B.sw[who] = idx;
      if (["p", "e"].every(x => !B.need[x] || B.sw[x] != null)) resolve(B);
    }
    B.lastAct[who] = now();
    return { ok: true, battle: battleState(s, Number(a.seen) || 0) };
  }
  function leave(s) { const B = byUser.get(s.uid); if (B && B.over) byUser.delete(s.uid); return { ok: true }; }

  function startTimers() {
    setInterval(() => {
      sweepChallenges();
      for (const [id, B] of battles) {
        check(B);
        if (B.over && now() - (B.overAt || 0) > KEEP_OVER) { battles.delete(id); for (const w of ["p", "e"]) if (byUser.get(B[w].uid) === B) byUser.delete(B[w].uid); }
      }
      for (const [uid, p] of presence) if (now() - p.t > 600e3) presence.delete(uid);
    }, 15e3).unref?.();
  }
  return { state, challenge, cancel, decline, accept, act, leave, inBattle, startTimers, _battles: battles, _presence: presence, _byUser: byUser };
}
module.exports = { create };
