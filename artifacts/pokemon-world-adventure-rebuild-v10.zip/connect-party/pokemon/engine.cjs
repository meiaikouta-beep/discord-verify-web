// ============================================================
// ポケモン バトル計算（サーバー側）。画面とは分離：結果は「出来事の列(events)」で返す。
// 元のbotの式（ダメージ・命中・相性・経験値・捕獲率）をそのまま移植。
// 今の版で対応（追加）：天気/フィールド/壁/まもる/みがわり/やどりぎ/こんらん/設置技/回復/一部の固有技 など
// 今の版で対応：タイプ相性/タイプ一致/急所/命中・回避/能力ランク/状態異常(やけど・まひ・どく・もうどく・ねむり・こおり)
//   ひるみ/連続技/固定ダメージ/一撃必殺/吸収/反動/回復/自爆/反動で動けない。
// 特性：元botで動いている23種に対応（いかく・天候/フィールド発動・さいせいりょく・がんじょう・かそく 等）。
// 性格・努力値・主な持ち物まで対応。複数体を同時に出すダブル／トリプルは対象外。
// ============================================================
const P = require('./progression.cjs');
const TYPE_JA = { normal: "ノーマル", fire: "ほのお", water: "みず", electric: "でんき", grass: "くさ", ice: "こおり", fighting: "かくとう", poison: "どく", ground: "じめん", flying: "ひこう", psychic: "エスパー", bug: "むし", rock: "いわ", ghost: "ゴースト", dragon: "ドラゴン", dark: "あく", steel: "はがね", fairy: "フェアリー" };
const CHART = {
  normal: { rock: .5, ghost: 0, steel: .5 },
  fire: { fire: .5, water: .5, grass: 2, ice: 2, bug: 2, rock: .5, dragon: .5, steel: 2 },
  water: { fire: 2, water: .5, grass: .5, ground: 2, rock: 2, dragon: .5 },
  electric: { water: 2, electric: .5, grass: .5, ground: 0, flying: 2, dragon: .5 },
  grass: { fire: .5, water: 2, grass: .5, poison: .5, ground: 2, flying: .5, bug: .5, rock: 2, dragon: .5, steel: .5 },
  ice: { fire: .5, water: .5, grass: 2, ice: .5, ground: 2, flying: 2, dragon: 2, steel: .5 },
  fighting: { normal: 2, ice: 2, poison: .5, flying: .5, psychic: .5, bug: .5, rock: 2, ghost: 0, dark: 2, steel: 2, fairy: .5 },
  poison: { grass: 2, poison: .5, ground: .5, rock: .5, ghost: .5, steel: 0, fairy: 2 },
  ground: { fire: 2, electric: 2, grass: .5, poison: 2, flying: 0, bug: .5, rock: 2, steel: 2 },
  flying: { electric: .5, grass: 2, fighting: 2, bug: 2, rock: .5, steel: .5 },
  psychic: { fighting: 2, poison: 2, psychic: .5, dark: 0, steel: .5 },
  bug: { fire: .5, grass: 2, fighting: .5, poison: .5, flying: .5, psychic: 2, ghost: .5, dark: 2, steel: .5, fairy: .5 },
  rock: { fire: 2, ice: 2, fighting: .5, ground: .5, flying: 2, bug: 2, steel: .5 },
  ghost: { normal: 0, psychic: 2, ghost: 2, dark: .5 },
  dragon: { dragon: 2, steel: .5, fairy: 0 },
  dark: { fighting: .5, psychic: 2, ghost: 2, dark: .5, fairy: .5 },
  steel: { fire: .5, water: .5, electric: .5, ice: 2, rock: 2, steel: .5, fairy: 2 },
  fairy: { fire: .5, fighting: 2, poison: .5, dragon: 2, dark: 2, steel: .5 },
};
const eff = (mt, t1, t2) => (CHART[mt]?.[t1] ?? 1) * (t2 ? (CHART[mt]?.[t2] ?? 1) : 1);
const STAGE = s => { s = Math.max(-6, Math.min(6, s)); return s >= 0 ? (2 + s) / 2 : 2 / (2 - s); };
const ACC = s => { s = Math.max(-6, Math.min(6, s)); return s >= 0 ? (3 + s) / 3 : 3 / (3 - s); };
const STAT_JA = { atk: "こうげき", def: "ぼうぎょ", spatk: "とくこう", spdef: "とくぼう", speed: "すばやさ", accuracy: "命中率", evasion: "回避率" };
const STATUS_JA = { burn: "やけど", freeze: "こおり", paralysis: "まひ", poison: "どく", "bad-poison": "もうどく", sleep: "ねむり", confusion: "こんらん" };
const STATUS_MSG = { burn: "やけどを負った！", freeze: "こおりづけになった！", paralysis: "まひして技が出にくくなった！", poison: "どくをあびた！", "bad-poison": "猛毒をあびた！", sleep: "ねむってしまった！" };
const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const roll = p => Math.random() * 100 < p;

const calcStats = (m, lv, iv, ev={},natureKey=m.nature_key) => {
  const x=k=>Math.floor((Number(ev[k])||Number(m['ev_'+k])||0)/4), n=k=>P.natureMod(natureKey,k);
  return {
   max_hp: Math.floor(((m.base_hp * 2 + iv.hp + x('hp')) * lv) / 100 + lv + 10),
   attack: Math.floor((Math.floor(((m.base_attack * 2 + iv.attack + x('attack')) * lv) / 100 + 5))*n('attack')),
   defense: Math.floor((Math.floor(((m.base_defense * 2 + iv.defense + x('defense')) * lv) / 100 + 5))*n('defense')),
   sp_attack: Math.floor((Math.floor(((m.base_sp_attack * 2 + iv.sp_attack + x('sp_attack')) * lv) / 100 + 5))*n('sp_attack')),
   sp_defense: Math.floor((Math.floor(((m.base_sp_defense * 2 + iv.sp_defense + x('sp_defense')) * lv) / 100 + 5))*n('sp_defense')),
   speed: Math.floor((Math.floor(((m.base_speed * 2 + iv.speed + x('speed')) * lv) / 100 + 5))*n('speed')),
  };
};
const expFor = lv => Math.floor((4 * lv ** 3) / 5);
const rewardExp = lv => rnd(Math.floor(lv * 22 * .8), Math.floor(lv * 22 * 1.3));
const BALL = Object.fromEntries(require('./balls.cjs').keys.map(k => [k, ({ "great-ball": 1.5, "ultra-ball": 2, "master-ball": 999 }[k] ?? 1)]));
function captureChance(maxHp, hp, rate, ball) {
  const b = typeof ball === 'number' ? ball : (BALL[ball] ?? 1); if (b >= 999) return 1;
  maxHp = Math.max(1, maxHp); hp = Math.max(1, hp); rate = rate || 45;
  return Math.max(.01, Math.min((((3 * maxHp - 2 * hp) * rate * b) / (3 * maxHp)) / 255, .95));
}
const pickGender = (rate, lock) => lock && ["male", "female", "genderless"].includes(lock) ? lock : (rate == null || rate === -1 ? "genderless" : (Math.random() < rate / 8 ? "female" : "male"));

// 戦闘用の個体を作る（stats: {max_hp, attack, ...}）
function makeBattler(o) {
  return { id: o.id ?? null, key: o.key, name: o.name, types: [o.type1, o.type2].filter(Boolean), level: o.level, hp: o.hp, maxHp: o.maxHp,
    atk: o.attack, def: o.defense, spatk: o.sp_attack, spdef: o.sp_defense, speed: o.speed,
    st: { atk: 0, def: 0, spatk: 0, spdef: 0, speed: 0, accuracy: 0, evasion: 0 }, status: o.status || null, sleep: o.status==='sleep'?2:0, toxic: 0, flinch: false, recharge: false, vs: {},
    moves: o.moves, img: o.img, shiny: !!o.shiny, gender: o.gender, fought: false,
    ability: o.ability || null, baseAbility: o.ability || null, abilityJa: o.abilityJa || null, baseAbilityJa: o.abilityJa || null, heldItem:o.heldItem||null, heldName:o.heldName||null, heldConsumed:false, nature:o.nature||null, flashFire: false, disguiseBroken: false, acted: false };
}
const statVal = (b, k) => Math.max(1, Math.floor(b[k] * STAGE(b.st[k])));
const held=b=>b.heldConsumed||b.vs.embargo>0?null:b.heldItem;
const effSpeed = b => statVal(b, "speed") * (b.status === "paralysis" ? .5 : 1) * (held(b)==='choice-scarf'?1.5:1);
const pub = b => ({ name: b.name, key: b.key, level: b.level, hp: b.hp, maxHp: b.maxHp, status: b.status, types: b.types, img: b.img, shiny: b.shiny, gender: b.gender, id: b.id, conf: b.vs.conf > 0, sub: b.vs.sub > 0, held:b.heldName||b.heldItem||null });
const consumeHeld=(b,s,ev,msg)=>{if(!held(b))return;b.heldConsumed=true;ev.push({t:'item',side:s,item:b.heldItem,consumed:true,msg:msg||`${b.name}は${b.heldName||b.heldItem}を使った！`})};
function berryCheck(b,s,ev){
 const h=held(b);if(!h||!h.endsWith('-berry')||b.hp<=0)return;
 const cures={"cheri-berry":'paralysis',"chesto-berry":'sleep',"pecha-berry":'poison',"rawst-berry":'burn',"aspear-berry":'freeze'};
 if(h==='lum-berry'&&b.status){b.status=null;consumeHeld(b,s,ev,`${b.name}はラムのみで状態異常を治した！`);ev.push({t:'status',side:s,status:null});return}
 if(cures[h]&&(b.status===cures[h]||(h==='pecha-berry'&&b.status==='bad-poison'))){b.status=null;consumeHeld(b,s,ev,`${b.name}はきのみで状態異常を治した！`);ev.push({t:'status',side:s,status:null});return}
 if(b.hp<=b.maxHp/2&&(h==='oran-berry'||h==='sitrus-berry')){const n=h==='oran-berry'?10:Math.floor(b.maxHp/4);consumeHeld(b,s,ev);healAbs(b,s,n,ev,`${b.name}はきのみでHPを回復した！`)}
}

// ---------------- 場・陣営・一時状態の入れ物 ----------------
// S.fld = 場全体（天気・フィールド・トリックルーム…） / S.sd = 陣営ごと（壁・しんぴ・まきびし…） / battler.vs = そのポケモンの一時状態
const D_OF = s => (s === "p" ? "e" : "p");
const sideJa = s => (s === "p" ? "味方" : "相手");
const fldOf = S => (S.fld ??= { weather: null, wt: 0, terrain: null, tt: 0, trick_room: 0, gravity: 0, wonder_room: 0, magic_room: 0 });
const sdOf = (S, s) => (S.sd ??= { p: { hz: {} }, e: { hz: {} } })[s];
const bold = s => String(s || "").replace(/\*\*/g, "");
const WEATHER_MSG = { rain: "雨が降り始めた！", sunny: "日差しが強くなった！", sandstorm: "砂あらしが吹き荒れる！", snow: "雪が降り始めた！" };
const WEATHER_END = { rain: "雨がやんだ！", sunny: "日差しがもとにもどった！", sandstorm: "砂あらしがおさまった！", snow: "雪がやんだ！" };
const TERRAIN_MSG = { electric: "足下に電気がかけめぐる！", grassy: "足下に草がおいしげった！", misty: "足下に霧がたちこめた！", psychic: "足下が不思議な感じになった！" };
const WALL_JA = { reflect: "リフレクター", light_screen: "ひかりのかべ", aurora_veil: "オーロラベール", safeguard: "しんぴのまもり", mist: "しろいきり", tailwind: "おいかぜ" };
const HAZ_JA = { spikes: "まきびし", toxic_spikes: "どくびし", stealth_rock: "ステルスロック", sticky_web: "ねばねばネット" };
const HAZ_MSG = { spikes: "相手の足下にまきびしが散らばった！", toxic_spikes: "相手の足下にどくびしが散らばった！", stealth_rock: "相手の周りにとがった岩がただよい始めた！", sticky_web: "相手の足下にねばねばネットが広がった！" };
const HAZ_MAX = { spikes: 3, toxic_spikes: 2, stealth_rock: 1, sticky_web: 1 };
const HEAL_WEATHER = { "あさのひざし": 1, "こうごうせい": 1, "つきのひかり": 1 };
const STAT_KEYS = ["atk", "def", "spatk", "spdef", "speed", "accuracy", "evasion"];
const jx = r => { try { return JSON.parse(r.extra_json || "{}"); } catch { return {}; } };
const fx = (ev, kind, side, key, msg) => ev.push({ t: "fx", kind, side, key, msg });
const say = (ev, msg) => ev.push({ t: "text", msg });
let picker = null, errorReporter = null; const setPicker = f => { picker = f; }; const setErrorReporter = f => { errorReporter = typeof f === 'function' ? f : null; };

function chip(b, s, d, ev, msg, extra = {}) { if (b.raidEndTurn) d = Math.max(1, Math.floor(d / 3)); d = Math.min(Math.max(1, d), b.hp); b.hp -= d; ev.push({ t: "dmg", side: s, amount: d, hp: b.hp, maxHp: b.maxHp, recoil: true, msg, ...extra }); return d; }
function healAbs(b, s, amt, ev, msg) {
  if (b.vs.healBlock > 0) { say(ev, `${b.name}は回復を封じられている！`); return 0; }
  amt = Math.min(b.maxHp - b.hp, Math.max(1, amt)); if (amt <= 0) { say(ev, `${b.name}のHPはこれ以上回復しない！`); return 0; }
  b.hp += amt; ev.push({ t: "heal", side: s, amount: amt, hp: b.hp, maxHp: b.maxHp, msg: msg ?? `${b.name}はHPを回復した！` }); return amt;
}
const healPct = (b, s, pct, ev, msg) => healAbs(b, s, Math.floor(b.maxHp * pct / 100), ev, msg);
function resetStages(b) { for (const k of STAT_KEYS) b.st[k] = 0; }

// ---------------- 特性 ----------------
const AB_JA = { intimidate: "いかく", drizzle: "あめふらし", drought: "ひでり", "sand-stream": "すなおこし", "snow-warning": "ゆきふらし", "electric-surge": "エレキメイカー", "grassy-surge": "グラスメイカー", "psychic-surge": "サイコメイカー", "misty-surge": "ミストメイカー", regenerator: "さいせいりょく", "natural-cure": "しぜんかいふく", chlorophyll: "ようりょくそ", "swift-swim": "すいすい", "poison-heal": "ポイズンヒール", "rain-dish": "あめうけざら", "dry-skin": "かんそうはだ", "shed-skin": "だっぴ", "speed-boost": "かそく", unaware: "てんねん", "flash-fire": "もらいび", multiscale: "マルチスケイル", disguise: "ばけのかわ", sturdy: "がんじょう", "mold-breaker": "かたやぶり", teravolt: "テラボルテージ", turboblaze: "ターボブレイズ", overcoat: "ぼうじん", "magic-guard": "マジックガード", simple: "たんじゅん", insomnia: "ふみん" };
const abOf = b => (b.vs.gastro ? null : b.ability);                       // かがくへんかガス（いえき）で無効なら null
const abName = b => AB_JA[b.ability] || b.abilityJa || b.ability;
const MOLD = new Set(["mold-breaker", "teravolt", "turboblaze"]);          // 相手の特性を無視
const setAb = (u, en, ja) => { u.ability = en; u.abilityJa = ja || AB_JA[en] || en; };
const PIVOT = new Set(["u-turn", "volt-switch", "flip-turn", "parting-shot"]);

// 状態異常をかける（無効条件つき）。成功したらtrue
function inflict(S, b, s, k, ev, loud) {
  const f = fldOf(S), sd = sdOf(S, s), no = m => { if (loud) say(ev, m); return false; };
  if (b.hp <= 0) return false;
  if (k === "confusion") {
    if (b.vs.conf > 0) return no(`${b.name}はすでにこんらんしている！`);
    if (sd.safeguard > 0) return no(`${b.name}はしんぴのまもりで守られている！`);
    if (f.terrain === "misty") return no(`${b.name}はミストフィールドに守られている！`);
    b.vs.conf = rnd(2, 5); ev.push({ t: "status", side: s, status: "confusion", vol: true, msg: `${b.name}はこんらんした！` }); return true;
  }
  if (b.status) return no("しかしうまく決まらなかった！");
  if ((k === "burn" && b.types.includes("fire")) || (k === "freeze" && (b.types.includes("ice") || f.weather === "sunny")) || ((k === "poison" || k === "bad-poison") && (b.types.includes("poison") || b.types.includes("steel"))) || (k === "paralysis" && b.types.includes("electric"))) return no(`${b.name}には効果がないようだ……`);
  const a=abOf(b);if((k==='sleep'&&['insomnia','vital-spirit'].includes(a))||(k==='burn'&&a==='water-veil')||((k==='poison'||k==='bad-poison')&&['immunity','pastel-veil'].includes(a))||(k==='paralysis'&&a==='limber')||(k==='freeze'&&a==='magma-armor'))return no(`${b.name}の${abName(b)}で状態異常にならない！`);
  if (sd.safeguard > 0) return no(`${b.name}はしんぴのまもりで守られている！`);
  if (f.terrain === "misty") return no(`${b.name}はミストフィールドに守られている！`);
  if (k === "sleep" && f.terrain === "electric") return no(`${b.name}はエレキフィールドで眠れない！`);
  b.status = k; b.toxic = 0; if (k === "sleep") b.sleep = rnd(1, 3);
  ev.push({ t: "status", side: s, status: k, msg: `${b.name}は${STATUS_MSG[k]}` }); return true;
}

// 場に出た時（まきびし等）
function enterHazards(S, b, s, ev) {
  const hz = sdOf(S, s).hz, f = fldOf(S); if (!hz || b.hp <= 0) return;
  const grounded = !b.types.includes("flying") && !(b.vs.magnet > 0);
  if (hz.stealth_rock) { const m = eff("rock", b.types[0], b.types[1]); chip(b, s, Math.floor(b.maxHp * m / 8), ev, `${b.name}にとがった岩が食い込んだ！`); }
  if (hz.spikes && grounded && b.hp > 0) chip(b, s, Math.floor(b.maxHp / ([8, 6, 4][Math.min(hz.spikes, 3) - 1])), ev, `${b.name}はまきびしでダメージを受けた！`);
  if (hz.toxic_spikes && grounded && b.hp > 0) { if (b.types.includes("poison")) { delete hz.toxic_spikes; say(ev, `${b.name}がどくびしを吸収した！`); } else inflict(S, b, s, hz.toxic_spikes >= 2 ? "bad-poison" : "poison", ev, false); }
  if (hz.sticky_web && grounded && b.hp > 0) { b.st.speed = Math.max(-6, b.st.speed - 1); ev.push({ t: "stage", side: s, stat: "speed", delta: -1, msg: `${b.name}はねばねばネットに引っかかった！すばやさが下がった！` }); }
}

const foeOf = (S, s) => (s === "p" ? S.enemy : S.party[S.active]);
// 場に出た時の特性（いかく・天候・フィールド）
function enterAbility(S, b, s, ev) {
  const a = abOf(b); if (!a || b.hp <= 0) return;
  const f = fldOf(S), foe = foeOf(S, s), nm = `${b.name}の${abName(b)}！`;
  const W = { drizzle: "rain", drought: "sunny", "sand-stream": "sandstorm", "snow-warning": "snow" };
  const T = { "electric-surge": "electric", "grassy-surge": "grassy", "psychic-surge": "psychic", "misty-surge": "misty" };
  if (a === "intimidate") {
    if (foe && foe.hp > 0) {
      const before = foe.st.atk; foe.st.atk = Math.max(-6, before - 1); const d = foe.st.atk - before;
      ev.push({ t: "stage", side: D_OF(s), stat: "atk", delta: d, msg: d ? `${nm}${foe.name}のこうげきが下がった！` : `${nm}${foe.name}のこうげきはこれ以上下がらない！` });
    }
  } else if (W[a]) { if (f.weather !== W[a]) { f.weather = W[a]; f.wt = 5; fx(ev, "weather", s, W[a], `${nm}${WEATHER_MSG[W[a]]}`); } }
  else if (T[a]) { if (f.terrain !== T[a]) { f.terrain = T[a]; f.tt = 5; fx(ev, "terrain", s, T[a], `${nm}${TERRAIN_MSG[T[a]]}`); } }
}
function enter(S, b, s, ev) { b.acted = false; enterHazards(S, b, s, ev); enterAbility(S, b, s, ev); }
// バトル開始時：両者の先頭ポケモンの特性を素早い順に発動
function battleStart(S, ev) {
  fldOf(S); sdOf(S, "p");
  for (const [b, s] of [[S.party[S.active], "p"], [S.enemy, "e"]].sort((x, y) => effSpeed(y[0]) - effSpeed(x[0]))) { b.acted = false; enterAbility(S, b, s, ev); }
}
// 引っ込む時：さいせいりょく・しぜんかいふく、一時状態と能力変化のリセット、変化した特性を元に戻す
function leave(S, s, b, ev) {
  if (b.hp > 0) {
    const a = abOf(b);
    if (a === "regenerator" && b.hp < b.maxHp) healAbs(b, s, Math.floor(b.maxHp / 3), ev, `${b.name}の${abName(b)}！HPが回復した！`);
    else if (a === "natural-cure" && b.status) { b.status = null; ev.push({ t: "status", side: s, status: null, msg: `${b.name}の${abName(b)}！状態異常が治った！` }); }
  }
  b.vs = {}; resetStages(b); b.toxic = 0; b.flashFire = false; b.ability = b.baseAbility; b.abilityJa = b.baseAbilityJa;
}

const SELF_HIT = (b) => Math.max(1, Math.floor(((2 * b.level / 5 + 2) * 40 * statVal(b, "atk") / Math.max(1, statVal(b, "def"))) / 50 + 2));
const FOE_RULE = new Set(["status", "stat_stage", "seed", "encore", "disable", "taunt", "torment", "heal_block", "trap", "force_switch", "partial_trap", "transform_state"]);

function moveBlock(b, mv) {
  const v = b.vs;
  if (v.taunt > 0 && mv.cls === "status") return `${b.name}はちょうはつされて${mv.name}が出せない！`;
  if (v.disable && v.disable.t > 0 && v.disable.mv === mv) return `${mv.name}は使えなくなっている！`;
  if (v.torment && v.lastMv === mv) return `${b.name}はいちゃもんをつけられて同じ技を出せない！`;
  if (v.healBlock > 0 && (mv.rules || []).some(r => r.effect_type === "heal" || (r.effect_type === "hp_change" && jx(r).mode === "heal") || r.effect_type === "rest")) return `${b.name}は回復を封じられていて${mv.name}が出せない！`;
  if (held(b)==='assault-vest' && mv.cls==='status') return `${b.name}はとつげきチョッキのため変化技を出せない！`;
  if (held(b)?.startsWith('choice-') && b.vs.choiceMove && b.vs.choiceMove!==mv.id) return `${b.name}はこだわっていて${mv.name}を出せない！`;
  return null;
}

function useMove(att, def, mv, side, ev, S) {
  if (def.raidBoss && mv.rules?.some(r => r.effect_type === "ohko")) { say(ev, "レイドボスには一撃必殺は効かない！"); if (mv.pp > 0) mv.pp--; return; }
  const A = side, D = D_OF(side), rules = mv.rules || [], f = fldOf(S), myS = sdOf(S, A), foeS = sdOf(S, D);
  const has = t => rules.find(r => r.effect_type === t);
  const mode = r => jx(r).mode;
  const isProtect = !!has("protect") || rules.some(r => r.effect_type === "custom_move" && mode(r) === "burning-bulwark");
  const chargeNames=new Set(['fly','dig','dive','bounce','solar-beam','solar-blade','sky-attack','razor-wind','skull-bash','meteor-beam','electro-shot','phantom-force','shadow-force','ice-burn','freeze-shock','geomancy']);
  const charge=chargeNames.has(mv.en)||has('charge_turn')||has('two_turn')||has('charge');
  if(charge&&att.vs.charging!==mv.id){ev.push({t:'move',side:A,name:mv.name,type:mv.type,cls:mv.cls});if(mv.pp>0)mv.pp--;att.vs.charging=mv.id;att.vs.chargingMove=mv;say(ev,`${att.name}は${mv.name}の準備に入った！`);return}
  const charged=charge&&att.vs.charging===mv.id;if(charged){delete att.vs.charging;delete att.vs.chargingMove}
  ev.push({ t: "move", side: A, name: mv.name, type: mv.type, cls: mv.cls });
  if (!charged&&mv.pp > 0) mv.pp--;
  if(held(att)?.startsWith('choice-')&&!att.vs.choiceMove)att.vs.choiceMove=mv.id;
  att.vs.lastMv = mv; if (!isProtect) att.vs.pn = 0;
  // 威力が無くても固定ダメージ・一撃必殺は「攻撃技」として扱う
  const special = has("fixed_damage") || has("ohko");
  const stat = mv.cls === "status" || (mv.power <= 0 && !special);
  const hitsFoe = !stat || rules.some(r => r.target_side !== "self" && r.target_side !== "both" && FOE_RULE.has(r.effect_type));
  // 先制技の制限：サイコフィールド／ねこだまし・ふいうち
  if (hitsFoe && f.terrain === "psychic" && mv.priority > 0 && !isProtect && !def.types.includes("flying") && !(def.vs.magnet > 0)) { say(ev, `${def.name}はサイコフィールドに守られている！`); return; }
  if ((mv.en === "fake-out" || mv.en === "first-impression") && att.acted) { say(ev, "しかしうまく決まらなかった！"); return; }
  if (mv.en === "sucker-punch" && (!S.foeMv || S.foeMv.cls === "status" || S.foeActed)) { say(ev, "しかしうまく決まらなかった！"); return; }
  // まもる
  if (hitsFoe && def.vs.protect && !isProtect) { fx(ev, "protect", D, "block"); say(ev, `${def.name}は攻撃から身を守った！`); return; }
  // 命中
  if (mv.accuracy != null && !has("ohko")) {
    let a = mv.accuracy * ACC(att.st.accuracy) / ACC(def.st.evasion);
    if (mv.name === "かみなり" || mv.name === "ぼうふう") a = f.weather === "rain" ? 100 : f.weather === "sunny" ? Math.min(a, 50) : a;
    if (!stat || hitsFoe) if (!(Math.random() * 100 < Math.max(1, Math.min(100, a)))) { ev.push({ t: "miss", side: A, msg: `${att.name}の攻撃は当たらなかった！` }); return; }
  }
  const tgt = r => (r.target_side === "self" ? [att, A] : [def, D]);
  let dmgTotal = 0, hits = 0, subbed = false;
  if (!stat) {
    let e = eff(mv.type, def.types[0], def.types[1]);
    if (mv.type === "ground" && def.vs.magnet > 0) e = 0;
    if ((mv.type==='ground'&&abOf(def)==='levitate')||(mv.type==='water'&&['water-absorb','storm-drain','dry-skin'].includes(abOf(def)))||(mv.type==='electric'&&['volt-absorb','lightning-rod','motor-drive'].includes(abOf(def)))||(mv.type==='grass'&&abOf(def)==='sap-sipper')) {if(['water-absorb','dry-skin','volt-absorb'].includes(abOf(def)))healAbs(def,D,Math.floor(def.maxHp/4),ev,`${def.name}の${abName(def)}で回復した！`);else{const k=mv.type==='grass'?'atk':mv.type==='electric'&&abOf(def)==='motor-drive'?'speed':'spatk';def.st[k]=Math.min(6,def.st[k]+1);say(ev,`${def.name}の${abName(def)}で${STAT_JA[k]}が上がった！`)}return}
    if (e === 0 || (abOf(def)==='wonder-guard'&&e<=1)) { say(ev, `${def.name}には効果がないようだ……`); return; }
    const dA = MOLD.has(abOf(att)) ? null : abOf(def);   // かたやぶり系は相手の特性を無視
    if (dA === "flash-fire" && mv.type === "fire") { def.flashFire = true; say(ev, `${def.name}の${abName(def)}！炎の技を受けて、炎の威力が上がった！`); return; }
    if (has("ohko") && dA === "sturdy") { say(ev, `${def.name}の${abName(def)}で技は決まらなかった！`); return; }
    const fxd = has("fixed_damage"), oh = has("ohko"), mh = has("multi_hit");
    const mx = mh ? jx(mh) : {}, n = mh ? rnd(+(mx.min || 2), +(mx.max || 2)) : 1;
    const phys = mv.cls === "physical";
    for (let i = 0; i < n && def.hp > 0; i++) {
      let d, crit = false, endured = false, abMsg = "";
      if (oh) { if (att.level < def.level) { say(ev, "しかし技は決まらなかった！"); return; } d = def.hp; }
      else if (fxd) { d = fxd.value > 0 ? fxd.value : att.level; }
      else {
        const ak = phys ? "atk" : "spatk", dk = phys ? "def" : "spdef";
        const stg = (u, k, ign) => Math.max(1, Math.floor(u[k] * STAGE(ign ? 0 : u.st[k])));   // てんねん：能力変化を無視
        let atk = stg(att, ak, dA === "unaware"), df = stg(def, dk, abOf(att) === "unaware");
        if(held(att)===(phys?'choice-band':'choice-specs'))atk=Math.floor(atk*1.5);
        if(phys&&['huge-power','pure-power'].includes(abOf(att)))atk*=2;if(phys&&abOf(att)==='guts'&&att.status)atk=Math.floor(atk*1.5);if(phys&&abOf(def)==='marvel-scale'&&def.status)df=Math.floor(df*1.5);
        if(!phys&&held(def)==='assault-vest')df=Math.floor(df*1.5);
        if(held(def)==='eviolite')df=Math.floor(df*1.5);
        crit = Math.random() < (att.vs.focus ? .5 : .0625);
        if (crit) { atk = Math.max(atk, att[phys ? "atk" : "spatk"]); df = Math.min(df, def[phys ? "def" : "spdef"]); }
        if (phys && att.status === "burn") atk = Math.floor(atk / 2);
        if (f.weather === "snow" && phys && def.types.includes("ice")) df = Math.floor(df * 1.5);          // ゆき：こおりのぼうぎょ+50%
        if (f.weather === "sandstorm" && !phys && def.types.includes("rock")) df = Math.floor(df * 1.5);   // すなあらし：いわのとくぼう+50%
        const stab = att.types.includes(mv.type) ? (abOf(att)==='adaptability'?2:1.5) : 1;
        let wm = 1; // 天気・フィールド
        if (f.weather === "rain") wm *= mv.type === "water" ? 1.5 : mv.type === "fire" ? .5 : 1;
        if (f.weather === "sunny") wm *= mv.type === "fire" ? 1.5 : mv.type === "water" ? .5 : 1;
        if (att.flashFire && abOf(att) === "flash-fire" && mv.type === "fire") wm *= 1.5;
        if (f.terrain === "grassy" && mv.type === "grass") wm *= 1.3;
        if (f.terrain === "electric" && mv.type === "electric") wm *= 1.3;
        if (f.terrain === "psychic" && mv.type === "psychic") wm *= 1.3;
        if (f.terrain === "misty" && mv.type === "dragon") wm *= .5;
        const wall = !crit && (foeS.aurora_veil > 0 || (phys ? foeS.reflect > 0 : foeS.light_screen > 0)) ? .5 : 1;
        let im=held(att)==='life-orb'?1.3:1,aa=abOf(att),da=abOf(def);if(mv.power<=60&&aa==='technician')im*=1.5;if(e<1&&aa==='tinted-lens')im*=2;if(e>1&&['filter','solid-rock','prism-armor'].includes(da))im*=.75;if(['fire','ice'].includes(mv.type)&&da==='thick-fat')im*=.5;if(att.hp<=att.maxHp/3&&({fire:'blaze',water:'torrent',grass:'overgrow',bug:'swarm'}[mv.type]===aa))im*=1.5;
        d = Math.max(1, Math.floor((((2 * att.level / 5 + 2) * mv.power * atk / Math.max(1, df)) / 50 + 2) * (crit ? 1.5 : 1) * stab * e * wm * wall * im * (0.85 + Math.random() * .15)));
      }
      hits++;
      if (def.vs.sub > 0 && !oh) { // みがわり
        const x = Math.min(d, def.vs.sub); def.vs.sub -= x; dmgTotal += x; subbed = true; fx(ev, "subhit", D, "hit");
        say(ev, def.vs.sub > 0 ? "身代わりが攻撃を受けた！" : "身代わりは消えてしまった！"); if (def.vs.sub <= 0) { def.vs.sub = 0; fx(ev, "subbreak", D, "break"); } continue;
      }
      if (dA === "disguise" && !def.disguiseBroken && !oh) { def.disguiseBroken = true; say(ev, `${def.name}の${abName(def)}がはがれた！`); continue; }
      if (dA === "multiscale" && def.hp === def.maxHp && !oh && !fxd) { d = Math.max(1, Math.floor(d / 2)); say(ev, `${def.name}の${abName(def)}でダメージが軽減された！`); }
      if (dA === "sturdy" && def.hp === def.maxHp && d >= def.hp) { d = Math.max(0, def.hp - 1); endured = true; abMsg = `${def.name}の${abName(def)}！`; }
      if (held(def)==='focus-sash' && def.hp===def.maxHp && d>=def.hp) {d=Math.max(0,def.hp-1);endured=true;consumeHeld(def,D,ev,`${def.name}はきあいのタスキで持ちこたえた！`)}
      if (def.vs.endure && d >= def.hp) { d = Math.max(0, def.hp - 1); endured = true; }
      d = Math.min(d, def.hp); def.hp -= d; dmgTotal += d;
      // カウンター系に必要なのは直前のダメージ量と分類だけ。攻撃者オブジェクトを保持すると
      // レイドの永続化時に循環参照になるため、JSON化できる値だけを保存する。
      def.vs.lastDamage={amount:d,cls:mv.cls};
      ev.push({ t: "dmg", side: D, amount: d, hp: def.hp, maxHp: def.maxHp, crit, eff: oh || fxd ? 1 : e, type: mv.type });
      berryCheck(def,D,ev);
      if (endured) say(ev, `${abMsg}${def.name}は攻撃をこらえた！`);
      if (def.status === "freeze" && mv.type === "fire") { def.status = null; ev.push({ t: "status", side: D, status: null, msg: `${def.name}のこおりがとけた！` }); }
    }
    if (n > 1) say(ev, `${hits}回当たった！`);
    if(dmgTotal>0&&held(att)==='life-orb'&&att.hp>0)chip(att,A,Math.floor(att.maxHp/10),ev,`${att.name}はいのちのたまの反動を受けた！`);
    if(dmgTotal>0&&held(att)==='shell-bell'&&att.hp>0&&att.hp<att.maxHp)healAbs(att,A,Math.floor(dmgTotal/8),ev,`${att.name}はかいがらのすずで回復した！`);
    if(dmgTotal>0&&held(def)==='rocky-helmet'&&mv.cls==='physical'&&att.hp>0)chip(att,A,Math.floor(att.maxHp/6),ev,`${att.name}はゴツゴツメットで傷ついた！`);
    if (!oh && !fxd && !subbed) { if (e >= 2) say(ev, "効果はばつぐんだ！"); else if (e < 1) say(ev, "効果はいまひとつのようだ……"); }
  }
  // ---- 技の効果
  const n0 = ev.length;
  for (const r of rules) {
   try {
    const x = jx(r), ph = x.phase;
    if (["fixed_damage", "multi_hit", "ohko"].includes(r.effect_type)) continue;
    if (!stat && ph === "status") continue;
    if (!stat && ph === "secondary" && (def.hp <= 0 && r.target_side !== "self")) continue;
    if (!stat && (att.hp <= 0 && r.effect_type !== "self_destruct")) continue;
    if (r.chance != null && r.chance < 100 && !roll(r.chance)) continue;
    const T = tgt(r), [b, s] = T;
    // みがわり：相手への追加効果・変化技は通らない
    if (b === def && def.vs.sub > 0 && FOE_RULE.has(r.effect_type) && r.effect_type !== "force_switch") { if (stat) say(ev, "しかしうまく決まらなかった！"); continue; }
    switch (r.effect_type) {
      case "stat_stage": {
        const k = r.stat_key; if (!k || !(k in att.st) || b.hp <= 0) break;
        if (b !== att && r.value < 0 && sdOf(S, s).mist > 0) { say(ev, `${b.name}は白い霧に守られている！`); break; }
        const before = b.st[k]; b.st[k] = Math.max(-6, Math.min(6, before + r.value)); const d = b.st[k] - before;
        ev.push({ t: "stage", side: s, stat: k, delta: d, msg: d === 0 ? `${b.name}の${STAT_JA[k]}はこれ以上${r.value > 0 ? "上がらない" : "下がらない"}！` : `${b.name}の${STAT_JA[k]}が${Math.abs(d) >= 2 ? (d > 0 ? "ぐーんと上がった" : "がくっと下がった") : (d > 0 ? "上がった" : "下がった")}！` });
        break;
      }
      case "status": { if (b.hp <= 0 || !r.status_key) break; inflict(S, b, s, r.status_key, ev, stat); break; }
      case "flinch": if (def.hp > 0 && !subbed) def.flinch = true; break;
      case "heal": {
        let pct = r.value > 0 ? r.value : 50;
        if (HEAL_WEATHER[mv.name]) pct = f.weather === "sunny" ? 66 : f.weather ? 25 : 50;
        if (b.hp >= b.maxHp) { say(ev, `${b.name}のHPは満タンだ！`); break; }
        healPct(b, s, pct, ev, `${b.name}はHPを回復した！`); break;
      }
      case "hp_change": {
        const m = x.mode || "heal", pct = r.value || x.value || 50;
        if (m === "heal") { if (b.hp >= b.maxHp) say(ev, `${b.name}のHPは満タンだ！`); else healPct(b, s, pct, ev); }
        else if (m === "damage") chip(b, s, Math.floor(b.maxHp * pct / 100), ev, `${b.name}はダメージを受けた！`);
        else if (m === "set_hp_1" && b.hp > 1) chip(b, s, b.hp - 1, ev, `${b.name}のHPが1になった！`);
        break;
      }
      case "rest": {
        if (att.hp >= att.maxHp && !att.status) { say(ev, "しかしうまく決まらなかった！"); break; }
        if (att.vs.healBlock > 0) { say(ev, `${att.name}は回復を封じられている！`); break; }
        att.status = "sleep"; att.sleep = 3; ev.push({ t: "status", side: A, status: "sleep", msg: `${att.name}は眠って元気になった！` });
        healAbs(att, A, att.maxHp - att.hp, ev, `${att.name}はHPを全回復した！`); break;
      }
      case "heal_block": def.vs.healBlock = 5; say(ev, `${def.name}は回復を封じられた！`); break;
      case "embargo": def.vs.embargo=r.value||5;say(ev,`${def.name}は道具を使えなくなった！`);break;
      case "imprison": att.vs.imprison=true;say(ev,`${att.name}は相手の技をふういんした！`);break;
      case "type_change": {const nt=x.type||x.new_type;if(nt){b.types=[nt];say(ev,`${b.name}のタイプが変わった！`)}break}
      case "ability_change": {const na=x.ability_en||x.ability;if(na){setAb(b,na,x.ability_ja);say(ev,`${b.name}の特性が変わった！`)}break}
      case "item_change": b.heldItem=x.item_key||null;b.heldName=x.item_name_ja||b.heldItem;say(ev,`${b.name}の持ち物が変化した！`);break;
      case "future_attack": def.vs.future={turns:r.value||2,damage:Math.max(1,Math.floor(att.level*2)),name:mv.name};say(ev,'未来に攻撃が予知された！');break;
      case "counter": {const ld=att.vs.lastDamage;if(!ld||ld.amount<=0){say(ev,'しかしうまく決まらなかった！');break}const want=mv.en==='mirror-coat'?'special':'physical';if(ld.cls!==want){say(ev,'しかしうまく決まらなかった！');break}const z=Math.min(def.hp,ld.amount*2);def.hp-=z;ev.push({t:'dmg',side:D,amount:z,hp:def.hp,maxHp:def.maxHp,type:mv.type});say(ev,`${def.name}に${z}のダメージ！`);break}
      case "drain": if (dmgTotal > 0) { const amt = Math.min(att.maxHp - att.hp, Math.max(1, Math.floor(dmgTotal * r.value / 100))); if (amt > 0 && !(att.vs.healBlock > 0)) { att.hp += amt; ev.push({ t: "heal", side: A, amount: amt, hp: att.hp, maxHp: att.maxHp, msg: `${def.name}から体力を吸い取った！` }); } } break;
      case "recoil": if (dmgTotal > 0) { const amt = Math.min(att.hp, Math.max(1, Math.floor(dmgTotal * r.value / 100))); att.hp -= amt; ev.push({ t: "dmg", side: A, amount: amt, hp: att.hp, maxHp: att.maxHp, recoil: true, msg: `${att.name}は反動を受けた！` }); } break;
      case "recharge": if (dmgTotal > 0) att.recharge = true; break;
      case "self_destruct": att.hp = 0; ev.push({ t: "dmg", side: A, amount: 0, hp: 0, maxHp: att.maxHp, recoil: true }); break;
      case "protect": {
        if (att.vs.pn > 0 && Math.random() > Math.pow(1 / 3, att.vs.pn)) { att.vs.pn = 0; say(ev, "しかしうまく決まらなかった！"); break; }
        att.vs.protect = true; att.vs.pn = (att.vs.pn || 0) + 1; fx(ev, "protect", A, "up", `${att.name}は身を守る体勢に入った！`); break;
      }
      case "weather": {
        const k = r.weather_key; if (!k) break; if (f.weather === k) { say(ev, "しかしうまく決まらなかった！"); break; }
        f.weather = k; f.wt = 5; fx(ev, "weather", A, k, WEATHER_MSG[k] || "天気が変わった！"); break;
      }
      case "terrain": {
        const k = r.terrain_key; if (!k) break; if (f.terrain === k) { say(ev, "しかしうまく決まらなかった！"); break; }
        f.terrain = k; f.tt = 5; fx(ev, "terrain", A, k, TERRAIN_MSG[k] || "足下の様子が変わった！"); break;
      }
      case "wall": {
        const k = x.wall_key; if (!k) break; if (myS[k] > 0) { say(ev, "しかしうまく決まらなかった！"); break; }
        myS[k] = 5; fx(ev, "wall", A, k, `${sideJa(A)}の場に${WALL_JA[k] || "壁"}が張られた！`); break;
      }
      case "mist": if (myS.mist > 0) say(ev, "しかしうまく決まらなかった！"); else { myS.mist = 5; fx(ev, "wall", A, "mist", `${sideJa(A)}の場が白い霧に包まれた！`); } break;
      case "room": {
        const k = x.room_key || "trick_room"; if (f[k] > 0) { f[k] = 0; fx(ev, "room", A, k, "ゆがんだ空間がもとに戻った！"); } else { f[k] = 5; fx(ev, "room", A, k, "空間がゆがんだ！"); } break;
      }
      case "field_state": {
        const k = x.field_key; if (!k) break;
        if (k === "aurora_veil") { if (f.weather !== "snow") { say(ev, "しかしうまく決まらなかった！"); break; } if (myS.aurora_veil > 0) { say(ev, "しかしうまく決まらなかった！"); break; } myS.aurora_veil = 5; fx(ev, "wall", A, "aurora_veil", `${sideJa(A)}の場にオーロラベールが張られた！`); break; }
        if (f[k] > 0) { say(ev, "しかしうまく決まらなかった！"); break; }
        f[k] = 5; fx(ev, "room", A, k, bold(x.message) || "場に不思議な力が働いた！"); break;
      }
      case "entry_hazard": {
        const k = x.hazard_key; if (!k) break; const tS = sdOf(S, D); if ((tS.hz[k] || 0) >= (HAZ_MAX[k] || 1)) { say(ev, "しかしうまく決まらなかった！"); break; }
        tS.hz[k] = (tS.hz[k] || 0) + 1; fx(ev, "hazard", D, k, bold(x.message) || HAZ_MSG[k]); break;
      }
      case "focus_energy": att.vs.focus = true; fx(ev, "buff", A, "focus", `${att.name}は気合をため始めた！`); break;
      case "clear_stages": { resetStages(att); resetStages(def); fx(ev, "haze", A, "haze", "全員の能力変化がもとに戻った！"); break; }
      case "seed": {
        if (b.types.includes("grass")) { say(ev, `${b.name}には効果がないようだ……`); break; } if (b.vs.seed) { say(ev, "しかしうまく決まらなかった！"); break; }
        b.vs.seed = true; fx(ev, "seed", s, "seed", `${b.name}にやどりぎのタネを植えつけた！`); break;
      }
      case "aqua_ring": if (att.vs.ring) say(ev, "しかしうまく決まらなかった！"); else { att.vs.ring = true; fx(ev, "buff", A, "ring", `${att.name}は水のヴェールをまとった！`); } break;
      case "substitute": {
        const cost = Math.max(1, Math.floor(att.maxHp / 4));
        if (att.vs.sub > 0) { say(ev, `${att.name}の身代わりはもういる！`); break; }
        if (att.hp <= cost) { say(ev, "身代わりを出すにはHPが足りない！"); break; }
        att.hp -= cost; ev.push({ t: "dmg", side: A, amount: 0, hp: att.hp, maxHp: att.maxHp, recoil: true }); att.vs.sub = cost; fx(ev, "sub", A, "sub", `${att.name}の身代わりが現れた！`); break;
      }
      case "encore": if (def.vs.lastMv && !(def.vs.encore?.t > 0)) { def.vs.encore = { mv: def.vs.lastMv, t: 3 }; say(ev, `${def.name}はアンコールを受けた！`); } else say(ev, "しかしうまく決まらなかった！"); break;
      case "disable": if (def.vs.lastMv && !(def.vs.disable?.t > 0)) { def.vs.disable = { mv: def.vs.lastMv, t: 4 }; say(ev, `${def.name}の${def.vs.lastMv.name}を封じ込めた！`); } else say(ev, "しかしうまく決まらなかった！"); break;
      case "taunt": if (def.vs.taunt > 0) say(ev, "しかしうまく決まらなかった！"); else { def.vs.taunt = 3; say(ev, `${def.name}はちょうはつに乗ってしまった！`); } break;
      case "torment": if (def.vs.torment) say(ev, "しかしうまく決まらなかった！"); else { def.vs.torment = true; say(ev, `${def.name}はいちゃもんをつけられた！`); } break;
      case "trap": if (def.vs.trapped) say(ev, "しかしうまく決まらなかった！"); else { def.vs.trapped = true; fx(ev, "trap", D, "trap", `${def.name}はもう逃げられない！`); } break;
      case "partial_trap": if (dmgTotal > 0 && !(def.vs.pt > 0) && def.hp > 0) { def.vs.pt = rnd(4, 5); def.vs.trapped = true; fx(ev, "trap", D, mv.type, `${def.name}はしめつけられた！`); } break;
      case "force_switch": {
        if (def.hp <= 0) break;
        if (D === "e" && S.kind === "wild") { S.over = { result: "run", kind: "wild" }; say(ev, `${def.name}は吹き飛ばされた！`); }
        else say(ev, "しかしうまく決まらなかった！"); break;
      }
      case "transform_state": {
        const nt = x.type; if (!nt) break;
        if (x.mode === "type_set") b.types = [nt]; else if (x.mode === "type_add" && !b.types.includes(nt)) b.types = [...b.types, nt].slice(0, 2);
        say(ev, `${b.name}のタイプが変わった！`); break;
      }
      case "swap_state": {
        if (x.mode === "swap_stages") { const t = { ...att.st }; Object.assign(att.st, def.st); Object.assign(def.st, t); say(ev, "お互いの能力変化が入れ替わった！"); }
        else if (x.mode === "copy_stages") { Object.assign(att.st, def.st); say(ev, `${att.name}は相手の能力変化をコピーした！`); }
        else say(ev, "しかしうまく決まらなかった！"); break;
      }
      case "volatile_state": {
        const k = x.state_key; if (!k) break; const turns = r.value || x.turns || 0, msg = bold(x.message).replace("{target}", b.name).replace("{attacker}", att.name);
        if (k === "safeguard_turn") { if (myS.safeguard > 0) { say(ev, "しかしうまく決まらなかった！"); break; } myS.safeguard = 5; fx(ev, "wall", A, "safeguard", `${sideJa(A)}の場がしんぴのベールに包まれた！`); break; }
        if (k === "endure_turn") { if (att.vs.pn > 0 && Math.random() > Math.pow(1 / 3, att.vs.pn)) { att.vs.pn = 0; say(ev, "しかしうまく決まらなかった！"); break; } att.vs.endure = true; att.vs.pn = (att.vs.pn || 0) + 1; fx(ev, "buff", A, "endure", msg); break; }
        if (k === "yawn_turn") { if (b.status || b.vs.yawn > 0) { say(ev, "しかしうまく決まらなかった！"); break; } b.vs.yawn = 2; say(ev, msg); break; }
        if (k === "ingrain") { b.vs.ingrain = true; fx(ev, "buff", s, "ring", msg); break; }
        if (k === "magnet_rise_turn") { b.vs.magnet = 5; fx(ev, "buff", s, "float", msg); break; }
        b.vs[k] = turns || true; say(ev, msg || `${b.name}に特殊な効果がかかった！`); break;
      }
      case "custom_move": {
        const m = x.mode, ST = (u, k, d) => { u.st[k] = Math.max(-6, Math.min(6, u.st[k] + d)); };
        const up = (u, s2, ks, d, msg) => { for (const k of ks) ST(u, k, d); fx(ev, "buff", s2, "up", msg); };
        switch (m) {
          case "belly-drum": { const c = Math.floor(att.maxHp / 2); if (att.hp <= c) { say(ev, "HPが足りず、はらだいこに失敗した！"); break; } att.hp -= c; ev.push({ t: "dmg", side: A, amount: 0, hp: att.hp, maxHp: att.maxHp, recoil: true }); att.st.atk = 6; ev.push({ t: "stage", side: A, stat: "atk", delta: 6, msg: `${att.name}はHPを削ってこうげきを最大まで上げた！` }); break; }
          case "pain-split": { const avg = Math.floor((att.hp + def.hp) / 2); const da = Math.min(att.maxHp, avg) - att.hp, dd = Math.min(def.maxHp, avg) - def.hp; att.hp += da; def.hp += dd;
            ev.push({ t: "heal", side: A, amount: Math.max(0, da), hp: att.hp, maxHp: att.maxHp, msg: "お互いのHPを分け合った！" }); ev.push({ t: "heal", side: D, amount: Math.max(0, dd), hp: def.hp, maxHp: def.maxHp }); break; }
          case "victory-dance": up(att, A, ["atk", "def", "speed"], 1, `${att.name}は勝利の舞でこうげき・ぼうぎょ・すばやさが上がった！`); break;
          case "shelter": up(att, A, ["def"], 2, `${att.name}のぼうぎょがぐーんと上がった！`); break;
          case "dragon-cheer": att.vs.focus = true; fx(ev, "buff", A, "focus", `${att.name}は鼓舞されて急所に当たりやすくなった！`); break;
          case "acupressure": { const k = STAT_KEYS[rnd(0, 6)]; ST(att, k, 2); ev.push({ t: "stage", side: A, stat: k, delta: 2, msg: `${att.name}の${STAT_JA[k]}がぐーんと上がった！` }); break; }
          case "take-heart": att.status = null; up(att, A, ["spatk", "spdef"], 1, `${att.name}は状態異常を治し、とくこう・とくぼうが上がった！`); ev.push({ t: "status", side: A, status: null, msg: "" }); break;
          case "heal-bell": case "aromatherapy": case "refresh": { if (!att.status) { say(ev, "しかしうまく決まらなかった！"); break; } att.status = null; ev.push({ t: "status", side: A, status: null, msg: `${att.name}の状態異常が治った！` }); fx(ev, "cure", A, "cure"); break; }
          case "purify": { if (!def.status) { say(ev, "しかしうまく決まらなかった！"); break; } def.status = null; ev.push({ t: "status", side: D, status: null, msg: `${def.name}の状態異常を治した！` }); healPct(att, A, 50, ev); break; }
          case "psycho-shift": { if (!att.status || def.status) { say(ev, "しかしうまく決まらなかった！"); break; } def.status = att.status; att.status = null; ev.push({ t: "status", side: A, status: null, msg: "" }); ev.push({ t: "status", side: D, status: def.status, msg: `${def.name}に状態異常を移した！` }); break; }
          case "swallow": healPct(att, A, 50, ev); break;
          case "teatime": healPct(att, A, 25, ev); break;
          case "reflect-type": att.types = [...def.types]; say(ev, `${att.name}は相手と同じタイプになった！`); break;
          case "transform": { att.types = [...def.types]; for (const k of ["atk", "def", "spatk", "spdef", "speed"]) att[k] = def[k]; Object.assign(att.st, def.st); say(ev, `${att.name}は${def.name}に変身した！`); break; }
          case "power-trick": [att.atk, att.def] = [att.def, att.atk]; say(ev, `${att.name}はこうげきとぼうぎょを入れ替えた！`); break;
          case "speed-swap": [att.speed, def.speed] = [def.speed, att.speed]; say(ev, "お互いのすばやさを入れ替えた！"); break;
          case "power-swap": for (const k of ["atk", "spatk"]) [att.st[k], def.st[k]] = [def.st[k], att.st[k]]; say(ev, "お互いの攻撃系の能力変化を入れ替えた！"); break;
          case "guard-swap": for (const k of ["def", "spdef"]) [att.st[k], def.st[k]] = [def.st[k], att.st[k]]; say(ev, "お互いの防御系の能力変化を入れ替えた！"); break;
          case "topsy-turvy": for (const k of STAT_KEYS) def.st[k] = -def.st[k]; say(ev, `${def.name}の能力変化が逆転した！`); break;
          case "power-split": { const a = Math.floor((att.atk + def.atk) / 2), sa = Math.floor((att.spatk + def.spatk) / 2); att.atk = def.atk = a; att.spatk = def.spatk = sa; say(ev, "お互いの攻撃力を平均化した！"); break; }
          case "guard-split": { const a = Math.floor((att.def + def.def) / 2), sa = Math.floor((att.spdef + def.spdef) / 2); att.def = def.def = a; att.spdef = def.spdef = sa; say(ev, "お互いの防御力を平均化した！"); break; }
          case "tailwind": if (myS.tailwind > 0) say(ev, "しかしうまく決まらなかった！"); else { myS.tailwind = 4; fx(ev, "wall", A, "tailwind", `${sideJa(A)}の後ろから追い風が吹き始めた！`); } break;
          case "lucky-chant": myS.lucky = 5; say(ev, `${sideJa(A)}の場は急所に当たらない守りに包まれた！`); break;
          case "laser-focus": att.vs.focus = true; say(ev, `${att.name}は精神を研ぎ澄ませた！`); break;
          case "wish": att.vs.wish = 2; say(ev, `${att.name}は願いをかけた！`); break;
          case "perish-song": for (const u of [att, def]) if (!(u.vs.perish > 0)) u.vs.perish = 4; fx(ev, "haze", A, "perish", "ほろびのうたが響き渡った！"); break;
          case "nightmare": if (def.status === "sleep" && !def.vs.nightmare) { def.vs.nightmare = true; say(ev, `${def.name}は悪夢を見始めた！`); } else say(ev, "しかしうまく決まらなかった！"); break;
          case "curse": {
            if (att.types.includes("ghost")) { if (def.vs.cursed) { say(ev, "しかしうまく決まらなかった！"); break; } chip(att, A, Math.floor(att.maxHp / 2), ev, `${att.name}は自分のHPを削って${def.name}をのろった！`); def.vs.cursed = true; }
            else { ST(att, "speed", -1); ST(att, "atk", 1); ST(att, "def", 1); up(att, A, [], 0, `${att.name}のこうげき・ぼうぎょが上がり、すばやさが下がった！`); }
            break;
          }
          case "attract": if (def.gender && att.gender && def.gender !== att.gender && def.gender !== "genderless" && att.gender !== "genderless" && !def.vs.attract) { def.vs.attract = true; say(ev, `${def.name}はメロメロになった！`); } else say(ev, "しかしうまく決まらなかった！"); break;
          case "metronome": { const m2 = picker && picker(); if (!m2) { say(ev, "しかし何も起こらなかった！"); break; } say(ev, `${m2.name}が選ばれた！`); useMove(att, def, { ...m2, pp: 1 }, side, ev, S); break; }
          case "burning-bulwark": {
            if (att.vs.pn > 0 && Math.random() > Math.pow(1 / 3, att.vs.pn)) { att.vs.pn = 0; say(ev, "しかしうまく決まらなかった！"); break; }
            att.vs.protect = true; att.vs.pn = (att.vs.pn || 0) + 1; fx(ev, "protect", A, "up", `${att.name}は攻撃から身を守る体勢に入った！`); break;
          }
          case "chilly-reception": {
            if (f.weather !== "snow") { f.weather = "snow"; f.wt = 5; fx(ev, "weather", A, "snow", WEATHER_MSG.snow); }
            if (A === "p" || S.pvp) { if (A === "p") S.selfSwitch = true; if (S.pvp) (S.pivot ||= {})[A] = true; say(ev, `${att.name}は交代の準備に入った！`); } break;
          }
          case "court-change": { [S.sd.p, S.sd.e] = [S.sd.e, S.sd.p]; say(ev, "お互いの場の効果を入れ替えた！"); break; }
          case "gastro-acid": if (!def.ability || def.vs.gastro) { say(ev, "しかしうまく決まらなかった！"); break; } def.vs.gastro = true; say(ev, `${def.name}の特性の効果が消えた！`); break;
          case "simple-beam": setAb(def, "simple", "たんじゅん"); say(ev, `${def.name}の特性が「たんじゅん」になった！`); break;
          case "worry-seed": setAb(def, "insomnia", "ふみん"); say(ev, `${def.name}の特性が「ふみん」になった！`); break;
          case "entrainment": if (!att.ability) { say(ev, "しかしうまく決まらなかった！"); break; } setAb(def, att.ability, att.abilityJa); say(ev, `${def.name}は${att.name}と同じ特性になった！`); break;
          case "role-play": if (!def.ability) { say(ev, "しかしうまく決まらなかった！"); break; } setAb(att, def.ability, def.abilityJa); say(ev, `${att.name}は相手の特性をまねた！`); break;
          case "destiny-bond": att.vs.bond = true; say(ev, `${att.name}は相手を道連れにしようとしている！`); break;
          default: say(ev, "しかし何も起こらなかった！");
        }
        break;
      }
    }
   } catch (error) {
    errorReporter?.(error, { move: mv.name, moveId: mv.id, effect: r.effect_type, side: A });
    say(ev, `${mv.name}の追加効果は発動しなかった。`);
   }
  }
  if (stat && ev.length === n0) say(ev, "しかし何も起こらなかった！");
  if (PIVOT.has(mv.en) && (A === "p" || S.pvp) && att.hp > 0 && (stat || dmgTotal > 0 || subbed)) { if (A === "p") S.selfSwitch = true; if (S.pvp) (S.pivot ||= {})[A] = true; }   // とんぼがえり等：技の後に自分が交代
}

// 動けるか（状態異常・ひるみ・反動・こんらん・メロメロ）
function canAct(b, side, ev) {
  if (b.flinch) { b.flinch = false; say(ev, `${b.name}はひるんで動けない！`); return false; }
  if (b.recharge) { b.recharge = false; say(ev, `${b.name}は反動で動けない！`); return false; }
  if (b.status === "sleep") { if (--b.sleep > 0) { ev.push({ t: "text", msg: `${b.name}はぐうぐう眠っている……`, status: "sleep", side }); return false; } b.status = null; b.vs.nightmare = false; ev.push({ t: "status", side, status: null, msg: `${b.name}は目を覚ました！` }); }
  if (b.status === "freeze") { if (roll(20)) { b.status = null; ev.push({ t: "status", side, status: null, msg: `${b.name}のこおりがとけた！` }); } else { say(ev, `${b.name}はこおってしまって動けない！`); return false; } }
  if (b.status === "paralysis" && roll(25)) { say(ev, `${b.name}はまひして動けない！`); return false; }
  if (b.vs.conf > 0) {
    if (--b.vs.conf <= 0) { b.vs.conf = 0; ev.push({ t: "status", side, status: null, vol: true, msg: `${b.name}のこんらんがとけた！` }); }
    else { say(ev, `${b.name}はこんらんしている！`);
      if (roll(33)) { const d = Math.min(b.hp, SELF_HIT(b)); b.hp -= d; ev.push({ t: "dmg", side, amount: d, hp: b.hp, maxHp: b.maxHp, recoil: true, msg: "わけもわからず自分を攻撃した！" }); return false; } }
  }
  if (b.vs.attract && roll(50)) { say(ev, `${b.name}はメロメロで技が出せない！`); return false; }
  return true;
}
function endTurn(b, s, ev, S, o) {
  if (b.hp <= 0) return;
  const f = fldOf(S), v = b.vs, ok = () => b.hp > 0;
  let d = 0;
  const psnHeal = (b.status === "poison" || b.status === "bad-poison") && abOf(b) === "poison-heal";
  if (psnHeal && b.hp < b.maxHp) healAbs(b, s, Math.floor(b.maxHp / 8), ev, `${b.name}は${abName(b)}で回復した！`);
  if (!psnHeal && (b.status === "burn" || b.status === "poison")) d = Math.max(1, Math.floor(b.maxHp / 8));
  if (!psnHeal && b.status === "bad-poison") d = Math.max(1, Math.floor(b.maxHp * Math.min(++b.toxic, 15) / 16));
  if (d) chip(b, s, d, ev, `${b.name}は${STATUS_JA[b.status]}のダメージを受けた！`, { status: b.status });
  if (ok() && f.weather === "sandstorm" && !b.types.some(t => ["rock", "ground", "steel"].includes(t)) && !["overcoat", "magic-guard"].includes(abOf(b))) chip(b, s, Math.floor(b.maxHp / 16), ev, `${b.name}は砂あらしに襲われた！`, { weather: "sandstorm" });
  if (ok() && v.seed) { const x = chip(b, s, Math.floor(b.maxHp / 8), ev, `${b.name}はやどりぎに体力を奪われた！`, { seed: 1 }); if (o && o.hp > 0) healAbs(o, D_OF(s), x, ev, `${o.name}は体力を吸い取った！`); }
  if (ok() && v.pt > 0) { chip(b, s, Math.floor(b.maxHp / 8), ev, `${b.name}はしめつけられている！`); if (--v.pt <= 0) { v.trapped = false; if (ok()) say(ev, `${b.name}はしめつけから解放された！`); } }
  if (ok() && v.nightmare && b.status === "sleep") chip(b, s, Math.floor(b.maxHp / 4), ev, `${b.name}は悪夢にうなされている！`);
  if (ok() && v.cursed) chip(b, s, Math.floor(b.maxHp / 4), ev, `${b.name}はのろわれている！`);
  if (ok() && b.hp < b.maxHp && !(v.healBlock > 0)) {
    if (held(b)==='leftovers') healAbs(b,s,Math.floor(b.maxHp/16),ev,`${b.name}はたべのこしで回復した！`);
    if (held(b)==='black-sludge'&&b.types.includes('poison')) healAbs(b,s,Math.floor(b.maxHp/16),ev,`${b.name}はくろいヘドロで回復した！`);
    if (v.ring) healAbs(b, s, Math.floor(b.maxHp / 16), ev, `${b.name}は水のヴェールで回復した！`);
    if (v.ingrain) healAbs(b, s, Math.floor(b.maxHp / 16), ev, `${b.name}は根から養分を吸い取った！`);
    if (f.terrain === "grassy" && !b.types.includes("flying")) healAbs(b, s, Math.floor(b.maxHp / 16), ev, `${b.name}はグラスフィールドで回復した！`);
  }
  if(ok()&&held(b)==='black-sludge'&&!b.types.includes('poison'))chip(b,s,Math.floor(b.maxHp/8),ev,`${b.name}はくろいヘドロで傷ついた！`);
  if(ok()&&!b.status&&held(b)==='flame-orb')inflict(S,b,s,'burn',ev,true);
  if(ok()&&!b.status&&held(b)==='toxic-orb')inflict(S,b,s,'bad-poison',ev,true);
  berryCheck(b,s,ev);
  if (ok()) {   // 特性：ターン終了時
    const a = abOf(b);
    if ((a === "rain-dish" || a === "dry-skin") && f.weather === "rain" && b.hp < b.maxHp) healAbs(b, s, Math.floor(b.maxHp / (a === "dry-skin" ? 8 : 16)), ev, `${b.name}は${abName(b)}で回復した！`);
    if (a === "shed-skin" && b.status && roll(30)) { b.status = null; ev.push({ t: "status", side: s, status: null, msg: `${b.name}の${abName(b)}で状態異常が治った！` }); }
    if (a === "speed-boost" && b.st.speed < 6) { b.st.speed++; ev.push({ t: "stage", side: s, stat: "speed", delta: 1, msg: `${b.name}の${abName(b)}！すばやさが上がった！` }); }
  }
  if (ok() && v.wish > 0 && --v.wish === 0) healAbs(b, s, Math.floor(b.maxHp / 2), ev, `${b.name}の願いが叶った！`);
  if (ok() && v.yawn > 0 && --v.yawn === 0) inflict(S, b, s, "sleep", ev, false);
  if (ok() && v.perish > 0) { v.perish--; say(ev, `${b.name}のほろびのカウントが${v.perish}になった！`); if (v.perish === 0) { const x = b.hp; b.hp = 0; ev.push({ t: "dmg", side: s, amount: x, hp: 0, maxHp: b.maxHp, recoil: true }); } }
  if(ok()&&v.future&&--v.future.turns<=0){const z=Math.min(b.hp,v.future.damage);b.hp-=z;ev.push({t:'dmg',side:s,amount:z,hp:b.hp,maxHp:b.maxHp,msg:`未来に予知された${v.future.name}の攻撃！`});delete v.future}
  // 一時状態のカウントダウン
  v.protect = false; v.endure = false; v.focus = v.focus && v.focusKeep ? true : v.focus;
  if (v.taunt > 0 && --v.taunt === 0) say(ev, `${b.name}のちょうはつがとけた！`);
  if (v.encore?.t > 0 && --v.encore.t === 0) say(ev, `${b.name}のアンコールがとけた！`);
  if (v.disable?.t > 0 && --v.disable.t === 0) say(ev, `${b.name}のかなしばりがとけた！`);
  if (v.healBlock > 0 && --v.healBlock === 0) say(ev, `${b.name}は回復できるようになった！`);
  if (v.magnet > 0 && --v.magnet === 0) say(ev, `${b.name}の電磁浮遊がとけた！`);
  if (v.embargo > 0 && --v.embargo === 0) say(ev, `${b.name}は道具を使えるようになった！`);
}
// 場・陣営の持続ターンを1つ進める
function tickField(S, ev) {
  const f = fldOf(S);
  if (f.weather && --f.wt <= 0) { fx(ev, "weatherEnd", "p", f.weather, WEATHER_END[f.weather]); f.weather = null; }
  if (f.terrain && --f.tt <= 0) { say(ev, "足下の不思議な感じが消えた！"); f.terrain = null; }
  for (const k of ["trick_room", "gravity", "wonder_room", "magic_room"]) if (f[k] > 0 && --f[k] === 0) say(ev, k === "trick_room" ? "ゆがんだ空間がもとに戻った！" : "場の不思議な効果が消えた！");
  for (const s of ["p", "e"]) { const sd = sdOf(S, s); for (const k of Object.keys(WALL_JA)) if (sd[k] > 0 && --sd[k] === 0) say(ev, `${sideJa(s)}の${WALL_JA[k]}の効果が切れた！`); }
}
function aiPick(e, p, S) {
  const ok = e.moves.filter(m => m.pp > 0 && !moveBlock(e, m)); if (!ok.length) return null;
  const f = fldOf(S), hpr = e.hp / e.maxHp, myS = sdOf(S, "e");
  const score = m => {
    const rs = m.rules || [], has = t => rs.some(r => r.effect_type === t);
    let s;
    if (m.power > 0 || has("fixed_damage") || has("ohko")) s = (m.power > 0 ? m.power : 60) * eff(m.type, p.types[0], p.types[1]) * (e.types.includes(m.type) ? 1.5 : 1) * ((m.accuracy ?? 100) / 100);
    else {
      s = 15;
      if (rs.some(r => r.effect_type === "heal" || (r.effect_type === "hp_change" && jx(r).mode === "heal") || r.effect_type === "rest")) s = hpr < .5 ? 130 : hpr < .75 ? 35 : 2;
      if (rs.some(r => r.effect_type === "status") && !p.status) s = 55;
      if (rs.some(r => r.effect_type === "stat_stage" && r.target_side === "self" && r.value > 0) && e.st.atk < 2 && e.st.spatk < 2) s = 45;
      if (has("weather") && !f.weather) s = 40; if (has("wall") && !(myS.reflect > 0 || myS.light_screen > 0)) s = 40;
      if (has("protect") && e.vs.pn > 0) s = 1;
    }
    return s * (0.6 + Math.random() * .8);
  };
  return ok.map(m => [score(m), m]).sort((a, b) => b[0] - a[0])[0][1];
}
const prio = m => m.priority || 0;
const spdOf = (S, s, b) => { let v = effSpeed(b); if (sdOf(S, s).tailwind > 0) v *= 2; const a = abOf(b), w = fldOf(S).weather; if ((a === "chlorophyll" && w === "sunny") || (a === "swift-swim" && w === "rain")) v *= 2; return v; };

// プレイヤーの行動を1ターン進める。S = {party:[battler], active:int, enemy:battler}
// act = {type:'move', idx} | {type:'switch', idx}
function playTurn(S, act) {
  const ev = [], p = () => S.party[S.active], e = S.enemy; fldOf(S); sdOf(S, "p");
  if (act.type === "switch") {
    const old = p(); leave(S, "p", old, ev);
    ev.push({ t: "switchOut", side: "p" }); S.active = act.idx; p().fought = true;
    ev.push({ t: "switchIn", side: "p", mon: pub(p()), moves: p().moves.map(mPub), msg: `ゆけっ！${p().name}！` });
    enter(S, p(), "p", ev);
  }
  const eMove = e.vs.chargingMove || aiPick(e, p(), S);
  const STRUGGLE = { name: "わるあがき", type: "normal", power: 40, accuracy: null, pp: 1, cls: "physical", rules: [{ effect_type: "recoil", value: 25, chance: 100, target_side: "self", extra_json: '{"phase":"after_damage"}' }] };
  let pMove = p().vs.chargingMove || (act.type === "move" ? p().moves[act.idx] ?? STRUGGLE : null);
  if (pMove) {
    const enc = p().vs.encore; if (enc?.t > 0 && enc.mv && enc.mv.pp > 0 && enc.mv !== pMove) { say(ev, `${p().name}はアンコールで${enc.mv.name}しか出せない！`); pMove = enc.mv; }
    const blk = moveBlock(p(), pMove); if (blk) { say(ev, blk); pMove = null; }
  }
  const order = [];
  if (pMove) order.push(["p", pMove]);
  let em = eMove || STRUGGLE; { const enc = e.vs.encore; if (enc?.t > 0 && enc.mv && enc.mv.pp > 0) em = enc.mv; }
  order.push(["e", em]);
  const tr = fldOf(S).trick_room > 0 ? -1 : 1;
  order.sort((a, b) => (prio(b[1]) - prio(a[1])) || tr * (spdOf(S, b[0], b[0] === "p" ? p() : e) - spdOf(S, a[0], a[0] === "p" ? p() : e)) || (Math.random() - .5));
  const moved = new Set();
  for (const [side, mv] of order) {
    const att = side === "p" ? p() : e, def = side === "p" ? e : p();
    if (att.hp <= 0) continue;
    if (S.over) break;
    S.foeMv = side === "p" ? em : pMove; S.foeActed = moved.has(D_OF(side));   // ふいうち判定用
    if (canAct(att, side, ev)) useMove(att, def, mv, side, ev, S);
    moved.add(side);
    for (const [b, s] of [[att, side], [def, D_OF(side)]]) {
      if (b.hp <= 0 && !ev.some(x => x.t === "faint" && x.side === s)) ev.push({ t: "faint", side: s, msg: `${b.name}はたおれた！` });
    }
    // みちづれ
    for (const [b, s] of [[att, side], [def, D_OF(side)]]) if (b.hp <= 0 && b.vs.bond) { const o = b === att ? def : att, so = D_OF(s); if (o.hp > 0) { const x = o.hp; o.hp = 0; ev.push({ t: "dmg", side: so, amount: x, hp: 0, maxHp: o.maxHp, recoil: true, msg: `${o.name}は道連れにされた！` }); ev.push({ t: "faint", side: so, msg: `${o.name}はたおれた！` }); } }
    if (e.hp <= 0 || p().hp <= 0) break;
  }
  if (e.hp > 0 && p().hp > 0 && !S.over) {
    for (const [b, s, o] of [[p(), "p", e], [e, "e", p()]]) {
      const was = b.hp; endTurn(b, s, ev, S, o);
      if (was > 0 && b.hp <= 0) ev.push({ t: "faint", side: s, msg: `${b.name}はたおれた！` });
      if (o.hp <= 0 && !ev.some(x => x.t === "faint" && x.side === D_OF(s))) ev.push({ t: "faint", side: D_OF(s), msg: `${o.name}はたおれた！` });
    }
    tickField(S, ev);
  }
  S.foeMv = null; S.foeActed = false;
  if (act.type === "move" && p().hp > 0) p().acted = true; if (e.hp > 0) e.acted = true;   // ねこだまし：場に出て最初のターンだけ
  return ev;
}

// ================= 2人対戦（フレンドバトル） =================
// S = { party, active, eparty, ei, enemy, names:{p,e}, kind:"friend", pvp:true }。p＝挑戦者(A)、e＝相手(B)。どちらも人間。
// 出来事(events)は p 視点で作る。B側に見せる時は flipEvents() で左右を入れ替える。
const STRUGGLE_PVP = { name: "わるあがき", type: "normal", power: 40, accuracy: null, pp: 1, cls: "physical", rules: [{ effect_type: "recoil", value: 25, chance: 100, target_side: "self", extra_json: '{"phase":"after_damage"}' }] };
const monOf = (S, s) => (s === "p" ? S.party[S.active] : S.eparty[S.ei]);
const syncEnemy = S => { S.enemy = S.eparty[S.ei]; };
function pvpInit(S) { S.pvp = true; S.kind = "friend"; syncEnemy(S); fldOf(S); sdOf(S, "p"); sdOf(S, "e"); S._down ||= new Set(); }
function pvpStart(S) {
  pvpInit(S); const ev = [];
  say(ev, `${S.names.p}が勝負を仕掛けてきた！`);
  say(ev, `${S.names.p}は${S.party[S.active].name}を繰り出した！`); say(ev, `${S.names.e}は${S.eparty[S.ei].name}を繰り出した！`);
  S.party[S.active].fought = true; S.eparty[S.ei].fought = true;
  battleStart(S, ev); markDown(S, ev); return ev;
}
// ひんしの通知は1匹につき1回だけ出す
function markDown(S, ev) {
  for (const s of ["p", "e"]) { const b = monOf(S, s); if (b.hp <= 0 && !S._down.has(b)) { S._down.add(b); ev.push({ t: "faint", side: s, msg: `${b.name}はたおれた！` }); } }
}
function pvpSwitch(S, s, idx, ev, voluntary) {
  const old = monOf(S, s);
  if (old.hp > 0) { leave(S, s, old, ev); ev.push({ t: "switchOut", side: s }); }
  if (s === "p") S.active = idx; else S.ei = idx; syncEnemy(S);
  const nb = monOf(S, s); nb.fought = true; nb.acted = false;
  ev.push({ t: "switchIn", side: s, mon: pub(nb), moves: nb.moves.map(mPub), vol: !!voluntary, msg: `${S.names[s]}は${nb.name}を繰り出した！` });
  enter(S, nb, s, ev); markDown(S, ev);
}
// ひんし・とんぼがえりの後の入れ替え。sw = {p: idx|undefined, e: idx|undefined}
function pvpReplace(S, sw) {
  pvpInit(S); const ev = [];
  for (const s of ["p", "e"].filter(s => sw[s] != null).sort((x, y) => spdOf(S, y, monOf(S, y)) - spdOf(S, x, monOf(S, x)) || Math.random() - .5)) pvpSwitch(S, s, sw[s], ev, monOf(S, s).hp > 0);
  return ev;
}
// 1ターン。acts = {p:{type:'move'|'switch', idx}, e:{...}}
function pvpTurn(S, acts) {
  pvpInit(S); const ev = [], M = s => monOf(S, s), spd = s => spdOf(S, s, M(s)); S.selfSwitch = false; S.pivot = {};
  for (const s of ["p", "e"].filter(s => acts[s].type === "switch").sort((x, y) => spd(y) - spd(x) || Math.random() - .5)) pvpSwitch(S, s, acts[s].idx, ev, true);
  const mv = {};
  for (const s of ["p", "e"]) {
    if ((acts[s].type !== "move" && !M(s).vs.chargingMove) || M(s).hp <= 0) continue;
    const b = M(s); let m = b.vs.chargingMove || (b.moves[acts[s].idx] ?? STRUGGLE_PVP);
    const enc = b.vs.encore; if (enc?.t > 0 && enc.mv && enc.mv.pp > 0 && enc.mv !== m) { say(ev, `${b.name}はアンコールで${enc.mv.name}しか出せない！`); m = enc.mv; }
    const blk = moveBlock(b, m); if (blk) { say(ev, blk); m = null; }
    if (m) mv[s] = m;
  }
  const order = Object.entries(mv), tr = fldOf(S).trick_room > 0 ? -1 : 1;
  order.sort((a, b) => (prio(b[1]) - prio(a[1])) || tr * (spd(b[0]) - spd(a[0])) || (Math.random() - .5));
  const moved = new Set();
  for (const [side, m] of order) {
    const att = M(side), def = M(D_OF(side));
    if (att.hp <= 0 || def.hp <= 0) continue;
    S.foeMv = mv[D_OF(side)] || null; S.foeActed = moved.has(D_OF(side));
    if (canAct(att, side, ev)) useMove(att, def, m, side, ev, S);
    moved.add(side); markDown(S, ev);
    for (const [b, s] of [[att, side], [def, D_OF(side)]]) if (b.hp <= 0 && b.vs.bond) { const o = b === att ? def : att, so = D_OF(s); if (o.hp > 0) { const x = o.hp; o.hp = 0; ev.push({ t: "dmg", side: so, amount: x, hp: 0, maxHp: o.maxHp, recoil: true, msg: `${o.name}は道連れにされた！` }); } }
    markDown(S, ev);
    if (M("p").hp <= 0 || M("e").hp <= 0) break;
  }
  if (M("p").hp > 0 && M("e").hp > 0) {
    for (const s of ["p", "e"].sort((x, y) => spd(y) - spd(x) || Math.random() - .5)) { if (M(s).hp > 0 && M(D_OF(s)).hp > 0) endTurn(M(s), s, ev, S, M(D_OF(s))); markDown(S, ev); }
    tickField(S, ev);
  }
  S.foeMv = null; S.foeActed = false;
  for (const s of ["p", "e"]) if (mv[s] && M(s).hp > 0) M(s).acted = true;
  return ev;
}
// B側に見せるために、左右（p/e）と「味方/相手」の文言を入れ替える。相手の手の内（技一覧）は渡さない
const swapJa = t => typeof t === "string" ? t.replace(/味方/g, "\u0000").replace(/相手/g, "味方").replace(/\u0000/g, "相手") : t;
function pvpView(events, who) {
  const flip = who === "e";
  return events.map(x => {
    const y = { ...x };
    if (flip) { if (y.side === "p") y.side = "e"; else if (y.side === "e") y.side = "p"; if (y.msg) y.msg = swapJa(y.msg); }
    if (y.t === "switchIn") {
      if (y.side === "e") { y.t = "enemyIn"; y.sw = y.vol; delete y.moves; }
      delete y.vol;
    }
    return y;
  });
}
// 技の効果の短い説明（UIのホバー表示用）
function fxList(m) {
  const out = [], seen = new Set();
  const add = s => { if (s && !seen.has(s) && out.length < 5) { seen.add(s); out.push(s); } };
  for (const r of m.rules || []) {
    const x = jx(r), ch = r.chance != null && r.chance < 100 ? `(${r.chance}%)` : "", who = r.target_side === "self" ? "自分の" : "相手の";
    switch (r.effect_type) {
      case "stat_stage": add(`${who}${STAT_JA[r.stat_key] || ""}${r.value > 0 ? "+" : ""}${r.value}${ch}`); break;
      case "status": add(`${STATUS_JA[r.status_key] || r.status_key}にする${ch}`); break;
      case "heal": add(`HPを${r.value || 50}%回復`); break;
      case "hp_change": add(x.mode === "heal" ? `HPを${r.value || 50}%回復` : x.mode === "damage" ? "HPを削る" : "HPを1にする"); break;
      case "rest": add("眠ってHP全回復"); break;
      case "drain": add(`与えた分の${r.value}%を回復`); break;
      case "recoil": add(`反動で${r.value}%ダメージ`); break;
      case "recharge": add("次のターンは動けない"); break;
      case "flinch": add(`ひるませる${ch}`); break;
      case "multi_hit": add("連続攻撃"); break; case "ohko": add("一撃必殺"); break; case "fixed_damage": add("固定ダメージ"); break;
      case "protect": add("攻撃を防ぐ"); break; case "substitute": add("HP1/4で身代わり"); break; case "seed": add("毎ターン体力を奪う"); break;
      case "weather": add({ rain: "天気：あめ", sunny: "天気：にほんばれ", sandstorm: "天気：すなあらし", snow: "天気：ゆき" }[r.weather_key] || "天気を変える"); break;
      case "terrain": add("フィールドを変える"); break; case "wall": add(`${WALL_JA[x.wall_key] || "壁"}を張る`); break;
      case "entry_hazard": add(`${HAZ_JA[x.hazard_key] || "罠"}を撒く`); break; case "trap": case "partial_trap": add("逃げられなくする"); break;
      case "taunt": add("変化技を封じる"); break; case "encore": add("同じ技を使わせる"); break; case "disable": add("直前の技を封じる"); break;
      case "clear_stages": add("能力変化をリセット"); break; case "focus_energy": add("急所に当たりやすくなる"); break;
      case "force_switch": add("相手を吹き飛ばす"); break; case "room": add("すばやさ逆転"); break;
      case "custom_move": add(({ "belly-drum": "HP半分でこうげき最大", "pain-split": "HPを分け合う", "heal-bell": "状態異常を治す", aromatherapy: "状態異常を治す", metronome: "ランダムな技を出す", wish: "次のターンに回復", "perish-song": "3ターン後にひんし", curse: "のろい", "victory-dance": "攻防速+1" })[x.mode] || "特殊な効果"); break;
    }
  }
  return out;
}
const mPub = m => ({ id: m.id, name: m.name, type: m.type, typeJa: TYPE_JA[m.type] || m.type, power: m.power, pp: m.pp, maxpp: m.maxpp, cls: m.cls, accuracy: m.accuracy, fx: fxList(m) });
module.exports = { pvpStart, pvpTurn, pvpReplace, pvpView, monOf, TYPE_JA, calcStats, expFor, rewardExp, captureChance, pickGender, makeBattler, pub, mPub, playTurn, rnd, eff, BALL, enter, setPicker, setErrorReporter, fldOf, sdOf, leave, battleStart };

// レイド用。既存の1対1 APIは変更しない。
module.exports.raidInternals = { useMove, canAct, endTurn, tickField, spdOf, prio, moveBlock };
