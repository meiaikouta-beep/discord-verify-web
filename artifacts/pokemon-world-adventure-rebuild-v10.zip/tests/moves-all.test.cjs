'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../connect-party/pokemon/engine.cjs');
const rows=require('./move-rules-fixture.json');
const offensive=new Set(['fixed_damage','ohko','multi_hit','recoil','drain','partial_trap']);
function mon(name,moves,speed){return E.makeBattler({name,key:name,type1:'normal',level:50,hp:1000,maxHp:1000,attack:100,defense:100,sp_attack:100,sp_defense:100,speed,moves,img:null,gender:name==='player'?'male':'female'});}
test('pokemon3.py由来の全汎用・固有技定義を通常戦で安全に処理する',()=>{
 for(const r of rows){
  const extra=r.extra||{},rule={effect_type:r.type,target_side:r.target,chance:100,value:r.value,extra_json:JSON.stringify(extra),stat_key:extra.stat_key||'atk',status_key:extra.status_key||'burn',weather_key:extra.weather_key,terrain_key:extra.terrain_key};
  const attack=offensive.has(r.type),move={id:1,name:r.name,en:r.name,type:'normal',power:attack?40:0,accuracy:null,pp:10,maxpp:10,cls:attack?'physical':'status',priority:0,rules:[rule]};
  const tackle={id:2,name:'たいあたり',en:'tackle',type:'normal',power:1,accuracy:null,pp:10,maxpp:10,cls:'physical',priority:0,rules:[]};
  const p=mon('player',[move],200),e=mon('enemy',[tackle],50),S={party:[p],active:0,enemy:e,kind:'trainer'};
  assert.doesNotThrow(()=>{for(let i=0;i<3&&p.hp>0&&e.hp>0;i++)E.playTurn(S,{type:'move',idx:0});JSON.stringify(S)},`${r.name} / ${r.type}`);
 }
 assert.equal(rows.length,198);
});
test('壊れた個別追加効果があってもHTTP 500相当の例外にせずターンを完了する',()=>{
 let reported=0;E.setErrorReporter(()=>reported++);
 try{
  const badRule={effect_type:'stat_stage',target_side:'self',chance:100,value:1,extra_json:'{}'};Object.defineProperty(badRule,'stat_key',{get(){throw new Error('simulated corrupt rule')}});
  const broken={id:999,name:'破損データ技',en:'broken-data-move',type:'normal',power:0,accuracy:null,pp:10,maxpp:10,cls:'status',priority:0,rules:[badRule]};
  const tackle={id:2,name:'たいあたり',en:'tackle',type:'normal',power:1,accuracy:null,pp:10,maxpp:10,cls:'physical',priority:0,rules:[]};
  const p=mon('player',[broken],200),e=mon('enemy',[tackle],50),S={party:[p],active:0,enemy:e,kind:'trainer'};
  const ev=E.playTurn(S,{type:'move',idx:0});
  assert.ok(reported>=1);assert.ok(ev.some(x=>x.t==='text'&&/追加効果/.test(x.msg)));assert.equal(broken.pp,9);
 }finally{E.setErrorReporter(null)}
});
