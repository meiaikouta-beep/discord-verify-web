統合後の機能・テスト・配置手順は INTEGRATED-README.md を参照してください。
生成したボールPNG一式はバイナリのため raid-integration.patch には含まれません。完全な配置には install-integrated.py を使用してください。
