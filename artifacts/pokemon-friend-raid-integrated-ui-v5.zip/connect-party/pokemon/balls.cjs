'use strict';

// 捕獲ボールの効果。倍率は第9世代相当を基準に、現在の野生戦で判定できる条件だけを扱う。
const BALLS = {
  'poke-ball':    { name:'モンスターボール', effect:'捕獲率 ×1', bonus:()=>1 },
  'great-ball':   { name:'スーパーボール', effect:'捕獲率 ×1.5', bonus:()=>1.5 },
  'ultra-ball':   { name:'ハイパーボール', effect:'捕獲率 ×2', bonus:()=>2 },
  'master-ball':  { name:'マスターボール', effect:'必ず捕まえる', bonus:()=>999 },
  'premier-ball': { name:'プレミアボール', effect:'捕獲率 ×1', bonus:()=>1 },
  'heal-ball':    { name:'ヒールボール', effect:'捕獲率 ×1／捕獲後は全回復', bonus:()=>1 },
  'net-ball':     { name:'ネットボール', effect:'みず・むしタイプなら ×3.5', bonus:c=>c.types?.some(t=>t==='water'||t==='bug')?3.5:1 },
  'nest-ball':    { name:'ネストボール', effect:'相手のレベルが低いほど最大 ×4', bonus:c=>Math.max(1,Math.min(4,(41-(c.level||1))/10)) },
  'repeat-ball':  { name:'リピートボール', effect:'捕獲済みなら ×3.5', bonus:c=>c.caughtBefore?3.5:1 },
  'timer-ball':   { name:'タイマーボール', effect:'経過ターンで最大 ×4', bonus:c=>Math.min(4,1+.3*Math.max(0,c.turns||0)) },
  'quick-ball':   { name:'クイックボール', effect:'最初のターンなら ×5', bonus:c=>(c.turns||0)===0?5:1 },
  'dusk-ball':    { name:'ダークボール', effect:'夜なら ×3', bonus:c=>c.isNight?3:1 },
  'dream-ball':   { name:'ドリームボール', effect:'相手が眠っていれば ×4', bonus:c=>c.status==='sleep'?4:1 },
  'beast-ball':   { name:'ウルトラボール', effect:'UBなら ×5、それ以外は ×0.1', bonus:c=>c.ultraBeast?5:.1 },
  'fast-ball':    { name:'スピードボール', effect:'相手の素早さ種族値が100以上なら ×4', bonus:c=>(c.baseSpeed||0)>=100?4:1 },
  'level-ball':   { name:'レベルボール', effect:'味方とのレベル差で最大 ×8', bonus:c=>{const p=c.playerLevel||1,e=c.level||1;return p>=e*4?8:p>=e*2?4:p>e?2:1} },
  'love-ball':    { name:'ラブラブボール', effect:'同種で異性なら ×8', bonus:c=>c.sameSpecies&&((c.playerGender==='male'&&c.gender==='female')||(c.playerGender==='female'&&c.gender==='male'))?8:1 },
  'moon-ball':    { name:'ムーンボール', effect:'つきのいしで進化する種類なら ×4', bonus:c=>c.moonStone?4:1 },
  'heavy-ball':   { name:'ヘビーボール', effect:'体重で捕獲率を補正', bonus:()=>1, rate:c=>{const w=c.weight;if(!Number.isFinite(w))return 0;return w<1000?-20:w<2000?0:w<3000?20:30} },
  'safari-ball':  { name:'サファリボール', effect:'捕獲率 ×1.5', bonus:()=>1.5 },
  'sport-ball':   { name:'コンペボール', effect:'捕獲率 ×1.5', bonus:()=>1.5 },
  'luxury-ball':  { name:'ゴージャスボール', effect:'捕獲率 ×1（なつき度効果は保留）', bonus:()=>1, partial:true },
  'friend-ball':  { name:'フレンドボール', effect:'捕獲率 ×1（なつき度効果は保留）', bonus:()=>1, partial:true },
};

const UNSUPPORTED = {
  'dive-ball':'釣り・ダイビングの遭遇種別がまだありません',
  'lure-ball':'釣りの遭遇種別がまだありません',
  'park-ball':'パルパーク専用の捕獲ルールがありません',
  'cherish-ball':'配布専用で、通常の捕獲には使いません',
  'strange-ball':'過去作転送時の表示専用です',
  'origin-ball':'イベント専用で、通常の捕獲には使いません',
};

function profile(key, context={}) {
  const def=BALLS[key]; if(!def)return null;
  return { key,name:def.name,effect:def.effect,partial:!!def.partial,bonus:def.bonus(context),rateAdd:def.rate?def.rate(context):0 };
}
const supported=key=>Object.hasOwn(BALLS,key);
const catalog=()=>Object.entries(BALLS).map(([key,v])=>({key,name:v.name,effect:v.effect,partial:!!v.partial}));
module.exports={BALLS,UNSUPPORTED,profile,supported,catalog,keys:Object.freeze(Object.keys(BALLS))};
