統合後の機能・テスト・配置手順は INTEGRATED-README.md を参照してください。
