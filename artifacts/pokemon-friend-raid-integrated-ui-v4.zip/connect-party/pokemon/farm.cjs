// ============================================================
// ポケモン 牧場・タマゴ（pokemon3.py の牧場まわりをそのまま移植）
//   預ける(最大10体) / 引き取る(蓄積経験値を付与) / 牧場ショップ / 牧場アイテム(同ジャンルは重複不可)
//   孵化待ちタマゴ → 幼体 → 所持ポケモンへ引き取り
//   定期処理：30分ごとに経験値蓄積＋交配、3分ごとに孵化
// server.cjs から create(ctx) で使う。ctx = { all, one, run, tx, awardExp, monImg, E, hasActiveBattle, log }
// ============================================================
const FARM_EXP_INTERVAL_AMOUNT = 500;       // 30分ごとに預けている全員へ（×経験値アイテムの倍率）
const FARM_BREED_CHANCE = 0.05;             // ♂♀の組ごと・30分ごとの確率（×交配アイテムの倍率、最大1）
const FARM_HATCH_SECONDS = 3 * 60 * 60;
const FARM_MAX_DEPOSIT = 10;
const FARM_MAX_EGGS_PER_PAIR = 3;
const FARM_TICK_MS = 30 * 60 * 1000;
const FARM_HATCH_TICK_MS = 3 * 60 * 1000;
const IV_KEYS = ["iv_hp", "iv_attack", "iv_defense", "iv_sp_attack", "iv_sp_defense", "iv_speed"];

function create(ctx) {
  const { all, one, run, tx, awardExp, monImg, E, hasActiveBattle, log } = ctx;
  const now = () => Math.floor(Date.now() / 1000);
  const ids = (g, uid) => [BigInt(g), BigInt(uid)];
  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const moneyOf = (G, U) => one("SELECT money FROM users WHERE guild_id = ? AND user_id = ?", G, U)?.money ?? 0;

  // ---------- 効果倍率（期限切れは消す） ----------
  function effectMultiplier(G, U, genre) {
    run("DELETE FROM user_pokemon_farm_active_effects WHERE expires_at <= ?", now());
    const r = one("SELECT multiplier FROM user_pokemon_farm_active_effects WHERE guild_id=? AND user_id=? AND genre=? AND expires_at > ? LIMIT 1", G, U, genre, now());
    return r ? Number(r.multiplier) : 1.0;
  }

  // ---------- 画面用の一覧 ----------
  function depositRows(G, U) {
    return all(`SELECT f.farm_deposit_id, f.owned_id, f.farm_exp, f.deposited_at, o.level, o.nickname, o.is_starred, o.is_shiny, o.gender,
        p.species_id, p.display_name_ja, p.image_url, p.shiny_image_url
      FROM user_pokemon_farm_deposits f JOIN user_pokemon_owned o ON f.owned_id = o.owned_id JOIN pokemon_master p ON o.pokemon_key = p.pokemon_key
      WHERE f.guild_id = ? AND f.user_id = ? ORDER BY f.deposited_at ASC, f.farm_deposit_id ASC`, G, U).map(r => ({
      ownedId: r.owned_id, name: r.nickname || r.display_name_ja, speciesId: r.species_id, level: r.level, farmExp: r.farm_exp,
      starred: !!r.is_starred, gender: r.gender, depositedAt: r.deposited_at, img: monImg(r, r.is_shiny) }));
  }
  function eggRows(G, U) {
    const t = now();
    return all(`SELECT e.farm_egg_id, e.hatch_at, p.display_name_ja, p.species_id FROM user_pokemon_farm_eggs e JOIN pokemon_master p ON e.pokemon_key = p.pokemon_key
      WHERE e.guild_id = ? AND e.user_id = ? AND e.is_hatched = 0 ORDER BY e.hatch_at ASC`, G, U)
      .map(e => ({ id: e.farm_egg_id, name: e.display_name_ja, speciesId: e.species_id, hatchAt: e.hatch_at, remainSec: Math.max(0, e.hatch_at - t) }));
  }
  function hatchedRows(G, U) {
    return all(`SELECT h.*, p.display_name_ja, p.flavor_text_ja, p.shiny_image_url FROM user_pokemon_farm_hatched h JOIN pokemon_master p ON h.pokemon_key = p.pokemon_key
      WHERE h.guild_id = ? AND h.user_id = ? ORDER BY h.hatched_at ASC, h.farm_hatched_id ASC`, G, U).map(h => {
      let moves = []; try { moves = JSON.parse(h.moves_json || "[]"); } catch {}
      return { id: h.farm_hatched_id, name: h.display_name_ja, speciesId: h.species_id, level: h.level, gender: h.gender, ability: h.ability_ja || h.ability_en || null,
        maxHp: h.max_hp, attack: h.attack, defense: h.defense, spAttack: h.sp_attack, spDefense: h.sp_defense, speed: h.speed,
        iv: { hp: h.iv_hp, attack: h.iv_attack, defense: h.iv_defense, spAttack: h.iv_sp_attack, spDefense: h.iv_sp_defense, speed: h.iv_speed },
        moves: moves.map(m => m.name_ja).filter(Boolean), flavor: h.flavor_text_ja || "", img: monImg({ image_url: h.image_url, shiny_image_url: h.shiny_image_url }, false) };
    });
  }
  function itemRows(G, U) {
    return all(`SELECT i.farm_item_id, i.quantity, m.name, m.genre, m.price, m.grade, m.multiplier, m.effect_time, m.description
      FROM user_pokemon_farm_items i JOIN pokemon_farm_shop_items m ON i.farm_item_id = m.farm_item_id
      WHERE i.guild_id = ? AND i.user_id = ? AND i.quantity > 0 ORDER BY m.grade ASC, m.price ASC, m.farm_item_id ASC`, G, U)
      .map(r => ({ id: r.farm_item_id, name: r.name, genre: r.genre, qty: r.quantity, multiplier: r.multiplier, hours: r.effect_time, desc: r.description || "" }));
  }
  function shopRows() {
    return all("SELECT * FROM pokemon_farm_shop_items ORDER BY grade ASC, price ASC, farm_item_id ASC")
      .map(r => ({ id: r.farm_item_id, name: r.name, genre: r.genre, price: r.price, multiplier: r.multiplier, hours: r.effect_time, desc: r.description || "" }));
  }
  function effectRows(G, U) {
    run("DELETE FROM user_pokemon_farm_active_effects WHERE expires_at <= ?", now());
    return all(`SELECT e.genre, e.multiplier, e.expires_at, m.name FROM user_pokemon_farm_active_effects e JOIN pokemon_farm_shop_items m ON e.farm_item_id = m.farm_item_id
      WHERE e.guild_id = ? AND e.user_id = ? AND e.expires_at > ?`, G, U, now())
      .map(e => ({ genre: e.genre, multiplier: e.multiplier, name: e.name, remainSec: e.expires_at - now() }));
  }
  function farmHome(g, uid) {
    const [G, U] = ids(g, uid);
    return { money: moneyOf(G, U), limit: FARM_MAX_DEPOSIT, expPerTick: FARM_EXP_INTERVAL_AMOUNT, deposits: depositRows(G, U), eggs: eggRows(G, U), hatched: hatchedRows(G, U),
      items: itemRows(G, U), shop: shopRows(), effects: effectRows(G, U) };
  }

  // ---------- 預ける ----------
  function depositSearch(g, uid, queries) {
    const [G, U] = ids(g, uid), out = [], seen = new Set();
    const base = `SELECT o.owned_id, o.level, o.nickname, o.is_starred, o.is_shiny, p.species_id, p.display_name_ja, p.image_url, p.shiny_image_url
      FROM user_pokemon_owned o JOIN pokemon_master p ON o.pokemon_key = p.pokemon_key
      WHERE o.guild_id = ? AND o.user_id = ? AND o.owned_id NOT IN (SELECT owned_id FROM user_pokemon_farm_deposits WHERE guild_id = ? AND user_id = ?)`;
    const qs = (Array.isArray(queries) ? queries : [queries]).map(q => String(q ?? "").trim()).filter(Boolean).slice(0, 5);
    if (!qs.length) return { error: "検索ワードを入力してください" };
    for (const q of qs) {
      const rows = /^\d+$/.test(q)
        ? all(base + " AND (o.owned_id = ? OR p.species_id = ?) ORDER BY o.owned_id ASC LIMIT 10", G, U, G, U, Number(q), Number(q))
        : all(base + " AND (p.display_name_ja LIKE ? OR o.nickname LIKE ?) ORDER BY o.owned_id ASC LIMIT 10", G, U, G, U, `%${q}%`, `%${q}%`);
      for (const r of rows) if (!seen.has(r.owned_id)) { seen.add(r.owned_id); out.push({ ownedId: r.owned_id, name: r.nickname || r.display_name_ja, speciesId: r.species_id, level: r.level, starred: !!r.is_starred, img: monImg(r, r.is_shiny) }); }
    }
    if (!out.length) return { error: "該当するポケモンが見つかりませんでした" };
    return { results: out.slice(0, 25) };
  }
  function deposit(g, uid, list) {
    if (hasActiveBattle(uid)) return { error: "バトル中は牧場を使えません" };
    const [G, U] = ids(g, uid);
    const sel = [...new Set((Array.isArray(list) ? list : []).map(Number).filter(Number.isInteger))];
    if (!sel.length) return { error: "預けるポケモンを選択してください" };
    return tx(() => {
      const cur = one("SELECT COUNT(*) c FROM user_pokemon_farm_deposits WHERE guild_id=? AND user_id=?", G, U).c;
      if (cur >= FARM_MAX_DEPOSIT) return { error: `牧場に預けられるポケモンは最大${FARM_MAX_DEPOSIT}体です（現在${cur}体）` };
      const remain = FARM_MAX_DEPOSIT - cur;
      if (sel.length > remain) return { error: `牧場の上限を超えています。あと預けられるのは${remain}体です（今回${sel.length}体選択）` };
      const mons = {};
      for (const id of sel) {
        const r = one("SELECT o.owned_id, o.nickname, o.level, p.species_id, p.display_name_ja FROM user_pokemon_owned o JOIN pokemon_master p ON o.pokemon_key = p.pokemon_key WHERE o.guild_id=? AND o.user_id=? AND o.owned_id=?", G, U, id);
        if (!r) return { error: `見つからないポケモンがあります（ID:${id}）` };
        mons[id] = r;
        if (one("SELECT 1 x FROM user_pokemon_farm_deposits WHERE guild_id=? AND user_id=? AND owned_id=?", G, U, id)) return { error: `すでに牧場にいるポケモンがいます（ID:${id}）` };
      }
      for (const id of sel) run("INSERT INTO user_pokemon_farm_deposits (guild_id,user_id,owned_id,farm_exp) VALUES (?,?,?,0)", G, U, id);
      return { ok: true, count: sel.length, total: cur + sel.length, limit: FARM_MAX_DEPOSIT,
        mons: sel.map(id => ({ ownedId: id, name: mons[id].nickname || mons[id].display_name_ja, speciesId: mons[id].species_id, level: mons[id].level })) };
    });
  }

  // ---------- 引き取る（蓄積経験値を付与） ----------
  function withdraw(g, uid, list) {
    if (hasActiveBattle(uid)) return { error: "バトル中は牧場を使えません" };
    const [G, U] = ids(g, uid);
    const sel = [...new Set((Array.isArray(list) ? list : []).map(Number).filter(Number.isInteger))];
    if (!sel.length) return { error: "引き取るポケモンを選択してください" };
    const results = [], failed = [];
    tx(() => {
      for (const id of sel) {
        try {
          const f = one(`SELECT f.farm_exp, o.level, o.nickname, p.display_name_ja, p.species_id FROM user_pokemon_farm_deposits f
            JOIN user_pokemon_owned o ON f.owned_id = o.owned_id JOIN pokemon_master p ON o.pokemon_key = p.pokemon_key
            WHERE f.guild_id=? AND f.user_id=? AND f.owned_id=? LIMIT 1`, G, U, id);
          if (!f) { failed.push({ ownedId: id, reason: "牧場データが見つかりませんでした" }); continue; }
          const gain = Number(f.farm_exp || 0);
          const r = awardExp([id], gain)[0];
          if (!r) { failed.push({ ownedId: id, reason: "経験値処理に失敗しました" }); continue; }
          run("DELETE FROM user_pokemon_farm_deposits WHERE guild_id=? AND user_id=? AND owned_id=?", G, U, id);
          results.push({ ownedId: id, name: f.nickname || f.display_name_ja, speciesId: f.species_id, gain, from: r.from, to: r.to, levelUps: r.to - r.from, learned: r.learned });
        } catch (e) { log("farm withdraw", id, e.message); failed.push({ ownedId: id, reason: "処理中にエラーが発生しました" }); }
      }
    });
    return { ok: results.length > 0, results, failed, error: results.length ? undefined : "引き取れるポケモンがいませんでした" };
  }

  // ---------- 牧場ショップ・アイテム ----------
  function buy(g, uid, itemId, qty) {
    qty = Math.floor(Number(qty)); if (!(qty >= 1 && qty <= 99999)) return { error: "数量は1以上で入力してください" };
    const [G, U] = ids(g, uid);
    const it = one("SELECT * FROM pokemon_farm_shop_items WHERE farm_item_id = ?", Number(itemId)); if (!it) return { error: "商品データが見つかりませんでした" };
    const cost = it.price * qty;
    return tx(() => {
      const money = moneyOf(G, U); if (money < cost) return { error: "所持金が不足しています" };
      run("UPDATE users SET money = money - ? WHERE guild_id=? AND user_id=?", cost, G, U);
      run("INSERT INTO user_pokemon_farm_items (guild_id,user_id,farm_item_id,quantity) VALUES (?,?,?,?) ON CONFLICT(guild_id,user_id,farm_item_id) DO UPDATE SET quantity = quantity + excluded.quantity", G, U, it.farm_item_id, qty);
      return { ok: true, name: it.name, qty, cost, money: money - cost };
    });
  }
  function useItem(g, uid, itemId) {
    const [G, U] = ids(g, uid), t = now();
    return tx(() => {
      run("DELETE FROM user_pokemon_farm_active_effects WHERE guild_id=? AND user_id=? AND expires_at <= ?", G, U, t);
      const it = one("SELECT * FROM pokemon_farm_shop_items WHERE farm_item_id = ?", Number(itemId)); if (!it) return { error: "アイテムデータが見つかりませんでした" };
      const act = one(`SELECT e.genre, e.multiplier, e.expires_at, m.name FROM user_pokemon_farm_active_effects e JOIN pokemon_farm_shop_items m ON e.farm_item_id = m.farm_item_id
        WHERE e.guild_id=? AND e.user_id=? AND e.genre=? AND e.expires_at > ? LIMIT 1`, G, U, it.genre, t);
      if (act) { const rem = act.expires_at - t; return { error: `同じジャンルの効果が発動中です：${act.name}（${act.genre} ×${act.multiplier}／残り${Math.floor(rem / 3600)}時間${Math.floor(rem % 3600 / 60)}分）。効果時間が切れてから使用してください` }; }
      const have = one("SELECT quantity FROM user_pokemon_farm_items WHERE guild_id=? AND user_id=? AND farm_item_id=?", G, U, it.farm_item_id);
      if (!have || have.quantity <= 0) return { error: "このアイテムを所持していません" };
      run("UPDATE user_pokemon_farm_items SET quantity = quantity - 1 WHERE guild_id=? AND user_id=? AND farm_item_id=?", G, U, it.farm_item_id);
      run("DELETE FROM user_pokemon_farm_items WHERE guild_id=? AND user_id=? AND farm_item_id=? AND quantity <= 0", G, U, it.farm_item_id);
      run(`INSERT INTO user_pokemon_farm_active_effects (guild_id,user_id,genre,farm_item_id,multiplier,expires_at) VALUES (?,?,?,?,?,?)
        ON CONFLICT(guild_id,user_id,genre) DO UPDATE SET farm_item_id=excluded.farm_item_id, multiplier=excluded.multiplier, expires_at=excluded.expires_at`,
        G, U, it.genre, it.farm_item_id, it.multiplier, t + it.effect_time * 3600);
      return { ok: true, name: it.name, genre: it.genre, multiplier: it.multiplier, hours: it.effect_time };
    });
  }

  // ---------- 幼体を所持ポケモンへ ----------
  function claimHatched(g, uid, hatchedId) {
    const [G, U] = ids(g, uid);
    return tx(() => {
      const h = one("SELECT * FROM user_pokemon_farm_hatched WHERE farm_hatched_id=? AND guild_id=? AND user_id=? LIMIT 1", Number(hatchedId), G, U);
      if (!h) return { error: "この幼体は見つかりませんでした" };
      const r = run(`INSERT INTO user_pokemon_owned (guild_id,user_id,pokemon_key,species_id,nickname,level,exp,gender,is_shiny,hp,max_hp,attack,defense,sp_attack,sp_defense,speed,
          iv_hp,iv_attack,iv_defense,iv_sp_attack,iv_sp_defense,iv_speed,nature_key,nature_name_ja,image_url,obtained_type,caught_at,ability_en,ability_ja)
        VALUES (?,?,?,?,NULL,?,?,?,0,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,NULL,?,'farm_hatch',?,?,?)`,
        G, U, h.pokemon_key, h.species_id, h.level, h.exp, h.gender, h.hp, h.max_hp, h.attack, h.defense, h.sp_attack, h.sp_defense, h.speed,
        h.iv_hp, h.iv_attack, h.iv_defense, h.iv_sp_attack, h.iv_sp_defense, h.iv_speed, h.image_url, now(), h.ability_en, h.ability_ja);
      const ownedId = Number(r.lastInsertRowid); if (!ownedId) throw new Error("所持ポケモンのowned_id取得に失敗しました");
      run("DELETE FROM owned_pokemon_moves WHERE owned_id = ?", ownedId);
      let moves = []; try { moves = JSON.parse(h.moves_json || "[]"); } catch {}
      moves.forEach((m, i) => { if (m.move_id != null) run("INSERT INTO owned_pokemon_moves (owned_id,slot,move_id) VALUES (?,?,?)", ownedId, i + 1, m.move_id); });
      run("DELETE FROM user_pokemon_farm_hatched WHERE farm_hatched_id=? AND guild_id=? AND user_id=?", Number(hatchedId), G, U);
      return { ok: true, ownedId };
    });
  }

  // ---------- 定期処理 ----------
  // 30分ごと：預けている人全員に経験値を蓄積し、同種の♂♀の組ごとに確率でタマゴ（1組につき最大3個まで）
  function farmTick() {
    const t = now();
    tx(() => {
      run("DELETE FROM user_pokemon_farm_active_effects WHERE expires_at <= ?", t);
      for (const u of all("SELECT DISTINCT guild_id, user_id FROM user_pokemon_farm_deposits")) {
        const G = BigInt(u.guild_id), U = BigInt(u.user_id);
        run("UPDATE user_pokemon_farm_deposits SET farm_exp = farm_exp + ? WHERE guild_id=? AND user_id=?", Math.floor(FARM_EXP_INTERVAL_AMOUNT * effectMultiplier(G, U, "経験値")), G, U);
        const chance = Math.min(1.0, FARM_BREED_CHANCE * effectMultiplier(G, U, "交配"));
        const rows = all(`SELECT f.owned_id, o.pokemon_key, o.species_id, o.gender FROM user_pokemon_farm_deposits f JOIN user_pokemon_owned o ON f.owned_id = o.owned_id
          WHERE f.guild_id=? AND f.user_id=? AND o.gender IN ('male','female')`, G, U);
        const grouped = {};
        for (const r of rows) (grouped[r.pokemon_key] ??= { male: [], female: [] })[r.gender].push(r);
        for (const [key, d] of Object.entries(grouped)) {
          for (const m of d.male) for (const f of d.female) {
            if (Math.random() > chance) continue;
            const cnt = one(`SELECT COUNT(*) c FROM user_pokemon_farm_eggs WHERE guild_id=? AND user_id=? AND pokemon_key=?
              AND ((parent_male_owned_id=? AND parent_female_owned_id=?) OR (parent_male_owned_id=? AND parent_female_owned_id=?))`, G, U, key, m.owned_id, f.owned_id, f.owned_id, m.owned_id).c;
            if (cnt >= FARM_MAX_EGGS_PER_PAIR) continue;
            run("INSERT INTO user_pokemon_farm_eggs (guild_id,user_id,pokemon_key,species_id,parent_male_owned_id,parent_female_owned_id,hatch_at) VALUES (?,?,?,?,?,?,?)",
              G, U, key, m.species_id, m.owned_id, f.owned_id, t + FARM_HATCH_SECONDS);
          }
        }
      }
    });
  }
  // タマゴ1個を幼体にする：親の個体値の最大値+1〜31、特性は通常/隠れから、Lv1の技は先頭4つ
  function hatchEgg(egg) {
    const m = one("SELECT * FROM pokemon_master WHERE pokemon_key = ? LIMIT 1", egg.pokemon_key); if (!m) return;
    const parents = all("SELECT * FROM user_pokemon_owned WHERE owned_id IN (?, ?)", egg.parent_male_owned_id ?? -1, egg.parent_female_owned_id ?? -1);
    const iv = {};
    for (const k of IV_KEYS) { const mx = parents.reduce((a, p) => Math.max(a, Number(p[k] || 0)), 0); iv[k] = rnd(Math.min(31, mx + 1), 31); }
    const abil = [];
    if (m.ability1_en) abil.push([m.ability1_en, m.ability1_ja]);
    if (m.ability2_en) abil.push([m.ability2_en, m.ability2_ja]);
    if (m.hidden_ability_en) abil.push([m.hidden_ability_en, m.hidden_ability_ja]);
    const ab = abil.length ? abil[rnd(0, abil.length - 1)] : [null, null];
    const st = E.calcStats(m, 1, { hp: iv.iv_hp, attack: iv.iv_attack, defense: iv.iv_defense, sp_attack: iv.iv_sp_attack, sp_defense: iv.iv_sp_defense, speed: iv.iv_speed });
    const moves = all(`SELECT m.move_id, m.name_ja FROM pokemon_learnset l JOIN pokemon_moves_master m ON l.move_id = m.move_id
      WHERE l.pokemon_key = ? AND l.learn_method = 'level-up' AND l.learn_level <= 1 GROUP BY m.move_id ORDER BY m.move_id ASC LIMIT 4`, egg.pokemon_key)
      .map(x => ({ move_id: x.move_id, name_ja: x.name_ja }));
    run(`INSERT INTO user_pokemon_farm_hatched (guild_id,user_id,pokemon_key,species_id,level,exp,gender,ability_en,ability_ja,hp,max_hp,attack,defense,sp_attack,sp_defense,speed,
        iv_hp,iv_attack,iv_defense,iv_sp_attack,iv_sp_defense,iv_speed,image_url,moves_json) VALUES (?,?,?,?,1,0,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      BigInt(egg.guild_id), BigInt(egg.user_id), egg.pokemon_key, egg.species_id, E.pickGender(m.gender_rate, m.gender_lock), ab[0], ab[1],
      st.max_hp, st.max_hp, st.attack, st.defense, st.sp_attack, st.sp_defense, st.speed,
      iv.iv_hp, iv.iv_attack, iv.iv_defense, iv.iv_sp_attack, iv.iv_sp_defense, iv.iv_speed, m.image_url, JSON.stringify(moves));
    run("UPDATE user_pokemon_farm_eggs SET is_hatched = 1 WHERE farm_egg_id = ?", egg.farm_egg_id);
  }
  // 3分ごと：孵化時刻を過ぎたタマゴを孵化
  function hatchTick() {
    const eggs = all("SELECT * FROM user_pokemon_farm_eggs WHERE is_hatched = 0 AND hatch_at <= ?", now()); if (!eggs.length) return 0;
    let n = 0;
    tx(() => { for (const e of eggs) { try { hatchEgg(e); n++; } catch (err) { log("farm hatch error", e.farm_egg_id, err.message); } } });
    return n;
  }
  function startTimers() {
    const safe = (name, fn) => () => { try { const r = fn(); if (r) log(name, r); } catch (e) { log(name, "error", e.stack || e.message); } };
    setInterval(safe("farm tick", farmTick), FARM_TICK_MS).unref();
    setInterval(safe("farm hatch", hatchTick), FARM_HATCH_TICK_MS).unref();
    setTimeout(safe("farm hatch", hatchTick), 15000).unref();
  }

  return { farmHome, depositSearch, deposit, withdraw, buy, useItem, claimHatched, farmTick, hatchTick, hatchEgg, startTimers };
}
module.exports = { create, FARM_EXP_INTERVAL_AMOUNT, FARM_BREED_CHANCE, FARM_HATCH_SECONDS, FARM_MAX_DEPOSIT };
