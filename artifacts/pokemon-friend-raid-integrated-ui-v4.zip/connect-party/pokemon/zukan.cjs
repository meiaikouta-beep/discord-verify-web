// ============================================================
// ポケモン図鑑（pokemon3.py の「ポケモン検索（図鑑）」＋マイページの図鑑／地方コンプ状況をWeb用に移植）
//   元bot：図鑑番号 or 名前で検索 → 種族の詳細（説明・タイプ・特性・種族値・サーバー内の所持者）
//          マイページ：見つけた数／捕まえた数／所持している種類／地方ごとのコンプ状況
//   Web版：一覧（検索・絞り込み・ページ送り）と詳細を1つの画面にまとめた。user_pokedex の記録を「見つけた／捕まえた」の印として表示する
// server.cjs から create(ctx) で使う。ctx = { all, one, sessions }
// ============================================================
const PAGE = 30;
const REGION_ORDER = ["カントー", "ジョウト", "ホウエン", "シンオウ", "イッシュ", "カロス", "アローラ", "ガラル", "ヒスイ", "パルデア", "ウルトラビースト"];   // 元botのマイページと同じ並び

function create(ctx) {
  const { all, one, sessions } = ctx;
  const local = (url, kind) => url ? `/poke/${kind}/${url.slice(url.lastIndexOf("/") + 1)}` : null;
  const img = (m, shiny) => (shiny && local(m.shiny_image_url, "art-shiny")) || local(m.image_url, "art");
  const clip = (t, n) => { t = String(t || "").replace(/[\f\r\n]+/g, " ").replace(/\s+/g, " ").trim(); return t.length > n ? t.slice(0, n - 1) + "…" : t; };

  // ---------- 全体の進み具合（元botのマイページと同じ数え方：種類＝図鑑No単位） ----------
  function summary(G, U) {
    const seen = one("SELECT COUNT(DISTINCT species_id) c FROM user_pokedex WHERE guild_id=? AND user_id=? AND seen_count > 0", G, U).c;
    const caught = one("SELECT COUNT(DISTINCT species_id) c FROM user_pokedex WHERE guild_id=? AND user_id=? AND caught_count > 0", G, U).c;
    const owned = one("SELECT COUNT(DISTINCT species_id) c FROM user_pokemon_owned WHERE guild_id=? AND user_id=?", G, U).c;
    const total = one("SELECT COUNT(DISTINCT species_id) c FROM pokemon_master").c;
    const tot = new Map(all("SELECT region_name_ja r, COUNT(DISTINCT species_id) c FROM pokemon_master WHERE region_name_ja IS NOT NULL AND region_name_ja != '' GROUP BY region_name_ja").map(r => [r.r, r.c]));
    const own = new Map(all("SELECT m.region_name_ja r, COUNT(DISTINCT o.species_id) c FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key = o.pokemon_key WHERE o.guild_id=? AND o.user_id=? GROUP BY m.region_name_ja", G, U).map(r => [r.r, r.c]));
    const regions = [...tot.keys()].sort((a, b) => (REGION_ORDER.indexOf(a) < 0 ? 99 : REGION_ORDER.indexOf(a)) - (REGION_ORDER.indexOf(b) < 0 ? 99 : REGION_ORDER.indexOf(b)))
      .map(r => ({ name: r, owned: own.get(r) || 0, total: tot.get(r) }));
    return { seen, caught, owned, total, regions };
  }

  // ---------- 一覧：図鑑番号 or 名前（部分一致）、状態・地方で絞り込み。図鑑番号順 ----------
  function list(g, uid, b) {
    const G = BigInt(g), U = BigInt(uid), where = [], args = [];
    const q = String(b.q || "").trim().slice(0, 30);
    if (q) {
      if (/^\d+$/.test(q)) { where.push("m.species_id = ?"); args.push(Number(q)); }
      else { const like = `%${q.replace(/[\\%_]/g, c => "\\" + c)}%`; where.push("(m.display_name_ja LIKE ? ESCAPE '\\' OR m.name_ja LIKE ? ESCAPE '\\')"); args.push(like, like); }
    }
    const st = String(b.state || "all");
    if (st === "caught") where.push("COALESCE(d.caught_count,0) > 0");
    else if (st === "seen") where.push("COALESCE(d.seen_count,0) > 0 AND COALESCE(d.caught_count,0) = 0");
    else if (st === "unseen") where.push("COALESCE(d.seen_count,0) = 0 AND COALESCE(d.caught_count,0) = 0");
    const reg = String(b.region || "").slice(0, 20);
    if (reg) { where.push("m.region_name_ja = ?"); args.push(reg); }
    const W = where.length ? "WHERE " + where.join(" AND ") : "";
    const FROM = "FROM pokemon_master m LEFT JOIN user_pokedex d ON d.pokemon_key = m.pokemon_key AND d.guild_id = ? AND d.user_id = ?";
    const total = one(`SELECT COUNT(*) c ${FROM} ${W}`, G, U, ...args).c;
    const pages = Math.max(1, Math.ceil(total / PAGE)), page = Math.max(0, Math.min(pages - 1, Math.floor(Number(b.page)) || 0));
    const rows = all(`SELECT m.pokemon_key k, m.species_id no, m.display_name_ja dn, m.type1, m.type2, m.type1_ja, m.type2_ja, m.image_url, m.shiny_image_url,
      COALESCE(d.seen_count,0) seen, COALESCE(d.caught_count,0) caught, COALESCE(d.shiny_caught,0) shiny
      ${FROM} ${W} ORDER BY m.species_id ASC, m.pokemon_key ASC LIMIT ${PAGE} OFFSET ${page * PAGE}`, G, U, ...args);
    const items = rows.map(r => ({ key: r.k, no: r.no, name: r.dn || r.k, img: img(r, false), types: [r.type1, r.type2].filter(Boolean), caught: r.caught > 0, seen: r.seen > 0 || r.caught > 0, shiny: r.shiny > 0 }));
    return { total, page, pages, items };
  }

  // ---------- 詳細：説明・タイプ・特性・種族値・自分の記録・サーバー内の所持者 ----------
  function detail(g, uid, key) {
    const G = BigInt(g), U = BigInt(uid), m = one("SELECT * FROM pokemon_master WHERE pokemon_key = ?", String(key || ""));
    if (!m) return { error: "ポケモンが見つかりません" };
    const my = one("SELECT seen_count, caught_count, normal_caught, shiny_caught, first_seen_at, first_caught_at FROM user_pokedex WHERE guild_id=? AND user_id=? AND pokemon_key=?", G, U, m.pokemon_key) || {};
    const mine = one("SELECT COUNT(*) c FROM user_pokemon_owned WHERE guild_id=? AND user_id=? AND pokemon_key=?", G, U, m.pokemon_key).c;
    const owners = all("SELECT CAST(user_id AS TEXT) u, COUNT(*) c FROM user_pokemon_owned WHERE guild_id=? AND pokemon_key=? GROUP BY user_id ORDER BY c DESC, user_id ASC", G, m.pokemon_key);
    const names = new Map(); for (const s of sessions.values()) if (s.g === g) names.set(s.uid, s.name);   // 名前がわかるのは、いま開いている人だけ（botのようにメンションは使えない）
    const ab = [m.ability1_ja && m.ability1_ja !== "なし" ? { name: m.ability1_ja, hidden: false } : null, m.ability2_ja && m.ability2_ja !== "なし" ? { name: m.ability2_ja, hidden: false } : null, m.hidden_ability_ja && m.hidden_ability_ja !== "なし" ? { name: m.hidden_ability_ja, hidden: true } : null].filter(Boolean);
    const base = { hp: m.base_hp || 0, attack: m.base_attack || 0, defense: m.base_defense || 0, sp_attack: m.base_sp_attack || 0, sp_defense: m.base_sp_defense || 0, speed: m.base_speed || 0 };
    const known = !!(my.seen_count > 0 || my.caught_count > 0);
    return { ok: true, key: m.pokemon_key, no: m.species_id, name: m.display_name_ja || m.pokemon_key, img: img(m, false), shinyImg: img(m, true) !== img(m, false) ? img(m, true) : null,
      types: [m.type1, m.type2].filter(Boolean), typesJa: [m.type1_ja, m.type2_ja].filter(t => t && t !== "なし"), region: m.region_name_ja || null,
      flavor: clip(m.flavor_text_ja, 400) || null, abilities: ab, base, total: Object.values(base).reduce((a, b) => a + b, 0),
      my: { known, seen: my.seen_count || 0, caught: my.caught_count || 0, normal: my.normal_caught || 0, shiny: my.shiny_caught || 0, firstSeen: my.first_seen_at || null, firstCaught: my.first_caught_at || null, have: mine },
      owners: owners.map(o => ({ name: names.get(o.u) || null, me: o.u === String(uid), count: o.c })), ownerTotal: owners.reduce((a, o) => a + o.c, 0), ownerUsers: owners.length };
  }

  return { summary: (g, uid) => summary(BigInt(g), BigInt(uid)), list, detail };
}

module.exports = { create };
