'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../connect-party/pokemon/engine.cjs'),{create}=require('../connect-party/pokemon/friend.cjs');
const move=(en='tackle',power=40)=>({id:1,name:'たいあたり',en,type:'normal',cls:'physical',power,accuracy:100,pp:35,maxpp:35,rules:[]});
function mon(id,name){return E.makeBattler({id,key:'S:'+id,name,type1:'normal',level:50,hp:500,maxHp:500,attack:100,defense:100,sp_attack:100,sp_defense:100,speed:100,moves:[move()]})}
function fixture(){
 const users=[{uid:'9007199254740993',g:'1',name:'A'},{uid:'9007199254740994',g:'1',name:'B'},{uid:'9007199254740995',g:'2',name:'C'}];
 const locked=new Set(),seen=[];
 const FR=create({all:()=>[],one:()=>({species_id:1}),run:()=>{throw Error('Friend battle must not save rewards')},E,
 loadParty:(g,u,id)=>id===1?{party:[mon(1,'先発'),mon(2,'控え')]}:{error:'invalid group'},markSeen:(...a)=>seen.push(a),pveActive:u=>locked.has(u),log:()=>{}});
 users.forEach(u=>FR.state(u,0));
 function start(){const r=FR.challenge(users[0],users[1].uid,1);assert.ifError(r.error);const a=FR.accept(users[1],r.outgoing.id,1);assert.ifError(a.error);return a;}
 return {FR,users,locked,seen,start};
}
test('挑戦・受諾・両者入力で進行・相手側の左右反転・二重選択拒否',()=>{
 const f=fixture(),[a,b]=f.users;f.start();assert.equal(f.FR.inBattle(a.uid),true);assert.equal(f.seen.length,2);
 let r=f.FR.act(a,{type:'move',idx:0,seen:1});assert.ifError(r.error);assert.equal(r.battle.n,1);assert.ok(f.FR.act(a,{type:'move',idx:0}).error);
 r=f.FR.act(b,{type:'move',idx:0,seen:1});assert.ifError(r.error);assert.equal(r.battle.n,2);
 const av=f.FR.state(a,1).battle,bv=f.FR.state(b,1).battle;
 assert.equal(av.view.p.hp,bv.view.e.hp);assert.equal(av.view.e.hp,bv.view.p.hp);
 assert.equal(av.turns[0].events.filter(e=>e.t==='move').length,2);
 assert.equal(av.turns[0].events.find(e=>e.t==='move').side,bv.turns[0].events.find(e=>e.t==='move').side==='p'?'e':'p');
});
test('レイド/通常戦闘ロック・別guild・無効チーム・自分への挑戦',()=>{
 const f=fixture(),[a,b,c]=f.users;assert.ok(f.FR.challenge(a,a.uid,1).error);assert.ok(f.FR.challenge(a,c.uid,1).error);assert.ok(f.FR.challenge(a,b.uid,99).error);
 f.locked.add(b.uid);assert.ok(f.FR.challenge(a,b.uid,1).error);f.locked.clear();
 const r=f.FR.challenge(a,b.uid,1);f.locked.add(a.uid);assert.ok(f.FR.accept(b,r.outgoing.id,1).error);
});
test('交代を両側で処理し相手側に技一覧を漏らさない',()=>{
 const f=fixture(),[a,b]=f.users;f.start();f.FR.act(a,{type:'switch',idx:1});const r=f.FR.act(b,{type:'move',idx:0});assert.ifError(r.error);
 assert.equal(f.FR.state(a,0).battle.view.p.name,'控え');const events=f.FR.state(b,1).battle.turns.flatMap(t=>t.events);const incoming=events.find(e=>e.t==='enemyIn');assert.ok(incoming);assert.equal(incoming.moves,undefined);
});
test('ひんし後の交代と全滅時の勝敗',()=>{
 const f=fixture(),[a,b]=f.users;f.start();const B=[...f.FR._battles.values()][0];B.S.party[0].hp=1;B.S.party[0].speed=1;B.S.eparty[0].speed=999;B.S.eparty[0].moves[0].power=9999;
 f.FR.act(a,{type:'move',idx:0});f.FR.act(b,{type:'move',idx:0});assert.equal(f.FR.state(a,0).battle.view.needSwitch,true);
 assert.ifError(f.FR.act(a,{type:'switch',idx:1}).error);assert.equal(f.FR.state(a,0).battle.view.p.name,'控え');
 B.S.party[1].hp=1;f.FR.act(a,{type:'move',idx:0});f.FR.act(b,{type:'move',idx:0});assert.equal(f.FR.state(a,0).battle.view.over.result,'lose');assert.equal(f.FR.state(b,0).battle.view.over.result,'win');
});
test('降参・終了後の離脱でロック解除・再挑戦できる',()=>{
 const f=fixture(),[a,b]=f.users;f.start();f.FR.act(a,{type:'forfeit'});assert.equal(f.FR.inBattle(a.uid),false);assert.equal(f.FR.state(b,0).battle.view.over.result,'win');
 f.FR.leave(a);f.FR.leave(b);assert.equal(f.FR.state(a,0).battle,null);assert.ifError(f.FR.challenge(a,b.uid,1).error);
});
test('PP切れのわるあがきとレイド用補正がPVPへ混入しない',()=>{
 const f=fixture(),[a,b]=f.users;f.start();const B=[...f.FR._battles.values()][0];B.S.party[0].moves[0].pp=0;
 assert.ok(f.FR.act(a,{type:'move',idx:0}).error);assert.ifError(f.FR.act(a,{type:'move',idx:-1}).error);assert.ifError(f.FR.act(b,{type:'move',idx:0}).error);
 assert.ok(f.FR.state(a,1).battle.turns.flatMap(t=>t.events).some(e=>e.t==='move'&&e.name==='わるあがき'));
 assert.equal(B.S.party[0].raidBoss,undefined);assert.equal(B.S.eparty[0].raidBoss,undefined);
});
