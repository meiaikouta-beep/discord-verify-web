'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite');
const {create,worldClock,weather,REGIONS}=require('../connect-party/pokemon/world.cjs');
function fixture(){
 const db=new DatabaseSync(':memory:');db.exec('PRAGMA journal_mode=MEMORY');
 const fix=r=>{if(!r)return r;for(const k in r)if(typeof r[k]==='bigint')r[k]=Number(r[k]);return r};
 const one=(q,...a)=>fix(db.prepare(q).get(...a)),run=(q,...a)=>db.prepare(q).run(...a),all=(q,...a)=>db.prepare(q).all(...a).map(fix);
 const locked=new Set(),W=create({db,one,run,all,busy:u=>locked.has(String(u))});return{db,W,locked};
}
test('初回はオーキド博士のセンター・全10地方・日時と天候を返す',()=>{const{W}=fixture(),s=W.snapshot('1','2',Date.UTC(2026,0,3,0));assert.equal(s.map,'center');assert.equal(s.region.key,'kanto');assert.equal(s.regions.length,10);assert.equal(REGIONS.find(x=>x.key==='hisui').starters.join(','),'722,155,501');assert.ok(s.triggers.some(x=>x.action==='oak'));assert.equal(s.clock.season,'winter');assert.equal(weather('hoenn',12345).key,weather('hoenn',12345).key)});
test('地方切替はセンターだけ、入口を調べると屋外へ移動する',()=>{const{W}=fixture();assert.equal(W.setRegion('1','2','hoenn').region.key,'hoenn');W.move('1','2',{x:0,z:12,direction:0});const r=W.interact('1','2','exit');assert.equal(r.world.map,'field');assert.ok(W.setRegion('1','2','sinnoh').error)});
test('移動距離・施設距離・建物衝突・戦闘ロックをサーバーが検証する',()=>{const{W,locked}=fixture();assert.ok(W.move('1','2',{x:40,z:40}).error);assert.ok(W.interact('1','2','heal').error);assert.match(W.move('1','2',{x:0,z:-8}).error,/カウンター/);W.move('1','2',{x:0,z:12});W.interact('1','2','exit');assert.match(W.move('1','2',{x:0,z:17}).error,/建物/);locked.add('2');assert.ok(W.move('1','2',{x:1,z:8}).error)});
test('草むら・洞窟・釣り・波乗りは対応地点だけで遭遇し会場を選ぶ',()=>{const{W,db}=fixture();W.move('1','2',{x:0,z:12});W.interact('1','2','exit');assert.ok(W.encounter('1','2','fishing').error);db.prepare("UPDATE web_world_state SET x=-10,z=-3,steps=4,last_encounter_at=0").run();let r=W.encounter('1','2','grass');assert.equal(r.encounter,true);assert.equal(r.scene.stage,'field');db.prepare("UPDATE web_world_state SET x=0,z=-28,steps=4,last_encounter_at=0").run();r=W.encounter('1','2','cave');assert.equal(r.scene.stage,'cave');db.prepare("UPDATE web_world_state SET x=23,z=1,last_encounter_at=0").run();r=W.encounter('1','2','fishing');assert.equal(r.scene.stage,'water')});
test('全滅時はセンターへ戻す',()=>{const{W}=fixture();W.faint('1','2');const s=W.snapshot('1','2');assert.equal(s.map,'center');assert.equal(s.position.z,9)});
