// ============================================================
// ポケットモンスターT サバイバー
// 認証は入口と同じ（Discordのトークン）。通常プレイは許可サーバーの参加者、管理画面だけADMIN_USER_IDSに限定。
// データは /opt/games-party/data/pokemon.sqlite（botから移したもの）。バトル計算は engine.cjs。
// ============================================================
const http = require("node:http"), fs = require("node:fs"), path = require("node:path"), crypto = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const E = require("./engine.cjs");
const PB = require("./balls.cjs");
const EV = require("./evolution.cjs");
const P = require("./progression.cjs");
const readEnv = f => { const o = {}; try { for (const l of fs.readFileSync(f, "utf8").split(/\r?\n/)) { const m = l.match(/^([A-Z_]+)=(.*)$/); if (m) o[m[1]] = m[2].trim(); } } catch {} return o; };
const env = { ...readEnv("/etc/games-hub.env"), ...readEnv("/etc/games-party.env") };
const CLIENT_ID = env.DISCORD_CLIENT_ID, BOT_TOKEN = env.DISCORD_BOT_TOKEN, API = env.DISCORD_API || "https://discord.com/api/v10";
const ALLOWED_GUILDS = new Set((env.ALLOWED_GUILD_IDS || "").split(",").map(s => s.trim()).filter(Boolean));
const ADMIN_IDS = new Set((env.ADMIN_USER_IDS || "").split(",").map(s => s.trim()).filter(Boolean));
const PORT = Number(env.POKEMON_PORT) || 8501;
const DB_FILE = env.POKEMON_DB || "/opt/games-party/data/pokemon.sqlite";
const IMG_DIR = env.POKEMON_IMG || "/opt/games-party/public/poke";
const PUBLIC = path.join(__dirname, "public");
if (!CLIENT_ID || !BOT_TOKEN) throw new Error("/etc/games-hub.env が読めません");
const allowedOrigins = new Set(["https://games.talksurvivor.online", `https://${CLIENT_ID}.discordsays.com`]);
const log = (...a) => console.log(new Date().toISOString(), ...a);

const db = new DatabaseSync(DB_FILE, { enableForeignKeyConstraints: false });   // 元のDBは存在しない親テーブルを参照しているため
db.exec("PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;");
db.exec(`CREATE TABLE IF NOT EXISTS web_evolution_progress(
 owned_id INTEGER PRIMARY KEY, friendship INTEGER NOT NULL DEFAULT 70, battle_count INTEGER NOT NULL DEFAULT 0,
 critical_hits INTEGER NOT NULL DEFAULT 0, damage_taken INTEGER NOT NULL DEFAULT 0, recoil_damage INTEGER NOT NULL DEFAULT 0,
 move_uses_json TEXT NOT NULL DEFAULT '{}', last_region TEXT, last_weather TEXT, luxury INTEGER NOT NULL DEFAULT 0, updated_at INTEGER
)`);
// 64bitのIDはJSの数では精度が落ちるため、BigIntで読んで、安全な範囲なら数に、大きければ文字列にする
const fix = r => { if (!r) return r; for (const k in r) if (typeof r[k] === "bigint") r[k] = (r[k] <= 9007199254740991n && r[k] >= -9007199254740991n) ? Number(r[k]) : r[k].toString(); return r; };
const prep = sql => { const st = db.prepare(sql); st.setReadBigInts(true); return st; };
const all = (sql, ...a) => prep(sql).all(...a).map(fix), one = (sql, ...a) => fix(prep(sql).get(...a)), run = (sql, ...a) => db.prepare(sql).run(...a);
const tx = fn => { db.exec("BEGIN IMMEDIATE"); try { const r = fn(); db.exec("COMMIT"); return r; } catch (e) { db.exec("ROLLBACK"); throw e; } };
P.migrate({db,all,one,run});

// 技の効果ルール（起動時に読む）／技の先制度
const RULES = new Map(); for (const r of all("SELECT * FROM pokemon_move_effect_rules ORDER BY priority")) (RULES.get(r.move_id) || RULES.set(r.move_id, []).get(r.move_id)).push(r);
const PRIO = {   // 技名(en) → 先制度。元botの表（protect/detect=+4 を含む）に、本家の主な先制技・後攻技を追加
  "quick-attack": 1, "aqua-jet": 1, "ice-shard": 1, "shadow-sneak": 1, "bullet-punch": 1, "mach-punch": 1, "vacuum-wave": 1, "sucker-punch": 1,
  "accelerock": 1, "water-shuriken": 1, "jet-punch": 1, "thunderclap": 1, "extreme-speed": 2, "feint": 2, "first-impression": 2, "fake-out": 3,
  "protect": 4, "detect": 4, "endure": 4, "spiky-shield": 4, "kings-shield": 4, "baneful-bunker": 4, "obstruct": 4, "silk-trap": 4, "burning-bulwark": 4,
  "vital-throw": -1, "roar": -6, "whirlwind": -6, "dragon-tail": -6, "circle-throw": -6, "trick-room": -7,
};
const mkMove = m => ({ id: m.move_id, name: m.name_ja || m.name_en, type: m.type, power: m.power ?? 0, accuracy: m.accuracy, pp: m.current_pp ?? m.pp ?? 10, maxpp: m.max_pp ?? m.pp ?? 10, cls: m.damage_class, priority: PRIO[m.name_en] || 0, en: m.name_en, rules: RULES.get(m.move_id) || [] });

E.setPicker(() => { const r = one("SELECT * FROM pokemon_moves_master WHERE COALESCE(power,0) > 0 AND name_en NOT IN ('struggle','metronome') ORDER BY RANDOM() LIMIT 1"); return r ? mkMove(r) : null; });

// 画像のURL → サーバーに保存した場所（fetch_images.py と同じ規則）
const local = (url, kind) => url ? `/poke/${kind}/${url.slice(url.lastIndexOf("/") + 1)}` : null;
const monImg = (m, shiny) => (shiny && local(m.shiny_image_url, "art-shiny")) || local(m.image_url, "art");

// ---------------- 認証 ----------------
async function verify(token, instanceId) {
  const u = await fetch(API + "/users/@me", { headers: { Authorization: "Bearer " + token }, signal: AbortSignal.timeout(10000) });
  if (!u.ok) return { error: "ログインが切れています。アクティビティを開き直してください" };
  const user = await u.json();
  if (!/^i-[A-Za-z0-9-]{1,250}$/.test(String(instanceId))) return { error: "アクティビティの情報がありません" };
  const r = await fetch(`${API}/applications/${CLIENT_ID}/activity-instances/${instanceId}`, { headers: { Authorization: "Bot " + BOT_TOKEN }, signal: AbortSignal.timeout(10000) });
  if (!r.ok) return { error: "アクティビティを確認できません" };
  const inst = await r.json(), guild = inst.location?.guild_id;
  if (inst.application_id !== CLIENT_ID || !inst.users?.includes(user.id) || !ALLOWED_GUILDS.has(guild)) return { error: "このサーバーでは遊べません" };
  return { user: { id: user.id, name: String(user.global_name || user.username || "プレイヤー").slice(0, 32), username: String(user.username || "").slice(0, 32), avatar: user.avatar || null }, guild };
}
const sessions = new Map();
const trainerName = uid => [...sessions.values()].find(x=>x.uid===String(uid))?.name||null;
const profileName=(g,uid)=>{
  const id=String(uid||'');if(!/^\d+$/.test(id))return null;
  const live=[...sessions.values()].find(x=>x.g===String(g)&&x.uid===id)?.name;if(live)return live;
  return one("SELECT display_name FROM web_user_profiles WHERE guild_id=? AND user_id=?",BigInt(g),BigInt(id))?.display_name||null;
};
const saveProfile=(g,user,name)=>{
  const id=String(user?.id||user?.user?.id||'');if(!/^\d+$/.test(id))return;
  const base=user.user||user,display=String(name||user.nick||base.global_name||base.username||'プレイヤー').slice(0,64);
  run(`INSERT INTO web_user_profiles(guild_id,user_id,display_name,username,avatar,updated_at) VALUES(?,?,?,?,?,strftime('%s','now'))
    ON CONFLICT(guild_id,user_id) DO UPDATE SET display_name=excluded.display_name,username=excluded.username,avatar=excluded.avatar,updated_at=excluded.updated_at`,
    BigInt(g),BigInt(id),display,String(base.username||'').slice(0,64),base.avatar||null);
};
const profileSync=new Map();
async function syncGuildProfiles(g){
  if(!BOT_TOKEN||BOT_TOKEN==='test')return;
  const key=String(g),last=profileSync.get(key)||0;if(Date.now()-last<6*3600e3)return;
  profileSync.set(key,Date.now());
  try{
    let after='0';
    for(let page=0;page<20;page++){
      const r=await fetch(`${API}/guilds/${key}/members?limit=1000&after=${after}`,{headers:{Authorization:'Bot '+BOT_TOKEN},signal:AbortSignal.timeout(15000)});
      if(!r.ok)throw new Error(`Discord members ${r.status}`);
      const members=await r.json();for(const m of members)saveProfile(key,m);
      if(members.length<1000)break;after=String(members.at(-1)?.user?.id||'0');if(after==='0')break;
    }
    run(`UPDATE user_pokemon_owned SET original_trainer_name=(SELECT p.display_name FROM web_user_profiles p WHERE p.guild_id=user_pokemon_owned.guild_id AND CAST(p.user_id AS TEXT)=user_pokemon_owned.original_trainer_id)
      WHERE guild_id=? AND original_trainer_id IS NOT NULL AND EXISTS(SELECT 1 FROM web_user_profiles p WHERE p.guild_id=user_pokemon_owned.guild_id AND CAST(p.user_id AS TEXT)=user_pokemon_owned.original_trainer_id)
      AND (original_trainer_name IS NULL OR original_trainer_name='' OR original_trainer_name=original_trainer_id)`,BigInt(key));
  }catch(e){profileSync.set(key,Date.now()-5*3600e3);log('profile sync skipped',key,e.message)}
}
// DB上のサーバーID（botが記録した値）を、ユーザーIDから引く。大きな数は文字列で扱い、精度を落とさない
function dbGuild(uid, guild) {
  const rows = all("SELECT CAST(guild_id AS TEXT) g FROM users WHERE user_id = ?", BigInt(uid));
  if (!rows.length) return guild;   // まだ1匹も選んでいない人：アクティビティを開いたサーバー（確認済み）を使う。スターター選択でusers行ができる
  return (rows.find(r => r.g === guild) || rows[0]).g;
}

// ---------------- 読み出し ----------------
function loadMon(o, withMoves = true) {
  const m = one("SELECT * FROM pokemon_master WHERE pokemon_key = ?", o.pokemon_key);
  let mv = withMoves ? all("SELECT mm.*,om.current_pp,om.max_pp FROM owned_pokemon_moves om JOIN pokemon_moves_master mm ON mm.move_id = om.move_id WHERE om.owned_id = ? AND om.active=1 ORDER BY om.slot LIMIT 4", o.owned_id).map(mkMove) : [];
  mv = mv.filter(x => x.power >= 0);
  if (!mv.length) mv = wildMoves(o.pokemon_key, o.level);
  const hi=o.held_item_key?one("SELECT name_ja FROM pokemon_items_master WHERE item_key=?",o.held_item_key):null;
  return E.makeBattler({ id: o.owned_id, key: o.pokemon_key, name: o.nickname || m?.display_name_ja || o.pokemon_key, type1: m?.type1, type2: m?.type2, level: o.level, hp: Math.max(0,Math.min(o.max_hp,o.hp??o.max_hp)), maxHp: o.max_hp,
    attack: o.attack, defense: o.defense, sp_attack: o.sp_attack, sp_defense: o.sp_defense, speed: o.speed, moves: mv, img: monImg(m || {}, o.is_shiny), shiny: o.is_shiny, gender: o.gender, ability: o.ability_en || null, abilityJa: o.ability_ja || null,status:o.persistent_status,heldItem:o.held_item_key,heldName:hi?.name_ja,nature:o.nature_key });
}
function wildMoves(key, level) {
  let rows = all(`SELECT m.* FROM (SELECT move_id, MIN(learn_level) lv FROM pokemon_learnset WHERE pokemon_key = ? AND learn_method='level-up' AND learn_level <= ? GROUP BY move_id) l JOIN pokemon_moves_master m ON m.move_id = l.move_id WHERE COALESCE(m.power,0) >= 0 ORDER BY l.lv DESC LIMIT 4`, key, level);
  if (!rows.length) { const sp = one("SELECT species_id FROM pokemon_master WHERE pokemon_key = ?", key)?.species_id; if (sp) rows = all(`SELECT m.* FROM (SELECT move_id, MIN(learn_level) lv FROM pokemon_learnset WHERE pokemon_key = ? AND learn_method='level-up' AND learn_level <= ? GROUP BY move_id) l JOIN pokemon_moves_master m ON m.move_id = l.move_id WHERE COALESCE(m.power,0) >= 0 ORDER BY l.lv DESC LIMIT 4`, "S:" + sp, level); }
  if (!rows.length) rows = all("SELECT * FROM pokemon_moves_master WHERE name_en IN ('tackle','scratch','pound') LIMIT 1");
  return rows.map(mkMove);
}
function home(uid, g) {
  const G = BigInt(g), U = BigInt(uid);
  const money = one("SELECT money FROM users WHERE guild_id = ? AND user_id = ?", G, U)?.money ?? 0;
  const balls = ballsOf(G, U);
  const groups = all("SELECT group_id, group_name FROM pokemon_user_groups WHERE guild_id = ? AND user_id = ? ORDER BY group_id", G, U).map(gr => ({ id: gr.group_id, name: gr.group_name,
    members: all("SELECT o.*, gm.slot FROM pokemon_user_group_members gm JOIN user_pokemon_owned o ON o.owned_id = gm.owned_id WHERE gm.group_id = ? ORDER BY gm.slot", gr.group_id).map(o => { const m = one("SELECT display_name_ja n, image_url, shiny_image_url FROM pokemon_master WHERE pokemon_key = ?", o.pokemon_key) || {}; return { name: o.nickname || m.n || o.pokemon_key, level: o.level, img: monImg(m, o.is_shiny) }; }) }));
  const regions = all("SELECT DISTINCT region_name_ja r FROM pokemon_master WHERE spawn_enabled = 1 AND region_name_ja IS NOT NULL").map(r => r.r);
  const gymRegions = []; for (const r of all("SELECT leader_id FROM gym_leaders ORDER BY order_index")) { const k = r.leader_id.split("_")[0]; if (!gymRegions.includes(k)) gymRegions.push(k); }
  const defeated = new Set(all("SELECT leader_id FROM user_gym_progress WHERE guild_id = ? AND user_id = ? AND is_defeated = 1", G, U).map(r => r.leader_id));
  const badges = all("SELECT region_name, badge_name FROM user_gym_badges WHERE guild_id = ? AND user_id = ? AND region_name != 'team rocket'", G, U);   // ロケット団の証はジムバッジに数えない（元botと同じ）
  const gyms = gymRegions.map(k => { const ls = all("SELECT * FROM gym_leaders WHERE leader_id LIKE ? ORDER BY order_index", k + "_%").map(l => ({ id: l.leader_id, name: l.name_ja, gym: l.gym_name, type: l.type_name, badge: l.badge_name, done: defeated.has(l.leader_id) })); return { key: k, ja: REGION_JA[k] || k, leaders: ls, next: ls.find(l => !l.done)?.id || null, badge: badges.some(b => b.region_name === k) }; });
  const rocket = all("SELECT * FROM special_gym_leaders ORDER BY order_index").map(l => ({ id: l.leader_id, name: l.name_ja, gym: l.gym_name, type: l.type_name, done: defeated.has(l.leader_id) }));
  const trainerRegions = all("SELECT DISTINCT region_name_ja r, generation_no g FROM pokemon_master WHERE region_name_ja IS NOT NULL AND region_name_ja != '' ORDER BY generation_no").map(r => r.r).filter(r => !REGION_EXCLUDE.has(r));
  const tickets={rare:invQty(G,U,'rare-battle-ticket'),raid:invQty(G,U,'raid-ticket')};
  return { money, balls, ballCatalog: PB.catalog(), tickets, isAdmin:ADMIN_IDS.has(String(uid)), groups, regions, gyms, rocket, badgeCount: badges.length, trainerRegions, trainers: TRAINER_NAMES, needStarter: !ST.started(g, uid) };
}

// ---------------- NPC戦の定数（元のbotと同じ） ----------------
const REGION_JA = { kanto: "カントー", johto: "ジョウト", hoenn: "ホウエン", sinnoh: "シンオウ", unova: "イッシュ", kalos: "カロス", alola: "アローラ", galar: "ガラル", hisui: "ヒスイ", paldea: "パルデア" };
const REGION_EXCLUDE = new Set(["アローラ", "ガラル", "パルデア", "ヒスイ"]);
const TRAINER_NAMES = ["ヒカル", "ミナキ", "モミ", "ゲン", "バク", "ミル", "マイ", "バンジロウ", "ジーナ", "デクシオ", "AZ", "ヒガナ", "リーリエ", "リュウキ", "ソッド", "シルディ", "マスタード", "ミツバ", "ピオニー", "シャクヤ", "ペパー", "ボタン", "ゼイユ", "スグリ"];
const TRAINER_RANK_JA = ["Lv.5~15程度", "Lv.16~30程度", "Lv.31~60程度", "Lv.70~100"];

// ---------------- 野生ポケモン（元のbotの出現ロジック） ----------------
function pickWild(g, region, ctx={}) {
  const s = one("SELECT * FROM pokemon_spawn_settings WHERE guild_id = ?", BigInt(g)) || one("SELECT * FROM pokemon_spawn_settings LIMIT 1");
  const ub = region === "ウルトラビースト" ? "" : "AND is_ultra_beast = 0";
  const rows = all(`SELECT * FROM pokemon_master WHERE spawn_enabled=1 AND spawn_weight>0 AND region_name_ja=? AND (is_default=1 OR is_regional=1) AND is_mega=0 AND is_gmax=0 AND is_legendary=0 AND is_mythical=0 ${ub}`, region);
  const W = m => { if (!(m.spawn_weight > 0)) return 0; let w=!s?m.spawn_weight:(m.is_regional?s.regional_weight:({ base: s.base_weight, middle: s.middle_weight, final: s.final_weight, none: s.none_weight }[m.evolution_stage] ?? m.spawn_weight));
    const types=[m.type1,m.type2],method=ctx?.method,weather=ctx?.conditions?.weather?.key||ctx?.scene?.weather,time=ctx?.conditions?.time,season=ctx?.conditions?.season;
    if(method==='surf')w*=types.includes('water')?6:.12;else if(method==='fishing')w*=types.includes('water')?5:.08;else if(method==='cave')w*=types.some(t=>['rock','ground','dark','ghost','steel'].includes(t))?4:.35;
    if(time==='night'&&types.some(t=>['dark','ghost'].includes(t)))w*=2;if(time==='morning'&&types.includes('flying'))w*=1.5;
    if(weather==='rain'&&types.some(t=>['water','electric'].includes(t)))w*=1.8;if(weather==='snow'&&types.includes('ice'))w*=2.5;if(weather==='sun'&&types.some(t=>['fire','grass'].includes(t)))w*=1.6;
    if(season==='winter'&&types.includes('ice'))w*=1.7;if(season==='summer'&&types.includes('fire'))w*=1.4;return w; };
  const ws = rows.map(W), tot = ws.reduce((a, b) => a + b, 0); if (!tot) return null;
  let x = Math.random() * tot, m = rows[0]; for (let i = 0; i < rows.length; i++) { x -= ws[i]; if (x <= 0) { m = rows[i]; break; } }
  const rng = m.is_regional ? [s?.regional_min_level ?? 10, s?.regional_max_level ?? 35] : { base: [s?.base_min_level ?? 3, s?.base_max_level ?? 10], middle: [s?.middle_min_level ?? 10, s?.middle_max_level ?? 25], final: [s?.final_min_level ?? 25, s?.final_max_level ?? 50], none: [s?.none_min_level ?? 5, s?.none_max_level ?? 30] }[m.evolution_stage] || [3, 10];
  const lv = E.rnd(Math.min(...rng), Math.max(...rng));
  const iv = { hp: E.rnd(0, 31), attack: E.rnd(0, 31), defense: E.rnd(0, 31), sp_attack: E.rnd(0, 31), sp_defense: E.rnd(0, 31), speed: E.rnd(0, 31) };
  const nature=P.randomNature(),st = E.calcStats(m, lv, iv,{},nature.key), shiny = Math.random() < 1 / 512;
  const ab = [[m.ability1_en, m.ability1_ja], [m.ability2_en, m.ability2_ja]].filter(a => a[0]); const ability = ab.length ? ab[E.rnd(0, ab.length - 1)] : ["none", "なし"];
  const b = E.makeBattler({ key: m.pokemon_key, name: m.display_name_ja, type1: m.type1, type2: m.type2, level: lv, hp: st.max_hp, maxHp: st.max_hp, attack: st.attack, defense: st.defense, sp_attack: st.sp_attack, sp_defense: st.sp_defense, speed: st.speed, moves: wildMoves(m.pokemon_key, lv), img: monImg(m, shiny), shiny, gender: E.pickGender(m.gender_rate, m.gender_lock), ability: ability[0] === "none" ? null : ability[0], abilityJa: ability[1] });
  b.wild = { master: m, iv, stats: st, ability, captureRate: m.capture_rate,nature };
  return b;
}
function pickRare(){
 const cats=[['legendary',12.5],['mythical',12.5],['special',25],['mega',25],['gmax',25]],n=Math.random()*100;let sum=0,cat='legendary';for(const [k,w] of cats){sum+=w;if(n<sum){cat=k;break}}
 const where={legendary:'is_legendary=1 AND is_mythical=0 AND is_default=1 AND is_mega=0 AND is_gmax=0',mythical:'is_mythical=1 AND is_default=1 AND is_mega=0 AND is_gmax=0',special:"(is_legendary=1 OR is_mythical=1) AND is_default=0 AND is_mega=0 AND is_gmax=0 AND COALESCE(form_key,'')!=''",mega:'is_mega=1',gmax:'is_gmax=1'}[cat];
 const fallback=`is_mega=1 OR is_gmax=1 OR is_legendary=1 OR is_mythical=1`;
 const m=one(`SELECT * FROM pokemon_master WHERE spawn_enabled=1 AND image_url IS NOT NULL AND (${where}) ORDER BY RANDOM() LIMIT 1`)||one(`SELECT * FROM pokemon_master WHERE spawn_enabled=1 AND image_url IS NOT NULL AND (${fallback}) ORDER BY RANDOM() LIMIT 1`);if(!m)return null;
 const lv=E.rnd(70,100),iv=Object.fromEntries(P.STATS.map(k=>[k,E.rnd(20,31)])),nature=P.randomNature(),st=E.calcStats(m,lv,iv,{},nature.key),shiny=Math.random()<1/512;
 const pool=[[m.ability1_en,m.ability1_ja],[m.ability2_en,m.ability2_ja],[m.hidden_ability_en,m.hidden_ability_ja]].filter(x=>x[0]),ability=pool.length?pool[E.rnd(0,pool.length-1)]:[null,null];
 const b=E.makeBattler({key:m.pokemon_key,name:m.display_name_ja,type1:m.type1,type2:m.type2,level:lv,...st,hp:st.max_hp,maxHp:st.max_hp,moves:wildMoves(m.pokemon_key,lv),img:monImg(m,shiny),shiny,gender:E.pickGender(m.gender_rate,m.gender_lock),ability:ability[0],abilityJa:ability[1],nature:nature.key});
 b.wild={master:m,iv,stats:st,ability,captureRate:m.capture_rate,nature,rareCategory:cat};return b;
}

// ---------------- NPCのパーティ ----------------
function npcMon(m, lv, perfect) {
  const iv = () => perfect ? 31 : E.rnd(0, 31);
  const st = E.calcStats(m, lv, { hp: iv(), attack: iv(), defense: iv(), sp_attack: iv(), sp_defense: iv(), speed: iv() });
  const abp = [[m.ability1_en, m.ability1_ja], [m.ability2_en, m.ability2_ja]].filter(a => a[0]), ab = abp.length ? abp[E.rnd(0, abp.length - 1)] : [null, null];   // 元botと同じく通常特性からランダム
  const b = E.makeBattler({ ability: ab[0], abilityJa: ab[1], key: m.pokemon_key, name: m.display_name_ja, type1: m.type1, type2: m.type2, level: lv, ...st, hp: st.max_hp, maxHp: st.max_hp, moves: wildMoves(m.pokemon_key, lv), img: monImg(m, false), shiny: false, gender: E.pickGender(m.gender_rate, m.gender_lock) });
  b.species = m.species_id; return b;
}
function trainerParty(region, rank) {
  const q = st => all(`SELECT * FROM pokemon_master WHERE region_name_ja = ? AND evolution_stage IN (${st}) AND (is_default = 1 OR is_regional = 1) AND is_mega = 0 AND is_gmax = 0 AND is_legendary = 0 AND is_mythical = 0 AND is_ultra_beast = 0`, region);
  let rows, lr;
  if (rank === 0) { rows = q("'base','none'"); lr = [5, 15]; } else if (rank === 1) { rows = q("'middle','none'"); lr = [16, 30]; } else if (rank === 2) { rows = q("'final','none'"); lr = [31, 60]; } else { rows = q("'final'"); lr = [70, 100]; }
  if (!rows.length) rows = all("SELECT * FROM pokemon_master WHERE region_name_ja = ? AND (is_default = 1 OR is_regional = 1) AND is_legendary = 0 AND is_mythical = 0", region);
  if (!rows.length) return [];
  return Array.from({ length: 3 }, () => npcMon(rows[E.rnd(0, rows.length - 1)], E.rnd(lr[0], lr[1]), false));
}
function gymParty(leaderId, special) {
  const rows = all(`SELECT t.level lv, m.* FROM ${special ? "special_gym_leader_teams" : "gym_leader_teams"} t JOIN pokemon_master m ON t.pokemon_key = m.pokemon_key WHERE t.leader_id = ? ORDER BY t.is_ace ASC, t.id ASC`, leaderId);
  return rows.map(r => npcMon(r, r.lv, true));
}

// ---------------- バトル ----------------
const battles = new Map();   // uid → battle
const battleItems=(g,uid)=>all("SELECT v.item_key k,v.qty,i.name_ja n FROM inventory v JOIN pokemon_items_master i ON i.item_key=v.item_key WHERE v.guild_id=? AND v.user_id=? AND v.qty>0 AND i.item_type IN ('medicine','battle') AND v.item_key NOT IN ('ether','max-ether','elixir','max-elixir') ORDER BY i.item_type,i.item_id",BigInt(g),BigInt(uid));
const view = (S, ev, extra = {}) => ({ kind: S.kind, foe: S.foe || null, eleft: S.eparty ? S.eparty.filter(b => b.hp > 0).length : null, etotal: S.eparty ? S.eparty.length : null, events: ev, p: E.pub(S.party[S.active]), e: E.pub(S.enemy), moves: S.party[S.active].moves.map(E.mPub), party: S.party.map((b, i) => ({ ...E.pub(b), idx: i, active: i === S.active })),items:battleItems(S.g,S.uid), needSwitch: !!S.needSwitch, fld: S.fld ? { w: S.fld.weather, t: S.fld.terrain, r: S.fld.trick_room > 0 } : null, scene:S.scene||null, fromWorld:!!S.fromWorld, over: S.over || null, ...extra });
const markSeen = (G, U, key, sp) => run(`INSERT INTO user_pokedex (guild_id,user_id,pokemon_key,species_id,seen_count,first_seen_at) VALUES (?,?,?,?,1,strftime('%s','now')) ON CONFLICT(guild_id,user_id,pokemon_key) DO UPDATE SET seen_count=seen_count+1`, G, U, key, sp);
function loadParty(G, U, groupId) {
  const grp = one("SELECT group_id FROM pokemon_user_groups WHERE group_id = ? AND guild_id = ? AND user_id = ?", groupId, G, U); if (!grp) return { error: "チームが見つかりません" };
  const party = all("SELECT o.* FROM pokemon_user_group_members gm JOIN user_pokemon_owned o ON o.owned_id = gm.owned_id WHERE gm.group_id = ? ORDER BY gm.slot", groupId).map(o => loadMon(o));
  const dep = all("SELECT o.nickname, m.display_name_ja n FROM pokemon_user_group_members gm JOIN user_pokemon_owned o ON o.owned_id = gm.owned_id JOIN pokemon_master m ON m.pokemon_key = o.pokemon_key JOIN user_pokemon_farm_deposits f ON f.owned_id = o.owned_id AND f.guild_id = o.guild_id AND f.user_id = o.user_id WHERE gm.group_id = ? AND o.guild_id = ? AND o.user_id = ?", groupId, G, U);
  if (dep.length) return { error: `牧場に預けているポケモンがいます（${dep.map(d => d.nickname || d.n).join("、")}）。チームを編集してください` };   // 元botと同じ
  if (!party.length) return { error: "チームにポケモンがいません" }; party[0].fought = true; return { party };
}
function startBattle(uid, g, groupId, region, scene=null, encounter=null) {
  if (FR && FR.inBattle(uid)) return { error: "フレンドバトル中です" };
  const G = BigInt(g), U = BigInt(uid);
  const L = loadParty(G, U, groupId); if (L.error) return L;
  const enemy = pickWild(g, region, encounter); if (!enemy) return { error: "この地方には出現するポケモンがいません" };
  markSeen(G, U, enemy.key, enemy.wild.master.species_id);
  const S = { kind: "wild", g, uid, party: L.party, active: 0, enemy, region, scene, fromWorld:!!scene, encounter, turns: 0, evoTrack:{}, needSwitch: false, over: null, t: Date.now() }; battles.set(uid, S);
  const ev = [{ t: "text", msg: `野生の${enemy.name}が現れた！` }, { t: "text", msg: `ゆけっ！${L.party[0].name}！` }];
  E.battleStart(S, ev);
  return { ok: true, ...view(S, ev, { intro: true, region }) };
}
function startRare(uid,g,groupId){
 if(FR&&FR.inBattle(uid))return{error:'フレンドバトル中です'};const G=BigInt(g),U=BigInt(uid);
 const L=loadParty(G,U,groupId);if(L.error)return L;if(invQty(G,U,'rare-battle-ticket')<=0)return{error:'レアバトルチケットを持っていません'};
 const enemy=pickRare();if(!enemy)return{error:'レアポケモンのデータが見つかりません'};
 const used=run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key='rare-battle-ticket' AND qty>0",G,U);if(!used.changes)return{error:'レアバトルチケットを持っていません'};
 markSeen(G,U,enemy.key,enemy.wild.master.species_id);const S={kind:'rare',g,uid,party:L.party,active:0,enemy,region:'レアバトル',turns:0,evoTrack:{},needSwitch:false,over:null,t:Date.now()};battles.set(uid,S);
 const ev=[{t:'text',msg:'レアバトルチケットを1枚使った！'},{t:'text',msg:`レアな${enemy.name}が現れた！`},{t:'text',msg:`ゆけっ！${L.party[0].name}！`}];E.battleStart(S,ev);return{ok:true,...view(S,ev,{intro:true,region:'レアバトル',tickets:{rare:invQty(G,U,'rare-battle-ticket')}})};
}
// トレーナー／ジム／ロケット団。o = {kind, groupId, region, rank, leaderId}
function startNpc(uid, g, o) {
  if (FR && FR.inBattle(uid)) return { error: "フレンドバトル中です" };
  const G = BigInt(g), U = BigInt(uid); let foe, eparty, extra = {}, title;
  if (o.kind === "trainer") {
    const regs = all("SELECT DISTINCT region_name_ja r FROM pokemon_master WHERE region_name_ja IS NOT NULL AND region_name_ja != '' ORDER BY generation_no").map(r => r.r);
    const ri = regs.indexOf(o.region), rank = Number(o.rank); if (ri < 0 || !(rank >= 0 && rank <= 3)) return { error: "トレーナーが見つかりません" };
    foe = TRAINER_NAMES[(ri * 4 + rank) % TRAINER_NAMES.length]; eparty = trainerParty(o.region, rank); extra = { rank }; title = `ポケモントレーナー${foe}`;
  } else {
    const sp = o.kind === "rocket", l = one(`SELECT * FROM ${sp ? "special_gym_leaders" : "gym_leaders"} WHERE leader_id = ?`, String(o.leaderId)); if (!l) return { error: "対戦相手が見つかりません" };
    const done = id => !!one("SELECT 1 x FROM user_gym_progress WHERE guild_id=? AND user_id=? AND leader_id=? AND is_defeated=1", G, U, id);
    if (done(l.leader_id)) return { error: "この相手にはすでに勝利しています" };
    if (sp) { if (one("SELECT COUNT(*) c FROM user_gym_badges WHERE guild_id=? AND user_id=? AND region_name != 'team rocket'", G, U).c < 9) return { error: "伝説のロケット団に挑戦するには、9カ所全てのジムを制覇する必要があります" }; }
    else { const reg = l.leader_id.split("_")[0], next = all("SELECT leader_id FROM gym_leaders WHERE leader_id LIKE ? ORDER BY order_index", reg + "_%").find(x => !done(x.leader_id)); if (next?.leader_id !== l.leader_id) return { error: "先に前のジムリーダーを倒してください" }; }
    foe = l.name_ja; eparty = gymParty(l.leader_id, sp); extra = { leaderId: l.leader_id, badge: l.badge_name, gym: l.gym_name }; title = sp ? `伝説のロケット団の${foe}` : `ジムリーダーの${foe}`;
  }
  if (!eparty.length) return { error: "相手のポケモンが見つかりません" };
  const L = loadParty(G, U, Number(o.groupId)); if (L.error) return L;
  markSeen(G, U, eparty[0].key, eparty[0].species);
  const S = { kind: o.kind, g, uid, party: L.party, active: 0, eparty, ei: 0, enemy: eparty[0], foe, region: o.region || null, scene:o.scene||null, fromWorld:!!o.scene, evoTrack:{}, ...extra, needSwitch: false, over: null, t: Date.now() }; battles.set(uid, S);
  const ev = [{ t: "text", msg: `${title}が勝負を仕掛けてきた！` }, { t: "text", msg: `${foe}は${eparty[0].name}を繰り出した！` }, { t: "text", msg: `ゆけっ！${L.party[0].name}！` }];
  E.battleStart(S, ev);
  return { ok: true, ...view(S, ev, { intro: true, region: o.region || null, title }) };
}

// 経験値を配る（元のbotのadd_exp_to_owned_pokemonと同じ：累計経験値で判定し、上がったレベルの間の技を覚える）
function awardExp(ids, gain) {
  const results = [];
  for (const id of ids) {
    const o = one("SELECT o.*, m.base_hp,m.base_attack,m.base_defense,m.base_sp_attack,m.base_sp_defense,m.base_speed, m.display_name_ja dn FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key=o.pokemon_key WHERE o.owned_id = ?", id); if (!o) continue;
    const growth=P.growthType(o);let lv = o.level; const exp = o.exp + gain; while (lv < 100 && exp >= P.expFor(lv + 1,growth)) lv++;
    const st = E.calcStats(o, lv, { hp: o.iv_hp, attack: o.iv_attack, defense: o.iv_defense, sp_attack: o.iv_sp_attack, sp_defense: o.iv_sp_defense, speed: o.iv_speed });
    const hp=Math.max(0,Math.min(st.max_hp,(o.hp??o.max_hp)+(st.max_hp-o.max_hp)));
    run("UPDATE user_pokemon_owned SET level=?, exp=?, hp=?, max_hp=?, attack=?, defense=?, sp_attack=?, sp_defense=?, speed=? WHERE owned_id=?", lv, exp, hp, st.max_hp, st.attack, st.defense, st.sp_attack, st.sp_defense, st.speed, o.owned_id);
    const learned = [];
    if (lv > o.level) {
      const key = all("SELECT 1 FROM pokemon_learnset WHERE pokemon_key=? LIMIT 1", o.pokemon_key).length ? o.pokemon_key : "S:" + o.species_id;
      let slot = (one("SELECT COALESCE(MAX(slot),0) s FROM owned_pokemon_moves WHERE owned_id=?", o.owned_id).s) + 1,active=one("SELECT COUNT(*) c FROM owned_pokemon_moves WHERE owned_id=? AND active=1",o.owned_id).c;
      for (const m of all("SELECT DISTINCT m.move_id, m.name_ja, l.learn_level FROM pokemon_learnset l JOIN pokemon_moves_master m ON m.move_id=l.move_id WHERE l.pokemon_key=? AND l.learn_method='level-up' AND l.learn_level>? AND l.learn_level<=? ORDER BY l.learn_level, m.move_id", key, o.level, lv))
        if (!one("SELECT 1 FROM owned_pokemon_moves WHERE owned_id=? AND move_id=?", o.owned_id, m.move_id)) {const pp=one("SELECT pp FROM pokemon_moves_master WHERE move_id=?",m.move_id)?.pp||10,isActive=active<4?1:0;run("INSERT INTO owned_pokemon_moves (owned_id,slot,move_id,active,current_pp,max_pp) VALUES (?,?,?,?,?,?)", o.owned_id, slot++, m.move_id,isActive,pp,pp);if(isActive)active++; learned.push(m.name_ja+(isActive?'':'（思い出し候補）')); }
    }
    if(lv>o.level)raiseFriendship(o.owned_id,'level',lv-o.level);
    results.push({ name: o.nickname || o.dn, from: o.level, to: lv, learned, id: o.owned_id, key: o.pokemon_key, shiny: !!o.is_shiny });
  }
  return results;
}
function awardEv(ids,master){
 const y=P.evYield(master),out=[];for(const id of ids){const o=one("SELECT o.*,m.base_hp,m.base_attack,m.base_defense,m.base_sp_attack,m.base_sp_defense,m.base_speed,m.raw_species_json FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key=o.pokemon_key WHERE o.owned_id=?",id);if(!o)continue;
  const cur=Object.fromEntries(P.STATS.map(k=>[k,o['ev_'+k]||0])),next=P.applyEv(cur,y),changed=P.STATS.filter(k=>next[k]!==cur[k]);if(!changed.length)continue;
  const st=E.calcStats(o,o.level,{hp:o.iv_hp,attack:o.iv_attack,defense:o.iv_defense,sp_attack:o.iv_sp_attack,sp_defense:o.iv_sp_defense,speed:o.iv_speed},next,o.nature_key),hp=Math.max(0,Math.min(st.max_hp,(o.hp??o.max_hp)+(st.max_hp-o.max_hp)));
  run(`UPDATE user_pokemon_owned SET ${P.STATS.map(k=>'ev_'+k+'=?').join(',')},hp=?,max_hp=?,attack=?,defense=?,sp_attack=?,sp_defense=?,speed=? WHERE owned_id=?`,...P.STATS.map(k=>next[k]),hp,st.max_hp,st.attack,st.defense,st.sp_attack,st.sp_defense,st.speed,id);out.push({id,gained:Object.fromEntries(changed.map(k=>[k,next[k]-cur[k]]))});
 }return out;
}
// ---------------- 進化（全条件を evolution.cjs で共通判定） ----------------
const pendingEvo = new Map();   // uid → Map(owned_id → 進化ルール)。サーバーが覚えている個体だけが進化できる
const evoRules=key=>all("SELECT e.*,m.display_name_ja to_name,m.image_url to_image_url,m.shiny_image_url to_shiny_url FROM pokemon_evolution_rules e JOIN pokemon_master m ON m.pokemon_key=e.to_pokemon_key WHERE e.from_pokemon_key=? ORDER BY e.id",key);
function evoProgress(id){const p=one("SELECT * FROM web_evolution_progress WHERE owned_id=?",id)||{friendship:70,battle_count:0,critical_hits:0,damage_taken:0,recoil_damage:0,move_uses_json:'{}',luxury:0};let uses={};try{uses=JSON.parse(p.move_uses_json||'{}')}catch{}return{...p,moveUses:Object.values(uses).reduce((a,n)=>a+(Number(n)||0),0),uses}}
function raiseFriendship(id,cause,times=1){const o=one("SELECT held_item_key FROM user_pokemon_owned WHERE owned_id=?",id);let p=evoProgress(id),v=Number(p.friendship??70);for(let i=0;i<times;i++){let d=['level','vitamin'].includes(cause)?(v<100?5:v<200?3:2):P.friendshipDelta(cause);if(d>0&&p.luxury)d++;if(d>0&&o?.held_item_key==='soothe-bell')d=Math.max(1,Math.floor(d*1.5));v=Math.max(0,Math.min(255,v+d))}run(`INSERT INTO web_evolution_progress(owned_id,friendship,luxury,updated_at) VALUES(?,?,?,strftime('%s','now')) ON CONFLICT(owned_id) DO UPDATE SET friendship=excluded.friendship,updated_at=excluded.updated_at`,id,v,p.luxury||0);return v}
function evoContext(G,U,o,extra={}){
 const owned=all("SELECT o.species_id,m.name_en,m.type1,m.type2 FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key=o.pokemon_key WHERE o.guild_id=? AND o.user_id=?",G,U),hour=new Date(Date.now()+9*3600000).getUTCHours();
 return{trigger:'manual',hour,money:moneyOf(G,U),progress:evoProgress(o.owned_id),moves:all("SELECT m.name_en en,m.type FROM owned_pokemon_moves x JOIN pokemon_moves_master m ON m.move_id=x.move_id WHERE x.owned_id=?",o.owned_id),inventory:new Set(all("SELECT item_key FROM inventory WHERE guild_id=? AND user_id=? AND qty>0",G,U).map(x=>x.item_key)),partySpecies:owned.flatMap(x=>[x.species_id,x.name_en]).filter(Boolean),partyTypes:[...new Set(owned.flatMap(x=>[x.type1,x.type2]).filter(Boolean))],region:extra.region||evoProgress(o.owned_id).last_region,weather:extra.weather||evoProgress(o.owned_id).last_weather,...extra};
}
function evoMon(o){return{level:o.level,gender:o.gender,attack:o.attack,defense:o.defense}}
function evolutionStatus(g,uid,ownedId){const G=BigInt(g),U=BigInt(uid),id=Math.floor(Number(ownedId)),o=one("SELECT * FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?",id,G,U);if(!o)return{error:'ポケモンが見つかりません'};const from=one("SELECT display_name_ja n,image_url,shiny_image_url FROM pokemon_master WHERE pokemon_key=?",o.pokemon_key)||{};const ctx=evoContext(G,U,o);return{ok:true,ownedId:id,name:o.nickname||from.n||o.pokemon_key,friendship:ctx.progress.friendship,rules:evoRules(o.pokemon_key).map(r=>{const c=EV.check(r,evoMon(o),ctx),actionReady=!!c.action&&c.missing.every(x=>['spin','tower','rotate'].includes(x.code));return{id:r.id,toName:r.to_name,toImg:monImg({image_url:r.to_image_url,shiny_image_url:r.to_shiny_url},o.is_shiny),ok:c.ok,ready:c.ok||actionReady,missing:c.missing,trigger:c.triggerJa,action:c.action}})}}
function collectEvo(uid, results) {
  const m = new Map(), out = [];
  for (const r of results) {
    if (!(r.to > r.from)) continue;
    const o=one("SELECT * FROM user_pokemon_owned WHERE owned_id=?",r.id);if(!o)continue;const G=BigInt(o.guild_id),U=BigInt(o.user_id),ctx=evoContext(G,U,o,{trigger:'level-up'});
    const eligible=evoRules(r.key).filter(x=>EV.check(x,evoMon(o),ctx).ok),byTarget=new Map(eligible.map(x=>[x.to_pokemon_key,x]));
    // 分岐先が複数ある場合は勝手に先頭を選ばず、個体詳細で選ばせる。
    if (byTarget.size!==1) continue;
    const e=byTarget.values().next().value;
    const from = one("SELECT * FROM pokemon_master WHERE pokemon_key = ?", r.key) || {};
    m.set(r.id, e);
    out.push({ ownedId: r.id, name: r.name, toName: e.to_name, fromImg: monImg(from, r.shiny), toImg: monImg({ image_url: e.to_image_url, shiny_image_url: e.to_shiny_url }, r.shiny) });
  }
  if (m.size) pendingEvo.set(uid, m); else pendingEvo.delete(uid);
  return out;
}
// 進化の実処理（レベル進化・石進化で共通。元botの evolve_owned_pokemon と同じ）
function applyEvolution(G, U, ownedId, rule) {
  const o = one("SELECT * FROM user_pokemon_owned WHERE owned_id = ? AND guild_id = ? AND user_id = ?", ownedId, G, U); if (!o) return { error: "ポケモンが見つかりません" };
  const to = one("SELECT * FROM pokemon_master WHERE pokemon_key = ?", rule.to_pokemon_key); if (!to) return { error: "進化先が見つかりません" };
  const st = E.calcStats(to, o.level, { hp: o.iv_hp, attack: o.iv_attack, defense: o.iv_defense, sp_attack: o.iv_sp_attack, sp_defense: o.iv_sp_defense, speed: o.iv_speed },Object.fromEntries(P.STATS.map(k=>[k,o['ev_'+k]||0])),o.nature_key);
  const pool = [[to.ability1_en, to.ability1_ja], [to.ability2_en, to.ability2_ja]].filter(a => a[0]), ab = pool.length ? pool[E.rnd(0, pool.length - 1)] : ["none", "なし"];   // 進化後の特性は再抽選（元botと同じ）
  const col = o.is_shiny ? "shiny_caught" : "normal_caught";
  run("UPDATE user_pokemon_owned SET pokemon_key=?, species_id=?, hp=?, max_hp=?, attack=?, defense=?, sp_attack=?, sp_defense=?, speed=?, image_url=?, ability_en=?, ability_ja=? WHERE owned_id=?", to.pokemon_key, to.species_id, st.max_hp, st.max_hp, st.attack, st.defense, st.sp_attack, st.sp_defense, st.speed, to.image_url, ab[0], ab[1], ownedId);
  run(`INSERT INTO user_pokedex (guild_id,user_id,pokemon_key,species_id,seen_count,caught_count,normal_caught,shiny_caught,first_seen_at,first_caught_at) VALUES (?,?,?,?,1,1,?,?,strftime('%s','now'),strftime('%s','now')) ON CONFLICT(guild_id,user_id,pokemon_key) DO UPDATE SET seen_count=seen_count+1, caught_count=caught_count+1, ${col}=${col}+1`, G, U, to.pokemon_key, to.species_id, o.is_shiny ? 0 : 1, o.is_shiny ? 1 : 0);
  let shed=null;const sr=evoRules(o.pokemon_key).find(x=>EV.detail(x).trigger==='shed');
  if(sr&&invQty(G,U,'poke-ball')>0){const gr=one("SELECT g.group_id,(SELECT COUNT(*) FROM pokemon_user_group_members z WHERE z.group_id=g.group_id) c FROM pokemon_user_group_members gm JOIN pokemon_user_groups g ON g.group_id=gm.group_id WHERE gm.owned_id=? AND g.guild_id=? AND g.user_id=? AND (SELECT COUNT(*) FROM pokemon_user_group_members z WHERE z.group_id=g.group_id)<3 ORDER BY g.group_id LIMIT 1",ownedId,G,U),sm=one("SELECT * FROM pokemon_master WHERE pokemon_key=?",sr.to_pokemon_key);if(gr&&sm){const ev=Object.fromEntries(P.STATS.map(k=>[k,o['ev_'+k]||0])),ss=E.calcStats(sm,o.level,{hp:o.iv_hp,attack:o.iv_attack,defense:o.iv_defense,sp_attack:o.iv_sp_attack,sp_defense:o.iv_sp_defense,speed:o.iv_speed},ev,o.nature_key),sa=[[sm.ability1_en,sm.ability1_ja],[sm.ability2_en,sm.ability2_ja]].find(x=>x[0])||['none','なし'];ss.max_hp=1;const z=run(`INSERT INTO user_pokemon_owned(guild_id,user_id,pokemon_key,species_id,level,exp,gender,is_shiny,hp,max_hp,attack,defense,sp_attack,sp_defense,speed,iv_hp,iv_attack,iv_defense,iv_sp_attack,iv_sp_defense,iv_speed,image_url,obtained_type,caught_at,ability_key,ability_name_ja,ability_en,ability_ja) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'evolution',strftime('%s','now'),?,?,?,?)`,G,U,sm.pokemon_key,sm.species_id,o.level,o.exp,'genderless',o.is_shiny,1,1,ss.attack,ss.defense,ss.sp_attack,ss.sp_defense,ss.speed,o.iv_hp,o.iv_attack,o.iv_defense,o.iv_sp_attack,o.iv_sp_defense,o.iv_speed,sm.image_url,sa[0],sa[1],sa[0],sa[1]),sid=Number(z.lastInsertRowid);run(`UPDATE user_pokemon_owned SET nature_key=?,nature_name_ja=?,${P.STATS.map(k=>'ev_'+k+'=?').join(',')},original_trainer_id=?,original_trainer_name=?,origin_region=?,ribbons_json=?,marks_json=? WHERE owned_id=?`,o.nature_key,o.nature_name_ja,...P.STATS.map(k=>ev[k]),o.original_trainer_id,o.original_trainer_name,o.origin_region,o.ribbons_json||'[]',o.marks_json||'[]',sid);run("INSERT INTO owned_pokemon_moves(owned_id,slot,move_id,active,current_pp,max_pp) SELECT ?,slot,move_id,active,current_pp,max_pp FROM owned_pokemon_moves WHERE owned_id=?",sid,ownedId);run("INSERT INTO pokemon_user_group_members(group_id,owned_id,slot) VALUES(?,?,?)",gr.group_id,sid,gr.c+1);run(`INSERT INTO user_pokedex (guild_id,user_id,pokemon_key,species_id,seen_count,caught_count,normal_caught,shiny_caught,first_seen_at,first_caught_at) VALUES (?,?,?,?,1,1,?,?,strftime('%s','now'),strftime('%s','now')) ON CONFLICT(guild_id,user_id,pokemon_key) DO UPDATE SET seen_count=seen_count+1,caught_count=caught_count+1,${col}=${col}+1`,G,U,sm.pokemon_key,sm.species_id,o.is_shiny?0:1,o.is_shiny?1:0);run("INSERT OR IGNORE INTO web_evolution_progress(owned_id,friendship,updated_at) VALUES(?,70,strftime('%s','now'))",sid);run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key='poke-ball'",G,U);shed={name:sm.display_name_ja,img:monImg(sm,o.is_shiny),ownedId:sid}}}
  return { ok: true, name: to.display_name_ja, img: monImg(to, o.is_shiny), level: o.level, hp: st.max_hp, attack: st.attack, defense: st.defense, sp_attack: st.sp_attack, sp_defense: st.sp_defense, speed: st.speed, shed };
}
function evolve(uid, g, ownedId, yes) {
  const m = pendingEvo.get(uid), rule = m?.get(ownedId); if (!rule) return { error: "進化できるポケモンがいません" };
  m.delete(ownedId); if (!m.size) pendingEvo.delete(uid);
  if (!yes) return { ok: true, cancelled: true };
  return tx(() => applyEvolution(BigInt(g), BigInt(uid), ownedId, rule));
}
function evolveManual(g,uid,ownedId,ruleId,action){
 if(hasActiveBattle(uid))return{error:'バトル中は進化できません'};
 const G=BigInt(g),U=BigInt(uid),id=Math.floor(Number(ownedId)),o=one("SELECT * FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?",id,G,U);if(!o)return{error:'ポケモンが見つかりません'};
 const rule=evoRules(o.pokemon_key).find(r=>r.id===Number(ruleId));if(!rule)return{error:'進化先が見つかりません'};
 const c=EV.check(rule,evoMon(o),evoContext(G,U,o,{trigger:'manual',action:String(action||'')}));if(!c.ok)return{error:'進化条件が足りません：'+c.missing.map(x=>x.text).join('、')};
 return tx(()=>{if(c.consume){if(invQty(G,U,c.consume)<=0)return{error:'必要なアイテムがありません'};run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key=?",G,U,c.consume)}if(c.consumeMoney){if(moneyOf(G,U)<c.consumeMoney)return{error:'必要なお金が足りません'};run("UPDATE users SET money=money-? WHERE guild_id=? AND user_id=?",c.consumeMoney,G,U)}return applyEvolution(G,U,id,rule)});
}
function evolveTrade(G,U,ownedId,tradeSpecies,itemOwner=U){
 const o=one("SELECT * FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?",ownedId,G,U);if(!o)return null;
 const ctx=evoContext(G,U,o,{trigger:'trade',tradeSpecies,inventory:new Set(all("SELECT item_key FROM inventory WHERE guild_id=? AND user_id=? AND qty>0",G,itemOwner).map(x=>x.item_key))}),rules=evoRules(o.pokemon_key);
 for(const rule of rules){const c=EV.check(rule,evoMon(o),ctx);if(!c.ok||c.detail.trigger!=='trade')continue;if(c.consume){if(invQty(G,itemOwner,c.consume)<=0)continue;run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key=?",G,itemOwner,c.consume)}return applyEvolution(G,U,ownedId,rule)}
 return null;
}

// ---------------- ショップ・バッグ・わざマシン・進化の石（元botのショップ／アイテム進化／わざマシンと同じ仕様） ----------------
// 元botのショップは ball / medicine / tm / berry / evolution / misc の6種。このうち、元botでも使い道があるのは
// ボール（捕獲）・わざマシン（技の習得）・進化の石（アイテム進化）だけなので、この3種を扱う。
const SHOP_TYPES = ["ball", "tm", "evolution","medicine","battle","held","berry"];
let R;
const pveActive = uid => { const b = battles.get(uid); return !!(b && !b.over); };
const hasActiveBattle = uid => pveActive(uid) || !!R?.busy(uid) || !!(FR && FR.inBattle(uid));   // レイド・フレンドバトル中も、買い物・預け入れ・交換等を断る
const invQty = (G, U, key) => one("SELECT qty FROM inventory WHERE guild_id=? AND user_id=? AND item_key=?", G, U, key)?.qty || 0;
const moneyOf = (G, U) => one("SELECT money FROM users WHERE guild_id=? AND user_id=?", G, U)?.money ?? 0;
const ballsOf = (G, U) => Object.fromEntries(all(`SELECT item_key k, qty FROM inventory WHERE guild_id = ? AND user_id = ? AND qty > 0 AND item_key IN (${PB.keys.map(()=>'?').join(',')})`, G, U, ...PB.keys).map(r => [r.k, r.qty]));
const clip = (t, n) => { t = String(t || "").replace(/\s+/g, " ").trim(); return t.length > n ? t.slice(0, n - 1) + "…" : t; };
function shopList(g, uid) {
  const G = BigInt(g), U = BigInt(uid);
  const items = all(`SELECT i.item_key, i.name_ja, i.item_type, i.buy_price, i.flavor_text_ja, i.effect_ja, td.move_key, mm.name_ja AS move_ja, mm.type AS move_type, mm.power AS move_power, mm.accuracy AS move_acc
    FROM pokemon_items_master i LEFT JOIN pokemon_tm_data td ON td.item_key = i.item_key LEFT JOIN pokemon_moves_master mm ON mm.name_en = td.move_key
    WHERE i.item_type IN ('ball','tm','evolution','medicine','battle','held','berry') AND i.is_shop_item = 1 AND i.buy_price > 0 ORDER BY i.item_type,i.buy_price ASC, i.item_id ASC`);
  const have = Object.fromEntries(all("SELECT item_key k, qty FROM inventory WHERE guild_id=? AND user_id=? AND qty>0", G, U).map(r => [r.k, r.qty]));
  return { money: moneyOf(G, U), items: items.map(i => {const ball=i.item_type==='ball',p=ball?PB.profile(i.item_key):null;return { key: i.item_key, name: i.name_ja || p?.name || i.item_key, type: i.item_type, price: i.buy_price, desc: p?.effect||clip(i.flavor_text_ja || i.effect_ja, 90), supported:!ball||!!p, unsupported:ball&&!p?(PB.UNSUPPORTED[i.item_key]||'現在の野生戦では効果条件を判定できません'):null, partial:!!p?.partial, have: have[i.item_key] || 0, move: i.move_ja ? { name: i.move_ja, type: i.move_type, power: i.move_power, acc: i.move_acc } : null }} ) };
}
function buyItem(g, uid, key, qty) {
  if (hasActiveBattle(uid)) return { error: "バトル中は買い物できません" };
  qty = Math.floor(Number(qty)); if (!(qty >= 1 && qty <= 999)) return { error: "個数は1〜999で指定してください" };
  const G = BigInt(g), U = BigInt(uid);
  const it = one("SELECT * FROM pokemon_items_master WHERE item_key = ?", String(key));
  if (!it || !SHOP_TYPES.includes(it.item_type) || !it.is_shop_item || !(it.buy_price > 0)) return { error: "その商品は売っていません" };   // 売り物かどうかはサーバーが判断する
  if (it.item_type === 'ball' && !PB.supported(it.item_key)) return { error: PB.UNSUPPORTED[it.item_key] || "このボールは現在の野生戦では使えません" };
  const cost = it.buy_price * qty;
  return tx(() => {
    const money = moneyOf(G, U); if (money < cost) return { error: "所持金が足りません" };
    run("UPDATE users SET money = money - ? WHERE guild_id=? AND user_id=?", cost, G, U);
    run("INSERT INTO inventory (guild_id,user_id,item_key,qty) VALUES (?,?,?,?) ON CONFLICT(guild_id,user_id,item_key) DO UPDATE SET qty = qty + excluded.qty", G, U, it.item_key, qty);
    return { ok: true, name: it.name_ja || it.item_key, qty, cost, money: money - cost, have: invQty(G, U, it.item_key), balls: ballsOf(G, U) };
  });
}
function bagList(g, uid) {
  const G = BigInt(g), U = BigInt(uid);
  const rows = all(`SELECT v.item_key, v.qty, i.name_ja, i.item_type, i.flavor_text_ja, i.effect_ja, td.move_key, mm.name_ja AS move_ja, mm.type AS move_type, mm.power AS move_power, mm.accuracy AS move_acc
    FROM inventory v JOIN pokemon_items_master i ON i.item_key = v.item_key LEFT JOIN pokemon_tm_data td ON td.item_key = v.item_key LEFT JOIN pokemon_moves_master mm ON mm.name_en = td.move_key
    WHERE v.guild_id=? AND v.user_id=? AND v.qty > 0 ORDER BY i.item_type, i.item_id`, G, U);
  return { money: moneyOf(G, U), items: rows.map(i => {const p=i.item_type==='ball'?PB.profile(i.item_key):null;return { key: i.item_key, name: i.name_ja || p?.name || i.item_key, type: i.item_type, qty: i.qty, desc:p?.effect||clip(i.flavor_text_ja || i.effect_ja,90), supported:i.item_type!=='ball'||!!p, unsupported:i.item_type==='ball'&&!p?(PB.UNSUPPORTED[i.item_key]||'現在の野生戦では使えません'):null, partial:!!p?.partial, move: i.move_ja ? { name: i.move_ja, type: i.move_type, power: i.move_power, acc: i.move_acc } : null }} ) };
}
const ownedView = o => { const m = one("SELECT display_name_ja n, image_url, shiny_image_url FROM pokemon_master WHERE pokemon_key = ?", o.pokemon_key) || {}; return { id: o.owned_id, name: o.nickname || m.n || o.pokemon_key, level: o.level, img: monImg(m, o.is_shiny), shiny: !!o.is_shiny }; };
// わざマシンを使える個体：その技を「わざマシン」で覚えられて、まだ覚えていないもの（元botと同じ条件。フォルム個体は通常種族 S:xxx の習得表も使う）
function tmTargets(g, uid, key) {
  const G = BigInt(g), U = BigInt(uid);
  const tm = one(`SELECT td.move_key, mm.move_id, mm.name_ja FROM pokemon_tm_data td JOIN pokemon_items_master i ON i.item_key = td.item_key JOIN pokemon_moves_master mm ON mm.name_en = td.move_key WHERE td.item_key = ? AND i.item_type = 'tm'`, String(key));
  if (!tm) return { error: "わざマシンではありません" };
  if (invQty(G, U, key) <= 0) return { error: "そのわざマシンを持っていません" };
  const rows = all(`SELECT o.* FROM user_pokemon_owned o WHERE o.guild_id=? AND o.user_id=?
    AND EXISTS (SELECT 1 FROM pokemon_learnset l WHERE l.move_id = ? AND l.learn_method = 'machine' AND l.pokemon_key IN (o.pokemon_key, 'S:' || o.species_id))
    AND NOT EXISTS (SELECT 1 FROM owned_pokemon_moves m WHERE m.owned_id = o.owned_id AND m.move_id = ?)
    ORDER BY o.level DESC, o.owned_id LIMIT 100`, G, U, tm.move_id, tm.move_id);
  return { ok: true, move: tm.name_ja, targets: rows.map(ownedView) };
}
function useTm(g, uid, key, ownedId) {
  if (hasActiveBattle(uid)) return { error: "バトル中は使えません" };
  const G = BigInt(g), U = BigInt(uid), id = Number(ownedId), r = tmTargets(g, uid, key); if (r.error) return r;
  if (!r.targets.some(t => t.id === id)) return { error: "そのポケモンはこの技を覚えられません" };   // 対象かどうかはサーバーが判断する
  const mv = one("SELECT mm.move_id FROM pokemon_tm_data td JOIN pokemon_moves_master mm ON mm.name_en = td.move_key WHERE td.item_key = ?", String(key));
  return tx(() => {
    if (invQty(G, U, key) <= 0) return { error: "そのわざマシンを持っていません" };
    run("UPDATE inventory SET qty = qty - 1 WHERE guild_id=? AND user_id=? AND item_key=?", G, U, key);
    const slot = (one("SELECT COALESCE(MAX(slot),0) s FROM owned_pokemon_moves WHERE owned_id=?", id).s) + 1,active=one("SELECT COUNT(*) c FROM owned_pokemon_moves WHERE owned_id=? AND active=1",id).c<4?1:0,pp=one("SELECT pp FROM pokemon_moves_master WHERE move_id=?",mv.move_id)?.pp||10;
    run("INSERT INTO owned_pokemon_moves (owned_id,slot,move_id,active,current_pp,max_pp) VALUES (?,?,?,?,?,?)", id, slot, mv.move_id,active,pp,pp);
    const t = r.targets.find(x => x.id === id); return { ok: true, name: t.name, move: r.move, waiting:!active,left: invQty(G, U, key) };
  });
}
// 進化の石：from → to のルールがその石で見つかる個体（元botの bot_trigger='use-item'。通信交換用の trade_stone は除く）
const stoneRules = (from,key) => all("SELECT * FROM pokemon_evolution_rules WHERE from_pokemon_key=? AND (api_trigger='use-item' OR bot_trigger='use-item') AND COALESCE(api_item_key,required_item_key)=? AND COALESCE(required_item_key,'')!='trade_stone' ORDER BY id",from,String(key));
function stoneTargets(g, uid, key) {
  const G = BigInt(g), U = BigInt(uid);
  const it = one("SELECT item_key FROM pokemon_items_master WHERE item_key = ? AND item_type = 'evolution'", String(key)); if (!it) return { error: "進化の石ではありません" };
  if (invQty(G, U, key) <= 0) return { error: "その石を持っていません" };
  const rows = all("SELECT o.* FROM user_pokemon_owned o WHERE o.guild_id=? AND o.user_id=? ORDER BY o.level DESC,o.owned_id LIMIT 100",G,U),targets=[];
  for(const o of rows){const ctx=evoContext(G,U,o,{trigger:'item',item:String(key)}),r=stoneRules(o.pokemon_key,key).find(x=>EV.check(x,evoMon(o),ctx).ok);if(r){const to=one("SELECT display_name_ja n FROM pokemon_master WHERE pokemon_key=?",r.to_pokemon_key);targets.push({...ownedView(o),toName:to?.n||r.to_pokemon_key})}}
  return { ok: true, targets };
}
function useStone(g, uid, key, ownedId) { try { return useStone0(g, uid, key, ownedId); } catch (e) { return { error: e.message || "進化に失敗しました" }; } }
function useStone0(g, uid, key, ownedId) {
  if (hasActiveBattle(uid)) return { error: "バトル中は使えません" };
  const G = BigInt(g), U = BigInt(uid), id = Number(ownedId);
  const o = one("SELECT * FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?", id, G, U); if (!o) return { error: "ポケモンが見つかりません" };
  const it = one("SELECT item_key FROM pokemon_items_master WHERE item_key = ? AND item_type = 'evolution'", String(key)); if (!it) return { error: "進化の石ではありません" };
  const ctx=evoContext(G,U,o,{trigger:'item',item:String(key)}),rule=stoneRules(o.pokemon_key,key).find(x=>EV.check(x,evoMon(o),ctx).ok); if (!rule) return { error: "おや？進化条件が足りないようだ…" };
  const before = ownedView(o);
  return tx(() => {
    if (invQty(G, U, key) <= 0) return { error: "その石を持っていません" };
    run("UPDATE inventory SET qty = qty - 1 WHERE guild_id=? AND user_id=? AND item_key=?", G, U, key);
    const r = applyEvolution(G, U, id, rule); if (r.error) throw new Error(r.error);
    return { ...r, fromName: before.name, fromImg: before.img, left: invQty(G, U, key) };
  });
}
// ---------------- ポケモン詳細・ボックス・チーム編集・技を忘れさせる・お別れ（元botの PokemonDetailView / PokemonMoveManageView / ReleaseConfirmView / グループ編集と同じ仕様） ----------------
const BOX_PAGE = 24, TEAM_MAX = 3, GROUP_MAX = 5;
const isDeposited = (G, U, id) => !!one("SELECT 1 x FROM user_pokemon_farm_deposits WHERE guild_id=? AND user_id=? AND owned_id=?", G, U, id);
const boxItem = o => ({ id: o.owned_id, no: o.species_id, name: o.nickname || o.dn || o.pokemon_key, level: o.level, img: monImg({ image_url: o.m_img, shiny_image_url: o.m_simg }, o.is_shiny), shiny: !!o.is_shiny, star: !!o.is_starred, gender: o.gender || null, dep: !!o.dep });
const BOX_SEL = `SELECT o.owned_id, o.species_id, o.pokemon_key, o.nickname, o.level, o.gender, o.is_shiny, o.is_starred, m.display_name_ja dn, m.image_url m_img, m.shiny_image_url m_simg,
  EXISTS (SELECT 1 FROM user_pokemon_farm_deposits f WHERE f.owned_id = o.owned_id AND f.guild_id = o.guild_id AND f.user_id = o.user_id) dep
  FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key = o.pokemon_key`;
// ボックス一覧：名前／図鑑No／所持IDで検索（元botの検索と同じ）、⭐だけの絞り込み、並び替え
function boxList(g, uid, b) {
  const G = BigInt(g), U = BigInt(uid), where = ["o.guild_id = ?", "o.user_id = ?"], args = [G, U];
  const q = String(b.q || "").trim().slice(0, 30);
  if (q) { const like = `%${q.replace(/[\\%_]/g, c => "\\" + c)}%`; where.push("(m.display_name_ja LIKE ? ESCAPE '\\' OR o.nickname LIKE ? ESCAPE '\\' OR CAST(o.owned_id AS TEXT) LIKE ? ESCAPE '\\' OR CAST(o.species_id AS TEXT) LIKE ? ESCAPE '\\')"); args.push(like, like, like, like); }
  if (b.star) where.push("o.is_starred = 1");
  const order = { new: "o.owned_id DESC", old: "o.owned_id ASC", level: "o.level DESC, o.owned_id DESC", no: "o.species_id ASC, o.owned_id ASC" }[b.sort] || "o.owned_id DESC";
  const total = one(`SELECT COUNT(*) c FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key = o.pokemon_key WHERE ${where.join(" AND ")}`, ...args).c;
  const pages = Math.max(1, Math.ceil(total / BOX_PAGE)), page = Math.max(0, Math.min(pages - 1, Math.floor(Number(b.page)) || 0));
  const rows = all(`${BOX_SEL} WHERE ${where.join(" AND ")} ORDER BY ${order} LIMIT ${BOX_PAGE} OFFSET ${page * BOX_PAGE}`, ...args);
  const all_ = one("SELECT COUNT(*) c FROM user_pokemon_owned WHERE guild_id=? AND user_id=?", G, U).c;
  return { total, all: all_, page, pages, items: rows.map(boxItem) };
}
// チーム編集の候補（牧場に預けているポケモンは入れられない）
function teamCandidates(g, uid, b) {
  const r = boxList(g, uid, { ...b, sort: b.sort || "level" }); r.items = r.items.filter(x => !x.dep); return r;
}
function monDetail(g, uid, ownedId) {
  const G = BigInt(g), U = BigInt(uid), id = Math.floor(Number(ownedId));
  const o = one("SELECT * FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?", id, G, U); if (!o) return { error: "ポケモンが見つかりません" };
  const m = one("SELECT * FROM pokemon_master WHERE pokemon_key = ?", o.pokemon_key) || {};
  const moves = all("SELECT om.slot,om.active,om.current_pp,om.max_pp,mm.* FROM owned_pokemon_moves om JOIN pokemon_moves_master mm ON mm.move_id = om.move_id WHERE om.owned_id = ? ORDER BY om.active DESC,om.slot", id)
    .map(x => ({ slot: x.slot,active:!!x.active, id: x.move_id, name: x.name_ja || x.name_en, type: x.type, power: x.power, acc: x.accuracy, pp:x.current_pp,maxpp:x.max_pp, cls: x.damage_class, desc: clip(x.effect_ja || x.flavor_text_ja, 80) }));
  const growth=P.growthType(m),nextExp = o.level < 100 ? P.expFor(o.level + 1,growth) : null,nat=P.nature(o.nature_key),friend=evoProgress(id).friendship;
  const held=o.held_item_key?one("SELECT item_key,name_ja FROM pokemon_items_master WHERE item_key=?",o.held_item_key):null,heldOptions=all("SELECT v.item_key,v.qty,i.name_ja,i.item_type FROM inventory v JOIN pokemon_items_master i ON i.item_key=v.item_key WHERE v.guild_id=? AND v.user_id=? AND v.qty>0 AND i.item_type IN ('held','berry') ORDER BY i.item_type,i.name_ja",G,U);
  const ppItems=all("SELECT v.item_key,v.qty,i.name_ja FROM inventory v JOIN pokemon_items_master i ON i.item_key=v.item_key WHERE v.guild_id=? AND v.user_id=? AND v.qty>0 AND v.item_key IN ('ether','max-ether','elixir','max-elixir')",G,U),vitamins=all("SELECT v.item_key,v.qty,i.name_ja FROM inventory v JOIN pokemon_items_master i ON i.item_key=v.item_key WHERE v.guild_id=? AND v.user_id=? AND v.qty>0 AND i.item_type='vitamin' ORDER BY i.item_id",G,U);
  const teams = all("SELECT g.group_name FROM pokemon_user_group_members gm JOIN pokemon_user_groups g ON g.group_id = gm.group_id WHERE gm.owned_id = ? AND g.guild_id = ? AND g.user_id = ?", id, G, U).map(r => r.group_name);
  const otId=String(o.original_trainer_id||o.user_id||''),storedOt=String(o.original_trainer_name||'').trim(),otName=(storedOt&&storedOt!==otId?storedOt:null)||profileName(g,otId);
  return { ok: true, id, no: o.species_id, key: o.pokemon_key, name: o.nickname || m.display_name_ja || o.pokemon_key, baseName: m.display_name_ja || o.pokemon_key, level: o.level, gender: o.gender || null, shiny: !!o.is_shiny, star: !!o.is_starred,
    img: monImg(m, o.is_shiny), types: [m.type1, m.type2].filter(Boolean), typesJa: [m.type1_ja, m.type2_ja].filter(Boolean), region: m.region_name_ja || null, flavor: m.flavor_text_ja || null,
    ability: o.ability_ja || null, nature:nat,friendship:friend,how: o.obtained_type || "capture", exp: o.exp, baseExp:P.expFor(o.level,growth), nextExp,growth, dep: isDeposited(G, U, id), teams,held,heldOptions,ppItems,vitamins,
    originalTrainer:{id:otId||null,name:otName||'不明なトレーナー'},origin:o.origin_region||m.region_name_ja||null,ribbons:P.json(o.ribbons_json),marks:P.json(o.marks_json),
    stats: { hp: [o.hp, o.max_hp, o.iv_hp,o.ev_hp], attack: [o.attack, o.iv_attack,o.ev_attack], defense: [o.defense, o.iv_defense,o.ev_defense], sp_attack: [o.sp_attack, o.iv_sp_attack,o.ev_sp_attack], sp_defense: [o.sp_defense, o.iv_sp_defense,o.ev_sp_defense], speed: [o.speed, o.iv_speed,o.ev_speed] }, moves:moves.filter(x=>x.active),remember:moves.filter(x=>!x.active) };
}
function toggleStar(g, uid, ownedId) {
  const G = BigInt(g), U = BigInt(uid), id = Math.floor(Number(ownedId)), o = one("SELECT is_starred s FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?", id, G, U); if (!o) return { error: "ポケモンが見つかりません" };
  const s = o.s ? 0 : 1; run("UPDATE user_pokemon_owned SET is_starred=? WHERE owned_id=? AND guild_id=? AND user_id=?", s, id, G, U); return { ok: true, star: !!s };
}
// 技を忘れさせる（元botと同じ：最後の1つは忘れさせられない）
function forgetMove(g, uid, ownedId, slot, moveId) {
  if (hasActiveBattle(uid)) return { error: "バトル中は技を忘れさせられません" };
  const G = BigInt(g), U = BigInt(uid), id = Math.floor(Number(ownedId)); slot = Math.floor(Number(slot)); moveId = Math.floor(Number(moveId));
  if (!one("SELECT 1 x FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?", id, G, U)) return { error: "ポケモンが見つかりません" };
  return tx(() => {
    const mv = one("SELECT mm.name_ja n, mm.name_en e FROM owned_pokemon_moves om JOIN pokemon_moves_master mm ON mm.move_id = om.move_id WHERE om.owned_id=? AND om.slot=? AND om.move_id=?", id, slot, moveId);
    if (!mv) return { error: "その技は覚えていません" };
    if (one("SELECT COUNT(*) c FROM owned_pokemon_moves WHERE owned_id=? AND active=1", id).c <= 1) return { error: "最後の1つの技は忘れさせられません" };
    run("UPDATE owned_pokemon_moves SET active=0 WHERE owned_id=? AND slot=? AND move_id=?", id, slot, moveId);
    return { ok: true, move: mv.n || mv.e };
  });
}
function rememberMove(g,uid,ownedId,slot,replaceSlot){
 if(hasActiveBattle(uid))return{error:'バトル中は技を入れ替えられません'};const G=BigInt(g),U=BigInt(uid),id=Number(ownedId),sl=Number(slot),rep=Number(replaceSlot);
 if(!one("SELECT 1 FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?",id,G,U))return{error:'ポケモンが見つかりません'};
 return tx(()=>{const m=one("SELECT mm.name_ja n FROM owned_pokemon_moves om JOIN pokemon_moves_master mm ON mm.move_id=om.move_id WHERE om.owned_id=? AND om.slot=? AND om.active=0",id,sl);if(!m)return{error:'思い出せる技が見つかりません'};const c=one("SELECT COUNT(*) c FROM owned_pokemon_moves WHERE owned_id=? AND active=1",id).c;if(c>=4){if(!one("SELECT 1 FROM owned_pokemon_moves WHERE owned_id=? AND slot=? AND active=1",id,rep))return{error:'入れ替える技を選んでください'};run("UPDATE owned_pokemon_moves SET active=0 WHERE owned_id=? AND slot=?",id,rep)}run("UPDATE owned_pokemon_moves SET active=1 WHERE owned_id=? AND slot=?",id,sl);return{ok:true,move:m.n}})
}
function renameMon(g,uid,ownedId,name){
 if(hasActiveBattle(uid))return{error:'バトル中は変更できません'};const G=BigInt(g),U=BigInt(uid),id=Number(ownedId),n=String(name??'').replace(/[\r\n\t]/g,' ').trim();if(n.length>12)return{error:'ニックネームは12文字以内です'};
 const r=run("UPDATE user_pokemon_owned SET nickname=? WHERE owned_id=? AND guild_id=? AND user_id=?",n||null,id,G,U);return r.changes?{ok:true,name:n||null}:{error:'ポケモンが見つかりません'}
}
function setHeld(g,uid,ownedId,key){
 if(hasActiveBattle(uid))return{error:'バトル中は持ち物を変更できません'};const G=BigInt(g),U=BigInt(uid),id=Number(ownedId),k=String(key||'');return tx(()=>{const o=one("SELECT held_item_key FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?",id,G,U);if(!o)return{error:'ポケモンが見つかりません'};if(k){const it=one("SELECT item_key,name_ja,item_type FROM pokemon_items_master WHERE item_key=? AND item_type IN ('held','berry')",k);if(!it||invQty(G,U,k)<=0)return{error:'持たせられるアイテムがありません'};run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key=?",G,U,k)}if(o.held_item_key)run("INSERT INTO inventory(guild_id,user_id,item_key,qty) VALUES(?,?,?,1) ON CONFLICT(guild_id,user_id,item_key) DO UPDATE SET qty=qty+1",G,U,o.held_item_key);run("UPDATE user_pokemon_owned SET held_item_key=? WHERE owned_id=?",k||null,id);return{ok:true,held:k||null}})
}
// この個体が覚えられて、まだ覚えていない、持っているわざマシン
function monTms(g, uid, ownedId) {
  const G = BigInt(g), U = BigInt(uid), id = Math.floor(Number(ownedId)), o = one("SELECT pokemon_key, species_id FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?", id, G, U); if (!o) return { error: "ポケモンが見つかりません" };
  const rows = all(`SELECT v.item_key, v.qty, i.name_ja, mm.name_ja move_ja, mm.type move_type, mm.power move_power, mm.accuracy move_acc FROM inventory v JOIN pokemon_items_master i ON i.item_key = v.item_key AND i.item_type = 'tm'
    JOIN pokemon_tm_data td ON td.item_key = v.item_key JOIN pokemon_moves_master mm ON mm.name_en = td.move_key
    WHERE v.guild_id=? AND v.user_id=? AND v.qty > 0
    AND EXISTS (SELECT 1 FROM pokemon_learnset l WHERE l.move_id = mm.move_id AND l.learn_method = 'machine' AND l.pokemon_key IN (?, 'S:' || ?))
    AND NOT EXISTS (SELECT 1 FROM owned_pokemon_moves m WHERE m.owned_id = ? AND m.move_id = mm.move_id) ORDER BY i.item_id`, G, U, o.pokemon_key, o.species_id, id);
  return { ok: true, tms: rows.map(r => ({ key: r.item_key, name: r.name_ja || r.item_key, qty: r.qty, move: { name: r.move_ja, type: r.move_type, power: r.move_power, acc: r.move_acc } })) };
}
// お別れ（元botと同じ：牧場・技・チームからも消す。バトル中は不可）
function releaseMon(g, uid, ownedId) {
  if (hasActiveBattle(uid)) return { error: "バトル中はお別れできません" };
  const G = BigInt(g), U = BigInt(uid), id = Math.floor(Number(ownedId));
  return tx(() => {
    const o = one("SELECT o.nickname, m.display_name_ja n FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key = o.pokemon_key WHERE o.owned_id=? AND o.guild_id=? AND o.user_id=?", id, G, U); if (!o) return { error: "ポケモンが見つかりません" };
    run("DELETE FROM user_pokemon_farm_deposits WHERE owned_id=?", id); run("DELETE FROM owned_pokemon_moves WHERE owned_id=?", id);
    run("DELETE FROM pokemon_user_group_members WHERE owned_id=?", id); run("DELETE FROM user_favorite_pokemon WHERE user_id=? AND owned_id=?", U, id);
    run("DELETE FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?", id, G, U);
    pendingEvo.get(uid)?.delete(id);
    return { ok: true, name: o.nickname || o.n };
  });
}
// チームの作成・上書き（グループは最大5つ、1チーム最大3匹。元botと同じ）
function saveTeam(g, uid, b) {
  const G = BigInt(g), U = BigInt(uid), name = String(b.name ?? "").trim().slice(0, 30), ids = [...new Set((Array.isArray(b.ids) ? b.ids : []).map(Number))];
  if (!ids.length || ids.length > TEAM_MAX || ids.some(n => !Number.isInteger(n))) return { error: `ポケモンを1〜${TEAM_MAX}匹選んでください` };
  const gid = b.groupId == null ? null : Math.floor(Number(b.groupId));
  return tx(() => {
    for (const id of ids) { if (!one("SELECT 1 x FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?", id, G, U)) return { error: "持っていないポケモンが含まれています" }; if (isDeposited(G, U, id)) return { error: "牧場に預けているポケモンはチームに入れられません" }; }
    let gId = gid;
    if (gid == null) {
      if (!name) return { error: "チーム名を入力してください" };
      if (one("SELECT COUNT(*) c FROM pokemon_user_groups WHERE guild_id=? AND user_id=?", G, U).c >= GROUP_MAX) return { error: `チームは最大${GROUP_MAX}つまで登録できます` };
      gId = Number(run("INSERT INTO pokemon_user_groups (guild_id, user_id, group_name, created_at) VALUES (?,?,?,strftime('%s','now'))", G, U, name).lastInsertRowid);
    } else {
      if (!one("SELECT 1 x FROM pokemon_user_groups WHERE group_id=? AND guild_id=? AND user_id=?", gid, G, U)) return { error: "チームが見つかりません" };
      if (name) run("UPDATE pokemon_user_groups SET group_name=? WHERE group_id=?", name, gid);
      run("DELETE FROM pokemon_user_group_members WHERE group_id=?", gid);
    }
    ids.forEach((id, i) => run("INSERT INTO pokemon_user_group_members (group_id, owned_id, slot) VALUES (?,?,?)", gId, id, i + 1));
    return { ok: true, groupId: gId };
  });
}
function deleteTeam(g, uid, groupId) {
  const G = BigInt(g), U = BigInt(uid), gid = Math.floor(Number(groupId));
  return tx(() => {
    if (!one("SELECT 1 x FROM pokemon_user_groups WHERE group_id=? AND guild_id=? AND user_id=?", gid, G, U)) return { error: "チームが見つかりません" };
    run("DELETE FROM pokemon_user_group_members WHERE group_id=?", gid); run("DELETE FROM pokemon_user_groups WHERE group_id=? AND guild_id=? AND user_id=?", gid, G, U); return { ok: true };
  });
}
// 編集画面用：チームの中身（スロット順）
function teamDetail(g, uid, groupId) {
  const G = BigInt(g), U = BigInt(uid), gid = Math.floor(Number(groupId)), gr = one("SELECT group_id, group_name FROM pokemon_user_groups WHERE group_id=? AND guild_id=? AND user_id=?", gid, G, U); if (!gr) return { error: "チームが見つかりません" };
  const rows = all(`${BOX_SEL} JOIN pokemon_user_group_members gm ON gm.owned_id = o.owned_id WHERE gm.group_id = ? AND o.guild_id = ? AND o.user_id = ? ORDER BY gm.slot`, gid, G, U);
  return { ok: true, id: gr.group_id, name: gr.group_name, members: rows.map(boxItem) };
}
const healAll = (G, U) => {run("UPDATE user_pokemon_owned SET hp=max_hp,persistent_status=NULL WHERE guild_id=? AND user_id=?",G,U);run("UPDATE owned_pokemon_moves SET current_pp=max_pp WHERE owned_id IN (SELECT owned_id FROM user_pokemon_owned WHERE guild_id=? AND user_id=?)",G,U)};
function persistParty(S){
 for(const b of S.party||[]){if(!b.id)continue;const hp=Math.max(0,Math.floor(b.hp*(b.persistScale||1)));run("UPDATE user_pokemon_owned SET hp=?,persistent_status=?,held_item_key=CASE WHEN ? THEN NULL ELSE held_item_key END WHERE owned_id=?",hp,b.status||null,b.heldConsumed?1:0,b.id);for(const m of b.moves||[])run("UPDATE owned_pokemon_moves SET current_pp=? WHERE owned_id=? AND move_id=? AND active=1",Math.max(0,m.pp),b.id,m.id)}
}
function center(g,uid){if(hasActiveBattle(uid))return{error:'バトル中は利用できません'};const G=BigInt(g),U=BigInt(uid);healAll(G,U);return{ok:true,message:'ポケモンのHP・状態異常・PPを全回復しました'}}
function awardTickets(G,U,random=Math.random){const got=P.ticketDrops(random);for(const {key} of got)run("INSERT INTO inventory(guild_id,user_id,item_key,qty) VALUES(?,?,?,1) ON CONFLICT(guild_id,user_id,item_key) DO UPDATE SET qty=qty+1",G,U,key);return got}
function usePpItem(g,uid,key,ownedId,moveId){
 if(hasActiveBattle(uid))return{error:'バトル中はバッグから使えません'};const G=BigInt(g),U=BigInt(uid),id=Number(ownedId),items=new Set(['ether','max-ether','elixir','max-elixir']);if(!items.has(String(key)))return{error:'PP回復アイテムではありません'};
 if(!one("SELECT 1 FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?",id,G,U))return{error:'ポケモンが見つかりません'};return tx(()=>{if(invQty(G,U,key)<=0)return{error:'そのアイテムを持っていません'};let rows=all("SELECT slot,current_pp,max_pp FROM owned_pokemon_moves WHERE owned_id=? AND active=1 ORDER BY slot",id);if(key==='ether'||key==='max-ether')rows=rows.filter(x=>x.slot===Number(moveId));if(!rows.length)return{error:'回復する技を選んでください'};if(rows.every(x=>x.current_pp>=x.max_pp))return{error:'PPは満タンです'};for(const x of rows)run("UPDATE owned_pokemon_moves SET current_pp=? WHERE owned_id=? AND slot=?",key.startsWith('max-')?x.max_pp:Math.min(x.max_pp,x.current_pp+10),id,x.slot);run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key=?",G,U,key);return{ok:true,left:invQty(G,U,key)}})
}
function useVitamin(g,uid,key,ownedId){
 if(hasActiveBattle(uid))return{error:'バトル中はバッグから使えません'};
 const map={'hp-up':'hp',protein:'attack',iron:'defense',calcium:'sp_attack',zinc:'sp_defense',carbos:'speed'},k=String(key||''),stat=map[k];if(!stat)return{error:'基礎ポイントアイテムではありません'};
 const G=BigInt(g),U=BigInt(uid),id=Number(ownedId);
 return tx(()=>{if(invQty(G,U,k)<=0)return{error:'そのアイテムを持っていません'};const o=one("SELECT o.*,m.base_hp,m.base_attack,m.base_defense,m.base_sp_attack,m.base_sp_defense,m.base_speed FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key=o.pokemon_key WHERE o.owned_id=? AND o.guild_id=? AND o.user_id=?",id,G,U);if(!o)return{error:'ポケモンが見つかりません'};
  const cur=Object.fromEntries(P.STATS.map(s=>[s,o['ev_'+s]||0])),gain=Object.fromEntries(P.STATS.map(s=>[s,s===stat?10:0])),next=P.applyEv(cur,gain);if(next[stat]===cur[stat])return{error:'これ以上その基礎ポイントを上げられません'};
  const st=E.calcStats(o,o.level,{hp:o.iv_hp,attack:o.iv_attack,defense:o.iv_defense,sp_attack:o.iv_sp_attack,sp_defense:o.iv_sp_defense,speed:o.iv_speed},next,o.nature_key),hp=Math.max(0,Math.min(st.max_hp,(o.hp??o.max_hp)+(st.max_hp-o.max_hp)));
  run(`UPDATE user_pokemon_owned SET ${P.STATS.map(s=>'ev_'+s+'=?').join(',')},hp=?,max_hp=?,attack=?,defense=?,sp_attack=?,sp_defense=?,speed=? WHERE owned_id=?`,...P.STATS.map(s=>next[s]),hp,st.max_hp,st.attack,st.defense,st.sp_attack,st.sp_defense,st.speed,id);run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key=?",G,U,k);return{ok:true,stat,value:next[stat],friendship:raiseFriendship(id,'vitamin')}})
}
function trackEvolutionBattle(S,ownedId,move,events){if(!ownedId)return;const t=S.evoTrack[ownedId]??={critical:0,damage:0,recoil:0,uses:{}};if(move)t.uses[move]=(t.uses[move]||0)+1;for(const e of events){if(e.t==='dmg'&&e.side==='e'&&e.crit)t.critical++;if(e.t==='dmg'&&e.side==='p'&&e.amount>0){if(e.recoil)t.recoil+=e.amount;else t.damage+=e.amount}}}
function saveEvolutionBattle(S,won){if(S.evoSaved)return;S.evoSaved=true;const weather=S.fld?.weather||null;for(const p of S.party.filter(x=>x.id&&x.fought)){const old=evoProgress(p.id),t=S.evoTrack[p.id]||{critical:0,damage:0,recoil:0,uses:{}},uses={...old.uses};for(const[k,n]of Object.entries(t.uses))uses[k]=(uses[k]||0)+n;const foeLevel=Number(S.enemy?.level||0),loss=p.hp<=0?(foeLevel>=p.level+30?-5:-1):0,friend=Math.max(0,Math.min(255,(old.friendship??70)+loss));run(`INSERT INTO web_evolution_progress(owned_id,friendship,battle_count,critical_hits,damage_taken,recoil_damage,move_uses_json,last_region,last_weather,luxury,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,strftime('%s','now')) ON CONFLICT(owned_id) DO UPDATE SET friendship=excluded.friendship,battle_count=excluded.battle_count,critical_hits=max(critical_hits,excluded.critical_hits),damage_taken=max(damage_taken,excluded.damage_taken),recoil_damage=recoil_damage+excluded.recoil_damage,move_uses_json=excluded.move_uses_json,last_region=excluded.last_region,last_weather=excluded.last_weather,updated_at=excluded.updated_at`,p.id,friend,(old.battle_count||0)+1,t.critical,t.damage,t.recoil,JSON.stringify(uses),S.region||old.last_region||null,weather||old.last_weather||null,old.luxury||0)}}
function finishWin(S) {
  const G = BigInt(S.g), U = BigInt(S.uid);
  saveEvolutionBattle(S,true);
  persistParty(S);
  if (S.kind === "wild"||S.kind==='rare') {
    const gold = Math.floor(200 * .25) + S.enemy.level * E.rnd(15, 30), gain = E.rewardExp(S.enemy.level);
    let results,tickets=[]; tx(() => { run("UPDATE users SET money = money + ? WHERE guild_id = ? AND user_id = ?", gold, G, U); results = awardExp(S.party.filter(x => x.fought && x.id).map(x => x.id), gain);if(S.kind==='wild')tickets=awardTickets(G,U); });
    S.over = { result: "win", gold, exp: gain, results,tickets, evo: collectEvo(S.uid, results) }; return;
  }
  // トレーナー：ランク別の固定レンジ／ジム：経験値2000・賞金3000／ロケット団：経験値10000・賞金なし。手持ち全員に経験値を配る。
  let exp, gold;
  if (S.kind === "trainer") { const r = [[400, 800], [1000, 1500], [2000, 4000], [5000, 7000]][S.rank]; exp = E.rnd(...r); gold = E.rnd(...r); }
  else if (S.kind === "gym") { exp = 2000; gold = 3000; } else { exp = 10000; gold = 0; }
  let results, badge = null, region = null;
  tx(() => {
    if (gold) run("UPDATE users SET money = money + ? WHERE guild_id = ? AND user_id = ?", gold, G, U);
    results = awardExp(S.party.map(x => x.id).filter(Boolean), exp);
    if (S.kind === "gym" || S.kind === "rocket") {
      run("INSERT OR REPLACE INTO user_gym_progress (guild_id,user_id,leader_id,is_defeated) VALUES (?,?,?,1)", G, U, S.leaderId);
      const reg = S.leaderId.split("_")[0], tbl = S.kind === "rocket" ? "special_gym_leaders" : "gym_leaders";
      const left = all(`SELECT leader_id FROM ${tbl} WHERE leader_id LIKE ?`, reg + "_%").filter(l => !one("SELECT 1 x FROM user_gym_progress WHERE guild_id=? AND user_id=? AND leader_id=? AND is_defeated=1", G, U, l.leader_id));
      if (!left.length) { badge = S.badge; region = REGION_JA[reg] || reg; run("INSERT OR IGNORE INTO user_gym_badges (guild_id,user_id,region_name,badge_name) VALUES (?,?,?,?)", G, U, reg, S.badge); }
    }
  });
  S.over = { result: "win", gold, exp, results, badge, region, foe: S.foe, evo: collectEvo(S.uid, results) };
}
function finishLose(S) { saveEvolutionBattle(S,false);persistParty(S); S.over = { result: "lose", kind: S.kind, foe: S.foe }; }
function tryCatch(S, ball) {
  const G = BigInt(S.g), U = BigInt(S.uid), w = S.enemy.wild, e = S.enemy;
  const have = one("SELECT qty FROM inventory WHERE guild_id=? AND user_id=? AND item_key=?", G, U, ball)?.qty || 0;
  if (!PB.supported(ball) || have <= 0) return { error: "そのボールを持っていないか、まだ使用できません" };
  const pm=one("SELECT species_id FROM pokemon_master WHERE pokemon_key=?",S.party[S.active].key),raw=(()=>{try{return JSON.parse(w.master.raw_pokemon_json||'{}')}catch{return{}}})(),hour=new Date(Date.now()+9*3600000).getUTCHours();
  const bp=PB.profile(ball,{types:e.types,level:e.level,status:e.status,gender:e.gender,playerLevel:S.party[S.active].level,playerGender:S.party[S.active].gender,sameSpecies:pm?.species_id===w.master.species_id,caughtBefore:!!one("SELECT 1 x FROM user_pokedex WHERE guild_id=? AND user_id=? AND species_id=? AND caught_count>0",G,U,w.master.species_id),turns:S.turns||0,isNight:hour>=20||hour<6,ultraBeast:!!w.master.is_ultra_beast,baseSpeed:w.master.base_speed,moonStone:!!one("SELECT 1 x FROM pokemon_evolution_rules WHERE from_pokemon_key IN (?,?) AND required_item_key='moon-stone' LIMIT 1",e.key,'S:'+w.master.species_id),weight:Number(raw.weight)});
  run("UPDATE inventory SET qty = qty - 1 WHERE guild_id=? AND user_id=? AND item_key=?", G, U, ball);
  const ev = [{ t: "ball", ball, msg: `${bp.name}を投げた！` }];
  const ch = E.captureChance(e.maxHp, e.hp, Math.max(1,w.captureRate+bp.rateAdd), bp.bonus);
  const ok = Math.random() < ch;
  if (!ok) { ev.push({ t: "shake", n: E.rnd(1, 3) }, { t: "broke", msg: `ああっ！${e.name}がボールから出てしまった！` }); return { ev, caught: false }; }
  const m = w.master;
  const saveLevel=S.kind==='rare'?1:e.level,nature=w.nature||P.randomNature(),saveStats=S.kind==='rare'?E.calcStats(m,1,w.iv,{},nature.key):w.stats,saveExp=P.expFor(saveLevel,P.growthType(m)),obtained=S.kind==='rare'?'rare_capture':'capture';
  let caughtId=null;
  tx(() => {
    const r = run(`INSERT INTO user_pokemon_owned (guild_id,user_id,pokemon_key,species_id,level,exp,gender,is_shiny,hp,max_hp,attack,defense,sp_attack,sp_defense,speed,iv_hp,iv_attack,iv_defense,iv_sp_attack,iv_sp_defense,iv_speed,image_url,obtained_type,caught_at,ability_key,ability_name_ja,ability_en,ability_ja) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,strftime('%s','now'),?,?,?,?)`,
      G, U, e.key, m.species_id,saveLevel,saveExp, e.gender, e.shiny ? 1 : 0,saveStats.max_hp,saveStats.max_hp,saveStats.attack,saveStats.defense,saveStats.sp_attack,saveStats.sp_defense,saveStats.speed, w.iv.hp, w.iv.attack, w.iv.defense, w.iv.sp_attack, w.iv.sp_defense, w.iv.speed, m.image_url,obtained, w.ability[0], w.ability[1], w.ability[0], w.ability[1]);
    const id = Number(r.lastInsertRowid);caughtId=id; let slot = 1;
    for (const mv of (S.kind==='rare'?wildMoves(m.pokemon_key,1):e.moves).slice(0,4)) run("INSERT OR IGNORE INTO owned_pokemon_moves (owned_id,slot,move_id,active,current_pp,max_pp) VALUES (?,?,?,1,?,?)", id, slot++, mv.id,mv.maxpp||mv.pp,mv.maxpp||mv.pp);
    run("UPDATE user_pokemon_owned SET nature_key=?,nature_name_ja=?,original_trainer_id=?,original_trainer_name=?,origin_region=?,marks_json=? WHERE owned_id=?",nature.key,nature.ja,String(S.uid),trainerName(S.uid),S.region||null,S.kind==='rare'?JSON.stringify(['レアバトルのあかし']):'[]',id);
    run(`INSERT INTO user_pokedex (guild_id,user_id,pokemon_key,species_id,seen_count,caught_count,normal_caught,shiny_caught,first_seen_at,first_caught_at) VALUES (?,?,?,?,1,1,?,?,strftime('%s','now'),strftime('%s','now')) ON CONFLICT(guild_id,user_id,pokemon_key) DO UPDATE SET caught_count=caught_count+1, normal_caught=normal_caught+?, shiny_caught=shiny_caught+?, first_caught_at=COALESCE(first_caught_at,strftime('%s','now'))`, G, U, e.key, m.species_id, e.shiny ? 0 : 1, e.shiny ? 1 : 0, e.shiny ? 0 : 1, e.shiny ? 1 : 0);
  });
  if(caughtId)run("INSERT OR REPLACE INTO web_evolution_progress(owned_id,friendship,luxury,updated_at) VALUES(?,?,?,strftime('%s','now'))",caughtId,ball==='friend-ball'?200:70,ball==='luxury-ball'?1:0);
  const tickets=S.kind==='wild'?awardTickets(G,U):[];S.captureTickets=tickets;
  ev.push({ t: "shake", n: 3 }, { t: "caught", msg: `やったー！${e.name}を捕まえた！` });
  return { ev, caught: true,tickets };
}
function useBattleItem(S,key){
 const G=BigInt(S.g),U=BigInt(S.uid),b=S.party[S.active],k=String(key||''),heal={potion:20,'super-potion':60,'hyper-potion':120,'max-potion':Infinity,'full-restore':Infinity},cure={antidote:['poison','bad-poison'],'paralyze-heal':['paralysis'],awakening:['sleep'],'burn-heal':['burn'],'ice-heal':['freeze'],'full-heal':['burn','freeze','paralysis','poison','bad-poison','sleep']},boost={'x-attack':'atk','x-defense':'def','x-sp-atk':'spatk','x-sp-def':'spdef','x-speed':'speed'};
 if(invQty(G,U,k)<=0)return{error:'そのアイテムを持っていません'};const ev=[];
 if(k in heal){if(b.hp>=b.maxHp&&!(k==='full-restore'&&b.status))return{error:'今は使っても効果がありません'};const n=Math.min(b.maxHp-b.hp,heal[k]);if(n>0){b.hp+=n;ev.push({t:'heal',side:'p',amount:n,hp:b.hp,maxHp:b.maxHp,msg:`${b.name}のHPが回復した！`})}if(k==='full-restore'&&b.status){b.status=null;ev.push({t:'status',side:'p',status:null,msg:`${b.name}の状態異常が治った！`})}}
 else if(k in cure){if(!cure[k].includes(b.status))return{error:'今は使っても効果がありません'};b.status=null;ev.push({t:'status',side:'p',status:null,msg:`${b.name}の状態異常が治った！`})}
 else if(k in boost){const s=boost[k],old=b.st[s];b.st[s]=Math.min(6,old+2);if(b.st[s]===old)return{error:'能力はこれ以上上がりません'};ev.push({t:'stage',side:'p',stat:s,delta:b.st[s]-old,msg:`${b.name}の能力がぐーんと上がった！`})}
 else return{error:'このアイテムは戦闘中に使えません'};
 run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key=?",G,U,k);ev.unshift({t:'item',side:'p',item:k,msg:`${one("SELECT name_ja FROM pokemon_items_master WHERE item_key=?",k)?.name_ja||k}を使った！`});return{ev};
}
function act(uid, a) {
  const S = battles.get(uid); if (!S || S.over) return { error: "バトル中ではありません" };
  const P = () => S.party[S.active]; let ev = []; S.selfSwitch = false;const actorId=P().id,moveUsed=a.type==='move'?P().moves[a.idx]?.en:null;
  if (S.needSwitch) {
    if (a.type !== "switch") return { error: "つぎに出すポケモンを選んでください" };
    const t = S.party[a.idx]; if (!t || t.hp <= 0 || a.idx === S.active) return { error: "そのポケモンは出せません" };
    const old = P(), sev = []; if (old.hp > 0) { E.leave(S, "p", old, sev); sev.push({ t: "switchOut", side: "p" }); }   // 自分交代：さいせいりょく等
    S.active = a.idx; t.fought = true; S.needSwitch = false;
    sev.push({ t: "switchIn", side: "p", mon: E.pub(t), msg: `ゆけっ！${t.name}！` }); E.enter(S, t, "p", sev);
    if (t.hp <= 0) { sev.push({ t: "faint", side: "p", msg: `${t.name}はたおれた！` }); if (S.party.some(b => b.hp > 0)) S.needSwitch = true; else { finishLose(S); sev.push({ t: "text", msg: S.kind === "wild" ? "目の前が真っ暗になった……" : `${S.foe}との勝負に敗れた……` }); } }
    persistParty(S);return view(S, sev);
  }
  if ((a.type === "run" || a.type === "switch") && (P().vs.trapped || P().vs.pt > 0)) {S.turns=(S.turns||0)+1;const r=view(S, [{ t: "text", msg: `${P().name}は逃げられない！` }, ...E.playTurn(S, { type: "none" })]);persistParty(S);return r;}
  if (a.type === "run") { S.over = { result: "run", kind: S.kind };persistParty(S); return view(S, [{ t: "text", msg: ["wild","rare"].includes(S.kind) ? "うまく逃げ切れた！" : "勝負をあきらめた……" }]); }
  if (a.type === "ball" && !["wild","rare"].includes(S.kind)) return { error: "人のポケモンは捕まえられません" };
  if (a.type === "ball") {
    const r = tryCatch(S, a.ball); if (r.error) return r;
    ev = r.ev; if (r.caught) { saveEvolutionBattle(S,true);persistParty(S);S.over = { result: "caught", name: S.enemy.name,tickets:r.tickets||[] }; return view(S, ev); }
  } else if(a.type==='item'){
    const r=useBattleItem(S,a.item);if(r.error)return r;ev=r.ev.concat(E.playTurn(S,{type:'none'}));
  } else if (a.type === "switch") {
    const t = S.party[a.idx]; if (!t || t.hp <= 0 || a.idx === S.active) return { error: "そのポケモンは出せません" };
    ev = E.playTurn(S, { type: "switch", idx: a.idx });
  } else if (a.type === "move") {
    if (!P().moves[a.idx]) return { error: "その技は使えません" };
    ev = E.playTurn(S, { type: "move", idx: a.idx });
  } else return { error: "不明な操作です" };
  if (a.type === "ball") { // 捕獲失敗：野生の攻撃だけ
    const sub = E.playTurn(S, { type: "none" }); ev = ev.concat(sub);
  }
  trackEvolutionBattle(S,actorId,moveUsed,ev);
  S.turns=(S.turns||0)+1;
  if (S.enemy.hp <= 0) {
    if(!S.enemy.evAwarded){const master=S.enemy.wild?.master||one("SELECT * FROM pokemon_master WHERE pokemon_key=?",S.enemy.key);S.lastEv=awardEv(S.party.filter(x=>x.fought&&x.id).map(x=>x.id),master);S.enemy.evAwarded=true}
    if (S.kind !== "wild" && S.ei + 1 < S.eparty.length) {   // 相手の次のポケモンが出てくる
      S.enemy = S.eparty[++S.ei]; markSeen(BigInt(S.g), BigInt(S.uid), S.enemy.key, S.enemy.species);
      ev.push({ t: "enemyIn", mon: E.pub(S.enemy), msg: `${S.foe}は${S.enemy.name}を繰り出した！` }); E.enter(S, S.enemy, "e", ev);
    } else { finishWin(S); ev.push({ t: "text", msg: ["wild","rare"].includes(S.kind) ? `${S.over.exp}の経験値を手に入れた！` : `${S.foe}との勝負に勝った！` }); return view(S, ev); }
  }
  if (P().hp <= 0) {
    if (S.party.some(b => b.hp > 0)) S.needSwitch = true; else { finishLose(S); ev.push({ t: "text", msg: ["wild","rare"].includes(S.kind) ? "目の前が真っ暗になった……" : `${S.foe}との勝負に敗れた……` }); }
  }
  if (S.selfSwitch && !S.over && !S.needSwitch && P().hp > 0 && S.party.some((b, i) => i !== S.active && b.hp > 0)) S.needSwitch = true;   // とんぼがえり・ボルトチェンジ等
  S.selfSwitch = false;
  persistParty(S);return view(S, ev);
}
setInterval(() => { for (const [k, b] of battles) if (Date.now() - b.t > 3600e3) battles.delete(k); }, 600e3);

// ---------------- 牧場・タマゴ（farm.cjs：元botの牧場をそのまま移植） ----------------
// ---- レイド結線（フレンド対戦とは独立）
R = require("./raid.cjs").create({ all, one, run, tx, E,P, loadParty, mkMove, wildMoves, monImg,persistParty,
  soloTest: env.POKEMON_RAID_TEST_SOLO === "1",
  hasActiveBattle: uid => pveActive(uid) || !!(FR && FR.inBattle(uid)) });   // レイド開始・参加時、フレンドバトル中も断る
const F = require("./farm.cjs").create({ all, one, run, tx, awardExp, raiseFriendship, monImg, E, P, trainerName, hasActiveBattle, log });
const Z = require("./zukan.cjs").create({ all, one, sessions, profileName });   // 図鑑
const ST = require("./starter.cjs").create({ all, one, run, tx, E, P, trainerName });   // スターター選択
const MP = require("./mypage.cjs").create({ all, one, Z, REGION_JA });   // マイページ

// ---------------- 通信交換（trade.cjs：元botのポケモンセンター「通信交換」をそのまま移植。演出は画面側） ----------------
const T = require("./trade.cjs").create({ all, one, run, tx, monImg, hasActiveBattle, sessions, pendingEvo, applyEvolution, evolveTrade, log });

// ---------------- フレンドバトル（フラット50・ランク対応） ----------------
function normalizeParty(party,level=50){for(const b of party){const o=one("SELECT o.*,m.base_hp,m.base_attack,m.base_defense,m.base_sp_attack,m.base_sp_defense,m.base_speed FROM user_pokemon_owned o JOIN pokemon_master m ON m.pokemon_key=o.pokemon_key WHERE o.owned_id=?",b.id);if(!o)continue;const st=E.calcStats(o,level,{hp:o.iv_hp,attack:o.iv_attack,defense:o.iv_defense,sp_attack:o.iv_sp_attack,sp_defense:o.iv_sp_defense,speed:o.iv_speed},Object.fromEntries(P.STATS.map(k=>[k,o['ev_'+k]||0])),o.nature_key);Object.assign(b,{persistScale:o.max_hp/st.max_hp,level,hp:Math.max(0,Math.round((o.hp/o.max_hp)*st.max_hp)),maxHp:st.max_hp,atk:st.attack,def:st.defense,spatk:st.sp_attack,spdef:st.sp_defense,speed:st.speed,status:o.persistent_status||null})}return party}
function recordPvp(B,winner){if(B.mode!=='ranked')return;const G=BigInt(B.g),a=BigInt(B.p.uid),b=BigInt(B.e.uid);for(const u of[a,b])run("INSERT OR IGNORE INTO web_pvp_ratings(guild_id,user_id) VALUES(?,?)",G,u);const A=one("SELECT * FROM web_pvp_ratings WHERE guild_id=? AND user_id=?",G,a),D=one("SELECT * FROM web_pvp_ratings WHERE guild_id=? AND user_id=?",G,b),ea=1/(1+10**((D.rating-A.rating)/400)),sa=winner==null ? .5 : winner==='p'?1:0,da=Math.round(32*(sa-ea));run(`UPDATE web_pvp_ratings SET rating=rating+?,wins=wins+?,losses=losses+?,draws=draws+? WHERE guild_id=? AND user_id=?`,da,sa===1?1:0,sa===0?1:0,sa===.5?1:0,G,a);run(`UPDATE web_pvp_ratings SET rating=rating-?,wins=wins+?,losses=losses+?,draws=draws+? WHERE guild_id=? AND user_id=?`,da,sa===0?1:0,sa===1?1:0,sa===.5?1:0,G,b)}
var FR = require("./friend.cjs").create({ all, one, run, E, loadParty, markSeen,persistParty,normalizeParty,recordPvp, pveActive: uid => pveActive(uid) || !!R?.busy(uid), log });   // レイド参加中の人とも対戦しない
const W = require("./world.cjs").create({db,all,one,run,busy:uid=>hasActiveBattle(uid)});

// ---------------- 管理画面（出現率・レベル・地方設定は扱わない） ----------------
async function adminView(g,q=''){
 await syncGuildProfiles(g);
 const G=BigInt(g),term=String(q||'').trim().slice(0,64),args=[G];let w='u.guild_id=?';if(term){w+=" AND (CAST(u.user_id AS TEXT) LIKE ? OR CAST(u.money AS TEXT) LIKE ? OR COALESCE(p.display_name,'') LIKE ? OR COALESCE(p.username,'') LIKE ?)";args.push(...Array(4).fill('%'+term+'%'))}
 const users=all(`SELECT CAST(u.user_id AS TEXT) user_id,COALESCE(p.display_name,p.username,'不明なユーザー') display_name,p.username,u.money,(SELECT COUNT(*) FROM user_pokemon_owned o WHERE o.guild_id=u.guild_id AND o.user_id=u.user_id) mons,(SELECT qty FROM inventory i WHERE i.guild_id=u.guild_id AND i.user_id=u.user_id AND i.item_key='rare-battle-ticket') rare_tickets,(SELECT qty FROM inventory i WHERE i.guild_id=u.guild_id AND i.user_id=u.user_id AND i.item_key='raid-ticket') raid_tickets FROM users u LEFT JOIN web_user_profiles p ON p.guild_id=u.guild_id AND p.user_id=u.user_id WHERE ${w} ORDER BY display_name COLLATE NOCASE,u.user_id LIMIT 100`,...args);
 return{ok:true,counts:{users:one("SELECT COUNT(*) c FROM users WHERE guild_id=?",G).c,mons:one("SELECT COUNT(*) c FROM user_pokemon_owned WHERE guild_id=?",G).c,activeBattles:battles.size,raidRooms:R.list(g,'0').rooms.length},users,items:all("SELECT item_key,name_ja,item_type FROM pokemon_items_master ORDER BY item_type,name_ja").map(x=>({key:x.item_key,name:x.name_ja||x.item_key,type:x.item_type||'misc'}))};
}
function adminAction(admin,g,b){
 const G=BigInt(g),target=String(b.userId||'');if(!/^\d{5,25}$/.test(target))return{error:'対象ユーザーIDが正しくありません'};const U=BigInt(target),action=String(b.action||'');if(!one("SELECT 1 FROM users WHERE guild_id=? AND user_id=?",G,U))return{error:'対象ユーザーが見つかりません'};
 return tx(()=>{let detail={};if(action==='money'){const n=Math.max(-99999999,Math.min(99999999,Math.trunc(Number(b.amount)||0)));run("UPDATE users SET money=max(0,money+?) WHERE guild_id=? AND user_id=?",n,G,U);detail={amount:n}}
 else if(action==='item'){const k=String(b.item||''),n=Math.max(1,Math.min(9999,Math.trunc(Number(b.qty)||1)));if(!one("SELECT 1 FROM pokemon_items_master WHERE item_key=?",k))return{error:'アイテムが見つかりません'};run("INSERT INTO inventory(guild_id,user_id,item_key,qty) VALUES(?,?,?,?) ON CONFLICT(guild_id,user_id,item_key) DO UPDATE SET qty=qty+excluded.qty",G,U,k,n);detail={item:k,qty:n}}
 else if(action==='heal'){healAll(G,U);detail={heal:true}}
 else return{error:'管理操作が正しくありません'};run("INSERT INTO web_admin_log(admin_user_id,target_user_id,action,detail_json) VALUES(?,?,?,?)",String(admin),target,action,JSON.stringify(detail));return{ok:true,...detail,money:one("SELECT money FROM users WHERE guild_id=? AND user_id=?",G,U)?.money??0}})
}

// ---------------- HTTP ----------------
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".webp": "image/webp", ".png": "image/png", ".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".json": "application/json" };
async function readBody(req, limit) { let b = ""; for await (const c of req) { b += c; if (b.length > limit) return null; } return b; }
const server = http.createServer(async (req, res) => {
  const reply = (st, o) => { res.writeHead(st, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }); res.end(JSON.stringify(o)); };
  let p; try { p = new URL(req.url, "http://x").pathname; } catch { return reply(400, {}); }
  try {
    if (p === "/api/health") return reply(200, { ok: true, battles: battles.size });
    if (p === "/api/login" && req.method === "POST") {
      if (!allowedOrigins.has(req.headers.origin)) return reply(403, { error: "Origin not allowed" });
      const b = JSON.parse(await readBody(req, 4000) || "{}");
      if (typeof b.access_token !== "string" || !/^[A-Za-z0-9._~-]{10,200}$/.test(b.access_token)) return reply(400, { error: "ログイン情報がありません" });
      const v = await verify(b.access_token, b.instanceId); if (v.error) return reply(v.status || 403, { error: v.error });
      const g = dbGuild(v.user.id, v.guild); if (!g) return reply(404, { error: "ポケモンのデータが見つかりません（botで一度遊んだアカウントが必要です）" });
      saveProfile(g,v.user,v.user.name);
      run("UPDATE user_pokemon_owned SET original_trainer_name=? WHERE guild_id=? AND original_trainer_id=? AND (original_trainer_name IS NULL OR original_trainer_name='' OR original_trainer_name=original_trainer_id)",v.user.name,BigInt(g),String(v.user.id));
      const sid = crypto.randomBytes(24).toString("hex"); sessions.set(sid, { uid: v.user.id, g, name: v.user.name, exp: Date.now() + 12 * 3600e3 });
      if (sessions.size > 500) sessions.delete(sessions.keys().next().value);
      log("login", v.user.id, v.user.name); return reply(200, { session: sid, me: v.user, ...home(v.user.id, g) });
    }
    if (p.startsWith("/api/") && req.method === "POST") {
      const s = sessions.get(req.headers["x-session"]); if (!s || s.exp < Date.now()) return reply(401, { error: "ログインが切れました。開き直してください" });
      s.seen = Date.now();   // 交換の相手候補に「いま遊んでいる人」だけを出すため
      const b = JSON.parse(await readBody(req, 4000) || "{}");
      if (p === "/api/raid") return reply(200, R.list(s.g, s.uid));
      if (p === "/api/raid/create") { const r = R.createRoom(s.g, s.uid, s.name, b.rank); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/raid/action") { const r = R.action(s.g, s.uid, s.name, b); return reply(r.error ? 409 : 200, r); }
      if (p === "/api/world") return reply(200,W.snapshot(s.g,s.uid));
      if (p === "/api/world/move") {const r=W.move(s.g,s.uid,b);return reply(r.error?400:200,r)}
      if (p === "/api/world/interact") {const r=W.interact(s.g,s.uid,b.id);return reply(r.error?400:200,r)}
      if (p === "/api/world/region") {const r=W.setRegion(s.g,s.uid,b.region);return reply(r.error?400:200,r)}
      if (p === "/api/world/faint") return reply(200,W.faint(s.g,s.uid));
      if (p === "/api/world/start") {const c=W.encounter(s.g,s.uid,b.method);if(c.error)return reply(400,c);if(!c.encounter)return reply(200,c);const r=startBattle(s.uid,s.g,Number(b.groupId),c.region,c.scene,c);return reply(r.error?400:200,r)}
      // 募集中から終了まで、使用中の個体や所持品を他の処理で変更させない。
      const raidReadOnly = new Set(["/api/home","/api/shop","/api/bag","/api/box","/api/dex","/api/mypage","/api/dex/mon","/api/team/candidates","/api/team/get","/api/mon","/api/mon/tms","/api/evolution/status","/api/trade","/api/trade/partners","/api/trade/mons","/api/farm","/api/farm/search"]);
      if (R.busy(s.uid) && !raidReadOnly.has(p)) return reply(409, {error:"レイド参加中です。レイド画面で離脱・終了してください"});
      if (p === "/api/home") return reply(200, home(s.uid, s.g));
      if (p === "/api/start") { const r = startBattle(s.uid, s.g, Number(b.groupId), String(b.region)); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/rare/start") { const r = startRare(s.uid,s.g,Number(b.groupId)); return reply(r.error?400:200,r); }
      if (p === "/api/npc") {let scene=null;if(b.fromWorld){const gate=W.interact(s.g,s.uid,b.kind==='gym'?'gym':'trainer');if(gate.error)return reply(400,gate);scene=gate.scene}const r = startNpc(s.uid, s.g, { kind: String(b.kind), groupId: b.groupId, region: b.region, rank: b.rank, leaderId: b.leaderId,scene }); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/center") {const r=center(s.g,s.uid);return reply(r.error?400:200,r)}
      if (p === "/api/shop") return reply(200, shopList(s.g, s.uid));
      if (p === "/api/buy") { const r = buyItem(s.g, s.uid, b.item, b.qty); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/bag") return reply(200, bagList(s.g, s.uid));
      if (p === "/api/item/pp") {const r=usePpItem(s.g,s.uid,b.item,b.ownedId,b.slot);return reply(r.error?400:200,r)}
      if (p === "/api/item/vitamin") {const r=useVitamin(s.g,s.uid,b.item,b.ownedId);return reply(r.error?400:200,r)}
      if (p === "/api/tm/targets") { const r = tmTargets(s.g, s.uid, b.item); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/tm/use") { const r = useTm(s.g, s.uid, b.item, b.ownedId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/stone/targets") { const r = stoneTargets(s.g, s.uid, b.item); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/stone/use") { const r = useStone(s.g, s.uid, b.item, b.ownedId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/evolution/status") {const r=evolutionStatus(s.g,s.uid,b.ownedId);return reply(r.error?400:200,r)}
      if (p === "/api/evolution/evolve") {const r=evolveManual(s.g,s.uid,b.ownedId,b.ruleId,b.action);return reply(r.error?400:200,r)}
      if (p === "/api/box") return reply(200, boxList(s.g, s.uid, b));
      if (p === "/api/dex") return reply(200, { ...Z.list(s.g, s.uid, b), ...(b.summary ? { sum: Z.summary(s.g, s.uid) } : {}) });
      if (p === "/api/mypage") return reply(200, MP.view(s.g, s.uid));
      if (p === "/api/starter") { const r = ST.list(s.g, s.uid,b.region); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/starter/pick") { const r = ST.preview(s.g, s.uid, b.no,b.region); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/starter/confirm") { const r = ST.confirm(s.g, s.uid); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/dex/mon") { const r = Z.detail(s.g, s.uid, b.key); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/team/candidates") return reply(200, teamCandidates(s.g, s.uid, b));
      if (p === "/api/team/get") { const r = teamDetail(s.g, s.uid, b.groupId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/team/save") { const r = saveTeam(s.g, s.uid, b); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/team/delete") { const r = deleteTeam(s.g, s.uid, b.groupId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/mon") { const r = monDetail(s.g, s.uid, b.ownedId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/mon/star") { const r = toggleStar(s.g, s.uid, b.ownedId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/mon/forget") { const r = forgetMove(s.g, s.uid, b.ownedId, b.slot, b.moveId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/mon/remember") {const r=rememberMove(s.g,s.uid,b.ownedId,b.slot,b.replaceSlot);return reply(r.error?400:200,r)}
      if (p === "/api/mon/rename") {const r=renameMon(s.g,s.uid,b.ownedId,b.name);return reply(r.error?400:200,r)}
      if (p === "/api/mon/held") {const r=setHeld(s.g,s.uid,b.ownedId,b.item);return reply(r.error?400:200,r)}
      if (p === "/api/mon/tms") { const r = monTms(s.g, s.uid, b.ownedId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/mon/release") { const r = releaseMon(s.g, s.uid, b.ownedId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/evolve") { const r = evolve(s.uid, s.g, Number(b.ownedId), !!b.yes); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/act") { const r = act(s.uid, { type: b.type, idx: Number(b.idx), ball: String(b.ball || ""),item:String(b.item||'') }); return reply(r.error ? 400 : 200, r); }
      if(p==="/api/admin"){if(!ADMIN_IDS.has(s.uid))return reply(403,{error:'管理者のみ'});return reply(200,await adminView(s.g,b.q))}
      if(p==="/api/admin/action"){if(!ADMIN_IDS.has(s.uid))return reply(403,{error:'管理者のみ'});const r=adminAction(s.uid,s.g,b);return reply(r.error?400:200,r)}
      if (p === "/api/trade") return reply(200, T.view(s.uid));
      if (p === "/api/trade/partners") return reply(200, T.partners(s.g, s.uid, b.q));
      if (p === "/api/trade/mons") return reply(200, T.candidates(s.g, s.uid, b.q));
      if (p === "/api/trade/offer") { const r = T.offer(s.g, s.uid, b.to, b.ownedId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/trade/respond") { const r = T.respond(s.g, s.uid, b.tradeId, b.ownedId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/trade/decline") { const r = T.cancel(s.g, s.uid, b.tradeId, true); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/trade/cancel") { const r = T.cancel(s.g, s.uid, b.tradeId, false); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/trade/confirm") { const r = T.confirm(s.g, s.uid, b.tradeId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/trade/close") return reply(200, T.close(s.uid, b.tradeId));
      if (p === "/api/farm") return reply(200, F.farmHome(s.g, s.uid));
      if (p === "/api/farm/search") { const r = F.depositSearch(s.g, s.uid, b.queries ?? b.q); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/farm/deposit") { const r = F.deposit(s.g, s.uid, b.ids); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/farm/withdraw") { const r = F.withdraw(s.g, s.uid, b.ids); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/farm/buy") { const r = F.buy(s.g, s.uid, b.itemId, b.qty); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/farm/use") { const r = F.useItem(s.g, s.uid, b.itemId); return reply(r.error ? 400 : 200, r); }
      if (p === "/api/farm/claim") { const r = F.claimHatched(s.g, s.uid, b.hatchedId); return reply(r.error ? 400 : 200, r); }
      if (p.startsWith("/api/friend/")) {
        const fr = p.slice(12), me = { uid: s.uid, g: s.g, name: s.name };
        if (fr === "state") return reply(200, FR.state(me, b.seen));
        if (fr === "challenge") { const r = FR.challenge(me, b.to, b.groupId,b.mode,b.stage); return reply(r.error ? 400 : 200, r); }
        if (fr === "cancel") return reply(200, FR.cancel(me));
        if (fr === "decline") { const r = FR.decline(me, b.id); return reply(r.error ? 400 : 200, r); }
        if (fr === "accept") { const r = FR.accept(me, b.id, b.groupId); return reply(r.error ? 400 : 200, r); }
        if (fr === "act") { const r = FR.act(me, { type: String(b.type), idx: b.idx, seen: b.seen }); return reply(r.error ? 400 : 200, r); }
        if (fr === "leave") return reply(200, FR.leave(me));
      }
      return reply(404, {});
    }
    if (req.method !== "GET" && req.method !== "HEAD") return reply(405, {});
    const isImg = p.startsWith("/poke/"), root = isImg ? IMG_DIR : PUBLIC;
    const rel = isImg ? decodeURIComponent(p.slice(5)) : p === "/" ? "/index.html" : decodeURIComponent(p);
    const f = path.normalize(path.join(root, rel));
    if (!f.startsWith(root + path.sep) || !fs.existsSync(f) || !fs.statSync(f).isFile()) return reply(404, { error: "not found" });
    res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream", "Cache-Control": isImg ? "public, max-age=604800" : "no-cache" }); fs.createReadStream(f).pipe(res);
  } catch (e) { log("http", e.stack || e.message); if (!res.headersSent) reply(500, { error: "server error" }); }
});
if (require.main === module) server.listen(PORT, "127.0.0.1", () => { log(`pokemon server on 127.0.0.1:${PORT}`); F.startTimers(); FR.startTimers(); });
else module.exports = { sessions, T, F, R, FR,W, server, startBattle, startNpc, act, home, db, battles, evolve, pendingEvo, evolutionStatus, evolveManual, shopList, buyItem, bagList, tmTargets, useTm, stoneTargets, useStone, boxList, teamCandidates, teamDetail, saveTeam, deleteTeam, monDetail, toggleStar, forgetMove, monTms, releaseMon };
