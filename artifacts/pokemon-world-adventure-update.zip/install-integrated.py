from pathlib import Path
import hashlib, json, shutil, subprocess, sys, time, urllib.request
from datetime import datetime

root = Path(__file__).resolve().parent
app = Path('/opt/games-pokemon')
config = Path('/etc/games-party.env')
node = '/opt/node22/bin/node'
service = 'games-pokemon.service'
manifest = json.loads((root / 'install-manifest.json').read_text())
if not app.is_dir():
    raise SystemExit('停止：/opt/games-pokemon がありません')
for name, hashes in manifest.items():
    target = app / name
    digest = hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
    if digest not in hashes:
        raise SystemExit('停止：想定外の変更があります。上書きしていません：' + name)
for name in ['progression.test.cjs', 'balls.test.cjs', 'evolution.test.cjs', 'zukan.test.cjs', 'raid.test.cjs', 'friend.test.cjs', 'world.test.cjs', 'raid-http.test.cjs']:
    subprocess.run([node, str(root / 'tests' / name)], cwd=root, check=True)
for target in (root / 'connect-party/pokemon').glob('*.cjs'):
    subprocess.run([node, '--check', str(target)], check=True)
backup = Path('/root/games-pokemon-integrated-backup-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
backup.mkdir(mode=0o700)
existing = []
for name in manifest:
    target = app / name
    if target.exists():
        saved = backup / name
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, saved)
        existing.append(name)
had_config = config.exists()
if had_config:
    shutil.copy2(config, backup / 'games-party.env')
old_config = config.read_text() if had_config else ''
new_config = '\n'.join(line for line in old_config.splitlines() if not line.startswith('POKEMON_RAID_TEST_SOLO='))
new_config = new_config.rstrip('\n') + '\nPOKEMON_RAID_TEST_SOLO=1\n'
subprocess.run(['systemctl', 'stop', service], check=True)
try:
    for name in manifest:
        target = app / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / 'connect-party/pokemon' / name, target)
        if name not in existing:
            target.chmod(0o644)
    config.write_text(new_config)
    if not had_config:
        config.chmod(0o600)
    subprocess.run(['systemctl', 'start', service], check=True)
    settings = {}
    for file in [Path('/etc/games-hub.env'), config]:
        if file.exists():
            for line in file.read_text().splitlines():
                if '=' in line:
                    key, value = line.split('=', 1)
                    settings[key] = value.strip()
    port = int(settings.get('POKEMON_PORT') or 8501)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for attempt in range(15):
        try:
            with opener.open(f'http://127.0.0.1:{port}/api/health', timeout=2) as response:
                if json.load(response).get('ok'):
                    break
        except Exception:
            pass
        time.sleep(1)
    else:
        raise RuntimeError('ヘルスチェックが通りませんでした')
except Exception as error:
    subprocess.run(['systemctl', 'stop', service], check=False)
    for name in manifest:
        if name in existing:
            shutil.copy2(backup / name, app / name)
        else:
            (app / name).unlink(missing_ok=True)
    if had_config:
        shutil.copy2(backup / 'games-party.env', config)
    else:
        config.unlink(missing_ok=True)
    subprocess.run(['systemctl', 'start', service], check=False)
    raise SystemExit('適用に失敗したため旧版に戻しました：' + str(error) + '\nバックアップ：' + str(backup))
print('3D冒険マップ・全地方・施設・遭遇・バトル会場統合版の配置と起動確認が完了しました。')
print('通常プレイは許可サーバーの参加者が利用できます。管理画面だけADMIN_USER_IDSに限定しています。')
print('バックアップ：' + str(backup))
print('Discordを開き直し、オーキド博士のポケモンセンターから冒険を開始してください。')
