'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
const E=require('../connect-party/pokemon/engine.cjs'),P=require('../connect-party/pokemon/progression.cjs');

function fixture(){
 const db=new DatabaseSync(':memory:',{enableForeignKeyConstraints:false});
 db.exec(fs.readFileSync(path.join(__dirname,'bot-schema.sql'),'utf8'));
 const all=(q,...a)=>db.prepare(q).all(...a),one=(q,...a)=>db.prepare(q).get(...a),run=(q,...a)=>db.prepare(q).run(...a);
 const tx=fn=>{db.exec('BEGIN IMMEDIATE');try{const r=fn();db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}};
 P.migrate({db,all,one,run});
 db.exec(`INSERT INTO pokemon_master(pokemon_key,species_id,pokeapi_pokemon_id,display_name_ja,is_default,type1,base_hp,base_attack,base_defense,base_sp_attack,base_sp_defense,base_speed,gender_rate,image_url,ability1_en,ability1_ja,raw_species_json,raw_pokemon_json)
 VALUES('S:1',1,1,'フシギダネ',1,'grass',45,49,49,65,65,45,1,'https://fixture/1.png','overgrow','しんりょく','{"growth_rate":{"name":"medium-slow"}}','{"stats":[{"effort":1,"stat":{"name":"special-attack"}}]}');
 INSERT INTO pokemon_moves_master(move_id,name_en,name_ja,type,power,accuracy,pp,damage_class) VALUES(1,'tackle','たいあたり','normal',40,100,35,'physical'),(2,'growl','なきごえ','normal',0,100,40,'status'),(3,'vine-whip','つるのムチ','grass',45,100,25,'physical'),(4,'poison-powder','どくのこな','poison',0,75,35,'status'),(5,'sleep-powder','ねむりごな','grass',0,75,15,'status');
 INSERT INTO pokemon_learnset(pokemon_key,move_id,learn_method,learn_level,version_group) VALUES('S:1',1,'level-up',1,'x'),('S:1',2,'level-up',1,'x'),('S:1',3,'level-up',3,'x'),('S:1',4,'level-up',4,'x'),('S:1',5,'level-up',5,'x');`);
 return{db,all,one,run,tx};
}

test('性格・努力値上限・経験値タイプを計算する',()=>{
 const m={base_hp:80,base_attack:100,base_defense:100,base_sp_attack:100,base_sp_defense:100,base_speed:100,nature_key:'adamant'};
 const iv={hp:31,attack:31,defense:31,sp_attack:31,sp_defense:31,speed:31},plain=E.calcStats({...m,nature_key:'hardy'},50,iv,{attack:252,sp_attack:252,hp:6}),adamant=E.calcStats(m,50,iv,{attack:252,sp_attack:252,hp:6});
 assert.ok(adamant.attack>plain.attack);assert.ok(adamant.sp_attack<plain.sp_attack);assert.equal(adamant.max_hp,plain.max_hp);
 const ev=P.applyEv({hp:250,attack:250,defense:0,sp_attack:0,sp_defense:0,speed:0},{hp:3,attack:3,defense:3,sp_attack:3,sp_defense:3,speed:3});
 assert.equal(ev.hp,252);assert.equal(ev.attack,252);assert.equal(Object.values(ev).reduce((a,b)=>a+b,0),510);
 assert.equal(P.expFor(50,'medium'),125000);assert.notEqual(P.expFor(50,'fast'),P.expFor(50,'slow'));
 let seq=[.019,.02];assert.deepEqual(P.ticketDrops(()=>seq.shift()).map(x=>x.key),['rare-battle-ticket']);seq=[0,0];assert.deepEqual(P.ticketDrops(()=>seq.shift()).map(x=>x.key),['rare-battle-ticket','raid-ticket']);
});

test('スターターは性格・親情報・4技・PPを保存する',()=>{
 const f=fixture(),ST=require('../connect-party/pokemon/starter.cjs').create({...f,E,P});
 const p=ST.preview('1','10',1);assert.ifError(p.error);assert.ok(p.nature);
 const c=ST.confirm('1','10');assert.ifError(c.error);
 const o=f.one('SELECT * FROM user_pokemon_owned WHERE owned_id=?',c.ownedId);assert.ok(o.nature_key);assert.equal(o.original_trainer_id,'10');assert.equal(o.origin_region,'starter');assert.equal(o.exp,P.expFor(5,'medium-slow'));
 const moves=f.all('SELECT * FROM owned_pokemon_moves WHERE owned_id=? ORDER BY slot',c.ownedId);assert.equal(moves.length,5);assert.equal(moves.filter(x=>x.active).length,4);assert.ok(moves.every(x=>x.current_pp===x.max_pp&&x.max_pp>0));f.db.close();
});

test('牧場の幼体は性格・親情報・PPを所持個体へ引き継ぐ',()=>{
 const f=fixture();
 f.run(`INSERT INTO user_pokemon_farm_hatched(guild_id,user_id,pokemon_key,species_id,level,exp,gender,ability_en,ability_ja,hp,max_hp,attack,defense,sp_attack,sp_defense,speed,iv_hp,iv_attack,iv_defense,iv_sp_attack,iv_sp_defense,iv_speed,nature_key,nature_name_ja,image_url,moves_json) VALUES(2,20,'S:1',1,1,0,'female','overgrow','しんりょく',12,12,6,6,7,7,6,20,20,20,20,20,20,'modest','ひかえめ','https://fixture/1.png','[{"move_id":1,"name_ja":"たいあたり"}]')`);
 const F=require('../connect-party/pokemon/farm.cjs').create({...f,E,P,awardExp:()=>[],monImg:()=>null,hasActiveBattle:()=>false,log:()=>{}}),r=F.claimHatched('2','20',1);assert.ifError(r.error);
 const o=f.one('SELECT * FROM user_pokemon_owned WHERE owned_id=?',r.ownedId),m=f.one('SELECT * FROM owned_pokemon_moves WHERE owned_id=?',r.ownedId);assert.equal(o.nature_key,'modest');assert.equal(o.original_trainer_id,'20');assert.equal(o.origin_region,'farm');assert.equal(m.active,1);assert.equal(m.current_pp,35);assert.equal(m.max_pp,35);f.db.close();
});
