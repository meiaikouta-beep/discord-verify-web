'use strict';
const {randomUUID} = require('node:crypto');
const {RAID_RANK_SETTINGS:RANKS,RAID_CATEGORY_WEIGHTS_BY_RANK:WEIGHTS}=require('./raid-settings.cjs');
const WHERE={
 mythical:'is_mythical=1',legendary:'is_legendary=1 AND is_mythical=0',mega:'is_mega=1',
 special_form:"form_key IS NOT NULL AND form_key!='' AND (is_legendary=1 OR is_mythical=1) AND is_mega=0 AND is_gmax=0 AND form_key NOT LIKE '%primal%'",
 final:"evolution_stage='final' AND is_legendary=0 AND is_mythical=0 AND is_mega=0 AND is_gmax=0 AND is_ultra_beast=0 AND EXISTS (SELECT 1 FROM pokemon_evolution_rules e2 JOIN pokemon_evolution_rules e1 ON e1.to_pokemon_key=e2.from_pokemon_key WHERE e2.to_pokemon_key=pokemon_master.pokemon_key)"
};
const LIVE=new Set(['lobby','battle','capture']);
function create(ctx) {
 const {all,one,run,tx,E,loadParty,mkMove,wildMoves,monImg,hasActiveBattle,persistParty}=ctx,P=ctx.P||require('./progression.cjs');
 const random=ctx.random||Math.random, clock=ctx.clock||Date.now;
 const requiredPlayers=ctx.soloTest===true?1:3;
 const engine=require('./raid-engine.cjs')(E,random), rooms=new Map();
 run('CREATE TABLE IF NOT EXISTS web_raid_sessions (id TEXT PRIMARY KEY, state_json TEXT NOT NULL)');
 for(const row of all('SELECT state_json FROM web_raid_sessions')) {const r=JSON.parse(row.state_json); rooms.set(r.id,r);}
 const rnd=(a,b)=>a+Math.floor(random()*(b-a+1));
 const takeTicket=(g,ps)=>{if(ctx.takeRaidTicket)return ctx.takeRaidTicket(g,ps);try{const p=ps.find(x=>!x.npc&&one("SELECT qty FROM inventory WHERE guild_id=? AND user_id=? AND item_key='raid-ticket'",BigInt(g),BigInt(x.uid))?.qty>0);if(!p)return null;run("UPDATE inventory SET qty=qty-1 WHERE guild_id=? AND user_id=? AND item_key='raid-ticket' AND qty>0",BigInt(g),BigInt(p.uid));return p}catch(e){if(/no such table: inventory/.test(e.message))return ps.find(x=>!x.npc);throw e}};
 const player=(r,u)=>r.players.find(p=>p.uid===String(u));
 const current=(g,u)=>[...rooms.values()].find(r=>r.guild===String(g) && LIVE.has(r.phase) && player(r,u));
 function busy(uid) {sweep(); return [...rooms.values()].some(r=>LIVE.has(r.phase)&&player(r,uid));}
 function save(r) {run('INSERT OR REPLACE INTO web_raid_sessions (id,state_json) VALUES (?,?)',r.id,JSON.stringify(r));}
 function sweep() {
  for(const r of rooms.values()) {
   if(LIVE.has(r.phase)&&r.deadline<=clock()) {const n={...r,phase:'expired',version:r.version+1,deadline:clock()+600000}; save(n); rooms.set(r.id,n);}
   else if(!LIVE.has(r.phase)&&r.deadline+3600000<clock()) {run('DELETE FROM web_raid_sessions WHERE id=?',r.id);rooms.delete(r.id);}
  }
 }
 function ranks() {
  return Object.entries(RANKS).map(([id,r])=>({id:+id,label:r.label,name:r.rank_name,level:r.level}));
 }
 function boss(rank) {
  const cfg=RANKS[rank], ws=WEIGHTS[rank], n=random()*100; let sum=0,cat;
  for(const [k,w] of Object.entries(ws)){sum+=w;if(n<sum){cat=k;break;}}
  const m=one(`SELECT * FROM pokemon_master WHERE ${WHERE[cat]} ORDER BY RANDOM() LIMIT 1`);
  if(!m) throw Error('選ばれたカテゴリのボスデータがありません。別のランクで再試行してください');
  const iv=Object.fromEntries(['hp','attack','defense','sp_attack','sp_defense','speed'].map(k=>[k,cfg['iv_'+k]]));
  const st=E.calcStats(m,cfg.level,iv);
  const recharge=new Set(['hyper-beam','giga-impact','blast-burn','hydro-cannon','frenzy-plant','rock-wrecker','roar-of-time','prismatic-laser','meteor-assault','eternabeam']);
  let ms=all('SELECT DISTINCT m.* FROM pokemon_learnset l JOIN pokemon_moves_master m ON m.move_id=l.move_id WHERE l.pokemon_key=?',m.pokemon_key);
  if(!ms.length) ms=all('SELECT DISTINCT m.* FROM pokemon_learnset l JOIN pokemon_moves_master m ON m.move_id=l.move_id WHERE l.pokemon_key=?','S:'+m.species_id);
  const attacks=ms.filter(m=>m.power>0 && ['physical','special'].includes(m.damage_class)).sort((a,b)=>b.power-a.power);
  // 通常戦と同じ効果ルールを持つ変化技は、レイドボスも候補にできる（最大1枠）。
  const statuses=ms.filter(m=>m.damage_class==='status'&&(mkMove(m).rules||[]).length);
  const chosen=statuses.length?[statuses[Math.floor(random()*statuses.length)]]:[];
  const top=attacks.slice(0,5); for(let i=top.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[top[i],top[j]]=[top[j],top[i]];}
  let charged=false;
  for(const m of [...top,...attacks]) {if(chosen.length>=4)break;if(chosen.some(x=>x.move_id===m.move_id)||charged&&recharge.has(m.name_en))continue; chosen.push(m);if(recharge.has(m.name_en))charged=true;}
  const moves=chosen.length?chosen.map(mkMove):wildMoves(m.pokemon_key,cfg.level);
  if(!moves.length)throw Error('ボスの技データがありません');
  const b=E.makeBattler({key:m.pokemon_key,name:m.display_name_ja||m.name_ja,type1:m.type1,type2:m.type2,level:cfg.level,
   hp:st.max_hp*cfg.hp_multiplier,maxHp:st.max_hp*cfg.hp_multiplier,attack:Math.floor(st.attack*cfg.atk_multiplier),defense:Math.floor(st.defense*cfg.def_multiplier),
   sp_attack:Math.floor(st.sp_attack*cfg.spatk_multiplier),sp_defense:Math.floor(st.sp_defense*cfg.spdef_multiplier),speed:Math.floor(st.speed*cfg.speed_multiplier),moves,img:monImg(m,false)});
  b.raidBoss=true; return {b,master:m,category:cat};
 }
 function snapshot(r) {return {boss:E.pub(r.boss),players:r.players.map(p=>({uid:p.uid,name:p.name,npc:!!p.npc,active:p.active,mon:p.party[p.active]?E.pub(p.party[p.active]):null}))};}
 function animation(r,kind,before,events) {
  r.animationSeq=(r.animationSeq||0)+1;
  const batch={seq:r.animationSeq,turn:r.turn,kind,before,after:snapshot(r),events};
  r.timeline=[...(r.timeline||[]),batch].slice(-12);
 }
 function view(r,u) {
  const me=player(r,u);
  return {id:r.id,host:r.host,phase:r.phase,rank:r.rank,requiredPlayers:r.requiredPlayers||3,version:r.version,turn:r.turn,deadline:r.deadline,boss:E.pub(r.boss),logs:r.logs||[],animationSeq:r.animationSeq||0,timeline:r.timeline||[],
   players:r.players.map(p=>({uid:p.uid,name:p.name,npc:!!p.npc,ready:!!p.party.length,chosen:p.choice!==null,active:p.active,balls:p.balls,caught:p.caught,done:p.done,
    party:p.party.map(E.pub),...(p.uid===String(u)?{moves:p.party[p.active]?.moves.map(E.mPub)||[]}:{} )})),me:me?.uid||null};
 }
 function list(g,u) {
  sweep();return {requiredPlayers,ranks:ranks(),room:current(g,u)?view(current(g,u),u):null,rooms:[...rooms.values()].filter(r=>r.guild===String(g)&&r.phase==='lobby').map(r=>({id:r.id,host:r.players[0].name,rank:r.rank,boss:r.boss.name,requiredPlayers:r.requiredPlayers||3,count:r.players.length}))};
 }
 function makePlayer(u,name) {return {uid:String(u),name:String(name||'プレイヤー').slice(0,32),party:[],active:0,choice:null,balls:0,caught:0,done:false};}
 function createRoom(g,u,name,rank) {
  sweep(); rank=Number(rank);
  if(busy(u)||hasActiveBattle(String(u)))return {error:'すでにバトル・レイドに参加しています'};
  if(!ranks().some(r=>r.id===rank))return {error:'このランクは選べません'};
  try {
   const b=boss(rank),r={id:randomUUID(),guild:String(g),host:String(u),requiredPlayers,rank,boss:b.b,master:b.master,category:b.category,phase:'lobby',players:[makePlayer(u,name)],version:1,turn:1,deadline:clock()+600000,logs:[]};
   save(r);rooms.set(r.id,r);return {room:view(r,u)};
  } catch(e){return {error:e.message};}
 }
 function capture(r,p) {
  if(p.done||p.balls<=0)throw Error('捕獲チャレンジは終了しています');
  p.balls--;
  const success=random()<E.captureChance(r.boss.maxHp,1,r.master.capture_rate,'raid-ball');
  if(success) {
   const m=r.master, G=BigInt(r.guild),U=BigInt(p.uid),iv=Object.fromEntries(['hp','attack','defense','sp_attack','sp_defense','speed'].map(k=>[k,rnd(1,31)])),nature=P.randomNature(random),st=E.calcStats(m,1,iv,{},nature.key);
   const abilities=['ability1','ability2','hidden_ability'].filter(k=>m[k+'_en']);const ab=abilities.length?abilities[Math.floor(random()*abilities.length)]:null;
   const vals={guild_id:G,user_id:U,pokemon_key:m.pokemon_key,species_id:m.species_id,level:1,exp:0,gender:E.pickGender(m.gender_rate,m.gender_lock),is_shiny:0,hp:st.max_hp,max_hp:st.max_hp,
    attack:st.attack,defense:st.defense,sp_attack:st.sp_attack,sp_defense:st.sp_defense,speed:st.speed,...Object.fromEntries(Object.entries(iv).map(([k,v])=>['iv_'+k,v])),
    image_url:m.image_url,obtained_type:'raid_capture',caught_at:Math.floor(clock()/1000),ability_en:ab?m[ab+'_en']:null,ability_ja:ab?m[ab+'_ja']:null,nature_key:nature.key,nature_name_ja:nature.ja,original_trainer_id:String(p.uid),original_trainer_name:p.name,origin_region:'レイド',ribbons_json:JSON.stringify(['レイド制覇リボン'])};
   const ownCols=new Set(all('PRAGMA table_info(user_pokemon_owned)').map(x=>x.name)),keys=Object.keys(vals).filter(k=>ownCols.has(k)),id=run(`INSERT INTO user_pokemon_owned (${keys.join(',')}) VALUES (${keys.map(()=>'?').join(',')})`,...keys.map(k=>vals[k])).lastInsertRowid;
   const moveCols=new Set(all('PRAGMA table_info(owned_pokemon_moves)').map(x=>x.name));wildMoves(m.pokemon_key,1).slice(0,4).forEach((mv,i)=>{if(moveCols.has('active'))run('INSERT INTO owned_pokemon_moves (owned_id,slot,move_id,active,current_pp,max_pp) VALUES (?,?,?,1,?,?)',id,i+1,mv.id,mv.maxpp||mv.pp,mv.maxpp||mv.pp);else run('INSERT INTO owned_pokemon_moves (owned_id,slot,move_id) VALUES (?,?,?)',id,i+1,mv.id)});
   run(`INSERT INTO user_pokedex (guild_id,user_id,pokemon_key,species_id,seen_count,caught_count,normal_caught,shiny_caught,first_seen_at,first_caught_at) VALUES (?,?,?,?,1,1,1,0,?,?) ON CONFLICT(guild_id,user_id,pokemon_key) DO UPDATE SET seen_count=seen_count+1,caught_count=caught_count+1,normal_caught=normal_caught+1,first_caught_at=COALESCE(first_caught_at,excluded.first_caught_at)`,G,U,m.pokemon_key,m.species_id,vals.caught_at,vals.caught_at);
   p.caught++;p.lastCapture={success:true,ownedId:String(id)};
  }else p.lastCapture={success:false};
  if(!p.balls)p.done=true;
  r.logs=[{msg:success?`${p.name}は${r.boss.name}を捕まえた！`:`${p.name}のボールから逃げ出した！`}];
  if(r.players.every(p=>p.done))r.phase='finished';
 }
 function action(g,u,name,b) {
  sweep(); const old=rooms.get(String(b.id));
  if(!old||old.guild!==String(g))return {error:'レイドが見つかりません'};
  if(b.type==='status')return {room:view(old,u)};
  if(!LIVE.has(old.phase))return {error:'このレイドは終了しました',room:view(old,u)};
  if(!Number.isSafeInteger(b.version)||b.version!==old.version)return {error:'状況が更新されました。確認してもう一度操作してください',room:view(old,u)};
  const r=structuredClone(old); let p=player(r,u);
  try {
   tx(()=>{
    if(b.type==='join') {
     if(r.phase!=='lobby'||p||r.players.length>=(r.requiredPlayers||3))throw Error('参加できません');
     if(busy(u)||hasActiveBattle(String(u)))throw Error('すでにバトル中です');
     r.players.push(makePlayer(u,name));p=player(r,u);
    } else {
     if(!p)throw Error('このレイドの参加者ではありません');
     if(b.type==='leave') {
      if(r.phase==='lobby') {if(r.host===String(u))r.phase='cancelled';else r.players=r.players.filter(p=>p.uid!==String(u));}
      else if(r.phase==='capture') {p.done=true;if(r.players.every(p=>p.done))r.phase='finished';}
      else {p.party.forEach(b=>b.hp=0);p.active=p.party.length;p.choice=null;if(r.requiredPlayers===1)r.phase='cancelled';}
     } else if(b.type==='party') {
      if(r.phase!=='lobby')throw Error('チームは募集中のみ変更できます');
      const L=loadParty(BigInt(g),BigInt(u),Number(b.groupId));if(L.error)throw Error(L.error);
      if(!L.party.length||L.party.length>6)throw Error('チームは1〜6体です');
      p.party=L.party;p.active=0;
     } else if(b.type==='start') {
      if(r.phase!=='lobby'||r.host!==String(u))throw Error('開始できるのは募集者だけです');
      if(r.players.length!==(r.requiredPlayers||3)||r.players.some(p=>!p.party.length))throw Error(`${r.requiredPlayers||3}人全員のチーム選択が必要です`);
      // 募集中のDB変更・牧場預け入れを再検証する。
      for(const p of r.players) {for(const mon of p.party) {
       if(!one('SELECT 1 FROM user_pokemon_owned WHERE owned_id=? AND guild_id=? AND user_id=?',mon.id,BigInt(g),BigInt(p.uid)))throw Error('チームのポケモンが変更されています');
       if(one('SELECT 1 FROM user_pokemon_farm_deposits WHERE owned_id=?',mon.id))throw Error('牧場のポケモンは参加できません');
      }}
      const payer=takeTicket(g,r.players);if(!payer)throw Error('参加者の誰もレイドチケットを持っていません');r.ticketPayer={uid:payer.uid,name:payer.name};
      if(r.requiredPlayers===1) {
       for(let i=1;i<=2;i++) {
        const npc=makePlayer('test-npc-'+i,'テストNPC '+i);npc.npc=true;npc.party=structuredClone(p.party);
        // NPCは所持個体のコピーで演出・連携を確認する。DBへの保存や報酬は発生しない。
        const offset=i%p.party.length;npc.party=[...npc.party.slice(offset),...npc.party.slice(0,offset)];
        r.players.push(npc);
       }
      }
      r.phase='battle';const before=snapshot(r);r.logs=[{t:'item',msg:`${r.ticketPayer.name}のレイドチケットを1枚使った！`},...engine.init(r)];animation(r,'intro',before,r.logs);r.deadline=clock()+120000;
     } else if(b.type==='move') {
      if(r.phase!=='battle')throw Error('技を選択できません');
      if(b.turn!==r.turn)throw Error('ターンが更新されました');
      const mon=p.party[p.active];if(!mon||mon.hp<=0||p.choice!==null)throw Error('選択済み、または全滅しています');
      if(!Number.isInteger(b.idx)||!mon.moves[b.idx]||mon.moves[b.idx].pp<=0 && mon.moves.some(m=>m.pp>0))throw Error('この技は使えません');
      p.choice=b.idx;
     } else if(b.type==='capture') {if(r.phase!=='capture')throw Error('捕獲できません');const before=snapshot(r);capture(r,p);animation(r,'capture',before,[{t:'ball',side:'p',actor:p.uid,target:'boss',uid:p.uid,ball:'raid-ball',msg:`${p.name}はレイドボールを投げた！`},{t:'shake',n:p.lastCapture.success?3:1,actor:p.uid,target:'boss',uid:'boss'},{t:p.lastCapture.success?'caught':'broke',actor:p.uid,target:'boss',uid:'boss',msg:p.lastCapture.success?`${r.boss.name}を捕まえた！`:'ボールから逃げ出した！'}]);}
     else throw Error('不明な操作です');
    }
    if(r.phase==='battle') {
     for(const npc of r.players.filter(p=>p.npc)) {
      const mon=npc.party[npc.active];if(mon?.hp>0&&npc.choice===null) {
       const moves=mon.moves.map((m,i)=>({m,i})).filter(x=>x.m.pp>0);
       npc.choice=moves.length?moves[Math.floor(random()*moves.length)].i:0;
      }
     }
     const alive=r.players.filter(p=>p.party[p.active]?.hp>0);
     if(!alive.length) {r.phase='lost';r.logs=[{msg:'全員のポケモンが倒れた……'}];}
     else if(alive.every(p=>p.choice!==null)) {
      const before=snapshot(r);r.logs=engine.turn(r);for(const x of r.players.filter(x=>!x.npc))persistParty?.({party:x.party});animation(r,'turn',before,r.logs);r.turn++;r.deadline=clock()+120000;
      if(r.boss.hp<=0){r.phase='capture';r.deadline=clock()+180000;for(const p of r.players){p.balls=p.npc?0:rnd(1,RANKS[r.rank].ball_count);p.done=!!p.npc;}r.logs.push({msg:'ボスを撃破！各自のレイドボールで捕獲に挑戦できます。'});}
      else if(!r.players.some(p=>p.party[p.active]?.hp>0))r.phase='lost';
     }
    }
    r.version++;save(r);
   });
   rooms.set(r.id,r);return {room:view(r,u),...(p?.lastCapture&&b.type==='capture'?{capture:p.lastCapture}:{})};
  } catch(e){return {error:e.message,room:view(old,u)};}
 }
 return {list,createRoom,action,busy,sweep};
}
module.exports={create};
